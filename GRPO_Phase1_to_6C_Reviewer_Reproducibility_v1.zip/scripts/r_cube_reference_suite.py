"""Run the REAL CRAN BalancedSampling::cube on multiple independent cases.

Requires Rscript and installed BalancedSampling in the R library path.
Monte Carlo R moments are explicitly marked empirical, not exact inclusions.
"""

import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from time import perf_counter

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from phase2_grpo.balanced import imbalance_squared
from phase2_grpo.classic_cube import cube_full_flight_landing
from phase2_grpo.design import uniform_design
from phase2_grpo.r_cube_bridge import reference_available


def _cases():
    rng=np.random.default_rng(20261105)
    return [
        ("equal_six_random",np.full(6,.5),rng.normal(size=(3,6))),
        ("unequal_seven",np.array([.15,.25,.30,.45,.55,.75,.55]),
         rng.normal(size=(2,7))),
        ("feasible_exact_balance",np.full(4,.5),
         np.array([[1.,-1.,1.,-1.]])),
        ("redundant_auxiliaries",np.full(8,.5),
         np.stack((np.linspace(-1,1,8),np.linspace(-1,1,8),
                   np.ones(8)))),
        ("anisotropic_marginals",np.array([.25,.35,.45,.55,.65,.75]),
         rng.normal(size=(4,6))),
    ]


def _risk_by_samples(samples, pi, scores, v):
    # Treat each R random subset as a literal sampled acquisition design;
    # use known prescribed pi in its HT gradient covariance calculation.
    from phase2_grpo.geometry import gradient_map
    m=gradient_map(scores)
    a=samples/pi[None,:]-1
    k=m.T@m
    risk=np.einsum("ni,ij,nj->n",a,k*v,a,optimize=True)
    return risk


def run_suite(outdir:Path,draws:int=5000,seed:int=81)->dict:
    if not reference_available():
        raise RuntimeError("actual Rscript + CRAN BalancedSampling::cube are mandatory")
    if draws<500:
        raise ValueError("need at least 500 R draws per case")
    outdir.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(20261106)
    cases=[]
    for case_idx,(label,pi,aux) in enumerate(_cases()):
        budget=int(np.rint(pi.sum()))
        py,diag=cube_full_flight_landing(pi,budget,aux)
        baseline=uniform_design(len(pi),budget) if np.ptp(pi)<1e-12 else None
        scores=rng.normal(size=(3,len(pi)))
        raw=rng.normal(size=(len(pi),len(pi)))
        v=raw@raw.T/len(pi)+.3*np.eye(len(pi))
        start=perf_counter()
        with tempfile.TemporaryDirectory(prefix="actual_r_cube_") as temp:
            data=Path(temp)/"data.csv"
            samples_file=Path(temp)/"draws.csv"
            np.savetxt(data,np.column_stack((pi,pi,aux.T)),delimiter=",",fmt="%.17g")
            run=subprocess.run(["Rscript",str(ROOT/"scripts"/"r_cube_reference_audit.R"),
                                str(data),str(samples_file),str(draws),str(seed+case_idx)],
                               capture_output=True,text=True,check=False,timeout=300)
            if run.returncode:
                raise RuntimeError("real R cube returned failure: "+run.stderr[-1400:])
            z=np.loadtxt(samples_file,delimiter=",",dtype=np.int8,ndmin=2)
        elapsed=perf_counter()-start
        if z.shape!=(draws,len(pi)) or not np.all(z.sum(axis=1)==budget):
            raise AssertionError("R cube broke exact sample size")
        if not np.all((z==0)|(z==1)):
            raise AssertionError("R cube produced a nonindicator")
        empirical_pi=z.mean(axis=0)
        errors=np.abs(empirical_pi-pi)
        empirical_se=np.sqrt(pi*(1-pi)/draws)
        # A conservative numeric smoke check, not multiple-testing-calibrated.
        if np.max(errors/(empirical_se+1e-10))>6:
            raise AssertionError("R empirical marginal far outside Monte Carlo range")
        losses=imbalance_squared(z,pi,aux)
        py_losses=imbalance_squared(py.subsets,pi,aux)
        # These are conditional quadratic risks for a chosen *synthetic* V;
        # use q_R empirical for diagnostic comparison only, never as exact.
        r_risk=_risk_by_samples(z,pi,scores,v)
        p_risk=_risk_by_samples(py.subsets,pi,scores,v)
        comparison={"case":label,"G":len(pi),"B":budget,"R_draws":draws,
             "R_backend":"CRAN BalancedSampling 2.1.1 cube",
             "actual_R_executed":True,"R_sample_sizes_all_exact":True,
             "R_empirical_pi":empirical_pi.tolist(),
             "target_pi":pi.tolist(),"R_max_marginal_error":float(errors.max()),
             "R_max_marginal_zscore":float(np.max(errors/(empirical_se+1e-10))),
             "Python_exact_max_marginal_error":diag.largest_marginal_error,
             "R_empirical_mean_aux_balance":float(losses.mean()),
             "R_balance_MC_se":float(losses.std(ddof=1)/np.sqrt(draws)),
             "Python_exact_mean_aux_balance":float(py.probs@py_losses),
             "R_empirical_conditional_gradient_risk":float(r_risk.mean()),
             "R_gradient_risk_MC_se":float(r_risk.std(ddof=1)/np.sqrt(draws)),
             "Python_exact_conditional_gradient_risk":float(py.probs@p_risk),
             "uniform_reference_balance":(
                  float(baseline.probs@imbalance_squared(baseline.subsets,pi,aux))
                  if baseline is not None else None),
             "R_runtime_seconds_including_process":elapsed,
             "interpretation":"R inclusion/risk Monte Carlo; Python full-flight/landing exact; no distributional identity claimed"}
        # Store the R samples themselves, so the MC estimates are auditable.
        np.savetxt(outdir/f"R_actual_draws_{label}.csv",z,fmt="%d",delimiter=",")
        cases.append(comparison)
    result={"title":"Actual independent CRAN cube cross-implementation suite",
            "draws_per_case":draws,"cases":cases,"reference_seed":seed,
            "R_draws_total":draws*len(cases),
            "methods":"R BalancedSampling::cube vs independent Python finite-tree flight/landing",
            "scope":"static sampling algorithm verification, not proof of LLM benefit"}
    (outdir/"R_reference_suite.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--draws",type=int,default=5000)
    parser.add_argument("--seed",type=int,default=81)
    parser.add_argument("--output",type=Path,default=ROOT/"results"/"phase4_real_R_cube")
    args=parser.parse_args()
    report=run_suite(args.output,args.draws,args.seed)
    print(json.dumps({"R_draws_total":report["R_draws_total"],
          "cases":[{"case":r["case"],"R_max_pi_error":r["R_max_marginal_error"],
                    "R_balance":r["R_empirical_mean_aux_balance"],
                    "Python_exact_balance":r["Python_exact_mean_aux_balance"]}
                   for r in report["cases"]]},indent=2))
