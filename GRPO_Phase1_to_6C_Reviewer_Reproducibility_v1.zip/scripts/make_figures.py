"""Render only actually executed results; figures are exploratory diagnostics."""

import csv
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    base = Path(__file__).resolve().parents[1] / "results"
    rows = list(csv.DictReader((base / "full" / "design_grid.csv").open()))
    train = list(csv.DictReader((base / "full" / "toy_training.csv").open()))
    output = base / "figures"
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "savefig.dpi": 170})

    fig, ax = plt.subplots(figsize=(7.1, 3.4))
    rho_values = [.0,.4,.8]
    oracle, practical = [], []
    for rho in rho_values:
        filtered = [r for r in rows if float(r["rho"]) == rho
                    and int(r["B"]) not in (1,int(r["G"])-1)]
        oracle.append(float(np.mean([float(r["oracle_gain"]) for r in filtered])))
        practical.append(float(np.mean([float(r["practical_gain"]) for r in filtered])))
    x = np.arange(3)
    ax.bar(x - .18, oracle, width=.35, color="#2a6f97", label="Oracle LP (upper benchmark)")
    ax.bar(x + .18, practical, width=.35, color="#e6a23c", label="Pilot-estimated LP")
    ax.axhline(0, color="#666", lw=.8)
    ax.set_xticks(x, [str(v) for v in rho_values])
    ax.set_xlabel("Residual exchangeable correlation parameter")
    ax.set_ylabel("Mean absolute query-risk reduction")
    ax.set_title("Interior budgets only; synthetic score geometries")
    ax.legend(frameon=False, ncol=2, fontsize=8)
    fig.tight_layout()
    fig.savefig(output / "controlled_coupling.png")
    plt.close(fig)

    byseed = {}
    for r in train:
        byseed.setdefault(int(r["seed"]), {})[r["method"]] = float(r["final_expected_reward"])
    seeds = sorted(byseed)
    delta = [byseed[s]["joint"]-byseed[s]["uniform"] for s in seeds]
    fig, ax = plt.subplots(figsize=(7.1, 3.0))
    ax.bar([str(s) for s in seeds], delta,
           color=["#4c956c" if d >= 0 else "#bd5b53" for d in delta])
    ax.axhline(0, color="black", lw=.85)
    ax.set_xlabel("Paired simulation seed")
    ax.set_ylabel("Joint minus uniform expected reward")
    ax.set_title("Tiny toy on-policy training; descriptive only (n = 6 seeds)")
    fig.tight_layout()
    fig.savefig(output / "toy_training_differences.png")
    plt.close(fig)
    print("Created", output / "controlled_coupling.png", "and", output / "toy_training_differences.png")


if __name__ == "__main__":
    main()

