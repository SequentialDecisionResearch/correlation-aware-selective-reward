"""Once-only Phase-4 calibration + independent frozen holdout evaluation."""

import argparse
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from phase2_grpo.holdout_study import run_holdout


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--quick",action="store_true",
                   help="smoke checks only; not independent scientific evidence")
    p.add_argument("--output",type=Path,
                   default=ROOT/"results"/"phase4_frozen_holdout_full")
    args=p.parse_args()
    s=run_holdout(args.output,quick=args.quick)
    print(json.dumps({k:v for k,v in s.items() if k not in (
        "strata","guard_detector","model_parameters_frozen_from_phase3")},indent=2))
