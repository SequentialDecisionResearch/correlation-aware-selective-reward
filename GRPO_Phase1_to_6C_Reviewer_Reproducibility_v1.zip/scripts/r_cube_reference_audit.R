# Independent reference experiment; actual CRAN BalancedSampling::cube.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 4L) stop("need input.csv output.csv draws seed")
if (!requireNamespace("BalancedSampling",quietly=TRUE)) {
  stop("R package BalancedSampling is not installed")
}
d <- as.matrix(utils::read.csv(args[1],header=FALSE))
pi <- as.numeric(d[,1])
x <- as.matrix(d[,-1,drop=FALSE])
if (max(abs(x[,1]-pi))>1e-9) stop("first balancing variable must equal pi")
n <- as.integer(args[3]); if (n<10L) stop("draws must be >=10")
set.seed(as.integer(args[4]))
samples <- matrix(0L,nrow=n,ncol=length(pi))
for (k in seq_len(n)) {
  chosen <- BalancedSampling::cube(pi,x)
  samples[k,chosen] <- 1L
}
utils::write.table(samples,file=args[2],sep=",",row.names=FALSE,
                   col.names=FALSE,quote=FALSE)
