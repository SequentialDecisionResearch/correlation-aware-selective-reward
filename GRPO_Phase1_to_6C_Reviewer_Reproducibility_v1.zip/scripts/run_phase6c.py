"""Actual LoRA parameter-update training with budgeted group rewards."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))

from phase2_grpo.phase6c_objectives import ARMS, OBJECTIVES, Phase6CConfig
from phase2_grpo.phase6c_training import run


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",required=True)
    p.add_argument("--stage",choices=("all","train","summary","audit"),default="all")
    p.add_argument("--arms",nargs="+",choices=ARMS,default=list(ARMS))
    p.add_argument("--objective",choices=OBJECTIVES,default="loo_ht")
    p.add_argument("--steps",type=int,default=60)
    p.add_argument("--seed",type=int,default=6207)
    p.add_argument("--warmup",type=int,default=12)
    p.add_argument("--window",type=int,default=9)
    p.add_argument("--max-new-tokens",type=int,default=64)
    p.add_argument("--update-epochs",type=int,default=1)
    p.add_argument("--clip-epsilon",type=float,default=.20)
    p.add_argument("--learning-rate",type=float,default=1e-5)
    p.add_argument("--lora-rank",type=int,default=8)
    p.add_argument("--lora-alpha",type=int,default=16)
    p.add_argument("--eval-every",type=int,default=10)
    p.add_argument("--eval-size",type=int,default=24)
    p.add_argument("--train-schedule",choices=("easy_to_hard","interleaved"),
                   default="easy_to_hard")
    p.add_argument("--model",default="Qwen/Qwen2.5-0.5B-Instruct")
    p.add_argument("--model-revision",default="main")
    p.add_argument("--device",default="cuda")
    p.add_argument("--local-files-only",action="store_true")
    p.add_argument("--max-new-steps",type=int,
                   help="commit at most this many new optimizer steps across selected arms")
    a=p.parse_args()
    cfg=Phase6CConfig(steps=a.steps,seed=a.seed,warmup=a.warmup,window=a.window,
           max_new_tokens=a.max_new_tokens,objective=a.objective,
           update_epochs=a.update_epochs,clip_epsilon=a.clip_epsilon,
           learning_rate=a.learning_rate,lora_rank=a.lora_rank,
           lora_alpha=a.lora_alpha,eval_every=a.eval_every,eval_size=a.eval_size,
           train_schedule=a.train_schedule,
           model=a.model,model_revision=a.model_revision,device=a.device,
           local_files_only=a.local_files_only)
    def progress(arm,step,total):
        print(f"COMMITTED REAL LoRA [{arm}] optimizer step {step}/{total}",flush=True)
    print("WARNING: objective=loo_ht is a GRPO-family LOO estimator, not canonical normalized TRL GRPO; normalized_plugin is biased under partial observation.",flush=True)
    result=run(cfg,a.output,arms=tuple(a.arms),stage=a.stage,
               max_new_steps=a.max_new_steps,progress=progress)
    print(json.dumps(result,indent=2),flush=True)


if __name__=="__main__":
    main()
