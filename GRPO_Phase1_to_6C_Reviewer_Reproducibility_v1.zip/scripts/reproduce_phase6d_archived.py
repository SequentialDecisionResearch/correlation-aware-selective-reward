"""CPU-only replay of the archived Phase 6D conditional LoRA-gradient risks.

This tool verifies saved six-by-six autograd Gram matrices as *records*, their
cryptographic envelopes, all 20-subset probability laws, the exact HT risks,
and the published CSV and JSON aggregates. It does not recompute GPU autograd
or verify that the saved Grams came from the stated model weights.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from phase2_grpo.design import ExactBDesign  # noqa: E402
from phase2_grpo.phase6a_checkpoint import digest  # noqa: E402
from phase2_grpo.phase6d_gradient_risk import evaluate_fixed_designs  # noqa: E402


def require(test: bool, message: str) -> None:
    if not test:
        raise RuntimeError(message)


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def approx(a: float, b: float, *, rtol: float = 2e-7,
           atol: float = 2e-11) -> bool:
    return math.isclose(float(a), float(b), rel_tol=rtol, abs_tol=atol)


def compare_rows(observed: dict, expected: dict, label: str) -> None:
    require(set(observed) == set(expected), f"CSV columns differ: {label}")
    numeric = {
        "design_pair_gap", "real_uniform_risk", "real_joint_ewma_risk",
        "real_gain", "sketch_uniform_risk", "sketch_joint_ewma_risk",
        "sketch_gain", "centered_gram_alignment",
    }
    for key, value in expected.items():
        actual = observed[key]
        if key in numeric and value is not None:
            require(actual not in ("", None) and approx(float(actual), value),
                    f"CSV mismatch {label}: {key}")
        elif key in numeric:
            require(actual == "", f"missing-value mismatch {label}: {key}")
        else:
            require(str(value) == actual, f"CSV mismatch {label}: {key}")


def replay(data_dir: Path) -> dict:
    data_dir = data_dir.resolve()
    manifest = json.loads((data_dir / "phase6d_manifest.json").read_text())
    bank = json.loads((data_dir / "phase6d_task_bank.json").read_text())
    summary = json.loads((data_dir / "phase6d_summary.json").read_text())
    require(manifest["protocol"] == bank["protocol"] == summary["protocol"],
            "Phase 6D protocol mismatch")
    require(manifest["task_bank_sha256"] == digest(bank), "task bank hash mismatch")
    require(summary["complete"], "summary is incomplete")

    # Original Phase 6C JSON evidence is included in the lightweight archive;
    # its training states were deliberately excluded. Do not follow absolute
    # source-Windows paths present in the original immutable manifest.
    for source in manifest["runs"]:
        seed = int(source["seed"])
        original = REPO / "results" / f"phase6c_cal2_seed{seed}"
        for filename, key in (("phase6c_summary.json", "summary_sha256"),
                              ("phase6c_audit.json", "audit_sha256")):
            require(sha_file(original / filename) == source[key],
                    f"original Phase 6C file hash differs: {seed}/{filename}")
        for arm, expected in source["arm_manifest_sha256"].items():
            require(sha_file(original / "arms" / arm / "manifest.json") == expected,
                    f"original arm manifest hash differs: {seed}/{arm}")

    expected_keys = set()
    for run in manifest["runs"]:
        seed = int(run["seed"])
        for arm in manifest["source_arms"]:
            for snapshot in manifest["snapshots"]:
                for idx in range(len(bank["tasks_by_seed"][str(seed)])):
                    expected_keys.add((seed, arm, int(snapshot), idx))

    rebuilt_rows = {}
    paths = sorted((data_dir / "groups").rglob("group_*.json"))
    for path in paths:
        record = json.loads(path.read_text())
        saved_sha = record.pop("sha256", None)
        require(saved_sha == digest(record), f"group record SHA mismatch: {path}")
        seed, arm = int(record["seed"]), record["source_arm"]
        step, idx = int(record["snapshot"]), int(record["group_index"])
        key = (seed, arm, step, idx)
        require(key in expected_keys and key not in rebuilt_rows,
                f"extra or duplicated group: {key}")
        require(record["protocol"] == manifest["protocol"], f"protocol mismatch: {key}")
        require(record["task_bank_sha256"] == manifest["task_bank_sha256"],
                f"task hash mismatch: {key}")
        require(record["task"] == bank["tasks_by_seed"][str(seed)][idx],
                f"task mismatch: {key}")
        require(record["source_state_sha256"] ==
                manifest["source_states_sha256"][f"{seed}:{arm}:{step}"],
                f"source state provenance mismatch: {key}")
        require(record["current_gold_hidden_at_proposal"] is True,
                f"missing ex-ante acquisition declaration: {key}")

        design = {}
        for label in ("uniform", "joint_ewma"):
            entry = record["designs"][label]
            design[label] = ExactBDesign(np.asarray(entry["subsets"]),
                                         np.asarray(entry["probs"]), label)
            require(design[label].G == 6 and design[label].B == 3 and
                    len(design[label].probs) == 20 and
                    np.max(abs(design[label].marginals - 0.5)) < 1e-8,
                    f"invalid fixed-budget design: {key}/{label}")

        rewards = np.asarray(record["rewards"], dtype=float)
        scores = np.asarray(record["generated"]["score_features"], dtype=float)
        gram = np.asarray(record["real_completion_gradient_gram"], dtype=float)
        rebuilt = evaluate_fixed_designs(gram, scores, rewards,
                                         design["uniform"], design["joint_ewma"])
        for geometry in ("real_lora", "phase6b_sketch"):
            for label in ("uniform", "joint_ewma"):
                a = rebuilt["risks"][geometry][label]["risk"]
                b = record["risk_result"]["risks"][geometry][label]["risk"]
                require(approx(a, b), f"risk replay mismatch: {key}/{geometry}/{label}")

        true = rebuilt["risks"]["real_lora"]
        sketch = rebuilt["risks"]["phase6b_sketch"]
        pair_gap = float(np.max(abs(
            design["uniform"].pair_inclusions -
            design["joint_ewma"].pair_inclusions)))
        npos = int(sum(rewards))
        row = {
            "seed": seed, "source_arm": arm, "snapshot": step,
            "group_index": idx, "family": record["task"]["family"],
            "positive_rewards": npos, "mixed_reward_group": int(0 < npos < 6),
            "design_pair_gap": pair_gap,
            "real_uniform_risk": true["uniform"]["risk"],
            "real_joint_ewma_risk": true["joint_ewma"]["risk"],
            "real_gain": true["gain_uniform_minus_joint"],
            "sketch_uniform_risk": sketch["uniform"]["risk"],
            "sketch_joint_ewma_risk": sketch["joint_ewma"]["risk"],
            "sketch_gain": sketch["gain_uniform_minus_joint"],
            "sketch_predicted_positive_true_negative": int(
                sketch["gain_uniform_minus_joint"] > 1e-12 and
                true["gain_uniform_minus_joint"] < -1e-12),
            "true_positive_sketch_predicted_negative": int(
                true["gain_uniform_minus_joint"] > 1e-12 and
                sketch["gain_uniform_minus_joint"] < -1e-12),
            "centered_gram_alignment": rebuilt["alignment"]["centered_gram_alignment"],
        }
        rebuilt_rows[key] = row

    require(set(rebuilt_rows) == expected_keys, "missing Phase 6D groups")
    csv_path = data_dir / "phase6d_group_risk_comparison.csv"
    with csv_path.open(newline="", encoding="utf-8-sig") as stream:
        archived_rows = list(csv.DictReader(stream))
    require(len(archived_rows) == len(expected_keys), "CSV length mismatch")
    seen = set()
    for row in archived_rows:
        key = (int(row["seed"]), row["source_arm"],
               int(row["snapshot"]), int(row["group_index"]))
        require(key in rebuilt_rows and key not in seen, f"CSV duplicate: {key}")
        seen.add(key)
        compare_rows(row, rebuilt_rows[key], str(key))

    require(summary["expected"] == len(expected_keys) ==
            summary["checked_groups"], "report group-count mismatch")
    require(len(summary["strata"]) == 12, "report stratum-count mismatch")
    for name, stratum in summary["strata"].items():
        family, arm, step_name = name.split("/")
        snapshot = int(step_name.removeprefix("checkpoint"))
        for summary_seed in stratum["per_seed"]:
            seed = int(summary_seed["seed"])
            sample = [r for r in rebuilt_rows.values() if
                      (r["family"], r["source_arm"], r["snapshot"], r["seed"]) ==
                      (family, arm, snapshot, seed)]
            require(len(sample) == summary_seed["groups"] == 4,
                    f"summary stratum group count: {name}/{seed}")
            for key, base, delta in (("true_relative_risk_gain",
                                      "real_uniform_risk", "real_gain"),
                                     ("sketch_relative_risk_gain",
                                      "sketch_uniform_risk", "sketch_gain")):
                denominator = sum(r[base] for r in sample)
                actual = sum(r[delta] for r in sample)/denominator \
                    if denominator > 1e-18 else None
                published = summary_seed[key]
                require((actual is None and published is None) or
                        (actual is not None and published is not None and
                         approx(actual, published)),
                        f"summary risk ratio: {name}/{seed}/{key}")

    post = [r for r in rebuilt_rows.values() if r["snapshot"] in (30, 60)]

    def reduction(rows: list[dict], prefix: str) -> float:
        baseline = sum(r[f"{prefix}_uniform_risk"] for r in rows)
        return (baseline - sum(r[f"{prefix}_joint_ewma_risk"] for r in rows))/baseline

    def risk_sign(gain: float, base: float) -> int:
        threshold = 1e-8 * max(base, 1e-12)
        return (gain > threshold) - (gain < -threshold)

    signs = [(risk_sign(r["real_gain"], r["real_uniform_risk"]),
              risk_sign(r["sketch_gain"], r["sketch_uniform_risk"]))
             for r in post]
    result = {
        "status": "VERIFIED_FROM_ARCHIVED_GRAMS",
        "archived_groups_checked": len(rebuilt_rows),
        "nonuniform_later_design_groups": sum(r["design_pair_gap"] > 1e-8
                                               for r in post),
        "later_real_risk_reduction": reduction(post, "real"),
        "later_sketch_risk_reduction": reduction(post, "sketch"),
        "checkpoint_30_real_risk_reduction": reduction(
            [r for r in post if r["snapshot"] == 30], "real"),
        "checkpoint_60_real_risk_reduction": reduction(
            [r for r in post if r["snapshot"] == 60], "real"),
        "source_arm_real_risk_reduction": {
            arm: reduction([r for r in post if r["source_arm"] == arm], "real")
            for arm in manifest["source_arms"]
        },
        "seed_real_risk_reduction": {
            str(seed): reduction([r for r in post if r["seed"] == seed], "real")
            for seed in (6207, 6219, 6251)
        },
        "later_group_counts": {
            "positive": sum(t == 1 for t, _ in signs),
            "negative": sum(t == -1 for t, _ in signs),
            "tie": sum(t == 0 for t, _ in signs),
            "meaningful_opposite_signs": sum(t*s == -1 for t, s in signs),
        },
        "audit_boundary": "Saved Gram vectors and original Phase6C JSON hashes were checked; GPU autograd and model checkpoint weights were NOT reproduced.",
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path,
                        default=REPO / "results" / "phase6d_gradient_v1")
    args = parser.parse_args()
    print(json.dumps(replay(args.data_dir), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
