"""Reproducible diagnostics from the actual frozen independent holdout CSV."""

import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def figures(data:Path,output:Path):
    trials=data/"holdout_trials.csv"
    summary=json.loads((data/"holdout_summary.json").read_text(encoding="utf-8"))
    if summary.get("quick_smoke_only"):
        raise ValueError("full independent holdout required for the figures")
    scenarios=summary["new_worlds"]
    policies=summary["methods"]
    output.mkdir(parents=True,exist_ok=True)
    means=np.zeros((len(scenarios),len(policies)))
    for i,s in enumerate(scenarios):
        for j,m in enumerate(policies):
            means[i,j]=summary["strata"][f"{s}|later|{m}"]["mean_conditional_gradient_risk"]
    fig,ax=plt.subplots(figsize=(12,6.5),layout="constrained")
    image=ax.imshow(means,aspect="auto",cmap="viridis_r")
    for i in range(len(scenarios)):
        for j in range(len(policies)):
            ax.text(j,i,f"{means[i,j]:.3f}",ha="center",va="center",fontsize=8,
                    color="white" if means[i,j]>.65*means.max() else "black")
    ax.set_xticks(range(len(policies)),policies,rotation=32,ha="right")
    ax.set_yticks(range(len(scenarios)),[x.replace("_"," ") for x in scenarios])
    ax.set_title("Independent frozen holdout: later-half conditional acquisition risk (lower is better)")
    fig.colorbar(image,ax=ax,label="Squared-gradient acquisition risk")
    fig.savefig(output/"phase4_holdout_risk_heatmap.png",dpi=160)
    plt.close(fig)

    fig,ax=plt.subplots(figsize=(11,5.5),layout="constrained")
    compare=["cube_classic","scaled","joint_frozen","drift_gated","guarded_partial"]
    x=np.arange(len(scenarios))
    width=.16
    for j,method in enumerate(compare):
        diffs=[means[i,policies.index("joint_ewma")]-means[i,policies.index(method)]
               for i in range(len(scenarios))]
        ax.bar(x+(j-2)*width,diffs,width=width,label=method)
    ax.axhline(0,color="black",lw=.8)
    ax.set_xticks(x,[s.replace("_","\n") for s in scenarios],fontsize=8)
    ax.set_ylabel("Joint EWMA risk minus alternative risk (positive favors alternative)")
    ax.set_title("An improvement must beat continuously learned covariance, not just uniform")
    ax.legend(ncols=5,loc="upper center",bbox_to_anchor=(.5,-.21),fontsize=9)
    fig.savefig(output/"phase4_paired_risk_differences.png",dpi=160,bbox_inches="tight")
    plt.close(fig)

    fig,ax=plt.subplots(figsize=(10,5),layout="constrained")
    rates=[summary["guard_detector"][s]["any_alarm_fraction"] for s in scenarios]
    false=[summary["guard_detector"][s]["pre_onset_false_alarm_seed_fraction"]
           for s in scenarios]
    ax.bar(x-.19,rates,.38,label="Any guard alarm in run",color="#4477aa")
    ax.bar(x+.19,false,.38,label="Pre-change/false alarm run",color="#cc6677")
    ax.set_xticks(x,[s.replace("_","\n") for s in scenarios],fontsize=8)
    ax.set_ylim(0,1.05)
    ax.set_ylabel("Fraction of held-out independent seeds")
    ax.set_title("Clipped/persistent detector: detections and false alarms")
    ax.legend()
    fig.savefig(output/"phase4_guard_false_alarms.png",dpi=160)
    plt.close(fig)

    # Cross-check that source CSV truly contains precisely one recorded policy
    # decision per scenario/seed/time/policy, not reconstructed figure values.
    observed=set()
    with trials.open(newline="",encoding="utf-8") as inp:
        for row in csv.DictReader(inp):
            key=(row["scenario"],row["seed"],row["step"],row["policy"])
            if key in observed:
                raise AssertionError("duplicate holdout decision key")
            observed.add(key)
    if len(observed)!=summary["rows"]:
        raise AssertionError("holdout count in source CSV/summary disagrees")
    return {"output_files":[str(p) for p in sorted(output.glob("phase4_*.png"))],
            "verified_unique_trials":len(observed)}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input",type=Path,default=Path("results/phase4_frozen_holdout_full"))
    p.add_argument("--output",type=Path,default=Path("results/phase4_figures"))
    args=p.parse_args()
    print(json.dumps(figures(args.input,args.output),indent=2))
