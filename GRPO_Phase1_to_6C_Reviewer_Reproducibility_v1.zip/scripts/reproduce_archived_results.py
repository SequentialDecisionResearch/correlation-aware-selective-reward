"""Verify archived real-Phase6 summaries and redraw descriptive figures.

This is an OFFLINE, read-only replay from saved JSON/CSV and does not claim
to reproduce GPU backward passes or model inference without .pt checkpoints.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import csv
from hashlib import sha256
import json
from pathlib import Path
from statistics import mean


ARMS = ("full", "uniform", "joint_ewma")
SEEDS = (6207, 6219, 6251)
STRESS = ("two_digit_carry_ood", "three_digit_double_carry", "three_term_add")


def read_json(path: Path):
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def read_csv(path: Path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def close(a, b, tolerance=1e-10):
    return abs(float(a) - float(b)) <= tolerance


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def verify(root: Path):
    results = root / "results"
    diagnostics = results / "phase6c_v15_diagnostics"
    calibration = read_json(results / "phase6b_calibration2_v1" / "calibration2_summary.json")
    check(calibration["complete"] and calibration["selected_family"] == "two_digit_add",
          "Phase6B calibration not complete/locked to two_digit_add")
    manifest = read_json(diagnostics / "diagnostic_manifest.json")
    check([int(r["seed"]) for r in manifest["runs"]] == list(SEEDS),
          "diagnostic run seeds differ from the locked manifest")
    for record in manifest["runs"]:
        run = results / f"phase6c_cal2_seed{record['seed']}"
        for kind in ("summary", "audit"):
            path = run / f"phase6c_{kind}.json"
            actual = sha256(path.read_bytes()).hexdigest()
            check(actual == record[f"{kind}_sha256"],
                  f"locked diagnostic hash mismatch: {path}")

    summaries = {}
    for seed in SEEDS:
        run = results / f"phase6c_cal2_seed{seed}"
        summary = read_json(run / "phase6c_summary.json")
        audit = read_json(run / "phase6c_audit.json")
        check(summary["complete"] and summary["genuine_model_updates"],
              f"seed {seed} does not report genuine finished LoRA updates")
        check(audit["pass"] and audit["checked_train_steps"] == 180,
              f"seed {seed} original audit did not report 180 checks")
        check(summary["config"]["seed"] == seed and
              summary["config"]["steps"] == 60 and
              set(summary["progress"]) == set(ARMS),
              f"seed {seed} unexpected run configuration")
        check(all(summary["progress"][arm] == 60 for arm in ARMS),
              f"seed {seed} incomplete training arm")
        summaries[seed] = summary

    aggregate = read_json(results / "phase6c_cal2_multiseed" /
                          "phase6c_multiseed_summary.json")
    check(aggregate["n_seeds"] == 3 and
          aggregate["independent_seed_ids"] == list(SEEDS),
          "aggregate seed list mismatch")
    for name, a, b in (("adaptive_minus_uniform", "joint_ewma", "uniform"),
                       ("adaptive_minus_full", "joint_ewma", "full"),
                       ("uniform_minus_full", "uniform", "full")):
        difference = mean(summaries[s]["final_heldout"][a]["accuracy"] -
                          summaries[s]["final_heldout"][b]["accuracy"]
                          for s in SEEDS)
        check(close(difference, aggregate["paired_accuracy"][name]["mean_delta"]),
              f"aggregate discrepancy: {name}")

    curves = read_csv(diagnostics / "phase6c_checkpoint_learning_curves.csv")
    indexed = {(int(r["seed"]), r["arm"], int(r["step"])):
               float(r["accuracy"]) for r in curves}
    check(len(indexed) == 3 * 3 * 7, "missing or repeated checkpoint accuracy")
    for seed in SEEDS:
        for arm in ARMS:
            old = summaries[seed]["initial_heldout"][arm]["accuracy"]
            new = summaries[seed]["final_heldout"][arm]["accuracy"]
            check(close(indexed[seed, arm, 0], old), "initial heldout mismatch")
            check(close(indexed[seed, arm, 60], new), "final heldout mismatch")
    lc = read_json(diagnostics / "phase6c_learning_curve_stats.json")
    for record in lc["seed_arm"]:
        seed, arm = int(record["seed"]), record["arm"]
        points = [indexed[seed, arm, k] for k in range(0, 61, 10)]
        area = sum((points[i] + points[i + 1]) * 5 for i in range(6)) / 60
        check(close(area, record["auc_accuracy_trapezoid"]),
              f"AULC inconsistency seed={seed} arm={arm}")

    pairs = read_csv(diagnostics / "phase6c_item_pairs.csv")
    items = read_csv(diagnostics / "phase6c_item_predictions.csv")
    check(len(pairs) == 1080 and len(items) == 3240,
          "unexpected number of paired task/prediction records")
    check(all(int(r["ewma_minus_uniform"]) ==
              (int(r["joint_ewma_correct"] == "True") -
               int(r["uniform_correct"] == "True")) for r in pairs),
          "paired item differences cannot be replayed")

    observed = defaultdict(list)
    for r in pairs:
        if r["panel"] == "heldout" and int(r["step"]) == 60:
            for arm in ARMS:
                observed[int(r["seed"]), arm].append(r[f"{arm}_correct"] == "True")
    for seed in SEEDS:
        for arm in ARMS:
            check(len(observed[seed, arm]) == 24, "missing final heldout pairs")
            check(sum(observed[seed, arm]) ==
                  summaries[seed]["final_heldout"][arm]["correct"],
                  "final item correctness disagrees with training summary")

    stress = read_csv(diagnostics / "phase6c_stress_by_seed.csv")
    check(len(stress) == 3 * 3 * 2 * 3,
          "unexpected number of stress seed/arm/step/stratum cells")
    report = read_json(diagnostics / "phase6c_diagnostic_summary.json")
    check(report["status"] == "complete", "stress diagnostic report incomplete")
    final_stress = defaultdict(list)
    for r in stress:
        check(int(r["count"]) == 32 and
              close(int(r["correct"]) / 32, r["accuracy"]),
              "stress count and accuracy disagree")
        if int(r["step"]) == 60:
            final_stress[r["stratum"], r["arm"]].append(float(r["accuracy"]))
    for difficulty in STRESS:
        for arm in ARMS:
            check(close(mean(final_stress[difficulty, arm]),
                        report["stress"][difficulty][arm]["final"]["mean"]),
                  f"stress report mismatch difficulty={difficulty} arm={arm}")
    distances = read_json(diagnostics / "phase6c_adapter_distances.json")
    check(sorted(x["seed"] for x in distances["per_seed"]) == list(SEEDS),
          "missing archived parameter-distance records")

    return {
        "mode": "archived_results_CPU_only",
        "status": "verified",
        "calibration": "two_digit_add (Phase6B locked)",
        "seeds": list(SEEDS),
        "archive_contains_optimizer_or_lora_states": False,
        "gpu_backward_or_inference_reexecuted": False,
        "original_training_audit": "archived PASS and hash-verified, not independently GPU-reexecuted",
        "final_accuracy_by_seed": {
            str(s): {a: summaries[s]["final_heldout"][a]["accuracy"] for a in ARMS}
            for s in SEEDS
        },
        "paired_accuracy_mean": {
            k: aggregate["paired_accuracy"][k]["mean_delta"]
            for k in ("adaptive_minus_uniform", "adaptive_minus_full", "uniform_minus_full")
        },
        "archived_item_prediction_rows": len(items),
        "archived_paired_item_rows": len(pairs),
        "stress_final_mean_by_difficulty": {
            difficulty: {arm: mean(final_stress[difficulty, arm]) for arm in ARMS}
            for difficulty in STRESS
        },
        "limitations": [
            "Cannot replay checkpoint weight deltas or model inference without saved .pt states.",
            "Three independent training seeds; multiple checkpoint rows are not independent.",
            "Stress bank was designed post hoc and is exploratory, not a confirmatory external test.",
            "Phase6C uses a custom LOO-HT GRPO-family objective, not canonical TRL GRPO.",
            "Full-feedback uses twice the logical reward labels of budgeted arms.",
        ],
    }, indexed, final_stress, distances


def figures(output: Path, indexed, final_stress, distances):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    output.mkdir(parents=True, exist_ok=True)
    colors = {"full": "#17639a", "uniform": "#b77816", "joint_ewma": "#2c8d71"}
    labels = {"full": "Full (6 labels)", "uniform": "Uniform (3 labels)",
              "joint_ewma": "Joint EWMA (3 labels)"}
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "savefig.dpi": 180})

    fig, ax = plt.subplots(figsize=(8.2, 4.7))
    steps = list(range(0, 61, 10))
    for arm in ARMS:
        values = [[indexed[s, arm, k] for s in SEEDS] for k in steps]
        ax.plot(steps, [mean(x) for x in values], color=colors[arm], marker="o",
                label=labels[arm])
        ax.fill_between(steps, [min(x) for x in values],
                        [max(x) for x in values], color=colors[arm], alpha=0.07)
    ax.set(xlabel="Optimizer steps", ylabel="Heldout accuracy",
           title="Phase 6C: observed mean learning curves (3 seeds)")
    ax.set_ylim(0.45, 1.025)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output / "phase6c_mean_learning_curves.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.2, 4.7))
    xs = list(range(len(STRESS)))
    short = ("2-digit OOD carry", "3-digit double carry", "3-term addition")
    for j, arm in enumerate(ARMS):
        ax.bar([x + 0.24 * (j - 1) for x in xs],
               [mean(final_stress[d, arm]) for d in STRESS], width=0.23,
               color=colors[arm], label=labels[arm])
    ax.set_xticks(xs, short)
    ax.set_ylim(0, 1.08)
    ax.set_ylabel("Final stress accuracy")
    ax.set_title("Phase 6C: post-hoc locked exploratory stress (3 seeds)")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output / "phase6c_stress_by_difficulty.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.1, 4.0))
    per_seed = sorted(distances["per_seed"], key=lambda d: d["seed"])
    vals = [x["effective_update"]["uniform_vs_joint_ewma"]["effective_delta_l2"]
            for x in per_seed]
    ax.bar([str(x["seed"]) for x in per_seed], vals, color="#2c8d71")
    ax.set(xlabel="Training seed", ylabel="Frobenius/L2 distance of effective LoRA updates",
           title="Uniform vs Joint EWMA: saved effective LoRA divergence")
    fig.tight_layout()
    fig.savefig(output / "phase6c_effective_lora_distances.png")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output", type=Path, default=None)
    ap.add_argument("--verify-only", action="store_true")
    args = ap.parse_args()
    root = args.root.resolve()
    output = (args.output or root / "reproduced_outputs").resolve()
    summary, indexed, stress, distances = verify(root)
    if not args.verify_only:
        output.mkdir(parents=True, exist_ok=True)
        (output / "phase6c_verified_summary.json").write_text(
            json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        figures(output / "figures", indexed, stress, distances)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
