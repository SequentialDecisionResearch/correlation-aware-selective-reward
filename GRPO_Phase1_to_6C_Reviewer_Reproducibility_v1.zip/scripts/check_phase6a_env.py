"""Minimal, read-only preflight for RTX 5070 + Qwen Phase 6A."""

import json
import platform
import sys


def main():
    information = {"python": sys.version.split()[0], "platform": platform.platform()}
    try:
        import torch
        information.update({"torch": torch.__version__, "torch_cuda": torch.version.cuda,
                            "cuda_available": torch.cuda.is_available()})
        if torch.cuda.is_available():
            information.update({"gpu": torch.cuda.get_device_name(0),
                                "capability": list(torch.cuda.get_device_capability(0)),
                                "vram_gib": round(torch.cuda.get_device_properties(0).total_memory/2**30,2),
                                "bf16_supported": torch.cuda.is_bf16_supported()})
    except ImportError:
        information["torch"] = "NOT INSTALLED"
        information["cuda_available"] = False
    try:
        import transformers
        information["transformers"] = transformers.__version__
    except ImportError:
        information["transformers"] = "NOT INSTALLED"
    print(json.dumps(information, indent=2))
    if not information["cuda_available"]:
        sys.exit("CUDA NOT READY: install a compatible Blackwell-capable PyTorch build")


if __name__ == "__main__":
    main()
