"""Phase 6C v1.5: inspect old LoRA checkpoints without modifying training.

Stages: prepare (CPU), inspect (CPU + PyTorch), evaluate (GPU, resumable),
report (CPU). Only the NEW --output diagnostic directory is written.
"""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))

from phase2_grpo.phase6c_diagnostics import inspect, prepare, locked_inputs
from phase2_grpo.phase6c_diagnostic_eval import evaluate, report


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--stage",choices=("prepare","inspect","evaluate","report","all"),
                    required=True)
    ap.add_argument("--runs",nargs="+",default=None,
                    help="completed, independently audited Phase6C training directories")
    ap.add_argument("--output",required=True,
                    help="NEW diagnostic directory; NEVER a Phase6C training directory")
    ap.add_argument("--stress-per-stratum",type=int,default=32,
                    help="number of post-hoc locked stress tasks per difficulty stratum")
    ap.add_argument("--max-new-evals",type=int,default=None,
                    help="limit newly computed arm/step/panel GPU evaluations; resume by rerunning")
    args=ap.parse_args()
    output=Path(args.output)
    result={}
    if args.stage in ("prepare","all"):
        if args.runs:
            result["prepare"]=prepare(args.runs,output,
                                       per_stratum=args.stress_per_stratum)
        elif args.stage=="prepare":
            ap.error("--stage prepare requires --runs")
        else:
            locked_inputs(output)
    else:
        locked_inputs(output)
    if args.stage in ("inspect","all"):
        result["inspect"]=inspect(output)
    if args.stage in ("evaluate","all"):
        result["evaluate"]=evaluate(output,max_new_evals=args.max_new_evals)
    if args.stage in ("report","all"):
        if args.stage!="all" or result["evaluate"]["complete"]:
            result["report"]=report(output)
        else:
            result["report"]="pending until GPU evaluations finish"
    print(json.dumps(result,indent=2,ensure_ascii=False))


if __name__=="__main__":
    main()
