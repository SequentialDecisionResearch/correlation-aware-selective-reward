"""Phase 6A entry point. Run from unpacked project root (see docs)."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from phase2_grpo.phase6a_study import (Phase6AConfig, collect, evaluate,
                                      summarize, audit)


def main() -> None:
    p = argparse.ArgumentParser(description="Resumable frozen-Qwen budgeted-reward Phase 6A")
    p.add_argument("--output", required=True, help="dedicated immutable run directory")
    p.add_argument("--stage", choices=("all", "collect", "evaluate", "summary", "audit"),
                   default="all")
    p.add_argument("--backend", choices=("hf", "fake"), default="hf",
                   help="fake is for TESTING ONLY; not a real LLM experiment")
    p.add_argument("--model", default="Qwen/Qwen2.5-0.5B-Instruct")
    p.add_argument("--model-revision", default="main")
    p.add_argument("--device", default="cuda")
    p.add_argument("--local-files-only", action="store_true")
    p.add_argument("--groups", type=int, default=120)
    p.add_argument("--seed", type=int, default=6103)
    p.add_argument("--warmup", type=int, default=26)
    p.add_argument("--window", type=int, default=18)
    p.add_argument("--max-new-tokens", type=int, default=96)
    p.add_argument("--schedule", choices=("interleaved", "easy_to_hard"),
                   default="easy_to_hard")
    p.add_argument("--max-new-groups", type=int, default=None,
                   help="interruptibility test: process at most this many NEW groups")
    p.add_argument("--max-new-decisions", type=int, default=None,
                   help="interruptibility test: process at most this many NEW policy decisions")
    args = p.parse_args()
    cfg = Phase6AConfig(groups=args.groups, master_seed=args.seed,
                        warmup=args.warmup, window=args.window,
                        max_new_tokens=args.max_new_tokens,
                        schedule=args.schedule, backend=args.backend,
                        model=args.model, model_revision=args.model_revision,
                        device=args.device, local_files_only=args.local_files_only)
    if cfg.backend == "fake":
        print("WARNING: FAKE BACKEND — smoke-test data, NOT a real Qwen experiment!", flush=True)
    def report(stage: str, completed: int, total: int) -> None:
        # A progress message is emitted only AFTER a durable checkpoint.
        if stage == "generated" or completed % 10 == 0 or completed == total:
            print(f"CHECKPOINT [{stage}] {completed}/{total} committed", flush=True)
    if args.stage in ("all", "collect"):
        print("Phase 6A collection: checking snapshots / loading model if needed ...",
              flush=True)
        result = collect(cfg, args.output, max_new_groups=args.max_new_groups,
                         progress=report)
        print(json.dumps({"collection":result}), flush=True)
        if args.stage == "collect" or result["completed_groups"] < cfg.groups:
            return
    if args.stage in ("all", "evaluate"):
        print("Phase 6A evaluation: restoring masked online histories ...", flush=True)
        result = evaluate(cfg, args.output, max_new_decisions=args.max_new_decisions,
                          progress=report)
        print(json.dumps({"evaluation":result}), flush=True)
        if args.stage == "evaluate" or not result["complete"]:
            summarize(cfg, args.output)
            return
    if args.stage in ("all", "summary"):
        summary = summarize(cfg, args.output)
        print(json.dumps({"summary":summary}, indent=2), flush=True)
    if args.stage in ("all", "audit"):
        result = audit(cfg, args.output)
        print(json.dumps({"audit":result}, indent=2), flush=True)


if __name__ == "__main__":
    main()
