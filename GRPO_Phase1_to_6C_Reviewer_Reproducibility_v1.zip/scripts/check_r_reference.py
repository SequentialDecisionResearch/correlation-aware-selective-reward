"""Optional Monte Carlo comparison to the *real* CRAN cube implementation.

R is not bundled. This script explicitly checks availability and aborts
rather than labeling a Python approximation as the official R sampler.
"""

import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from phase2_grpo.classic_cube import cube_full_flight_landing
from phase2_grpo.balanced import imbalance_squared
from phase2_grpo.geometry import gradient_map
from phase2_grpo.r_cube_bridge import reference_available


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--draws",type=int,default=3000)
    parser.add_argument("--seed",type=int,default=101)
    parser.add_argument("--output",type=Path,default=ROOT/"results"/"r_cube_reference_audit.json")
    args=parser.parse_args()
    if not reference_available():
        raise SystemExit("Rscript and CRAN BalancedSampling::cube are required for independent verification")
    if args.draws < 10:
        raise SystemExit("--draws must be >=10")
    rng=np.random.default_rng(27071)
    g,b=6,3
    pi=np.full(g,b/g)
    aux=gradient_map(rng.normal(size=(3,g)))
    exact,diag=cube_full_flight_landing(pi,b,aux)
    with tempfile.TemporaryDirectory(prefix="grpo_ref_audit_") as scratch:
        inp=Path(scratch)/"data.csv"
        out=Path(scratch)/"selected.csv"
        np.savetxt(inp,np.column_stack([pi,pi,aux.T]),delimiter=",",fmt="%.17g")
        cmd=["Rscript",str(ROOT/"scripts"/"r_cube_reference_audit.R"),
             str(inp),str(out),str(args.draws),str(args.seed)]
        completed=subprocess.run(cmd,check=False,text=True,capture_output=True,timeout=300)
        if completed.returncode:
            raise SystemExit("R cube reference failed: "+completed.stderr[-1000:])
        z=np.loadtxt(out,delimiter=",",dtype=float,ndmin=2)
    if z.shape!=(args.draws,g) or np.any(z.sum(axis=1)!=b):
        raise SystemExit("R reference returned invalid size-B samples")
    qerror=float(np.max(np.abs(z.mean(axis=0)-pi)))
    empirical=float(np.mean(imbalance_squared(z,pi,aux)))
    theoretical_python=float(np.dot(exact.probs,imbalance_squared(exact.subsets,pi,aux)))
    # Exact marginal test for our code. Official R inclusion is Monte Carlo
    # estimated and must never be represented as an exact inclusion vector.
    result={"backend":"actual_R_BalancedSampling_cube",
            "reference_draws":args.draws,"seed":args.seed,
            "reference_empirical_max_pi_error":qerror,
            "reference_empirical_score_balance_loss":empirical,
            "independent_python_cube_exact_score_balance_loss":theoretical_python,
            "python_marginal_error":diag.largest_marginal_error,
            "comparison_type":"different_valid_cube_implementations_not_identical_RNG",
            "interpretation":"Monte Carlo R properties; not an exact pair inclusion estimate"}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))
