"""Reproducible Python online covariance + drift/fallback study."""

import argparse
from dataclasses import replace
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"src"))
from phase2_grpo.online_study import run_online_study, OnlineConfig, SCENARIOS, SEEDS


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--quick", action="store_true")
    p.add_argument("--output",default="results/phase3_online_full")
    p.add_argument("--drift-threshold",type=float,default=None)
    p.add_argument("--scenario",choices=tuple(SCENARIOS),default=None)
    p.add_argument("--seed-count",type=int,choices=tuple(range(1,len(SEEDS)+1)),default=None)
    args = p.parse_args()
    customized = (args.drift_threshold is not None or args.scenario is not None
                  or args.seed_count is not None)
    if args.quick and customized:
        p.error("--quick cannot be combined with a custom experimental design")
    cfg = None
    if customized:
        cfg = OnlineConfig()
        if args.drift_threshold is not None:
            cfg = replace(cfg,drift_threshold=args.drift_threshold)
        if args.scenario is not None:
            cfg = replace(cfg,scenarios=(args.scenario,))
        if args.seed_count is not None:
            cfg = replace(cfg,seeds=SEEDS[:args.seed_count])
    s = run_online_study(args.output, quick=args.quick,config=cfg)
    print(json.dumps({k:v for k,v in s.items() if k not in ("strata","drift_detector")},
                     indent=2))
