"""Frozen 6B multi-seed/multi-scenario Qwen holdout, resumable by group."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from phase2_grpo.phase6b_study import Phase6BConfig, run, SEEDS, SCENARIOS


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",required=True)
    p.add_argument("--stage",choices=("all","collect","evaluate","summary","audit"),
                   default="all")
    p.add_argument("--backend",choices=("hf","fake"),default="hf")
    p.add_argument("--model",default="Qwen/Qwen2.5-0.5B-Instruct")
    p.add_argument("--model-revision",default="main")
    p.add_argument("--device",default="cuda")
    p.add_argument("--local-files-only",action="store_true")
    p.add_argument("--groups",type=int,default=80)
    p.add_argument("--seeds",nargs="+",type=int,default=list(SEEDS))
    p.add_argument("--scenarios",nargs="+",choices=SCENARIOS,default=list(SCENARIOS))
    p.add_argument("--warmup",type=int,default=20)
    p.add_argument("--window",type=int,default=12)
    p.add_argument("--max-new-tokens",type=int,default=96)
    p.add_argument("--max-new-groups",type=int)
    p.add_argument("--max-new-decisions",type=int)
    a=p.parse_args()
    cfg=Phase6BConfig(groups=a.groups,seeds=tuple(a.seeds),
         scenarios=tuple(a.scenarios),warmup=a.warmup,window=a.window,
         max_new_tokens=a.max_new_tokens,backend=a.backend,model=a.model,
         model_revision=a.model_revision,device=a.device,
         local_files_only=a.local_files_only)
    if a.backend=="fake":
        print("WARNING: fake model is software QA only, NOT real Qwen evidence",flush=True)
    def progress(cell,stage,step,total):
        print(f"COMMITTED {cell} [{stage}] {step}/{total}",flush=True)
    summary=run(cfg,a.output,stage=a.stage,max_new_groups=a.max_new_groups,
                max_new_decisions=a.max_new_decisions,progress=progress)
    print(json.dumps(summary,indent=2),flush=True)


if __name__=="__main__":
    main()
