"""Apply internally frozen, deliberately conservative LLM-pilot criteria."""

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from scipy.stats import t as tdist


def evaluate(holdout:Path, r_reference:Path, output:Path):
    summary=json.loads((holdout/"holdout_summary.json").read_text())
    ref=json.loads((r_reference/"R_reference_suite.json").read_text())
    rows=list(csv.DictReader((holdout/"holdout_trials.csv").open(newline="")))
    if summary.get("quick_smoke_only"):
        raise ValueError("quick smoke run cannot authorize spending")
    scenarios=summary["new_worlds"]
    seeds=summary["holdout_seeds"]
    # Average scenario-by-time paired difference in one held-out seed, then
    # use SEEDS (not 7*80 time points) as the independent analysis units.
    seed_averages=[]
    for seed in seeds:
        joint={(r["scenario"],r["step"]):float(r["true_risk"])
               for r in rows if int(r["seed"])==seed and r["policy"]=="joint_ewma"
               and r["phase"]=="later"}
        guard={(r["scenario"],r["step"]):float(r["true_risk"])
               for r in rows if int(r["seed"])==seed and r["policy"]=="guarded_partial"
               and r["phase"]=="later"}
        if joint.keys()!=guard.keys() or len(joint)!=len(scenarios)*80:
            raise AssertionError("unmatched policy-by-world heldout keys")
        seed_averages.append(float(np.mean([joint[k]-guard[k] for k in joint])))
    arr=np.asarray(seed_averages)
    mean=float(arr.mean())
    interval=float(tdist.ppf(.975,len(arr)-1)*arr.std(ddof=1)/np.sqrt(len(arr)))
    ci=[mean-interval,mean+interval]
    conditions={}
    r_ok=all(c["R_sample_sizes_all_exact"] and
             c["R_max_marginal_zscore"]<4 for c in ref["cases"])
    conditions["actual_R_fixed_size_and_plausible_marginal"]=r_ok
    conditions["positive_seed_cluster_95pct_lower_bound_vs_joint"]=bool(ci[0]>0)
    stationary={}
    for s in ("stationary_heteroscedastic","stationary_heavy_tail"):
        rj=summary["strata"][f"{s}|later|joint_ewma"]["mean_conditional_gradient_risk"]
        rg=summary["strata"][f"{s}|later|guarded_partial"]["mean_conditional_gradient_risk"]
        excess=float(rg/rj-1) if rj>0 else float("inf")
        alarm=summary["guard_detector"][s]["any_alarm_fraction"]
        stationary[s]={"guard_excess_fraction_vs_joint":excess,
                       "any_alarm_seed_fraction":alarm}
    conditions["both_stationary_excess_risk_at_most_5pct"]=all(
        x["guard_excess_fraction_vs_joint"]<=.05 for x in stationary.values())
    conditions["both_stationary_alarm_fraction_below_10pct"]=all(
        x["any_alarm_seed_fraction"]<.10 for x in stationary.values())
    if len(rows)!=summary["rows"]:
        raise AssertionError("holdout raw rows/summary inconsistent")
    if summary["metered_synthetic_calls"]!=len(rows)*3:
        raise AssertionError("synthetic verifier-call count inconsistent")
    conditions["no_observed_budget_or_output_integrity_failure"]=True
    result={"gate_report":"Phase4 original internally frozen criteria",
            "source_result_folder":str(holdout),
            "paired_later_half_gain_joint_minus_guard":mean,
            "independent_seed_clusters":len(arr),
            "descriptive_95pct_seed_t_interval":ci,
            "per_seed_paired_gains":dict(zip(map(str,seeds),seed_averages)),
            "stationary_control_diagnostics":stationary,
            "preregistered_externally":False,
            "criteria":conditions,
            "all_criteria_passed":bool(all(conditions.values())),
            "recommendation":("consider carefully metered small LLM pilot, not scale-up"
                    if all(conditions.values()) else
                    "do not begin LLM training from this evidence; redesign and use new holdout"),
            "limitations":"The 95% t interval is descriptive over seed clusters, not a time-uniform guarantee"}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2),encoding="utf-8")
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--holdout",type=Path,default=Path("results/phase4_frozen_holdout_full"))
    p.add_argument("--r-reference",type=Path,default=Path("results/phase4_real_R_cube"))
    p.add_argument("--output",type=Path,default=Path("results/phase4_go_no_go.json"))
    args=p.parse_args()
    result=evaluate(args.holdout,args.r_reference,args.output)
    print(json.dumps({k:v for k,v in result.items() if k not in (
        "per_seed_paired_gains",)},indent=2))
