"""Independent-code-path internal audit of frozen Phase 5 raw output.

Does not use phase5_study.summarize_phase5() or phase5_bridge internals.
Not equivalent to an external expert's independent scientific audit.
"""

import argparse
import csv
from collections import defaultdict
import json
from pathlib import Path

import numpy as np
from scipy.stats import t as student_t

POLICIES = ('uniform', 'cube_classic', 'scaled', 'joint_ewma', 'joint_frozen')
COMPARATORS = ('scaled', 'uniform', 'joint_frozen')
EXPECTED_WORLDS = ('stationary_independent', 'stationary_positive_factor',
    'stationary_sparse_t5', 'abrupt_sign_switch', 'two_change_blocks',
    'smooth_sigmoid_rotation')
EXPECTED_SEEDS = (4001, 4003, 4007, 4013, 4019, 4021, 4027, 4049,
                  4051, 4057, 4073, 4079, 4091, 4093, 4099, 4111)
FORBIDDEN_SEEDS = set((17, 29, 41, 53, 67, 79, 97, 109,
                         2017, 2027, 2039, 2053, 2063, 2081, 2089,
                         2111, 2129, 2137, 2153, 2161)) | set(range(3101,3133))


def _mean_seed_ci(d: dict[int, list[float]]) -> dict:
    values = np.asarray([np.mean(v) for _, v in sorted(d.items())], float)
    ave = float(values.mean())
    half = float(student_t.ppf(.975, len(values)-1)
                 * np.std(values, ddof=1) / np.sqrt(len(values)))
    return {'seed_count': len(values), 'paired_mean_gain': ave,
            'descriptive_t95': [ave-half, ave+half],
            'positive_seed_fraction': float(np.mean(values > 0))}


def audit(input_dir: Path) -> dict:
    original = json.loads((input_dir / 'phase5_summary.json').read_text())
    bridge = json.loads((input_dir / 'phase5_bridge.json').read_text())
    quick = original['quick_smoke_only']
    seeds = tuple(original['new_seeds'])
    worlds = tuple(original['new_worlds'])
    horizon = original['parameters']['horizon']
    expected_seeds = EXPECTED_SEEDS if not quick else EXPECTED_SEEDS[:2]
    expected_worlds = EXPECTED_WORLDS if not quick else EXPECTED_WORLDS[:2]
    assert seeds == expected_seeds and worlds == expected_worlds
    assert not set(seeds) & FORBIDDEN_SEEDS
    indexed = {}
    pairs = defaultdict(dict)
    counts = 0
    max_margin = 0.
    min_pair = float('inf')
    max_oracle_violation = 0.
    by_policy_late = defaultdict(list)
    group_actual_error = defaultdict(list)
    for row in csv.DictReader((input_dir/'phase5_trials.csv').open(newline='')):
        seed, step = int(row['seed']), int(row['step'])
        name, policy = row['world'], row['policy']
        assert seed in seeds and name in worlds and policy in POLICIES
        assert 0 <= step < horizon
        key = (seed, name, step, policy)
        assert key not in indexed, 'duplicate group/step/method'
        indexed[key] = True
        group_key = (seed, name, step)
        pairs[group_key][policy] = float(row['true_risk'])
        assert row['selected_subset'].count('1') == 3
        assert int(row['gold_queries']) == 3
        assert int(row['drift_alert']) == 0
        assert float(row['true_risk']) >= -1e-8
        gap = float(row['oracle_risk']) - float(row['true_risk'])
        max_oracle_violation = max(max_oracle_violation, gap)
        assert gap < 1e-7
        max_margin = max(max_margin, float(row['max_marginal_error']))
        min_pair = min(min_pair, float(row['min_pair_inclusion']))
        assert float(row['covariance_error_before']) >= 0
        assert np.isfinite(float(row['realized_squared_error']))
        expected_period = 'later' if step >= horizon//2 else 'early'
        assert row['period'] == expected_period
        if row['period'] == 'later':
            by_policy_late[policy].append(float(row['true_risk']))
            group_actual_error[(name, policy)].append(float(row['covariance_error_before']))
        counts += 1
    assert counts == len(seeds)*len(worlds)*horizon*len(POLICIES)
    assert len(pairs) == len(seeds)*len(worlds)*horizon
    assert all(set(p)==set(POLICIES) for p in pairs.values())
    assert max_margin < 1e-7 and min_pair > 0
    assert original['rows'] == counts
    assert original['metered_synthetic_gold_queries'] == counts*3

    recomputed = {}
    for baseline in COMPARATORS:
        clusters = {s:[] for s in seeds}
        for (seed,name,step), risks in pairs.items():
            if step >= horizon//2:
                clusters[seed].append(risks[baseline]-risks['joint_ewma'])
        val = _mean_seed_ci(clusters)
        target = original['primary_comparisons'][f'{baseline}_minus_joint']
        for field in ('paired_mean_gain', 'positive_seed_fraction'):
            assert abs(val[field]-target[field]) < 1e-11
        assert np.max(np.abs(np.array(val['descriptive_t95'])
                             -np.array(target['descriptive_t95']))) < 1e-10
        recomputed[f'{baseline}_minus_joint'] = val
    for method, risk_values in by_policy_late.items():
        expected = original['overall_later_risks'][method]['mean_later_risk']
        assert abs(np.mean(risk_values)-expected) < 1e-10

    independent = [risk for (seed,name,step),risk in pairs.items()
                   if name == 'stationary_independent']
    max_design_gap = max(max(d.values())-min(d.values()) for d in independent)
    assert max_design_gap < 1e-7, 'diagonal V, equal marginals must show no coupling gain'
    # Recompute held-out world means independently of Phase5 summarizer.
    recomputed_worlds = {}
    for world in worlds:
        on_world = [val for (s, w, t),val in pairs.items()
                    if w==world and t>=horizon//2]
        for method in POLICIES:
            expected = original['worlds'][world]['risk_by_policy'][method]
            actual = float(np.mean([v[method] for v in on_world]))
            assert abs(expected-actual) < 1e-10
        recomputed_worlds[world] = {
            'scaled_minus_joint': float(np.mean([
                v['scaled']-v['joint_ewma'] for v in on_world]))}
    assert sum(x['scaled_minus_joint'] > 1e-9 for x in recomputed_worlds.values()) == (
        original['worlds_joint_better_than_scaled'])

    # External representation of exact enumerated bridge is verified from
    # *stored per-group* values, not by invoking its simulation function.
    assert len(bridge['all_groups'])==64*5
    for budget in range(1,6):
        b_rows = [r for r in bridge['all_groups'] if r['budget']==budget]
        assert len(b_rows)==64
        for key in ('linear','normalized','clipped'):
            raw = float(np.mean([
                v[key]['exact_design_bias_norm'] for v in b_rows]))
            recorded = bridge['summary']['per_budget'][str(budget)][key][
                'exact_design_bias_norm']
            assert abs(raw-recorded)<1e-11
            if key=='linear':
                assert raw<1e-10, 'linear LOO must be exact-design unbiased'
    assert bridge['summary']['four_way_interaction_witness']['normalized_norm'] > 1e-8
    assert bridge['summary']['four_way_interaction_witness']['clipped_norm'] > 1e-8
    report = {
        'audit_type': 'independent_code_path_INTERNAL_only_not_external_peer_review',
        'passed': True, 'quick_smoke_only': quick, 'raw_rows_recomputed': counts,
        'unique_world_seed_steps': len(pairs),
        'exact_metered_synthetic_queries': counts*3,
        'maximum_first_marginal_error': max_margin,
        'minimum_pair_inclusion': min_pair,
        'max_true_oracle_violation': max_oracle_violation,
        'independent_diagonal_world_max_risk_gap': max_design_gap,
        'independently_recomputed_primary': recomputed,
        'independently_recomputed_worlds': recomputed_worlds,
        'bridge_linear_exactly_unbiased': True,
        'nonlinear_normalization_interaction_witness_nonzero': True,
        'restrictions': [
            'same project, separate summary code; not external independent reviewers',
            'synthetic one-step target; no real LLM verifier or policy optimization',
            'descriptive seed t intervals, not claims of inference across all worlds',
        ],
    }
    (input_dir/'phase5_audit.json').write_text(
        json.dumps(report, indent=2), encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(audit(args.input), indent=2))
