"""Phase 6D exact true LoRA-gradient versus Phase6B sketch risk diagnostic."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))

from phase2_grpo.phase6d_alignment import (SOURCES,FAMILIES,prepare,run,report,locked)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--stage",choices=("prepare","run","report"),required=True)
    ap.add_argument("--runs",nargs="+",default=None,
                    help="immutable, complete original Phase6C run roots")
    ap.add_argument("--output",required=True,
                    help="NEW Phase6D root; must not be within previous runs")
    ap.add_argument("--snapshots",nargs="+",type=int,default=[0,30,60],
                    help="saved LoRA checkpoint steps; 0 is a uniform warmup control")
    ap.add_argument("--source-arms",nargs="+",choices=SOURCES,default=list(SOURCES))
    ap.add_argument("--families",nargs="+",choices=FAMILIES,default=list(FAMILIES))
    ap.add_argument("--groups-per-family",type=int,default=4)
    ap.add_argument("--max-new-groups",type=int,default=None,
                    help="bounded GPU work; rerun with same directory to resume")
    a=ap.parse_args()
    out=Path(a.output)
    if a.stage=="prepare":
        if not a.runs:
            ap.error("--stage prepare requires --runs")
        result=prepare(a.runs,out,snapshots=a.snapshots,
                       source_arms=a.source_arms,families=a.families,
                       groups_per_family=a.groups_per_family)
    else:
        locked(out)
        result=(run(out,max_new_groups=a.max_new_groups) if a.stage=="run"
                else report(out))
    print(json.dumps(result,indent=2,ensure_ascii=False))


if __name__=="__main__":
    main()
