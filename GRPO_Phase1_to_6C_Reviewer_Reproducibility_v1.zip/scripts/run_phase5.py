"""Run frozen Phase 5 online holdout and exact finite-support GRPO bridge."""

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from phase2_grpo.phase5_study import run_phase5
from phase2_grpo.phase5_bridge import run_bridge


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick', action='store_true')
    parser.add_argument('--output', type=Path, default=ROOT / 'results' / 'phase5_full')
    args = parser.parse_args()
    results = run_phase5(args.output, quick=args.quick)
    bridge = run_bridge(args.output)
    print(json.dumps({
        'quick': args.quick,
        'rows': results['rows'],
        'primary_comparisons': results['primary_comparisons'],
        'independent_control_gap': results.get('independent_no_coupling_max_risk_gap'),
        'bridge_linear_b3_bias': bridge['per_budget']['3']['linear']['exact_design_bias_norm'],
        'bridge_normalized_b3_bias': bridge['per_budget']['3']['normalized']['exact_design_bias_norm'],
        'runtime_seconds': results['runtime_seconds'],
    }, indent=2))


if __name__ == '__main__':
    main()
