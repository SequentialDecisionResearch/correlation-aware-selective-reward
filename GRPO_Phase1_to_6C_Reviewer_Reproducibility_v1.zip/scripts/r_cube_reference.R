# Official implementation bridge: requires installed CRAN BalancedSampling.
# Usage: Rscript scripts/r_cube_reference.R input.csv selected.txt 123
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 3L) stop("expected input.csv output.txt seed")
if (!requireNamespace("BalancedSampling", quietly=TRUE)) {
  stop("Install the reference algorithm: install.packages('BalancedSampling')")
}
d <- as.matrix(utils::read.csv(args[1], header=FALSE, check.names=FALSE))
if (ncol(d) < 2L) stop("need inclusion probabilities and balance matrix")
pi <- as.numeric(d[,1])
x <- as.matrix(d[,-1,drop=FALSE])
if (max(abs(x[,1] - pi)) > 1e-9) stop("size balancing column not first")
set.seed(as.integer(args[3]))
chosen <- BalancedSampling::cube(pi, x)
writeLines(as.character(as.integer(chosen)-1L), con=args[2])
