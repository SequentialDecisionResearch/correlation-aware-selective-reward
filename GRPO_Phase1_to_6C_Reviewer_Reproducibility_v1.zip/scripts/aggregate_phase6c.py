"""Compare multiple complete, independently audited 6C training-seed runs."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from phase2_grpo.phase6c_analysis import aggregate


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs",nargs="+",required=True,
                        help="three+ independent Phase6C output directories")
    parser.add_argument("--output",required=True)
    parser.add_argument("--allow-fake-qa",action="store_true",
                        help="INTEGRATION TESTS ONLY; not publication evidence")
    args=parser.parse_args()
    result=aggregate(args.runs,args.output,allow_fake_qa=args.allow_fake_qa)
    print(json.dumps(result,indent=2,ensure_ascii=False))


if __name__=="__main__":
    main()
