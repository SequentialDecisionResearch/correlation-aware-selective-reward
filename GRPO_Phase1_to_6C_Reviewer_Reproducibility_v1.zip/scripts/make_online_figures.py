"""Publication-readable diagnostic plots from an already executed online CSV."""

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--input", type=Path,
               default=ROOT/"results"/"phase3_online_full"/"online_trials.csv")
p.add_argument("--output", type=Path,
               default=ROOT/"results"/"phase3_online_figures")
args = p.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
with args.input.open(encoding="utf-8",newline="") as f:
    rows = list(csv.DictReader(f))
if not rows:
    raise ValueError("run scripts/run_online_study.py before plotting")

scenarios = list(dict.fromkeys(r["scenario"] for r in rows))
methods = list(dict.fromkeys(r["policy"] for r in rows))
switch = int(rows[0]["switch_at"])
horizon = max(int(r["step"]) for r in rows)+1
plt.rcParams.update({"font.size":9,"axes.spines.top":False,
                     "axes.spines.right":False,"savefig.dpi":190})


def mean_field(dataset,field):
    return float(np.mean([float(r[field]) for r in dataset]))


# Figure 1: post-switch risk improvements vs the exact-B uniform baseline.
mat = np.zeros((len(scenarios),len(methods)-1))
for i,scenario in enumerate(scenarios):
    sub=[r for r in rows if r["scenario"]==scenario and r["phase"]=="after"]
    reference=mean_field([r for r in sub if r["policy"]=="uniform"],"true_risk")
    for j,method in enumerate(methods[1:]):
        selected=[r for r in sub if r["policy"]==method]
        mat[i,j]=reference-mean_field(selected,"true_risk")
fig,ax=plt.subplots(figsize=(9.5,5.1))
vmax=max(np.max(np.abs(mat)),.001)
image=ax.imshow(mat,cmap="RdBu",vmin=-vmax,vmax=vmax,aspect="auto")
ax.set_yticks(range(len(scenarios)),[s.replace("_"," ") for s in scenarios])
ax.set_xticks(range(len(methods)-1),[s.replace("_","\n") for s in methods[1:]])
for i in range(len(scenarios)):
    for j in range(len(methods)-1):
        ax.text(j,i,f"{mat[i,j]:+.3f}",ha="center",va="center",fontsize=8,
                color="white" if abs(mat[i,j])>.58*vmax else "black")
fig.colorbar(image,ax=ax,label="Mean exact query-risk gain over uniform")
ax.set_title("Post-switch synthetic risk: common first marginals and exact B")
fig.tight_layout()
fig.savefig(args.output/"online_postchange_risk_heatmap.png")
plt.close(fig)


# Figure 2: matched time trajectories, separate stationary vs changed worlds.
fig,axs=plt.subplots(1,2,figsize=(13,4.5),sharey=True)
step_values: defaultdict[tuple[str,str,int], list[float]] = defaultdict(list)
for row in rows:
    step_values[(row["scenario"],row["policy"],int(row["step"]))].append(
        float(row["true_risk"]))
for ax,scenario in zip(axs,["signed_to_common","common_to_signed"]):
    if scenario not in scenarios:
        scenario = scenarios[0]
    for method,color in (("uniform","#555555"),("scaled","#BC7B33"),
                         ("joint_ewma","#23759B"),("joint_frozen","#A85067"),
                         ("drift_gated","#309075")):
        values=np.array([np.mean(step_values[(scenario,method,step)])
                         for step in range(horizon)])
        # Edge-normalized smoothing avoids artificial falls at t=0 and t=T.
        kernel=np.ones(11)
        smoother=(np.convolve(values,kernel,mode="same")/
                  np.convolve(np.ones_like(values),kernel,mode="same"))
        ax.plot(range(horizon),smoother,label=method.replace("_"," "),
                color=color,lw=1.65)
    ax.axvline(switch-.5,color="black",ls="--",lw=1)
    ax.set_title(scenario.replace("_"," "))
    ax.set_xlabel("Sequence of acquisition decisions")
    ax.grid(alpha=.15)
axs[0].set_ylabel("11-step running mean of exact conditional risk")
fig.suptitle("Identical query budget, shared synthetic score and reward world")
handles,labels=axs[1].get_legend_handles_labels()
fig.legend(handles,labels,loc="lower center",ncol=5,frameon=False,fontsize=9,
           bbox_to_anchor=(.5,-.02))
fig.tight_layout(rect=(0,.075,1,.96))
fig.savefig(args.output/"online_drift_trajectories.png")
plt.close(fig)


# Figure 3: what the fallback policy actually did (including failures).
cats=("warmup_uniform","insufficient_pair_ess_fallback",
      "small_predicted_gain_fallback","drift_cooldown_fallback","joint_accepted")
colors=("#828282","#BF9E5D","#D2BC89","#BD6470","#337F90")
fig,ax=plt.subplots(figsize=(10.5,5.2))
bottom=np.zeros(len(scenarios))
for cat,color in zip(cats,colors):
    y=np.array([np.mean([r["decision"]==cat for r in rows if
                            r["scenario"]==scenario and r["policy"]=="drift_gated"])
                for scenario in scenarios])
    ax.bar(np.arange(len(scenarios)),y,bottom=bottom,color=color,label=cat)
    bottom+=y
ax.set_xticks(np.arange(len(scenarios)),[s.replace("_","\n") for s in scenarios])
ax.set_ylim(0,1.05)
ax.set_ylabel("Fraction of all acquisition decisions")
ax.set_title("Online fallback gate usage, including warm-up and false alarms")
ax.legend(ncol=3,loc="upper center",bbox_to_anchor=(.5,-.12),
          frameon=False,fontsize=8)
fig.tight_layout(rect=(0,.07,1,1))
fig.savefig(args.output/"online_gate_decisions.png")
plt.close(fig)
print(f"Wrote three online plots to {args.output}")
