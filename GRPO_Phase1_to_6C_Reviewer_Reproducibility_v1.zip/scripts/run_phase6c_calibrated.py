"""Phase 6C Calibration-2 real LoRA training, evidence-locked and resumable."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))

from phase2_grpo.phase6c_objectives import ARMS, Phase6CConfig
from phase2_grpo.phase6c_training import run


def verified_calibration_evidence(path):
    root=Path(path)
    names=("calibration2_selection.json","calibration2_summary.json",
           "calibration2_audit.json")
    documents=[];contents=[]
    for name in names:
        raw=(root/name).read_bytes()
        documents.append(json.loads(raw.decode("utf-8")))
        contents.append(raw)
    selected,summary,audit=documents
    if (selected.get("status")!="selected" or
            selected.get("selected_family")!="two_digit_add" or
            summary.get("selected_family")!="two_digit_add" or
            summary.get("backend")!="hf" or not summary.get("complete") or
            summary.get("evaluation_groups_complete")!=180 or
            summary.get("rows_available")!=900 or
            not audit.get("pass") or
            audit.get("checked_decisions")!=audit.get("expected") or
            audit.get("checked_decisions")!=900 or
            audit.get("checked_pilot_groups")!=84):
        raise RuntimeError("Phase6B calibrated selection, heldout completion, or audit is invalid")
    return hashlib.sha256(b"\0".join(contents)).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",required=True)
    p.add_argument("--calibration-root",required=True,
                   help="completed Phase6B Calibration-2 results directory")
    p.add_argument("--stage",choices=("all","train","summary","audit"),default="all")
    p.add_argument("--arms",nargs="+",choices=ARMS,default=list(ARMS))
    p.add_argument("--steps",type=int,default=60)
    p.add_argument("--seed",type=int,default=6207)
    p.add_argument("--warmup",type=int,default=12)
    p.add_argument("--window",type=int,default=9)
    p.add_argument("--max-new-tokens",type=int,default=64)
    p.add_argument("--learning-rate",type=float,default=1e-5)
    p.add_argument("--update-epochs",type=int,default=1)
    p.add_argument("--clip-epsilon",type=float,default=.20)
    p.add_argument("--lora-rank",type=int,default=8)
    p.add_argument("--lora-alpha",type=int,default=16)
    p.add_argument("--eval-every",type=int,default=10)
    p.add_argument("--eval-size",type=int,default=24)
    p.add_argument("--model",default="Qwen/Qwen2.5-0.5B-Instruct")
    p.add_argument("--model-revision",default="main")
    p.add_argument("--device",default="cuda")
    p.add_argument("--local-files-only",action="store_true")
    p.add_argument("--max-new-steps",type=int,
                   help="cap NEW durable steps across all specified arms")
    args=p.parse_args()

    evidence=verified_calibration_evidence(args.calibration_root)
    cfg=Phase6CConfig(steps=args.steps,seed=args.seed,warmup=args.warmup,
        window=args.window,max_new_tokens=args.max_new_tokens,
        objective="loo_ht",update_epochs=args.update_epochs,
        clip_epsilon=args.clip_epsilon,learning_rate=args.learning_rate,
        lora_rank=args.lora_rank,lora_alpha=args.lora_alpha,
        eval_every=args.eval_every,eval_size=args.eval_size,
        train_schedule="interleaved",task_family="two_digit_add",
        calibration_evidence_sha256=evidence,model=args.model,
        model_revision=args.model_revision,device=args.device,
        local_files_only=args.local_files_only)

    print("LOCKED: verified Phase6B two_digit_add, separate disjoint Phase6C task bank.",
          flush=True)
    print("WARNING: LOO-HT is GRPO-family and differs from normalized TRL GRPO; "+
          "full-feedback uses SIX reward labels versus THREE in budgeted arms.",flush=True)
    def progress(arm,step,total):
        print(f"COMMITTED CALIBRATED LoRA [{arm}] step {step}/{total}",flush=True)
    result=run(cfg,args.output,arms=tuple(args.arms),stage=args.stage,
               max_new_steps=args.max_new_steps,progress=progress)
    print(json.dumps(result,indent=2),flush=True)


if __name__=="__main__":
    main()
