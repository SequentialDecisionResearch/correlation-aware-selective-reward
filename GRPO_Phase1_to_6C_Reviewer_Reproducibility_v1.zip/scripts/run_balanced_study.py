"""Run the new Phase-2 same-marginal balancing/correlation experiment."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from phase2_grpo.phase2_study import run_phase2


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="results/phase2_full")
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()
    result = run_phase2(args.output, quick=args.quick)
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("by_profile_main", "limitations")}, indent=2))
