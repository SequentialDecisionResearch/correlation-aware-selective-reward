"""Paper-readable figures from a recorded CSV; no experiment rerun or refit."""

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--input", type=Path,
                    default=ROOT / "results" / "phase2_full" / "all_trials.csv")
parser.add_argument("--output", type=Path,
                    default=ROOT / "results" / "phase2_figures")
options = parser.parse_args()
DATA = options.input
OUT = options.output
OUT.mkdir(parents=True, exist_ok=True)
with DATA.open(newline="", encoding="utf-8") as stream:
    rows = list(csv.DictReader(stream))
if not rows:
    raise ValueError("run the full Phase 2 study first")

names = ["independent", "common_weak", "common_strong", "signed_factor",
         "negative_equicorr", "two_blocks"]
short = ["Independent", "Common weak", "Common strong", "Signed factor",
         "Negative equicorr.", "Two blocks"]


def subset(profile, pilot_n, drift):
    return [r for r in rows if r["profile"] == profile
            and int(r["pilot_n"]) == pilot_n
            and int(r["drifted_pilot"]) == drift
            and int(r["B"]) not in (1, int(r["G"]) - 1)]


def means(metric, pilot_n, drift):
    return [float(np.mean([float(r[metric]) for r in subset(n, pilot_n, drift)]))
            for n in names]


plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.dpi": 180})

fig, ax = plt.subplots(figsize=(10, 5.4))
positions = np.arange(len(names))
width = .23
for idx, (column, label, color) in enumerate([
    ("joint_vs_uniform", "Estimated joint coupling", "#256B9A"),
    ("scaled_vs_uniform", "Scaled-score balancing LP", "#CC8A33"),
    ("cube_vs_uniform", "Cube flight + pair landing", "#549A7B"),
]):
    ax.bar(positions + (idx - 1) * width, means(column, 600, 0), width,
           label=label, color=color)
ax.axhline(0, color="#454545", linewidth=.9)
ax.set_xticks(positions, short, rotation=20, ha="right")
ax.set_ylabel("Mean true query-risk reduction vs uniform")
ax.set_title("Same first-order marginals and B = G/2; 12 seeds, matched pilot, N = 600")
ax.legend(loc="upper left", frameon=False)
fig.tight_layout()
fig.savefig(OUT / "phase2_matched_comparators.png")
plt.close(fig)

fig, ax = plt.subplots(figsize=(10, 5.4))
marks = [(-.20, 120, 0, "120, matched", "#3C7DA8"),
         (-.07, 600, 0, "600, matched", "#13567F"),
         (.07, 120, 1, "120, drift", "#D89C47"),
         (.20, 600, 1, "600, drift", "#B35737")]
for offset, count, drift, label, color in marks:
    ax.scatter(positions + offset, means("joint_vs_scaled", count, drift),
               color=color, label=label, s=58, zorder=3)
ax.axhline(0, color="#343434", linewidth=1)
ax.set_xticks(positions, short, rotation=20, ha="right")
ax.set_ylabel("Joint LP gain over scaled-score balancing LP\n(positive favors joint)")
ax.set_title("Positive and negative results under covariance drift")
ax.legend(ncol=2, frameon=False)
fig.tight_layout()
fig.savefig(OUT / "phase2_drift_and_failure.png")
plt.close(fig)

fig, ax = plt.subplots(figsize=(9, 4.8))
main = [r for r in rows if int(r["B"]) not in (1, int(r["G"]) - 1)
        and int(r["pilot_n"]) == 600 and int(r["drifted_pilot"]) == 0]
per_seed: defaultdict[int, list[float]] = defaultdict(list)
for row in main:
    per_seed[int(row["seed"])].append(float(row["joint_vs_scaled"]))
seeds = sorted(per_seed)
y = np.array([np.mean(per_seed[s]) for s in seeds])
ax.bar([str(s) for s in seeds], y, color=["#4A9379" if z >= 0 else "#C05C54" for z in y])
ax.axhline(0, color="#555555", lw=1)
ax.axhline(float(y.mean()), color="#174D8A", linestyle="--", label="Mean across 12 seed clusters")
ax.set_ylabel("Mean per-seed risk gain: joint minus scaled balance")
ax.set_xlabel("Independent synthetic score/pilot RNG seed")
ax.set_title("Matched pilot N = 600, interior budgets, six covariance families")
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(OUT / "phase2_paired_seed_effects.png")
plt.close(fig)

print(f"Created three figures in {OUT}")
