"""Generate Phase 5 figures exclusively from saved held-out results.

Figures do not select a winner or re-tune methodology; they are descriptive.
"""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def figures(result_dir: Path, output_dir: Path) -> None:
    summary = json.loads((result_dir/'phase5_summary.json').read_text())
    bridge = json.loads((result_dir/'phase5_bridge.json').read_text())['summary']
    if summary.get('quick_smoke_only'):
        raise RuntimeError('figures for the full frozen evaluation only')
    output_dir.mkdir(parents=True,exist_ok=True)
    worlds = summary['new_worlds']
    names = summary['policies']
    matrix = np.array([[summary['worlds'][w]['risk_by_policy'][p]
                        for p in names] for w in worlds])
    fig, ax = plt.subplots(figsize=(11,4.8), constrained_layout=True)
    im=ax.imshow(matrix, cmap='viridis_r',aspect='auto')
    ax.set_yticks(range(len(worlds)), [w.replace('_',' ') for w in worlds])
    ax.set_xticks(range(len(names)), [n.replace('_',' ') for n in names],rotation=25,ha='right')
    for i in range(len(worlds)):
        for j in range(len(names)):
            ax.text(j,i,f'{matrix[i,j]:.3f}',ha='center',va='center',
                    color='white' if matrix[i,j]>np.quantile(matrix,.60) else 'black',fontsize=9)
    ax.set_title('Phase 5: held-out later-half conditional squared gradient risk (lower better)')
    fig.colorbar(im,ax=ax,label='conditional acquisition risk')
    fig.savefig(output_dir/'phase5_risk_heatmap.png',dpi=180)
    plt.close(fig)

    fig,ax=plt.subplots(figsize=(8,4.7),constrained_layout=True)
    x=np.arange(len(worlds))
    vals=np.array([summary['worlds'][w]['gain_scaled_minus_joint']['paired_mean_gain']
                  for w in worlds])
    ax.bar(x,vals,color=['#008e81' if v>0 else '#ba5843' for v in vals])
    ax.axhline(0,c='black',lw=.8)
    ax.set_xticks(x,[w.replace('_',' ') for w in worlds],rotation=27,ha='right')
    ax.set_ylabel('Risk(scaled)-Risk(joint)')
    ax.set_title('Phase 5: gains and losses versus diagonal-scaled balance')
    fig.savefig(output_dir/'phase5_joint_vs_scaled.png',dpi=180)
    plt.close(fig)

    fig, ax=plt.subplots(figsize=(7.4,4.6),constrained_layout=True)
    budgets=bridge['budgets']
    for label in ('linear','normalized','clipped'):
        values=[bridge['per_budget'][str(b)][label]['exact_design_bias_norm']
                for b in budgets]
        ax.plot(budgets,values,marker='o',label=label)
    ax.set_xticks(budgets)
    ax.set_xlabel('Purchased rewards B out of G=6')
    ax.set_ylabel('Mean exact-design bias norm')
    ax.set_title('Naive HT plug-in is unbiased only for the linear target')
    ax.legend()
    fig.savefig(output_dir/'phase5_nonlinear_bridge.png',dpi=180)
    plt.close(fig)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    figures(args.input,args.output)
