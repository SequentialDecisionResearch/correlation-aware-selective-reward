"""Phase6B Calibration-2: checkpointed pilot selection + sealed five-policy evaluation.

Run pilot, inspect results, freeze selection, then evaluate on untouched seeds.
"""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from phase2_grpo.phase6b_calibration2 import (Calibration2Config,FAMILIES,
    PILOT_SEEDS,EVAL_SEEDS,run)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",required=True)
    p.add_argument("--stage",choices=("all","pilot","select","evaluate","summary","audit"),
                   default="pilot")
    p.add_argument("--backend",choices=("hf","fake"),default="hf")
    p.add_argument("--model",default="Qwen/Qwen2.5-0.5B-Instruct")
    p.add_argument("--model-revision",default="main")
    p.add_argument("--device",default="cuda")
    p.add_argument("--local-files-only",action="store_true")
    p.add_argument("--pilot-groups",type=int,default=6)
    p.add_argument("--eval-groups",type=int,default=60)
    p.add_argument("--pilot-seeds",nargs="+",type=int,default=list(PILOT_SEEDS))
    p.add_argument("--eval-seeds",nargs="+",type=int,default=list(EVAL_SEEDS))
    p.add_argument("--families",nargs="+",choices=FAMILIES,default=list(FAMILIES))
    p.add_argument("--warmup",type=int,default=12)
    p.add_argument("--window",type=int,default=9)
    p.add_argument("--exploration",type=float,default=.25)
    p.add_argument("--max-new-tokens",type=int,default=64)
    p.add_argument("--min-positive-rate",type=float,default=.15)
    p.add_argument("--max-positive-rate",type=float,default=.85)
    p.add_argument("--min-diverse-group-fraction",type=float,default=.20)
    p.add_argument("--max-new-groups",type=int,default=None)
    p.add_argument("--max-new-decisions",type=int,default=None)
    a=p.parse_args()
    cfg=Calibration2Config(pilot_groups=a.pilot_groups,eval_groups=a.eval_groups,
        pilot_seeds=tuple(a.pilot_seeds),eval_seeds=tuple(a.eval_seeds),
        families=tuple(a.families),warmup=a.warmup,window=a.window,
        exploration=a.exploration,max_new_tokens=a.max_new_tokens,
        min_positive_rate=a.min_positive_rate,
        max_positive_rate=a.max_positive_rate,
        min_diverse_group_fraction=a.min_diverse_group_fraction,
        backend=a.backend,model=a.model,model_revision=a.model_revision,
        device=a.device,local_files_only=a.local_files_only)
    if cfg.backend=="fake":
        print("WARNING: FAKE backend for unit/mechanics testing; NOT REAL QWEN",flush=True)
    def progress(split,seed,family,task_stage,step,total):
        print(f"COMMITTED {split}/{family}/seed{seed} [{task_stage}] {step}/{total}",flush=True)
    result=run(cfg,a.output,stage=a.stage,max_new_groups=a.max_new_groups,
               max_new_decisions=a.max_new_decisions,progress=progress)
    print(json.dumps(result,indent=2),flush=True)


if __name__=="__main__":
    main()
