# Correlation-Aware Selective Reward Acquisition for Group-Relative Policy Updates

Code and archived evidence accompanying the paper by Shenggang Li, Bilian Song,
Yunfeng Qi, and Joseph Li.

This release contains the Python/R implementations, unit tests, configuration
files, plotting inputs, and archived Phase 1--6D results. It includes all 144
frozen-checkpoint Phase 6D group records. The original optimizer checkpoints
and base-model weights are not distributed.

## Verify archived results (CPU)

From the extracted archive root:

```bash
python -m pip install -e ".[figures]"
python -m unittest discover -s tests -q
python scripts/reproduce_archived_results.py --verify-only
python scripts/reproduce_phase6d_archived.py
python scripts/reproduce_archived_results.py --output reproduced_outputs
```

The Phase 6D replay checks the archived group hashes and recalculates the
conditional acquisition risks using saved LoRA-gradient Gram matrices and all
20 fixed-size subsets. It does **not** rerun GPU autograd or the original LoRA
training. See `README_REPRODUCE.md` and `REVIEWER_VALIDATION.md` for the exact
scope and experimental assumptions.

## Key empirical findings

- At three seed panels, uniform and joint-EWMA acquisition have identical
  final held-out accuracy.
- Among the 96 checkpoint-30/60 conditions, joint selection reduces pooled
  sketch risk by 26.91% but actual saved LoRA-gradient risk by only 3.27%; the
  true-risk effect is negative for one of the three seeds.
- These are conditional risk calculations on archived groups, not evidence of
  an improvement in downstream model accuracy.

## Repository structure

- `src/phase2_grpo/`: methods and acquisition-risk calculations.
- `scripts/`: experimental drivers, audits, and figure generation.
- `tests/`: unit and regression tests.
- `results/`: preserved numerical evidence, including Phase 6D records.
- `docs/`: experimental procedures and protocol history.
- `reproduced_outputs/`: illustrative outputs produced from archived evidence.

The manuscript and compilable LaTeX source are distributed separately. The
code archive keeps the established reviewer-reproducibility filename even
though it now includes Phase 6D.
