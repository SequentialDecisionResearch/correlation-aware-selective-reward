# Phase 6A delivery audit and scope declaration

## Verification completed without GPU

- The full repository's offline `unittest` discovery runs 73 tests to completion.
- Python source compilation succeeds with `python -m compileall -q src scripts`.
- A two-invocation fake-backend command-line rehearsal checkpoints groups 1–4,
  resumes at group 5 without rerunning 1–4, finishes all 12 groups and all
  60 matched policy decisions, and passes the internal independent replay.
- Unit tests reproduce the exact decision records of an interrupted experiment
  versus an uninterrupted one, including `joint_frozen` state restoration.
- A simulated exception during generation preserves already committed groups.
- Corrupting a record's bytes causes a SHA-256 integrity error, not a silent
  recovery with potentially different data.
- A mixed correct/incorrect *test-only* oracle produces nonzero exact risk,
  normalized plug-in error, a complete paired CSV and a passing audit.
- The restricted token-logit-bias score's analytical formula agrees with an
  independent finite-difference numerical check on a small vocabulary.

## NOT verified in this environment

- Actual Qwen2.5-0.5B-Instruct weight loading, GPU generations, throughput,
  RTX 5070 VRAM consumption and tokenizer/model-version compatibility were
  **not run**: the execution environment lacks Torch, Transformers, Qwen
  checkpoint weights and an accessible GPU. The first **two-group GPU smoke
  test** in `PHASE6A_RUN_GUIDE_ZH.md` is mandatory before the 120-group run.
- Generated statistical conclusions on Qwen outputs, significance, training
  gain, external reward cost saving and generalization are **not claimed**.

## Methodological safeguards

1. Every experimental run stores its exact source fingerprints and settings
   in `manifest.json`; resume rejects modified settings or source.
2. Each completed generation and each acquired-budget decision has its own
   checksum-validated, atomic checkpoint. No model reload is needed to resume
   the evaluation stage.
3. Identical frozen-generated groups are evaluated with exact B=3 budgets
   under five policies. Full labels are a separate cheap retrospective ledger;
   adaptive learners see only their selected three rewards.
4. Results distinguish exact conditional linear randomization risk, realized
   linear error, exact nonlinear normalized plug-in bias and squared error.
5. The "Cube" group in this Qwen stage uses the project's **Python** classic
   cube algorithm; actual official **R** `BalancedSampling` comparison belongs
   to the separate Phase 4 validation and is not mislabeled here.
6. 120 groups with one main seed are a pilot, not independent confirmation.
   Reward 0/1 saturation is possible and can make all methods' risks near
   zero. Preserve such negative or inconclusive findings.

Run from the extracted project root:

```bash
PYTHONPATH=src python -m unittest discover -s tests -q
python -m compileall -q src scripts
python scripts/check_phase6a_env.py
```
