# Phase 6B + 6C：完整执行、断点恢复和结果审计

**v1.2（2026-10-25，优先阅读）：** 96-token 真实 GPU 冒烟测试表明，
`Therefore, the answer is 320.` 被旧评分器误记为零。v1.2 已修正明确
最终答案的解析，将数值正确率和严格单个 `\boxed{N}` 格式合规率分开记录，
并从简单题中移除了无关的 `mod` 说明。旧 Phase6A/B/C 断点不得在 v1.2
继续恢复，必须使用**新结果目录**；旧数据完整保留。
先看 `PHASE6_V12_REWARD_PROMPT_AMENDMENT.md`，再运行下方命令。

**2026-10-25 修订提示：** 已根据真实 RTX 5070 的首次运行修复 Phase6C
heldout 生成时遗漏的 `attention_mask`。24-token 冒烟测试的 18 个训练/
采样奖励全部为零、首步梯度范数为零；这属于长度不足引起的无信号测试，
不能用于判断抽样策略优劣。先做 96-token 奖励密度校准，详情见
`PHASE6C_V11_NOTE.md`。修订源码后不要续跑旧版 Phase6C 断点。

更新时间：2026-10-23。目标电脑：Windows 11 + WSL2、NVIDIA RTX 5070 12GB。

## 一、先澄清三个严格区别

1. **Phase 6B**：冻结 Qwen 模型；使用独立的新题库、新种子和漂移场景，比较 5 种 B=3、G=6 奖励抽样策略。不更新模型权重。
2. **Phase 6C**：在同一个真实 Qwen2.5-0.5B-Instruct 模型上分别训练 3 个 LoRA 模型：`full`（完整 6 个奖励）、`uniform`（随机 3 个奖励）以及 `joint_ewma`（协方差自适应选 3 个奖励）。保存优化器/随机数状态和模型适配器。
3. **软件测试 vs 研究证据**：`--backend fake`、测试 FakePolicy 仅测试算法/存盘/审计；它们从未运行真实 Qwen 权重，绝不能作为 LLM 实验成功的证据。首次 GPU 运行必须由研究者在目标机器完成。

本实验的标准 `loo_ht` 是无标准化的 leave-one-out + Horvitz–Thompson 策略梯度估计，属于 GRPO 思想衍生的**自定义 LoRA 训练实现**，不声称复制 Hugging Face TRL `GRPOTrainer` 全部细节。`normalized_plugin` 有偏，仅用作额外消融。详见 [`PHASE6B_6C_RESEARCH_PROTOCOL.md`](PHASE6B_6C_RESEARCH_PROTOCOL.md)。

## 二、第一次安装（在 WSL2 Ubuntu 的项目根目录）

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

根据 [PyTorch 官方安装选择器](https://pytorch.org/get-started/locally/) 选择 NVIDIA RTX 5070 当前支持的 CUDA wheel 安装命令。随后：

```bash
python -m pip install -r requirements-phase6c.txt
python scripts/check_phase6a_env.py
python -m unittest discover -s tests -q
```

上面的 requirements 使用现有 `.[llm]` 依赖，加装 PEFT，并约束 Transformers 4.x，避免未经验证的 5.x 大版本升级。若你的 CUDA/PyTorch 安装与此环境不兼容，应先修环境，不要更改已经开始运行的实验配置和锁定代码。

## 三、Phase 6B：先软件预检，再真实新场景

无 GPU 的快速软件 QA：

```bash
python scripts/run_phase6b.py \
  --backend fake --groups 12 --seeds 8123 8249 8311 \
  --scenarios word_to_mod interleaved_control \
  --warmup 2 --window 3 --max-new-tokens 16 \
  --output results/phase6b_fake_qa
```

真实冻结 Qwen 的完整独立验证（**不要**把 fake 的目录拿来作为真实实验目录）：

```bash
python scripts/run_phase6b.py \
  --backend hf --groups 80 --seeds 8123 8249 8311 \
  --scenarios word_to_mod interleaved_control \
  --warmup 20 --window 12 --max-new-tokens 96 \
  --output results/phase6b_qwen_holdout
```

其中的 `word_to_mod` 在中途从文字算术切换为取余运算，`interleaved_control` 穿插两类题型。每次仅生成 6 条候选；每个策略逻辑上购买 3 个奖励；影子评价器免费地重评所有 6 条，并与在线学习器隔离。共 **6 个 cell × 80 组 × 5 个策略 = 2400 条已选择策略决策**、480 次冻结模型生成（共最多 2880 个 completions）。

中断后**重新执行完全相同的命令**即可续跑。也可分开阶段运行：

```bash
python scripts/run_phase6b.py --backend hf --stage collect \
  --groups 80 --seeds 8123 8249 8311 \
  --scenarios word_to_mod interleaved_control \
  --warmup 20 --window 12 --max-new-tokens 96 \
  --output results/phase6b_qwen_holdout
```

更换 `--stage evaluate`、`--stage summary`、`--stage audit` 继续使用相同的其他参数与路径。**启动新种子、修改任何参数、修改程序源码都要使用全新的 output 目录。** 程序逐条校验 SHA-256，并对生成模型指纹进行跨 cell 比对；更改模型会主动报错。

核心输出：`phase6b_summary.json`、`phase6b_audit.json`、`phase6b_group_policy_metrics.csv`；每个 cell 的单条记录见 `cells/*/generations/`、`cells/*/acq_*/`。回归测试中看到的 fake 实验结果不代表真实 Qwen 的优劣。

## 四、Phase 6C：先小规模真实 LoRA smoke

这一部分**会改变 LoRA 参数**，且每个臂都从同一个冻结底座和相同的初始 LoRA 随机数种子出发。模型底座和 tokenizer 是 Qwen2.5-0.5B-Instruct；底座本身不更新。

先运行最小 GPU 端到端检验（6 步 × 3 臂，**不能当论文结果**）：

```bash
python scripts/run_phase6c.py \
  --steps 6 --seed 6207 --warmup 2 --window 3 \
  --max-new-tokens 24 --eval-every 2 --eval-size 6 \
  --output results/phase6c_real_gpu_smoke
```

重点检查：是否下载/加载模型、LoRA 是否有可训练权重、是否真正完成了 `optimizer.step()`、每个臂是否产出优化器状态 `.pt`、最终 `phase6c_audit.json` 是否为 `pass=true`。仅 audit 通过不足以证明 CUDA/PEFT 训练可正常运行；第一次必须真实跑完 smoke。

完成 smoke 后才启动预定的主实验：

```bash
python scripts/run_phase6c.py \
  --steps 60 --seed 6207 --train-schedule easy_to_hard \
  --warmup 12 --window 9 --max-new-tokens 64 \
  --eval-every 10 --eval-size 24 \
  --objective loo_ht --update-epochs 1 \
  --output results/phase6c_qwen_seed6207
```

建议另一独立任务顺序作为**不同的预定义场景**测试：`--train-schedule interleaved`，务必另选输出目录。最终多种子重复可以保留其他参数，只分别换 `--seed 6269`、`--seed 6311` 以及输出路径。

如希望每次最多只执行 5 次参数更新，可在完全相同命令尾部加 `--max-new-steps 5`。再次运行时程序会从最后一条已提交的步数继续，而非从零开始。

训练每一步写入两个互相配套的断点：

- `arms/<arm>/optimizer_states/after_step_XXXXXX.pt`：当步 LoRA 适配器参数、AdamW 状态、CPU/CUDA RNG 状态；写临时文件并原子替换。
- `arms/<arm>/train_steps/group_XXXXXX.json`：只有在 `.pt` 完整写入且计算 SHA-256 后，才写入这条**正式提交记录**。重启时若最新 `.pt` 丢失或校验和不符，会拒绝恢复。

每个臂的设计选择与少量已购奖励通过历次 JSON 原样重放恢复。未提交的最后一步可能需要重做，但不会重做此前全部训练。**不要删除或人工修改 output 下的任何内容。** 保留所有 checkpoint 会占用一定硬盘容量。

主实验输出：`phase6c_learning_curves.csv`、`phase6c_summary.json`、`phase6c_audit.json`，以及每个臂的每步原始生成、付费奖励掩码、估计优势、训练损失和 heldout accuracy。`genuine_model_updates=true` 只在三个臂均完成且运行信息指向真实 LoRA 后报告。

## 五、独立多种子汇总（不需要再次载入大模型）

以下命令要求每个输入目录都有完整的三臂结果、审计通过、模型真实更新，而且除了 `seed` 外其他参数全部一致：

```bash
python scripts/aggregate_phase6c.py \
  --runs results/phase6c_qwen_seed6207 \
         results/phase6c_qwen_seed6269 \
         results/phase6c_qwen_seed6311 \
  --output results/phase6c_multiseed_analysis
```

它输出 `phase6c_seed_pairs.csv`、`phase6c_multiseed_summary.json`，包括自适应相对均匀、相对全反馈的配对改善与种子聚类描述性 t 区间。少量随机种子并不能构成总体性能保证；如果结果不稳定，应如实报告，而不是继续挑种子直到显著。

## 六、遇到报错怎么处理

| 现象 | 处理 |
|---|---|
| `checkpoint/config mismatch` | 运行参数或源码或 Python/NumPy/SciPy 版本变化；恢复原环境，或新建结果目录重新做独立实验；**不要手工修改 manifest**。 |
| `model/weights/PyTorch fingerprint changed` | Hugging Face `main` 解析到了不同底座版本；改回原模型版本，或用新目录开始新的实验。 |
| `checkpoint missing or corrupt` | 对应优化器状态文件无法校验；保留目录供诊断，不能跳过损坏步继续训练。 |
| `CUDA required` / `out of memory` | 优先验证 WSL NVIDIA/CUDA 与 PyTorch wheel；降低 smoke 的最大生成长度/评价数，注意更改实验配置须换新目录。 |
| 显示 `fake` | 仅用于验证软件，不属于 LLM 训练结果。 |

最后请把 `phase6b_qwen_holdout/`、各 `phase6c_qwen_seed.../` 的汇总、审计和运行日志发回供独立复核；不要只提供最好看的图表。

