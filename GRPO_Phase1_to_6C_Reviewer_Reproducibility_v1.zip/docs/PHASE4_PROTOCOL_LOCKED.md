# Phase 4: internally locked independent audit protocol

**Defined before the first full Phase 4 holdout execution on 2026-10-23.**
This is a transparent internal freeze of source and seed lists, **not** an
externally registered experiment. For reproducibility the JSON output
records SHA-256 hashes of the evaluated source files.

## Research goals

1. Exercise the actual official CRAN `BalancedSampling::cube` algorithm,
   independently of the finite-tree Python flight/landing code.
2. Evaluate exactly frozen Phase-3 policies and a new bounded-exposure guard
   on disjoint random seeds and unseen residual-covariance trajectories.
3. Distinguish improved detector sensitivity from actual risk improvements,
   especially false alarms under stationarity and harmful fallback switches.

## A. Genuine R reference

The independent R reference is **actually executed** with
`BalancedSampling::cube(prob,x)` from the CRAN `BalancedSampling` package,
version 2.1.1. Inputs place `pi` as the first balancing variable. We use
5,000 R random samples in each of five distinct designs: equal G=6,
heterogeneous G=7, feasible exact balance G=4, rank-deficient G=8, and
anisotropic inclusion G=6. Inputs and draws are saved, so reported R
inclusion rates are reproducible Monte Carlo estimates. Python reports exact
probabilities and exact risk via its finite tree, not empirical rates.

The R and Python implementations need not induce identical distributions.
We test sample size, binomial Monte Carlo inclusion deviations, auxiliary
Horvitz--Thompson balancing loss, and a separately chosen fixed quadratic
gradient-risk functional. The latter is a synthetic diagnostic and not an
LLM training result.

## B. Frozen holdout sampling plan

The previously implemented parameters are unchanged:

- Group size `G=6`; exact purchased count `B=3`; 160 decisions per run.
- Common first-order inclusions `pi_i=0.5`.
- Uniform exact-B exploration mixture `epsilon=0.25`, giving every pair
  inclusion probability at least `0.05`.
- Uniform startup warm-up 26 steps; online second-moment EWMA 0.075,
  diagonal shrinkage 0.08, PSD ridge 0.02.
- Original drift-gated candidate has its prior 1.30 threshold,
  two 18-step windows and 24-step cooldown; **no Phase-3 tuning**.
- The original six Phase-3 policies are compared alongside one new
  `guarded_partial` method. Every policy receives the same score sequence,
  latent error vector, and exact gold-label budget, with independent
  policy-specific acquisition RNG.

**New holdout seeds (not used in Phase 3):**

`2017, 2027, 2039, 2053, 2063, 2081, 2089, 2111, 2129, 2137, 2153, 2161`.

**New held-out worlds (not used to tune the new detector):**

1. Fixed heteroscedastic signed factor (negative-control stationarity).
2. Fixed heterogeneous Student-t-5 factor (heavy-tail negative control).
3. Abrupt rotation between two distinct rank-one factors at step 80.
4. Gradual linear covariance mixture during steps 35--130.
5. Periodic covariance oscillations with a 46-step period.
6. Late 2.25x variance and factor shock at step 118.
7. Student-t-5 residuals with factor switch at step 92.

All synthetic covariance matrices are strictly PSD by positive uniqueness
terms; the Student-t-5 draws use variance-one scaling. The evaluator sees
true conditional V, whereas each acquisition policy sees only scores and
previously purchased residuals. The model parameter vectors are *never*
updated, so the scope remains online query acquisition, not LLM training.

## C. Independently calibrated clipped monitor

The new monitor receives only purchased residuals and actual pair
propensities. It uses the arithmetic design-IPW matrix
`Z_i Z_j e_i e_j / pi_ij`, clips each **monitoring contribution only** to
Frobenius norm 18, and contrasts two sequential 18-step means. The online
EWMA second-moment learner itself is **not clipped** by this monitor.

Requiring **three consecutive** threshold crossings suppresses one-off
outlier alerts. The threshold is obtained **before holdout labels are
examined**, from 32 distinct calibration seeds
`3101, ..., 3132` applied to four Phase-3 stationary covariance profiles;
one profile also uses Student-t-5 errors. The calibration statistic is the
maximum running three-window minimum in each 160-step null trajectory. Its
empirical 90th percentile is frozen as the threshold.

This approximates a ten-percent *calibration-distribution* trajectory-level
alarm probability; it does **not** guarantee 10% family-wise error under
arbitrary distributions, nonstationarity, sequential peeking, or adaptive
sampling. The held-out stationary profile is deliberately different.

## D. Damage-limited covariance-informed rollback

The guarded method calculates an adaptive full-moment LP proposal and a
diagonal auxiliary-balancing fallback before observing the current reward.
With identical prescribed marginals, a mixture

`Q_lambda = (1-lambda)*Q_joint + lambda*Q_base`

retains exact budget, exact marginals, and pair support after adding the
unchanged exploration mixture. More importantly, for any fixed second-moment
matrix V and score matrix S,

`Risk(Q_lambda)-Risk(Q_joint) = lambda*(Risk(Q_base)-Risk(Q_joint))`.

This **exact algebraic identity** limits the *fraction of risk difference*
incurred by a mistaken full fallback. It does not give an absolute upper
bound on risk or a formal safety guarantee.

After a persistent alarm the mechanism continues with a 24-step cooldown.
It tests the most recent 24 previously observed IPW second-moment
contributions using the current pre-query gradient geometry. The baseline
is judged preferable only if a clipped empirical mean risk contrast plus
two descriptive standard errors is negative. The mixture probability is:

| Observed history/condition | Fallback mixture fraction |
|---|---:|
| Ordinary well-covered history, no alert | 0 |
| Pair ESS below 1.5 | 0.10 |
| During alarm cooldown, no evidence baseline is better | 0.05 |
| During cooldown, historical evidence favors baseline | 0.25 maximum |

These were fixed **before** examining any independent holdout outcomes.
Statistical inference from the empirical two-standard-error gate is
heuristic: adaptive IPW, dependent windows and changing V invalidate a
naive conventional Gaussian interval without additional assumptions.

## E. Pre-stated decision criteria for real LLM expense

The case for even a *small* real LLM/real-verifier pilot is materially
stronger only if all the following exploratory gates are satisfied:

1. The actual R benchmark confirms correct exact cardinality and plausible
   empirical prescribed marginals for every case.
2. On the independent holdout, the mean **seed-paired** later-half
   conditional risk of `guarded_partial` beats `joint_ewma` overall, with a
   positive lower endpoint of the descriptive 95% seed-cluster t interval.
3. In both genuinely stationary held-out controls, the guard does not
   increase mean conditional risk by more than 5% compared with `joint_ewma`.
4. Fewer than 10% of stationary held-out runs contain any guard alarm.
5. No unexplained implementation/test failures, propensity violations or
   evaluation-to-acquisition leaks remain.

Failing a gate is not a reason to tune on this holdout and claim independent
confirmation. The next development iteration would require a **new** holdout.

The underlying scientific question also requires real verifier economics,
an actual optimized GRPO objective, and task success once a GPU pilot begins.

## Executables

```bash
python scripts/run_independent_holdout.py --quick
python scripts/run_independent_holdout.py --output results/phase4_frozen_holdout_full
python scripts/make_phase4_holdout_figures.py --input results/phase4_frozen_holdout_full
R_LIBS_USER=/path/to/installed/R/library python scripts/r_cube_reference_suite.py
```

All outcome tables will be labeled either calibration, smoke, or independent
holdout in their corresponding JSON and CSV artifacts.
