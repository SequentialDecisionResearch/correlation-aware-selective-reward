# Phase 5: final confirmatory reinforcement and internal independent-code audit

Protocol written **before executing any Phase-5 confirmatory run**, 23 October 2026.
It is internally locked and **not externally preregistered**. Prior Phase 1--4
results are treated as development data. This document is not a manuscript.

## Scope and estimands

We evaluate the **unnormalized, one-step LOO group-gradient** acquisition
risk under exact budget B=3, G=6, and common first-order inclusion
probabilities pi_i=0.5. We do not evaluate LLM parameter updates, real
verifier monetary costs or generalization to clipped GRPO. The primary
endpoint is the **paired later-half oracle-evaluation-only conditional
squared gradient risk**, averaged first within independent seed, then over
seeds and worlds. Full latent residuals and true V are NEVER exposed to the
acquisition policy. The word *oracle* denotes evaluator access only.

## Frozen algorithm and comparisons

Use the unchanged Phase-4 `OnlineConfig` with G=6, B=3, horizon 160,
warmup 26, window 18 and uniform exact-B exploration epsilon=0.25.
No parameter tuning from Phase 5 will occur. Compare exactly:

1. uniform (budget-controlled reference),
2. `cube_classic` (Python cube-style algorithm; **NOT** official R Cube),
3. `scaled` (score auxiliary LP using historical diagonal second moments),
4. `joint_ewma` (online plug-in PSD second moments),
5. `joint_frozen` (one post-warmup plug-in PSD matrix, then frozen).

The genuine R/CRAN Cube implementation was separately benchmarked in
Phase 4 with 25,000 actual samples, but the Phase 5 online `cube_classic`
comparator is not to be misrepresented as that official backend. A further
official R comparison can be reported separately only with real R draws and
identical auxiliary vectors; it must not silently enter the online table.

## Previously untouched seeds, test worlds, and end points

New Phase-5 seeds: 4001, 4003, 4007, 4013, 4019, 4021, 4027, 4049,
4051, 4057, 4073, 4079, 4091, 4093, 4099, 4111. None is used in the
Phase 3/4 development, calibration or holdout sets. The generator has an
independent namespace `[20261113, seed, scenario_index]`.

Test worlds, all specified before evaluation, are:

- stationary independent, with distinct marginal scales (negative control);
- stationary positive-factor covariance (unseen loading structure);
- stationary heavy-tailed sparse-block covariance (t5 shocks);
- abrupt sign-switch of a covariance factor at step 68;
- two abrupt block-to-factor changes at steps 52 and 112;
- smooth sigmoid factor interpolation, midpoint step 92.

These are new *families* of profiles, not a claim that no analogous model
has ever appeared in earlier development. World covariances are positive
definite and genuine second moments of zero-mean generated residuals.

Prespecified comparisons:

- P1: mean later-half `risk(scaled)-risk(joint_ewma)` across the six worlds;
- P2: mean later-half `risk(uniform)-risk(joint_ewma)`;
- P3: mean later-half `risk(joint_frozen)-risk(joint_ewma)`;
- count of worlds for which P1 > 0; seed-cluster t95 intervals are
  *descriptive*, not guaranteed frequentist confidence statements over all
  possible covariance environments.

The independent world (with V strictly diagonal) must show **zero design
coupling benefit for all methods** up to numerical precision because pi is
fixed. Realized errors still have sampling noise.

## Nonlinear GRPO bridge: frozen negative/positive controls

Using fresh independent arrays (`seed=20261115`) for 64 groups with
G=6, d=3, B in {1,2,3,4,5}, consider full-reward normalized advantages
and clipped objectives. For each fully specified group and each exact-B
uniform sampling design, compute the **exact expectation over all subsets**
of the naive plug-in normalized/clipped HT reward reconstruction.
Report vector bias norms and mean squared errors separately from the
linear LOO target; the linear target must remain unbiased to floating-point
precision. This is **not** real GRPO training, and it proves no universal
nonlinear estimator impossibility by simulation alone.

Mathematical analysis will separately state an interaction-order
obstruction for any exactly B-label estimator, and exhibit a numerical
witness for group normalization using an auditable finite-difference test.

## Audit and go/no-go

An audit process distinct from the simulator implementation will load the
saved CSV and: (i) recompute every method's grouped risk and seed-paired
contrasts; (ii) verify exact budget, positive pair support, absence of
duplicate decisions and disjoint seeds; (iii) check empirical pair-moment
prediction error by method, risk-oracle inequality and diagonal negative
control; (iv) compare raw machine summary against recomputed values;
(v) test the bridge's exact linear unbiasedness and finite-difference
obstruction. This is an **independent code-path internal audit**, not a
third-party scientific audit.

No formal claim of publication readiness can be made merely because tests
pass. A positive paired comparison on new simulations supports the narrower
surrogate claim only. If P1 fails, report the failure and do not retune on
these seeds. If it passes, assess theory/GRPO bridge before choosing whether
to buy a small real-model study.

## Artifacts and reproducibility

Save `phase5_trials.csv`, `phase5_summary.json`,
`phase5_bridge.json`, `phase5_audit.json`, source hashes and version
details. Never overwrite original Phase 4 results. Keep positive and
negative outcomes, including comparisons that reverse direction.
