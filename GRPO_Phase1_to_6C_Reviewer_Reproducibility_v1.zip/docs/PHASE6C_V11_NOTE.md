# Phase 6C v1.1 — heldout-mask correction and zero-reward pilot diagnostic

Date: 2026-10-25. **This is a code-correctness fix, not evidence of algorithmic improvement.**

## Observed genuine-GPU pilot

The initial Windows 11 / RTX 5070 pilot successfully loaded actual Qwen2.5-0.5B-Instruct and wrote a real LoRA/AdamW checkpoint for the first training step. But the 24-token configuration yielded:

- Phase6B, two groups: 12/12 generated completions reached the 24-token limit without a parseable final correct integer; all 12 exact rewards were zero.
- Phase6C first full-feedback group: all 6 binary rewards were zero; the logged gradient norm was **exactly 0.0**. The AdamW step and checkpoint were real operations, but that step had **no effective reward-based parameter update**.
- Initial Phase6C heldout accuracy was 0/6 and parseability 50% under the same short output cap.

These outcomes say nothing about the relative effectiveness of the five sampling designs: without reward variation, the true design risk is zero for every method. We must calibrate reward density BEFORE committing GPU time to a full study.

## Concrete source correction

`src/phase2_grpo/phase6c_model.py` now passes

```python
attention_mask=torch.ones_like(prompt)
```

to the greedy `model.generate()` invocation in `RealLoRAPolicy.evaluate()`.
This addresses Transformers' explicit warning that attention masks cannot be
inferred when the pad token and EOS token are the same. Generation during
training already provided the mask; **only the heldout evaluation was missing
it**. A fake-model integration test now asserts mask presence and correctness.

The harmless `torch_dtype` deprecation and neutral generation flag warning
are not changed by this narrow fix, to avoid unrelated changes to the data
generating process. The statistical objective and reward function are also
unchanged.

`src/phase2_grpo/phase6c_training.py` additionally distinguishes
`real_optimizer_steps_committed_by_arm` from
`nonzero_gradient_steps_by_arm`. The former counts actual saved calls; the
latter counts steps whose logged pre-clip gradient norm was positive.
`genuine_model_updates` is now false if no nonzero-gradient steps were
observed in any arm, even when all optimizer calls and checkpoints succeeded.
This tightens **reporting only**, without changing which rewards, advantages
or model loss are used to train.

## Next calibration (existing 6B source remains identical)

Run from the project directory, using the original Phase6B code:

```bat
python scripts\run_phase6b.py --backend hf --groups 12 --seeds 8123 --scenarios word_to_mod --warmup 2 --window 3 --max-new-tokens 96 --output results\phase6b_qwen_calibration96
```

Inspect the stored per-group `shadow_oracle` binary rewards and generation
lengths. If all rewards are still zero, pause; consider an easier preregistered
arithmetic benchmark, better answer-format prompting, or longer generation
length, each documented as a new **exploratory** calibration. Do not simply
declare an algorithmic null result from constant outcome vectors.

Once a nondegenerate fixed benchmark and adequate token length are determined,
start a **new Phase6C output folder**. For example, a 96-token GPU smoke:

```bat
python scripts\run_phase6c.py --steps 6 --seed 6207 --warmup 2 --window 3 --max-new-tokens 96 --eval-every 2 --eval-size 6 --arms full --max-new-steps 1 --output results\phase6c_real_gpu_smoke_v11_96
```

**Do not resume** `results\phase6c_real_gpu_smoke` from the earlier code.
Phase6C includes its own source hashes in the checkpoint manifest, so a
v1.1 recovery must use a new output directory. The old data are preserved as
diagnostic evidence; no previous results need to be deleted.

## Windows hotfix installation

If you already have the full Phase6ABC v1.0 project extracted, you do not
need to replace the entire tree. Extract the companion
`Phase6C_MaskFix_v1_1.zip` **inside**
`C:\lsg\corr_grpo\phase4_holdout_grpo`, preserving paths. Replace
`src\phase2_grpo\phase6c_model.py`,
`src\phase2_grpo\phase6c_training.py`, and
`tests\test_phase6b_6c.py` with their v1.1 counterparts. The hotfix also
includes this note. Other source files, history, and results remain unchanged.
Then run:

```bat
python -m unittest discover -s tests -q
```

Alternatively, use the complete v1.1 project ZIP in a NEW sibling folder.
Keeping v1.0 archived is useful for reconstructing its actual smoke tests.
