# Evidence and limitations ledger

> **Foundation ledger, preserved:** this file records the original 26-test,
> 132-cell reconstruction. The new same-marginal balancing experiment has its
> **own** complete ledger in `PHASE2_BALANCING_STUDY.md`, with 35 combined
> passing tests and 1,008 additional cells. In particular, the earlier
> blanket statement "no balancing comparison" is superseded by a new
> score- and variance-scaled **global auxiliary-balancing LP** benchmark and
> a cube-**style** flight/pair-landing comparison. A faithful external
> Deville–Tillé cube implementation and real verifier remain open.

Date: 2026-10-23. This file is intended to make every scientific claim independently checkable. It is not a peer-review certificate.

## Source provenance

Three uploaded historical materials were read as references:

1. `Correlated_GRPO_Phase1_Independent_Audit_2026-10-21(2).pdf` — historical 16-page external audit, **not authored anew**.
2. `GRPO_Verifier_Three_Dialogues_Verbatim(2).pdf` — historical 15-page dialogue record, **not passed off as a fresh verbatim transcript**.
3. `Correlated-GRPO_code(4).zip` — original experimental software, examined for conceptual flaws but **not reused as a code base**.

The new mathematical PDF replaces the fragmented prior theory/dialogue **functionally**, with proofs, full assumptions, a research protocol and provenance. The new reconstruction PDF replaces the *practical purpose* of an audit but is **not a new external independent audit**. The new ZIP replaces the old code.

## Audit findings and reconstruction actions

| Historical issue | Phase 2 response | What remains open |
|---|---|---|
| F1 log-squared residual regression targets geometric rather than arithmetic second moment | Pooled IPW estimation of `e_i e_j`, with unit-normal regression test and PSD displacement tracking | Conditional `V(F0)` learning with finite-sample calibration |
| F2 exact-size marginal decomposition failed near legitimate boundaries | Feasibility LP and analytic `B=1`, `B=G-1` constructions | Larger dimensions, extreme ill-conditioning and reproducibility across LP solvers |
| F3 leakage test was too permissive | `CountingOracle` grants only purchased coordinates; unit tests reject unrevealed access | This is an API boundary, not a hardened security sandbox |
| F4 pair positivity needed separately | `pair_supported`, pair ESS and explicit `pi_ij` | Model-based extrapolation needs externally justified structure |
| F5 no real verifier | Honest synthetic count only | True verifier adapter and wall-time/dollar measurement |
| F6 seed configuration was not executed | Actual four-seed design grid and six-paired-seed training loop | Confirmatory power and preregistration |
| F7 gradient cosine not final reward | Separate gradient-risk and terminal expected-reward fields | Large-scale, statistically powered modern RL experiments |

## Executed verification

The **actual** commands used were:

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -v
python3 scripts/stress_marginals.py
PYTHONPATH=src python3 -m phase2_grpo --output results/full
MPLCONFIGDIR=/tmp/phase2-matplotlib python3 scripts/make_figures.py
```

Observed outcomes:

| Evidence item | Exact or displayed observation | Input/output |
|---|---:|---|
| Python standard-library unit tests | 26/26 pass | `tests/` |
| Fresh feasible-marginal stress instances | 2,600/2,600 pass | `scripts/stress_marginals.py`, `results/marginal_stress.json` |
| Maximum marginal error | 8.154296434570674e-11 | `results/marginal_stress.json` |
| Mathematical score-balance counterexample risks | 0 and 16 | `results/full/counterexample.json` |
| Monte Carlo high-risk estimate | 15.937660417331248 | `results/full/counterexample.json` |
| Distinct grid rows | 132 | `results/full/design_grid.csv` |
| Grid mean oracle gain | 0.14262453613590137 | `results/full/summary.json` |
| Grid mean practical gain | 0.13699916993784642 | `results/full/summary.json` |
| Fraction of all grid rows practical > baseline | 0.30303030303030304 | `results/full/summary.json` |
| Paired toy training runs | 6 seed pairs / 12 trials | `results/full/toy_training.csv` |
| Mean terminal reward, uniform | 0.5409392123860414 | `results/full/summary.json` |
| Mean terminal reward, joint | 0.5519019106148951 | `results/full/summary.json` |
| Mean paired terminal difference | 0.01096269822885367 | `results/full/summary.json` |
| Illustrative two-sided paired 95% t interval | [−0.014376310318712114, 0.03630170677641945] | `results/full/summary.json` |

The high-risk Monte Carlo estimate approximates 16; it is not a deterministic bound. The six-pair *t* interval depends on assuming approximately independent paired seed differences; its purpose is to expose uncertainty, and it **contains zero**. The small positive mean terminal reward difference is a development observation, not a valid powered claim. The 132-row mean includes mathematically forced zero-gain controls, so its sign and size must not be represented as an average over real verifier tasks.

## Claims: proved, simulated, or open

**Proved, conditional on explicit assumptions**: unnormalized LOO expectation; model-assisted Horvitz–Thompson conditional unbiasedness; acquisition covariance/risk; exact fixed-marginal LP reduction; no coupling freedom at `B=1` or `B=G-1`; additive pair-weight no-gain sufficiency; common-mode score-balance cancellation; missing-pair nonidentifiability; bounded pooled-moment concentration; deterministic plug-in design regret; valid-radius two-design safe switch.

These are not all novel mathematical claims: most come from sampling or elementary optimization theory. Novelty must be established against the cited work. The source PDF includes transparent proofs and their assumptions.

**Simulated checks**: 26 unit regressions, 2,600 boundary inputs, one analytically checkable construction, 132 grid rows, 12 tiny training runs. The covariance model, calibration stationarity and reward generation are deliberately simple. All data and reward-oracle call counts are synthetic.

**Not demonstrated**: prompt-conditional covariance guarantees, correct clipped/token GRPO gradient, actual expensive LLM verifier, reduction of real wall-clock or billed cost, reliable terminal policy improvement, large-group global LP feasibility, full novelty relative to balanced surveys and active U-statistics.

## Mandatory caution about the validity radius

The optional safe switch consumes an **externally valid** matrix error radius. The pooled estimator does *not* by itself provide a valid prompt-conditional Frobenius confidence ball. If a caller learns the radius by looking at inaccessible current gold rewards, the gate becomes invalid. Keep the lower-bound and upper-bound derivation separate from how a future statistical procedure certifies the radius.

## Reproduction and submission rule

The present artifacts qualify as a rigorous continuation of a research project and a useful self-contained code/test foundation. They do **not** qualify for any statement that "a new GRPO method was validated on real LLM post-training." A journal submission should await a prespecified confirmatory comparison including balanced/cube sampling, held-out conditional residual estimation, true verifier costs, terminal outcomes and uncertainty intervals.
