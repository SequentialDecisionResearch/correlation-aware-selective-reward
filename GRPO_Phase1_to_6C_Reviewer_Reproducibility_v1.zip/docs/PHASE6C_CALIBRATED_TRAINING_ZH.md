# Phase 6C 针对性修订：真实 Qwen LoRA 参数更新与奖励多样性

版本：2026-10-25 / Phase6C calibrated revision。继承 Phase6B Calibration-2 的
已独立锁定任务族 `two_digit_add`。这是**新增训练命令**，不是对旧 Phase6C
实验的追认或静默重写。使用新结果目录，保留全部原有数据。

## 1. 可验证的依据与研究边界

用户已经完成真实 `hf` Phase6B Calibration-2：先独立选择任务，随后在三个新的
随机种子上评估 `two_digit_add`，共180个生成组、900个采样决策、84个校准组；
内部审计全部通过。122/180个评估组有2–5个正确回答；相对Uniform的
平均**线性设计代理风险**降低为：Cube Classic 15.75%、Scaled 17.37%、
Joint EWMA 20.06%、Joint Frozen 12.97%。这些不是 LoRA 实际训练结果。

旧 Phase6C 96-token smoke 使用不同的困难任务协议，产生全零奖励和零梯度。
本修订测试能否在已校准任务族上进行**真实参数学习**，不假设风险改善
一定转化成最终准确率改善。

新增训练程序：`scripts/run_phase6c_calibrated.py`。

- 默认任务族 `two_digit_add`，与 Phase6B 采用同一评分器和 final-answer 格式。
- 启动前读取 `calibration2_selection.json`、`calibration2_summary.json` 和
  `calibration2_audit.json`，要求 `selected`/`complete`/`pass` 且180组、900条均齐备。
  三文件原始字节的合并 SHA256 冻结到实验 manifest 中。
- 训练题目和 heldout 题目从新的独立随机空间生成。除去同序和逆序求和重复，
  并严格排除先前 Phase6B 校准/评估的题目。
- 仍使用三条**预先存在的**训练臂：`full`（每组6标签，上界参照），
  `uniform`（每组3标签）以及 `joint_ewma`（每组3标签）。
  只有 `uniform` 对 `joint_ewma` 属于同等逻辑标注预算比较。
- 固定 `loo_ht` 主目标，属于 GRPO-family LOO-HT，不是 TRL 标准化 GRPO。
  clipping / 多 epoch reuse 会引入额外估计偏差；建议 `update_epochs=1`。
- 每步记录完整生成、购买的标签、仅观察标签形成的优势、梯度范数、
  **LoRA 实际权重变化范数**、optimizer+adapter+RNG 的原子断点；另外保存
  初始（第0步）权重，审计阶段从相邻检查点独立计算权重变化，与日志核对。
- 每个训练臂的 baseline 和所有 heldout 测试采用相同、未训练过的固定题目集；
  每次运行只一个 seed，跨 seed 请使用不同目录。

> 仅有有效非零梯度**并不**证明 heldout 表现改善。真实 HF 端到端训练还需要
> 用户 RTX5070 执行，当前开发环境只能验证离线接口、数学和断点逻辑。

## 2. Windows 上的安装

在 `(corr_grpo_phase6)` 环境中，将新的补丁 ZIP 的内部路径**合并**到
`C:\lsg\corr_grpo\phase4_holdout_grpo`，不要删除原有 `results`。

```bat
conda activate corr_grpo_phase6
cd C:\lsg\corr_grpo\phase4_holdout_grpo
python -m unittest discover -s tests -q
```

应报告 `Ran 97 tests` 以及 `OK`。都是离线测试，不代表 GPU 训练成功。

## 3. 真正 GPU 试运行：6 步单臂

**只跑1个新 LoRA 步**，不覆盖既有早期 smoke：

```bat
python scripts\run_phase6c_calibrated.py --calibration-root results\phase6b_calibration2_v1 --output results\phase6c_cal2_smoke6207 --seed 6207 --steps 6 --warmup 2 --window 3 --eval-every 2 --eval-size 6 --max-new-tokens 64 --arms full --max-new-steps 1
```

首个任务恰好可能没有正奖励。如果第一步梯度/权重变化均为零，不应立刻认定失败；
用**完全相同的参数**追加最多5个新步骤：

```bat
python scripts\run_phase6c_calibrated.py --calibration-root results\phase6b_calibration2_v1 --output results\phase6c_cal2_smoke6207 --seed 6207 --steps 6 --warmup 2 --window 3 --eval-every 2 --eval-size 6 --max-new-tokens 64 --arms full --max-new-steps 5
```

检查结果中：`training_shadow_reward_positive_fraction_by_arm`、
`nonzero_gradient_steps_by_arm`、**`nonzero_weight_delta_steps_by_arm`**。
若 `full` 已经出现非零参数变化，并且能正常保存状态，就可在同一smoke配置
下继续三臂比较：

```bat
python scripts\run_phase6c_calibrated.py --calibration-root results\phase6b_calibration2_v1 --output results\phase6c_cal2_smoke6207 --seed 6207 --steps 6 --warmup 2 --window 3 --eval-every 2 --eval-size 6 --max-new-tokens 64 --arms full uniform joint_ewma
```

如果任何 smoke 阶段出错，**停止并保留结果目录，发回报错**。
若全部6步依旧无非零梯度/参数变化，不应盲目扩大步骤数。

## 4. 正式 Phase6C 训练：60步、独立 heldout

**必须换新目录。** 上面 smoke 的 `steps=6` 不能变成60步续跑。
建议在真实GPU首轮smoke完全通过后按预先固定的参数进行：

```bat
python scripts\run_phase6c_calibrated.py --calibration-root results\phase6b_calibration2_v1 --output results\phase6c_cal2_seed6207 --seed 6207 --steps 60 --warmup 12 --window 9 --eval-every 10 --eval-size 24 --max-new-tokens 64 --arms full uniform joint_ewma
```

数据计算可能耗时较长；每步原子保存模型/优化器/RNG，意外中断后重跑
**完全同一命令**恢复，不会从第一步重新训练。

首个seed完成、审核heldout与非零 LoRA 更新之后，再考虑预先固定更多种子。
例如新目录/新种子 `6219`、`6251`，不要根据某个种子的准确率选择保留或删除。
所有种子应使用相同 `steps/learning_rate/eval` 方案。

## 5. 训练结束之后再次核查

```bat
python scripts\run_phase6c_calibrated.py --calibration-root results\phase6b_calibration2_v1 --output results\phase6c_cal2_seed6207 --seed 6207 --steps 60 --warmup 12 --window 9 --eval-every 10 --eval-size 24 --max-new-tokens 64 --arms full uniform joint_ewma --stage audit
```

审计额外核验相邻第0、1、2、…步保存的**实际 LoRA adapter**的 L2变化量
与训练报告是否一致，而不仅检查日志声称的 `optimizer.step()`。

主要输出：

- `phase6c_summary.json`：各臂的非零梯度/非零参数变化步骤、baseline、末次heldout。
- `phase6c_learning_curves.csv`：逐步训练损失、奖励、参数变化与heldout。
- `phase6c_audit.json`：重算奖励、抽样子集、在线状态和各模型检查点。
- `arms/*/train_steps/*.json`：逐步原始生成和采样日志。
- `arms/*/optimizer_states/*.pt`：每步 LoRA adapter、优化器、RNG，可恢复。
- `arms/*/baseline_eval` 和 `arms/*/tasks`：核对数据划分和训练前能力。

**科学边界：** 即便审计通过，也仅为内部可复查证明，不是独立复现实验。
完整 verifier 奖励用于事后诊断，真实 external scorer 成本节省未被证明；
`full` 的奖励查询预算是另外两臂的两倍；三个或更多独立种子的重复实验、独立 heldout
提升和多重比较处理仍是投稿前需要考虑的稳健性环节。

注意：不要覆盖此前 `results\phase6c_real_gpu_smoke*` 或 Phase6B
`results\phase6b_calibration2_v1`。本版本源代码哈希改变，旧 Phase6C 检查点
**不能在新版代码下直接续跑**；需把旧代码/旧输出留作历史记录。
