# Phase 2 → Phase 3: concrete research protocol

This is a **forward-looking, not-yet-executed** protocol. It is intended to support future full papers, code generation and pre-registration. It does not claim that planned experiments are already done.

## Main question and objective

Can a pre-query decision rule purchase exactly `B` of `G` expensive gold rewards while improving the mean-squared error of an *unnormalized* on-policy leave-one-out policy gradient at the **same marginal inclusion probabilities** as established survey-sampling alternatives? If so, does the improvement survive learned conditional second moments, actual verifier cost and real policy learning?

Three distinct objectives must be separately evaluated: **gradient acquisition risk**, **economic verification cost**, and **terminal policy utility**. Success on one does not imply success on the others.

## Mechanism under study

1. Generate `G` on-policy candidates and pre-query score vectors. No current gold reward may be visible to acquisition.
2. Form an auxiliary prediction `m(F0)` and matrix estimator `Vhat(F0)` from entirely disjoint prior observations, with held-out calibration, raw IPW statistics, pair-specific ESS and PSD projection reported.
3. Choose a feasible fixed-size marginal vector `zeta`, freezing it for all **same-marginal** comparisons. Evaluate alternative distributions over `B`-subsets (`q`) including maximum entropy, balanced surveys and the score-aware LP.
4. Reveal only the purchased rewards; construct the model-assisted HT gradient with the implemented inclusion probabilities.
5. During evaluation only, separately compute full-feedback and oracle-covariance counterfactuals in a simulator or a complete pre-collected benchmark.
6. Record true verifier calls, total wall time, candidate-generation cost, optimizer runtime, purchased reward failures, policy update statistics and final task outcomes.

## Primary and secondary endpoints

- **Primary controlled acquisition endpoint**: paired difference `R(baseline; V) − R(candidate; V)` in true query-induced squared gradient error, on independent held-out groups, with identical `zeta` and `B`. For real data, obtain a complete offline labeled evaluation subset; such a benchmark does not imply deployability at that acquisition budget.
- **Secondary**: regret relative to oracle full-`V` LP; calibration MSE for diagonal and off-diagonal conditional moments; pairwise ESS; support failures; LP solve time; numerical feasibility; verification wall time and dollars; fraction of acquired bad/failed verifications.
- **End-task endpoint (separate hypothesis)**: paired terminal reward or task success after training for a prespecified training budget, with training-seed confidence intervals, actual number of *physical* verifier calls and generation compute.

## Required baselines

At fixed feasible first-order marginals:

1. Uniform design **only if** those marginals are uniform (otherwise it is not a same-marginal comparison).
2. Maximum-entropy/rejective exact-size design with verified identical marginals.
3. Classical balanced survey/cube-type sampling using the same auxiliary-score totals; report if exact balancing is infeasible and whether inclusion marginals are actually preserved.
4. A DPP or diversity design with an honest match of `B`, and, **where possible**, of first-order marginals; otherwise clearly label it budget-matched only.
5. Oracle full-second-moment fixed-marginal LP, clearly an **evaluation bound**, not a deployable method.
6. Practical pilot-trained diagonal-only, pooled-IPW, feature-conditional pair-product, shrinkage/PSD and uncertainty-gated approaches.

If all baselines attain the same performance, publish the null result instead of selectively highlighting a favorable scenario.

## Factorial controlled design and negative controls

Predefine group size `G`, budget `B`, score dimension, reward-model mean bias, residual heterogeneity, correlation strength/sign and pre-query prediction error. Include negative controls:

- `B=1` and `B=G−1`: no coupling degrees of freedom at identical marginals.
- Independent residuals (`V` diagonal): off-diagonal coupling can have no effect on conditional squared-gradient error when marginals are fixed.
- Pair weights of the additive form `a_ij = u_i+u_j`: all feasible fixed-size couplings have equal risk.
- Low-signal or collapsed scores: check that measured effects are not manufactured by numerical instabilities.
- Rare pair co-inclusions, near-degenerate feasible marginals, asymmetric costs, model drift, PSD-valid negative correlation.
- Common-mode reward noise: use the analytically exact four-candidate score-balanced construction as a test, not as a headline novelty claim.

Keep the seeds for initial software development disjoint from confirmatory seeds. Block randomized trial assignments by environment and seed and blind the analysis of the pre-registered primary outcome until calibration choices are frozen.

## Statistical analysis plan

1. Specify the fixed-marginal target population and the unit of independence: prompts, tasks and/or independent trained policies. Repeated subsets from one prompt are not independent tasks.
2. Use paired seed- or prompt-level differences, not naive per-token independent standard errors. Report confidence intervals for effect sizes and failure probabilities, and show individual training runs.
3. Treat comparisons of many candidate algorithms as exploratory unless multiplicity is controlled. Freeze the primary baseline, effect size, power calculation and decision rule before evaluating final seeds.
4. Compare both raw and PSD-projected `Vhat` with ground truth on complete synthetic/held-out data. Do not infer conditional calibration from pooled unconditional agreement.
5. For pairwise estimates, report `pi_ij` and effective sample sizes separately. Entries with `pi_ij=0` must be declared unidentified unless a transparent model supplies assumptions.
6. If a valid prompt-conditional error radius is estimated, report empirical coverage and how the radius is constructed **without** using outcomes it seeks to protect. A heuristic radius must not be called a confidence guarantee.
7. Perform cost-aware sensitivity: if generation dominates verifier cost, a reduction in gold-label calls may worsen overall wall time after optimization overhead.

## Formal theory priorities

**T1 — Strict-gain boundary.** Classify when score-signed pair coefficients yield a strict improvement over genuine classical balanced sampling, beyond the known additive no-gain case; state necessary generic nondegeneracy conditions and construct an admissible witness design.

**T2 — Conditional covariance identification with acquisition feedback.** Couple an evolving sequence of query designs to a conditional residual moment learner, enforcing pairwise exploration; derive meaningful rates as a function of observable pair ESS and time-varying contexts.

**T3 — Robust safe acquisition.** Build honest high-probability or distributionally robust conditional matrix regions and a nonvacuous design-selection gate accounting for rare pairs. Prove its coverage and compute its conservatism.

**T4 — Large-group approximate coupling.** Investigate column generation, structured balancing, approximate LP dual bounds and computational scaling; an approximate algorithm must report primal residuals and an optimality gap or a clearly labeled heuristic result.

**T5 — Modern GRPO bridge.** Write the actual clipped/normalized per-token objective and separate oracle-reward selection bias from policy-sampling effects. Derive a correct estimation target or explicitly state the approximation and quantify its bias. Avoid relabeling the current unnormalized theorem as clipped GRPO.

These five items are open research directions, not theorems already proved by the accompanying implementation.

## Go/no-go milestones

| Gate | Must be shown | Decision |
|---|---|---|
| A: correctness | Tests, stress, no-leakage, actual inclusion probabilities | Prototype is at this gate; extend CI |
| B: calibration | Held-out feature-conditional errors, support/ESS, matched comparators | Still open |
| C: prior art | Same-marginal balanced/cube baseline, honest DPP comparator, reported null regimes | Still open |
| D: full task | True expensive verifier, time/cost accounting, paired multi-seed post-training with intervals | Still open |
| E: paper | Clear claimed distinction, no overstated novelty, independently repeatable outcomes | Publication decision deferred |

**Decision rule:** do not submit a "new sampling theory" paper on the strength of HT unbiasedness, Bernoulli diagonalization or a standard fixed-marginal LP. Only upgrade the claim if T1–T5 or the high-quality confirmatory applied results produce a genuinely defensible differentiator. The expert suggestion of *INFORMS Journal on Computing* remains conditional, not a guaranteed first choice.
