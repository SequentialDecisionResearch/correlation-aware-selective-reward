# Phase 6A 完整运行说明（RTX 5070 / Windows 11 / WSL2）

**重要：这是 Phase 6A 可执行代码与协议，不是声称真实 Qwen 已经跑完。**
此研究采用真实冻结 Qwen 生成文本，并比较有限奖励查询策略。不会更新模型
参数，所以仍不是 Phase 6C 的 GRPO 后训练。

## 1. 基础安装

推荐在 Windows 11 的 **WSL2 Ubuntu** 中运行。请先保证 Windows
NVIDIA 驱动支持 RTX 5070；WSL2 内**不要再安装 Linux NVIDIA 显卡驱动**。
使用官方 PyTorch 安装网页选择 Linux / pip / CUDA 12.8 或兼容更新版本；
避免旧版 GPU 不支持 `sm_120`。检查 `nvidia-smi` 是否能显示显卡。

在 WSL Ubuntu 的终端内，进入解压后的 `phase4_holdout_grpo` 项目根目录：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install torch --index-url https://download.pytorch.org/whl/cu128
python -m pip install -e '.[llm]'
python scripts/check_phase6a_env.py
```

如果 PyTorch 官方已调整 CUDA 构建版本，以官网实时安装命令为准：
https://pytorch.org/get-started/locally/ 。`check_phase6a_env.py`
必须显示 `cuda_available=true`、RTX 5070。建议 Python 3.11/3.12。

## 2. 检查完整代码（不下载模型、不调用GPU）

```bash
PYTHONPATH=src python -m unittest discover -s tests -q
python scripts/run_phase6a.py --backend fake --groups 12 --warmup 2 --window 3 \
  --max-new-tokens 16 --output runs/phase6a_fake_smoke
```

看到 `WARNING: FAKE BACKEND` 说明这是测试假模型，**不能拿结果写论文**。
项目目录内会生成 `phase6a_summary.json` 与 `phase6a_audit.json`。
另外，`phase6a_group_policy_metrics.csv` 逐组保存各方法的原始比较数值。

## 3. 真实 Qwen 小规模 GPU 测试（先用 2 组）

此前上传的 `qwen25_05b(2).zip` 只有模型配置和 tokenizer，**没有
model.safetensors 权重**。下面的命令使用官方模型名称，可在联网时让
Transformers 自动下载完整模型（约 1 GB）。

```bash
python scripts/run_phase6a.py --backend hf --groups 2 --warmup 1 --window 3 \
  --max-new-tokens 24 --output runs/phase6a_gpu_smoke
```

失败请先查驱动、CUDA、完整模型权重、Python 包版本，不要在同一
输出目录更换算法参数后覆盖；改用新的 `--output`。

也可以先手动下载权重至独立模型目录，再加：

`--model /path/to/complete/Qwen2.5-0.5B-Instruct --local-files-only`

## 4. 推荐完整 6A 实验

```bash
python scripts/run_phase6a.py --backend hf --groups 120 --warmup 26 \
  --window 18 --max-new-tokens 96 --seed 6103 \
  --schedule easy_to_hard --output runs/phase6a_qwen05_seed6103
```

默认 G=6、B=3、探索混合 25%，比较五种同预算策略。建议保持
模型文件和环境版本不变，运行前可记录 `nvidia-smi` 和代码 ZIP 的
SHA-256。正式复现实验更应提供固定模型 revision/commit。

这个工作量在 RTX 5070 上可能是数十分钟乃至数小时。**这只是
经验上的范围，不是实测性能数字。** 优先用 2 组计算平均耗时和显存。

## 5. 自动断点与恢复：直接重复相同命令

例如人为限制一次只新生成 10 组：

```bash
python scripts/run_phase6a.py --backend hf --stage collect --groups 120 \
  --warmup 26 --window 18 --max-new-tokens 96 --seed 6103 \
  --output runs/phase6a_qwen05_seed6103 --max-new-groups 10
```

之后重复**完全相同的固定参数和输出目录**，省略
`--max-new-groups`：

```bash
python scripts/run_phase6a.py --backend hf --stage collect --groups 120 \
  --warmup 26 --window 18 --max-new-tokens 96 --seed 6103 \
  --output runs/phase6a_qwen05_seed6103
```

此前已经成功提交的 10 组不会重新生成。收集完成后执行：

程序逐组输出 `CHECKPOINT [generated] x/120 committed`，这是**已落盘**的
进度，而不是仅在内存中暂存的工作；奖励决策阶段每十条输出一次进度。

```bash
python scripts/run_phase6a.py --backend hf --stage evaluate --groups 120 \
  --warmup 26 --window 18 --max-new-tokens 96 --seed 6103 \
  --output runs/phase6a_qwen05_seed6103
python scripts/run_phase6a.py --backend hf --stage summary --groups 120 \
  --warmup 26 --window 18 --max-new-tokens 96 --seed 6103 \
  --output runs/phase6a_qwen05_seed6103
python scripts/run_phase6a.py --backend hf --stage audit --groups 120 \
  --warmup 26 --window 18 --max-new-tokens 96 --seed 6103 \
  --output runs/phase6a_qwen05_seed6103
```

`evaluate` 可以用 `--max-new-decisions 20` 做分批测试，中断后原命令
重跑会轻量复原已购标签产生的在线状态，继续从最后一个有效决策往下做。
每一个完成组和每次策略决策都有单独原子 JSON 文件。写入一半的
临时文件不会被视为完成；但当次尚未提交的一个操作有可能重做。

## 6. 如何理解结果与限制

- `phase6a_summary.json`：是否完成、每种策略平均线性风险、已付
  **逻辑预算**、精确标准化插件偏差等。`complete=false` 代表尚未完成。
- `phase6a_audit.json`：所有记录是否能独立复算，`pass=true` 是内部
  路径审计，不是第三方科研审核。
- `generations/`：真实 Qwen 输出及冻结模型的低维 score sketch。
- `shadow_oracle/`：完整奖励，**只用于离线事后比较**，不可拿来做策略输入。
- `acq_uniform/` 等：实际抽样方案、选中项、已观察奖励及设计风险。

特别强调：本实验虽然是真实 Qwen 文本生成，但奖励评分是廉价
程序判题，所有六个潜在奖励都为学术审计在本地计算。因此它不能
证明真实昂贵评估器的时间或成本节省，也不能证明最终 GRPO
训练收益。它只是 6A，6B/6C 还需开展。

如模型版本、算法代码、种子或参数变化，程序会**拒绝**旧目录继续
运行；不要删除断点记录来绕过校验，应该新建一个独立研究运行目录。
