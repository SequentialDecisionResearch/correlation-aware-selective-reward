# Phase 4 completed: actual R Cube reference and frozen online holdout

**Evidence date:** 23 October 2026. All results reported below were
**actually executed**, saved as machine-readable raw records, and evaluated
once against the internal protocol frozen **before** the full holdout run.
This is a *synthetic one-step gradient-acquisition* study. No actual
post-training of an LLM, real costly verifier, model-weight optimization,
cost-in-dollars experiment or external experiment preregistration took place.

## Executive decision

**Do not initiate LLM fine-tuning from this evidence yet.** The external
sampling-algorithm validation succeeded, and the new conservative fallback
improved over our older drift-gated strategy, but it failed to beat the
continually adaptive covariance policy and did not meet its stationary
false-alert limit on new worlds. This negative result is reproducible.

## 1. Real independent CRAN sampling implementation

The R system and the three CRAN packages `Rcpp`, `RcppArmadillo` and
`BalancedSampling` were installed in the transient research environment.
The audit genuinely called **`BalancedSampling::cube` v2.1.1** from R,
not Python code labeled as R. Five 5,000-draw independent batches were
executed and preserved in `results/phase4_real_R_cube/R_actual_draws_*.csv`.
The runtime versions were **R 4.3.3**, Rcpp 1.1.2, RcppArmadillo 15.6.2.1,
and BalancedSampling 2.1.1.

| Design | G / B | R max empirical pi error | R HT balance (MC SE) | Independent Python exact HT balance |
|---|---:|---:|---:|---:|
| Equal pi, random 3 auxiliaries | 6 / 3 | 0.0128 | 10.666 (0.156) | 10.415 |
| Unequal prescribed pi | 7 / 3 | 0.0102 | 21.696 (0.249) | 21.658 |
| Exactly balanceable auxiliary | 4 / 2 | 0.0134 | **0.000 (0.000)** | **0.000** |
| Redundant collinear auxiliaries | 8 / 4 | 0.0080 | 2.858 (0.055) | 3.128 |
| Anisotropic prescribed pi | 6 / 3 | 0.0082 | 24.284 (0.198) | 24.138 |

Every official R draw had *exactly B elements*, and the maximal
first-inclusion deviation in each case was well within a conservative
six-Monte-Carlo-standard-error diagnostic bound. The two implementations
need not yield identical design distributions, balancing losses, or random
draws: their flight-direction and landing choices differ. The R rates,
pair co-selections, gradient risks and balance are **empirical**; the
finite-tree Python quantities are **exact for its own design**.

The evaluation also measures synthetic quadratic gradient risk for both
implementations with fixed prescribed pi, scores and positive-semidefinite
V. Those values and their R Monte Carlo SEs are saved in
`R_reference_suite.json`. The exercise verifies actual classical sampling
performance; it does not establish a new sampling theorem.

## 2. Data leakage and frozen design audit

The 32 independent calibration seeds were **3101–3132**; the 12 independent
held-out seeds were **2017, 2027, 2039, 2053, 2063, 2081, 2089, 2111,
2129, 2137, 2153, 2161**. Both lists are disjoint from the 8 Phase-3
development seeds. The holdout uses 7 new covariance trajectory types,
including both Gaussian and Student-t-5 shocks and negative controls.

All methods purchase exactly **3 out of 6** rewards on each of **160**
steps, with equal first inclusion pi=0.5 and 25% exact-B uniform
exploration. Except for the classical uniform baseline, every method
learns design-relevant information only from **previously purchased**
rewards. The evaluator alone sees latent full rewards and the exact true
conditional second-moment matrix.

The calibration sample only contains stationary Phase-3 covariance
profiles. It calibrates a **three-consecutive-alert** detector built on
clipped IPW matrices, producing and freezing threshold **1.18065401553**
before any full holdout evaluation. Its target is the development-null
empirical 90th percentile over trajectories, not a theorem about false
alarm probabilities. The first holdout evaluation ran **once**, without
re-tuning after seeing its results. Executed source hashes are included in
the machine-readable summary.

## 3. Complete observed holdout results

Full evaluation: **7 worlds × 12 seeds × 160 steps × 7 methods = 94,080
policy decisions**, with **282,240 metered synthetic gold requests**.
Calibration took **16.69 seconds** and the entire held-out run took
**254.15 seconds** on the reference Linux environment.

The table reports **mean later-half exact conditional acquisition risk**,
where **lower is better**. The underlying latent distribution changes at
scenario-specific times; "later half" means steps 80–159 for a consistent
paired comparison, and is not always identical to "after change".

| Held-out world | Uniform | Full Cube | Scaled balance | Joint EWMA | Frozen covariance | Old hard fallback | New guarded partial |
|---|---:|---:|---:|---:|---:|---:|---:|
| Stationary heteroscedastic | 0.5871 | 0.6052 | 0.6399 | **0.4652** | 0.4690 | 0.4885 | 0.4714 |
| Stationary Student-t-5 | 0.5861 | 0.6021 | 0.6246 | 0.4786 | **0.4775** | 0.4900 | 0.4820 |
| Abrupt factor rotation | 0.5992 | 0.6152 | 0.6383 | **0.4962** | 0.5868 | 0.5229 | 0.4988 |
| Gradual covariance rotation | 0.5855 | 0.5991 | 0.6221 | **0.4798** | 0.5561 | 0.5134 | 0.4907 |
| Oscillating correlation | 0.5933 | 0.6057 | 0.6116 | **0.5056** | 0.5142 | 0.5281 | 0.5140 |
| Late variance shock | 1.0017 | 1.0289 | 1.0547 | **0.8397** | 0.8833 | 0.8438 | 0.8399 |
| Student-t-5 factor flip | 0.5889 | 0.6033 | 0.6321 | **0.4958** | 0.5628 | 0.5093 | 0.5138 |
| **Equal-world average** | **0.6488** | 0.6656 | 0.6891 | **0.5373** | 0.5785 | 0.5566 | 0.5444 |

The main independent comparator is **joint EWMA**, not uniform or a stale
baseline. It was the best method in six of the seven later-half worlds;
the stationary Student-t case has nearly equal joint and frozen risks.

The mean paired advantage of joint EWMA over the new guard is
`Risk(joint)-Risk(guard) = -0.007100` (negative favors joint). Across
**12 seed-cluster averages**, its descriptive 95% t interval is
`[-0.013423, -0.000777]`: the new guard **failed** the pre-stated
positive-lower-endpoint requirement.

There is nevertheless incremental engineering value: compared with the
older Phase-3 **hard** drift-gated fallback, the new partial guard's
later-half risk was lower by **0.012204** on average. The descriptive
12-seed 95% interval for old-hard minus new-partial is
`[+0.000034, +0.024374]`; 9/12 seed-cluster differences are positive.
The honest conclusion is **less harmful fallback than before**, not
**more effective than using continuously adapted covariance**.

## 4. False alarms: calibration did not transport reliably

The 32 stationary calibration runs had a threshold of 1.18065; four
trajectories exceeded this empirical 90th-quantile criterion (12.5%,
owing to quantile granularity). On genuinely held-out, different stationary
covariance distributions, the **fraction of runs with any guard alarm** was:

| Held-out no-change world | Any-alarm fraction | Pre-stated limit | Result |
|---|---:|---:|---|
| Heteroscedastic Gaussian | **3/12 = 25.0%** | Less than 10% | Failed |
| Heteroscedastic Student-t-5 | **2/12 = 16.7%** | Less than 10% | Failed |

This is not evidence of a level-10% change detector. Calibration nulls
were not exchangeable with the held-out null distribution, and adaptive
query probabilities alter the variance of inverse-inclusion contributions.
The persistence and clipping mechanisms reduced excessive switches,
but false-alarm protection still needs a better statistical construction.

## 5. What the rollback rule actually guarantees

All candidate designs share the same first-order inclusion probabilities.
Therefore if an alarm prompts only a fraction `lambda` of diagonal
fallback rather than full replacement,

`Q_mix = (1-lambda) Q_joint + lambda Q_diagonal`

the exact conditional squared-gradient risk satisfies

`Risk(Q_mix) - Risk(Q_joint) = lambda [Risk(Q_diagonal)-Risk(Q_joint)]`.

The common uniform-exploration mixture scales this difference by the
additional factor `1-epsilon = 0.75`. Since `lambda<=0.25`, the guard can
incur at most **18.75% of the risk difference** of replacing the joint
design entirely with the diagonal design, conditional on the particular
same-step designs being compared. This is a real algebraic **relative
exposure bound**, but **not** an absolute guaranteed-loss bound. The
historical sample-contrast upper bound triggering larger rollback is
also not a calibrated confidence sequence.

The holdout supports the limited engineering benefit of partial switches;
it does not establish safe selective reward acquisition under drift.

## 6. Pre-stated go/no-go gates and actual outcomes

| Gate from internally locked protocol | Outcome |
|---|---|
| Genuine CRAN Cube size/marginal diagnostics | **Pass** |
| Guard beats joint EWMA with positive lower 95% seed-CI endpoint | **Fail** |
| Guard increases risk by at most 5% in both stationary controls | **Pass** |
| Stationary false-alarm runs under 10% in both controls | **Fail** |
| Accounting, exact budgets, output integrity | **Pass** |

**Decision: NO-GO for real LLM training right now.** We should improve
detector calibration in changing and heavy-tailed adaptive-IPW contexts,
develop bounded or robust second-moment estimators, and compare alternative
controlled mixtures. Any changed method must be evaluated on a **fresh
independent set of seeds and scenarios**, not re-used Phase 4 holdout.

Only after an independent run satisfies the agreed gates should a modest
real-LM experiment be considered. It must still measure actual verifier
cost, throughput, downstream task success and policy-update behavior.

## 7. Reproduction, QA and result files

- `results/phase4_real_R_cube/R_reference_suite.json`: five official R
  algorithm comparisons and Monte Carlo standard errors.
- `results/phase4_real_R_cube/R_actual_draws_*.csv`: all 25,000 R samples.
- `results/phase4_frozen_holdout_full/calibration.json`: raw 32-seed
  calibration maxima and **frozen** threshold.
- `results/phase4_frozen_holdout_full/holdout_trials.csv`: all 94,080
  decisions, selected subsets, historical diagnostics, true evaluation-only
  risks, observed gradient errors, and gold-query counts.
- `results/phase4_frozen_holdout_full/holdout_summary.json`: scenario- and
  seed-paired risk intervals, alarms, parameter/source hashes and runtime.
- `results/phase4_go_no_go.json`: mechanical application of internal
  frozen decision criteria.
- `results/phase4_figures/*.png`: held-out risk heatmap, policy contrasts
  and false-alarm rates from the same raw experiment.
- `tests/test_phase4_holdout.py`: separate unit tests for disjoint seeds,
  covariance PSD, t-5 scaling, clipping, detector persistence, and a
  complete quick-run reproduction, alongside historical tests.

**Final implementation verification:** all **54** unit/regression tests
passed **with R available**, including the actual official R bridge test;
the separate **2,600-case** marginal stress suite passed all cases with
maximum first-order marginal error **8.16e-11**.

All frozen method and simulator parameters are documented in
`docs/PHASE4_PROTOCOL_LOCKED.md`. Exact R package is documented at
https://cran.r-project.org/web/packages/BalancedSampling/refman/BalancedSampling.html.

### Interpretation warning

The reported unit is **conditional one-step acquisition-induced squared
gradient error**, not language-model perplexity, downstream accuracy,
dollar savings or investment return. The original mathematical basis is
classical model-assisted Horvitz--Thompson sampling and the Cube Method;
no claim of a novel survey sampling theorem is made.
