# Phase 5: executed final synthetic holdout and internal independent-code audit

**Evidence date:** 23 October 2026. **Status:** Completed, evaluated, and
mechanically audited. This is the final *synthetic one-step surrogate*
validation under the internally frozen Phase-5 protocol, not a publication
decision and **not a real LLM post-training result**.

## A. Frozen experiment actually executed

- Prespecified algorithm parameters retained from Phase 4: G=6, B=3,
  160 steps, warmup 26, exploration epsilon=0.25, fixed pi=0.5.
- 16 untouched seeds, six newly defined covariance/shock families, five
  matched-budget policies, totaling **76,800 policy decisions and 230,400
  metered synthetic gold-label queries**.
- Full online study time: **186.14 seconds** on the execution environment.
- The official CRAN `BalancedSampling::cube` implementation and its 25,000
  independent genuine R draws remain in the Phase-4 reference study.
  This Phase-5 online method named `cube_classic` is the Python cube-style
  algorithm, **not** the official R implementation; no claim of an online
  comparison directly against the official R executable is made.
- Full raw data: `results/phase5_full/phase5_trials.csv`.
- Summaries: `phase5_summary.json`, `phase5_bridge.json`, `phase5_audit.json`.

The primary unit is later-half (steps 80--159) exact *conditional
acquisition-induced squared gradient risk*. Lower is better. It uses the
true hidden V for evaluator scoring only; the policy uses historical
purchased residuals. No actual language-model parameter updates occur.

| Held-out world | Uniform | Python cube-style | Diagonal scaled LP | Joint EWMA | Joint frozen | Scaled minus joint |
|---|---:|---:|---:|---:|---:|---:|
| stationary independent | 0.593 | 0.593 | 0.593 | 0.593 | 0.593 | 0.00000 |
| stationary positive factor | 0.657 | 0.570 | **0.474** | 0.532 | 0.519 | **-0.05755** |
| stationary sparse Student-t5 | 0.602 | 0.598 | 0.594 | 0.580 | **0.575** | +0.01366 |
| abrupt factor sign switch | 0.589 | 0.602 | 0.632 | **0.488** | 0.625 | +0.14437 |
| two changes: blocks and factors | 0.623 | 0.595 | 0.569 | **0.516** | 0.619 | +0.05311 |
| smooth sigmoid rotation | 0.640 | 0.575 | **0.515** | 0.549 | 0.614 | **-0.03425** |
| **Equal-world overall** | **0.61760** | **0.58886** | **0.56296** | **0.54307** | **0.59092** | **+0.01989** |

The original machine-recorded exact precision, rather than the rounded
display values, is authoritative.

### Primary paired seed-cluster comparisons

Each number is average `risk(baseline)-risk(joint_ewma)` over 6 worlds,
using seed-level averages as the 16 descriptive independent clusters:

| Baseline | Mean paired gain of joint | Descriptive 95% t interval | Positive seed clusters |
|---|---:|---|---:|
| scaled LP | **+0.01988872** | [+0.01562099, +0.02415646] | 16/16 |
| uniform | **+0.07453791** | [+0.07125939, +0.07781642] | 16/16 |
| frozen joint | **+0.04785796** | [+0.03951182, +0.05620411] | 16/16 |

These are positive **for the six specified synthetic worlds and frozen
algorithm parameters**, not a universal-dominance theorem. Joint EWMA
beats scaled LP in only **3 of 6** worlds, ties exactly in one diagonal
negative control, and loses on stationary positive-factor and smooth
rotation worlds. Within-world time points are not independent units for
confidence intervals. The t intervals describe between-seed replication,
not uncertainty due to unmodeled world families.

### The negative and limitation checks matter

With diagonal true V and identical inclusion marginals, the maximum
per-step difference among *all five* designs is approximately
`1.33e-15`, as required by theory. Positive-factor and smooth-rotation
cases show material *negative* incremental value of joint covariance
adaptation. They are retained rather than tuned away.

An implementation subtlety: the stored `covariance_error_before`
diagnostic tracks `agent.model.fitted` in all five methods. For
`joint_frozen`, the actual design after warmup instead uses a separately
stored frozen matrix. Therefore this diagnostic must **not** be
interpreted as the error of the design-driving frozen covariance for
that particular method. Conditional risk and policy comparisons remain
computed on the actual chosen designs.

## B. Exact finite-support normalization and clipping bridge

64 independent synthetic full-reward groups were examined for
G=6 and budgets B=1--5. With each fully specified group, the script
enumerated **every** uniform exact-B subset, so reported sampling-design
biases are exact conditional expectations (averaged over the 64 groups).
The clipped diagnostic uses the score-gradient coefficient of a fixed
ratio surrogate and correctly assigns zero derivative on its flat
clipped branches. It still omits real sequence/token dynamics and KL.

| Purchased rewards B | Linear LOO bias norm | Naive normalized plug-in | Naive clipped plug-in |
|---|---:|---:|---:|
| 1 | ~0 | 0.43701 | 0.44703 |
| 2 | ~0 | 0.31381 | 0.32172 |
| 3 | ~0 | **0.21798** | **0.22461** |
| 4 | ~0 | 0.13733 | 0.14211 |
| 5 | ~0 | 0.06610 | 0.06875 |

The linear construction is exact-design unbiased to floating-point
precision. By contrast, simply substituting HT-reconstructed rewards
inside a nonlinear group standardizer changes the estimand and creates
nonzero design bias. This does **not** prove that no alternative useful
bias-corrected or model-assisted nonlinear estimator exists.

An explicit four-coordinate finite-difference witness with B=3 has
norm `0.0001343690733` for the normalized target and
`0.0001362046750` for the clipped signal. Thus the theorem's
necessary zero-(B+1)-interaction condition fails in this fixed-score
example: a universally design-unbiased estimator from exactly three
observed rewards, over all possible full reward vectors and without
further structural assumptions, cannot exist for this target.

## C. New theory memo: proved claims and caveats

`reports/04_phase5_theory_audit_memo.pdf` and its LaTeX source prove:

1. Correct fixed-margin model-assisted Horvitz--Thompson linear gradient
   unbiasedness and exact covariance/LP risk reduction (largely classical).
2. Adaptive IPW residual-second-moment concentration with **bounded**
   residual magnitude, predictable selection, strict positive pair overlap,
   and bounded covariance drift. The bound is a conservative Azuma/union
   bound and can be vacuous when pair propensities are small; it **does
   not apply directly to our unbounded Gaussian or Student-t5 worlds**.
3. A deterministic off-diagonal-only perturbation bound for the fixed-
   marginal optimal coupling: errors in diagonal residual moments alone
   cannot change exact coupling risk differences.
4. A general higher-interaction observability obstruction; the supplied
   normalized/clip witness demonstrates it for B=3, G=6. This is a
   structural unbiasedness barrier, not a novel sweeping theorem about
   every GRPO training algorithm.

**Novelty caution:** Some components are direct consequences of existing
survey-sampling and optimization results. The possibility of a journal
contribution lies in a **nontrivial problem-specific learning guarantee**
and/or convincing real-task evidence. These documents must not claim a
new general sampling theory.

## D. Independent-code-path internal audit

`scripts/audit_phase5.py` reloads the *raw CSV* and separately reconstructs
seed-blocked comparisons, cell risks, decisions, budgets and nonlinear
bridge summaries without calling the original summary engine. Audited:

- **76,800 distinct rows**, 15,360 unique world/seed/step keys;
- exact B=3 for every purchase, with 230,400 metered synthetic queries;
- maximum first-inclusion numerical error `3.33e-16`;
- minimum purchased-pair inclusion `0.05`;
- oracle lower-bound numerical discrepancies no larger than `1.23e-15`;
- diagonal no-coupling negative control at about `1.33e-15`;
- all three paired baseline contrasts and world means match raw records;
- exact bridge linear-unbiasedness and the nonlinear interaction witness.

**Audit result: PASS for these mechanical and statistical checks.**
This is an *internal separate-code-path audit*, **not an independent
third-party mathematical review**, and it does not reconstruct each
chosen design's original q-distribution from the stored CSV. A truly
independent specialist should additionally inspect theorems and
source-level leakage/sequential adaptivity assumptions before submission.

## E. Honest decision after Phase 5

1. **Finished:** the predeclared final low-cost synthetic validation and
   mechanically separate raw-data audit. Do not retune on these seeds.
2. **Supported within scope:** online covariance-aware coupling can
   reduce one-step acquisition risk at equal query budgets on the
   prespecified mixture of six synthetic worlds. Benefits are
   heterogeneous and can reverse.
3. **Not supported:** universal superiority, finite-sample safe drift
   detection, unbiased estimation of full normalized/clipped GRPO by
   naive HT plug-in, or improved downstream language-model quality.
4. **Publication decision:** the results support a candid, bounded
   methods manuscript *draft* but do not alone certify a high-level
   journal contribution. First obtain an independent mathematical
   novelty review; if claiming LLM post-training benefits, a properly
   metered small real-model experiment is required. The decision to
   purchase that compute is separate and remains with the user.

## F. Reproduction

From the unpacked project root:

```bash
python -m pip install -e ".[figures]"
PYTHONPATH=src python -m unittest discover -s tests -q
python scripts/run_phase5.py --quick --output results/phase5_quick_repeat
python scripts/audit_phase5.py --input results/phase5_quick_repeat
python scripts/run_phase5.py --output results/phase5_full_repeat
python scripts/audit_phase5.py --input results/phase5_full_repeat
python scripts/make_phase5_figures.py --input results/phase5_full_repeat --output results/phase5_figures_repeat
```

The run includes the exact finite-support bridge. It does not require R,
GPU, paid APIs or a language-model checkpoint. The official R reference
experiment remains available in the older Phase-4 results; `Rscript` and
CRAN `BalancedSampling` are needed only if explicitly repeating it.
