# Phase 6D：真实 LoRA 梯度与三维 score sketch 的条件采样风险对齐实验

**版本：v1.6；状态：144 组冻结模型 GPU 实验已完成并归档，另提供 CPU 原始记录复核脚本。**

正式结果位于 `results/phase6d_gradient_v1/`，含原始任务银行、原始 manifest、144 份逐组 JSON、CSV 和分层统计 JSON。独立审阅可运行 `python scripts/reproduce_phase6d_archived.py`；它从保存的真实 LoRA 梯度 Gram 矩阵重算全部风险，但**不**重新执行 GPU autograd。原始 checkpoint `.pt` 已从轻量公开包中省略，因此下面的 GPU 命令仍适用于持有本机原始 checkpoint 的作者，而不适用于直接解压的审稿人包。

结果重点（checkpoint 30/60，96 组）：sketch 风险合并下降 **26.91%**，真实 LoRA 风险仅下降 **3.27%**；三种子真实风险降低分别为 **16.80%、-22.46%、10.70%**，不能声称普遍获益。0 步负对照两设计完全一致。此后不再扩展新实验阶段。

## 1. 为何从 Phase 6C 继续做 6D

Phase 6B Calibration-2 在 `two_digit_add` 上，基于三维随机 token-score sketch 的**条件线性 LOO-HT 风险**，观察到 Joint EWMA 相对 Uniform 的平均风险下降约 20.06%。这并不是实际神经网络参数梯度的度量。Phase 6C 在三个种子（6207、6219、6251）上，60 步真实 LoRA 更新后，Joint EWMA 和 Uniform 最终留出准确率相同；v1.5 的较难独立测试也没有显示 Joint EWMA 优势。

**6D 不再训练。它检查机制断层：代理 sketch 上优化的采样分布，是否也能降低冻结 LoRA 模型上的真实梯度估计误差。**

## 2. 预先锁定的实验单位

- 完全沿用已经训练好的 Phase 6C 三个独立种子，保持 `Qwen/Qwen2.5-0.5B-Instruct`、LoRA 配置、优化历史、原始模型权重和全部旧结果不动。
- 两类冻结模型：`uniform` 和 `joint_ewma` 各自的 **step 0、30、60** adapter 状态。`full` 可以作为下游性能参照，但本机制比较首先聚焦预算相同的两臂。
- 每种子、每个 checkpoint、每个 source arm：新的 `two_digit_add`（同分布诊断）以及 `three_digit_double_carry`（外推诊断），每种任务默认 4 道。生成银行在计算任何结果前锁定并写入 SHA-256。
- 从原 Phase 6B calibration pilot/eval、Phase 6C 各 seed 的训练/留出题、以及 Phase 6C v1.5 压力集 64 题/层的固定超集排除加数对，并同时排除加数交换顺序。不能根据奖励或梯度重新挑选题目。
- 每道题每个冻结模型仅**一次**生成 (G=6) 条轨迹，固定采样种子；Uniform 和 Joint EWMA 两种采样设计共用**完全相同的六条轨迹、六个标准答案评测以及六条真实梯度**。历史 EWMA 统计只能回放训练过程中已支付的奖励，当前题的任何 reward 必须等到生成 Q 后才能读取。
- **固定奖励预算：**(B=3,\pi_i=1/2\)。同时枚举全部 \(\binom63=20\) 种三元素子集及其设计概率；不抽样、无需采样方差的 Monte Carlo 近似。实验离线揭示六个 reward 仅用于评估两个设计的条件风险；这一评估成本并非训练时实际奖励花费。

`source_arm` 定义实际提供六条轨迹和 LoRA 梯度的**冻结模型**；`design` 定义在该冻结模型的相同六条轨迹上反事实采购三个 reward 的分布。不要把不同 source arm 的 trajectory 当作配对样本；只能在同一 source arm／checkpoint／seed／task 之内比较两个 design。

## 3. 数学指标和真实梯度获取

对固定参数 \(\theta\)、第 \(i\) 条生成文本 \(y_i\)，令

\[
h_i(\theta)=\nabla_{\theta_{\mathrm{LoRA}}}
\frac{1}{T}\sum_t\log p_{\theta}(y_{it}\mid x,y_{i,<t}),
\qquad T=\texttt{max\_new\_tokens}=64.
\]

这里使用 PEFT 可训练 LoRA 张量、PyTorch 的**真实 autograd**；不调用优化器的 `step`，不实施梯度裁剪、不变动任何参数。此公式是 Phase 6C `loo_ht`、单更新 epoch、当前模型与旧模型比率等于 1 时的实际一阶 policy-gradient 方向（忽略优化器预条件和裁剪）；**不是**声称整个 AdamW 更新误差与下面指标完全相同。

将所有 \(h_i\) 排成行矩阵 \(H\in\mathbb{R}^{6\times P}\)，令

\[
M=\frac{H-\mathbf 1\bar h^\top}{G-1},\quad
g_{\mathrm{full}}=M^\top r,\quad
\widehat g_Q(Z)=M^\top\left(\frac{Z\odot r}{\pi}\right).
\]

采样设计 \(Q\) 的条件真风险为

\[
R_{\mathrm{LoRA}}(Q\mid x,y,\theta,r)
=\sum_{z\in\mathcal Z_3}Q(z)\,\|\widehat g_Q(z)-g_{\mathrm{full}}\|_2^2.
\]

用真梯度的 \(6\times6\) Gram \(K=MM^\top\) 直接计算，与下式相互核对：

\[
R(Q)=\sum_{i,j}r_ir_jK_{ij}
\left(\frac{\pi_{ij}}{\pi_i\pi_j}-1\right),
\qquad \pi_i=\frac12.
\]

三维 Phase 6B 代理继续定义 \(S\in\mathbb R^{3\times6}\)，\(M_s=(S-\bar S)/(G-1)\)，\(K_s=M_s^\top M_s\)，同一设计和同一 \(r\) 计算代理风险 \(R_{\mathrm{sketch}}(Q)\)。

每个条件实验同时报告：

- `real_uniform_risk`、`real_joint_ewma_risk`、`real_gain`，以及同一条件下的 sketch 对照；**gain 为 Uniform 风险减去 Joint EWMA 风险，正值才表示 EWMA 有利**。
- 真梯度／sketch 的中心化 Gram 对齐 \(\langle K,K_s\rangle_F/(\|K\|_F\|K_s\|_F)\)，仅是核几何相似度，不等同于参数空间投影。
- 真实收益与 sketch 收益符号是否一致、sketch 认为收益为正但真实风险反而上升的次数、混合正负奖励组占比、设计差异大小、每 seed 的累加风险降低百分比。
- snapshot 0 负对照：EWMA 尚无训练历史，Joint 应退化为 Uniform，两者风险严格一致；真正的采样策略差别应重点看 checkpoint 30/60。

> **核心识别边界**：即使 \(R_{\mathrm{LoRA}}(Q_{EWMA})<R_{\mathrm{LoRA}}(Q_U)\)，也只证明在当前冻结模型、固定六条轨迹、给定奖励下，更准确地估计**一次一阶 LOO-HT 梯度**；不能直接推出多步 AdamW 训练后留出准确率更好。对三个 seed 只能做 seed-cluster **描述性**区间，不能作独立外部复现或总体等价性声明。

## 4. Windows CMD 执行步骤

从原有代码库根目录、已启用 `corr_grpo_phase6` 环境开始；将本补丁 ZIP 解压**覆盖对应新增文件**，不覆盖原 6B/6C 的代码、配置或结果。先运行单个 seed 的最低工作量真 GPU smoke：

```bat
python -m unittest discover -s tests -p "test_phase6d_gradient_alignment.py" -v
python scripts\run_phase6d_gradient_alignment.py --stage prepare --runs results\phase6c_cal2_seed6207 --output results\phase6d_gradient_smoke6207 --snapshots 0 30 --source-arms uniform --families two_digit_add --groups-per-family 1
python scripts\run_phase6d_gradient_alignment.py --stage run --output results\phase6d_gradient_smoke6207 --max-new-groups 1
python scripts\run_phase6d_gradient_alignment.py --stage run --output results\phase6d_gradient_smoke6207
python scripts\run_phase6d_gradient_alignment.py --stage report --output results\phase6d_gradient_smoke6207
```

小型正式诊断（三种子、两 source arms、0/30/60、两种任务，每任务四题）共 \(3\times2\times3\times2\times4=144\) 条冻结条件实验，需要**864 条独立 per-completion LoRA autograd**；每条实验的 20 个采样子集风险通过 Gram 矩阵廉价枚举，不额外执行模型反向传播。

```bat
python scripts\run_phase6d_gradient_alignment.py --stage prepare --runs results\phase6c_cal2_seed6207 results\phase6c_cal2_seed6219 results\phase6c_cal2_seed6251 --output results\phase6d_gradient_v1 --snapshots 0 30 60 --source-arms uniform joint_ewma --families two_digit_add three_digit_double_carry --groups-per-family 4
python scripts\run_phase6d_gradient_alignment.py --stage run --output results\phase6d_gradient_v1 --max-new-groups 1
python scripts\run_phase6d_gradient_alignment.py --stage run --output results\phase6d_gradient_v1
python scripts\run_phase6d_gradient_alignment.py --stage report --output results\phase6d_gradient_v1
```

每个已提交 group 有独立不可改写的 SHA-256 记录，第二次 `--stage run` 自动跳过完整记录；中途断电后再次运行相同命令续做，绝不修改已经训练好的模型及原始 run。若某 group 的文件或源 checkpoint 被篡改，审计停止。需要改变任何设定必须使用**新 output 目录**。

## 5. 应检查的输出

- `phase6d_task_bank.json`：事先固定题目及每个 seed 的新题 ID、金标准（仅评测时可见）。
- `phase6d_manifest.json`：冻结配置、原始训练记录及模型 checkpoint SHA-256、题库 SHA-256。
- `groups/seed*/{uniform,joint_ewma}/step*/group_*.json`：每道题完整生成文本、token ID、当前模型 log probability、六个奖励、六乘六真正 LoRA 完成梯度 Gram、三维 sketch 特征、两个采样 Q、双空间的精确风险；有审计摘要散列。
- `phase6d_group_risk_comparison.csv`：逐任务同条件风险、相对收益方向、梯度 Gram 对齐、混合奖励标记。
- `phase6d_summary.json`：按任务类别、source model、checkpoint、seed 聚类的相对风险降低率、代理与真实不一致频数与样本限制。

**判读顺序：**先确认 0 步负对照；再看 30/60 步的 `mixed_reward_groups` 和 `nonuniform_design_groups` 是否非零；然后看 `true_risk_reduction_by_seed` 在 seed 间是否同号、与 `sketch_risk_reduction_by_seed` 是否一致；最后审视中心化 Gram 对齐度。若 sketch 风险下降而真实风险未降，Phase 6B 的代理质量可能是 Phase 6C 表现未分化的一条解释；若真风险下降但准确率未分化，则考虑优化器预条件、训练非线性、低分辨率准确率指标及任务天花板等后续机制。

## 6. 安全与局限

本代码只有新 Phase 6D artifact 的写操作；不执行 optimizer.step，不改变或重新训练任何 Phase 6C adapter。读取用户本机受信任的 Phase 6C torch checkpoint (`torch.load(..., weights_only=True)`)，模型仍由用户本地 Hugging Face 设置加载。报表的风险审计依赖已记录的真实 autograd Gram，不独立在第二台 GPU 重算全部 autograd。CPU 单测验证解析风险、完整子集枚举、Phase 6C LOO-HT 目标恒等式、任务锁定、断点续跑、SHA 篡改拒绝，以及不触碰原训练目录；实际 Qwen GPU 端必须运行 smoke 才能声称已获得实测结果。
