# Phase 6B + Phase 6C — source audit and verification ledger

Prepared 2026-10-23. This file records **software tests**, not an LLM performance result.

## Code review scope

- Independent Phase6B task generator and seeds: disjoint problem family from Phase6A; `word_to_mod` abrupt change and `interleaved_control` baseline.
- Frozen five-policy sampling: B=3, G=6; positive first/pair probabilities and exact design risks; same generated completions within each cell.
- Source-locked SHA-256 version/fingerprints and stagewise atomic JSON journal; root-wide model fingerprint also checked across Phase6B cells.
- Phase6C three separately initialized LoRA arms: full (6/6), uniform (3/6), adaptive (3/6); base-model fingerprint enforced **across arms**.
- Primary linear LOO-HT advantage: exact finite-design expectation verified independently in pure NumPy; normalized plug-in **explicitly biased**.
- Actual Phase6C training path: PEFT LoRA parameters and AdamW are created; PyTorch autograd computes current policy likelihoods; one-epoch clipped surrogate; `optimizer.step()` executed; dropout disabled during likelihood update so first-epoch on-policy ratios are well-defined.
- No gold answer passed to `generate()` or `update()`: only public task prompt/level and purchased-reward-derived advantages. Retrospective full labels appear only in the oracle and offline audit ledger.
- Optimizer recovery: atomic binary `.pt` followed by JSON step commit; SHA-256 checked on restore; adapter weights verified after PEFT state reload; AdamW scalar step device preserved; CPU/CUDA RNG saved.
- Separate exact journal audits of Phase6B sampling and Phase6C mask/design/reward/score-proxy integrity.
- Multi-seed reporting guard refuses incomplete audits, different configs beyond seed, repeated seeds, and fake backends unless an explicit test-only switch is passed.

## Executed tests and outcome

1. All existing Phase1–6A regression tests **plus** new Phase6B/6C tests: run using `PYTHONPATH=src python -m unittest discover -s tests -q`.
2. Python static compilation: `python -m compileall -q src scripts tests`.
3. Phase6B offline end-to-end smoke (fake model) with 3 new seeds, 2 independent scenarios, 12 groups per cell, 5 policies: **360 audited decisions / 360 expected, all passed**; 72 groups generated. This verifies sampling/replay plumbing but all generated rewards from a fake model are **not scientific evidence**.
4. Phase6B end-to-end resumability: forced partial generation and partial acquisition, followed by resume. Summaries and policy gains match an uninterrupted run.
5. Phase6C pure-math checks: exact finite uniform subset averaging equals the full-feedback leave-one-out score gradient; the nonlinear normalized plug-in is shown different from its full-data target; hidden unselected labels are rejected.
6. Phase6C fake-policy integration: forced optimizer-step interruption, subsequent resumption, restoration of tracked fake parameters, exact-match final results, full journal audits, CSV output; deliberate fake model fingerprint disagreement and corrupted optimizer-state file **must raise**; fake results are rejected by default in multi-seed aggregation.

## Explicitly **not** yet tested / not claimed

- **No real Qwen GPU execution on the user's RTX 5070 has occurred in this software-audit environment.** Real tokenizer/transformer/LoRA/AdamW CUDA integration, runtime, VRAM peak, tensor dtype and numerical stability require the user's local 6-step GPU smoke.
- No real Qwen Phase6B independent holdout results, no true Phase6C accuracy curves, no causal evidence that the new acquisition policy improves LLM post-training.
- No proof of unbiased gradient after clipping, repeated PPO epochs, normalization, or multiple policy updates. Only the conditional finite-design linear LOO-HT identity is established and unit-tested.
- No official TRL GRPOTrainer reproduction; this is a custom GRPO-family LoRA experiment with a deliberately different loss definition.
- Reward verification is a cheap local exact-arithmetic function. A real cost reduction in an expensive reward-model/API setting has **not** been measured.
- Source code and logs are internally self-audited. They have not undergone independent third-party replication or peer review.

## Operational go/no-go before the next phase

1. Pass local Qwen CUDA `--steps 6` smoke with noncorrupt LoRA/optimizer checkpoints and `audit.pass=true`.
2. Confirm that at least some generated groups have **nonconstant rewards** and that LoRA gradient norms are frequently nonzero. If nearly every group has identical rewards, binary supervision may be too sparse and the pilot should stop for reward/benchmark redesign.
3. Run Phase6B independent real-Qwen holdout; inspect both drift and stationary controls **without retuning** existing policies on the test set.
4. Complete Phase6C paired training arms and independently seeded repetitions. Compare `joint_ewma` vs `uniform` at *equal logical label budget*, and both against `full` with twice the labels. Report failures and seed variability.
5. Only then decide whether the combined evidence justifies writing the experimental claims into a paper.
