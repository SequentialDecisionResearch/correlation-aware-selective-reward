# Phase 6B Calibration-2：独立任务校准、奖励多样性与五方法重新评估

版本：2026-10-25。此模块独立新增，不改动已发布 v1.2 的 Phase6A/B/C 源码。

## 1. 为什么必须设计这一阶段

用户 RTX 5070 上的 Phase6B v1.2 Qwen-0.5B 探索性实验有 12 组、每组 6 个回答：

- 八组奖励全部为 0；
- 四组每组恰好只有一个奖励为 1；
- 没有任何一组出现两个及以上正确回答。

对所有固定一阶包含概率 `pi_i=3/6=1/2` 的设计，条件线性梯度估计风险为

```
V_d(r,S) = sum_{i,j} (pi_ij^d/(pi_i*pi_j)-1)*r_i*r_j*(M_i^T*M_j).
```

在全零奖励组中风险为零；在只有位置 k 有一个正奖励的组中，它化为
`(1/pi_k - 1) * ||M_k||^2`，因此与二阶设计无关。
v1.2 的五种方法风险差异在 `1e-21` 左右，是这个数学退化现象的预期结果，
不是某个方法优劣的证据。**至少出现两个非零奖励才可能通过交叉项区分设计，
但仍不能保证任何自适应设计必然改善风险。**

## 2. 本阶段的两个互相隔离的部分

### A. 探索性奖励密度校准（只选任务类型，不比较采样算法）

定义七个预置候选任务族：

| 任务族 | 例子 | 目标 |
|---|---|---|
| `add_small` | `5 + 7` | 最简单整数加法 |
| `subtract_small` | `32 - 11` | 一步减法 |
| `multiply_single` | `7 × 8` | 一步乘法 |
| `two_digit_add` | `41 + 27` | 两位数加法 |
| `multiply_then_add` | `(7 × 8) + 4` | 简单组合 |
| `mod_small` | `(23 + 15) mod 7` | 小规模模运算 |
| `word_single` | 一篮子苹果增加数量 | 简单文字应用题 |

默认两个校准种子：`9217, 9241`；每任务族、每种子 6 组；每组六个 Qwen 回答。
一个模型生成后，本地精确核验器分别记录 0、1、2、3、4、5、6 个正奖励的组数。

**预先固定的选择门槛**：

- 总体正奖励比例至少 0.15、至多 0.85；
- 至少 20% 的校准组包含 2–4 个正奖励；
- 满足门槛的任务族中，优先选择 `2<=K<=4` 的组占比最大的任务族；
- 并列先选总体正奖励率最接近 0.5 的，再按上表固定次序决胜。

如无合格任务族，程序返回 `no_eligible_family` 并**禁止进入独立评估**。
不得因正式评估结果好坏而重新挑选任务族。

### B. 冻结选择后，新的独立五方法比较

默认使用三个未用于校准的新种子：`9323, 9349, 9371`，每种子 60 组。
任务生成使用与校准不同的随机数命名空间；任务族一经 `select` 保存便不可改变。

在每组完全相同的真实 Qwen 回答/三维 token-logit-bias score sketch 上，
比较原有五种 B=3/G=6 设计：

1. `uniform`
2. `cube_classic`
3. `scaled`
4. `joint_ewma`
5. `joint_frozen`

保持同一阶包含概率 0.5、相同逻辑标签预算、相同精确设计风险定义。
校准标签仅用于选任务族；**正式评估的完整 oracle 奖励绝不进入在线策略的状态更新**，
在线更新只用抽取到的三个奖励；完整奖励仅供事后审计和风险计算。

主要输出包含：

- 独立评估中 `2<=K<=5` 的多正奖励组比例；
- 每种策略与 Uniform 的成对风险差、按种子聚类的描述性区间；
- 每组与 Uniform 的最大成对包含概率差；
- 所有策略实际决策标签与同等预算；
- 源码/模型指纹、任务、回答、oracle、采样子集和每步在线历史的独立重放审计。

**约束**：仅有三个新种子的 t 区间仍属于描述性统计，不能声称总体显著性；
本地算术评分器非常便宜，所谓“预算”只是反事实/逻辑查询预算，并不证明真实标注费用节约。
本阶段冻结 Qwen，不更新 LoRA 权重，不能替代 Phase 6C 的训练证据。

## 3. Windows 11 / RTX 5070 运行说明

前提：已完成 `corr_grpo_phase6` 环境安装并通过 Phase6 v1.2 的原 87 项测试。
将 Calibration-2 ZIP 中的目录合并到
`C:\lsg\corr_grpo\phase4_holdout_grpo`（原始文件不需要删除）。

在 `(corr_grpo_phase6)` 的 Anaconda Prompt 中进入该目录。

### Step 0：运行全部离线测试

```bat
python -m unittest discover -s tests -q
```

成功时应显示 `Ran 92 tests` 和 `OK`。这些是模拟/离线数学/断点测试，不是 Qwen 成果。

### Step 1：先仅生成两组，验证真实 GPU 与新断点

```bat
python scripts\run_phase6b_calibration2.py --stage pilot --max-new-groups 2 --output results\phase6b_calibration2_v1
```

`--max-new-groups 2` 是**本次调用的新增上限**，不是实验配置；
后续可以不带这个标志继续。默认自动加载 Qwen2.5-0.5B-Instruct 和 CUDA。

### Step 2：完成七类探索性校准

```bat
python scripts\run_phase6b_calibration2.py --stage pilot --output results\phase6b_calibration2_v1
```

默认共 `7 * 2 * 6 = 84` 个生成组、504 个候选回答（每次只加载一次模型）。
耗时受显卡占用、模型生成长度、CPU 评分代理计算影响，**无法保证固定时间**。
每一组写入后即保存 SHA-256 记录，断电后重复相同命令自动跳过已完成组。

### Step 3：冻结选择，不触发 GPU 生成

```bat
python scripts\run_phase6b_calibration2.py --stage select --output results\phase6b_calibration2_v1
```

如果出现 `"status":"no_eligible_family"`，**到此暂停**，将校准摘要发回研究者，
不得绕过门槛或运行 Step 4。

若返回 `"status":"selected"`，会写入不可覆盖的
`calibration2_selection.json` 与带 SHA-256 的选择检查点，确定一个任务族。

### Step 4：独立种子正式比较（可以分批保存）

```bat
python scripts\run_phase6b_calibration2.py --stage evaluate --max-new-groups 2 --output results\phase6b_calibration2_v1
```

检查正常后，直接重启继续：

```bat
python scripts\run_phase6b_calibration2.py --stage evaluate --output results\phase6b_calibration2_v1
```

默认总计 `3 * 60 = 180` 个独立评估生成组，五策略共 900 个抽样决策。
最终自动打印并保存 `calibration2_summary.json`、
`calibration2_eval_policy_rows.csv`、`calibration2_audit.json`。

### Step 5：可重复独立审计（无 GPU 生成）

```bat
python scripts\run_phase6b_calibration2.py --stage audit --output results\phase6b_calibration2_v1
```

审计会复算所有校准/测试奖励、重新决定入选任务族、重放抽样概率/选择随机数
及在线更新、核对成对设计风险。

## 4. 中断、修改与研究边界

- 任意命令被中断，原子 JSON 已完成步骤在同一输出目录重跑时会被跳过。
- 不要在同一个 `--output` 下改变种子、题目数量、阈值、prompt 或源码；
  指纹检查会拒绝恢复，需开**新目录**。
- 保留 v1.2 的原 `results\phase6b_qwen_v12_calibration96` 和 Phase6C 目录。
  本扩展不会删除、覆盖旧文件。
- 严禁把 `--backend fake` 的软件测试输出当成真实 LLM 结果。
- 若独立评估再次出现“多正奖励组占比很低”或五种设计的风险几乎相等，
  必须报告该负面结果；只能在新探索性实验中重新设计任务，而不能在已见
  评估数据上后验选择结果。
- 后续真正启动 Phase 6C 前，还要让其训练任务分布与本次锁定的任务族匹配，
  并对 LoRA 每步保存实际梯度范数、非零奖励比例和独立 heldout 变化。

## 5. 写论文时应保留的证据

将 `results\phase6b_calibration2_v1` 的整个目录及运行日志永久保存。
至少需要：选择 JSON、总报告 JSON、五方法逐组 CSV、审计 JSON、
原始 generations、shadow_oracle、acq_* 决策、manifest/model_info 文件。
没有这些原始证据，不应仅依据 PDF 图表宣称实际 Qwen 模型比较有统计支持。
