# Phase 6A protocol: real frozen-Qwen generation, paid-label design simulation

**Scope / status.** This is a prospective experiment implementation, **not**
an already-executed Qwen result. The provided offline fake-backend run is only
a software test. Qwen weights and CUDA are **not** available in the author's
execution container; the intended real run must be performed on the user's
RTX 5070 (12 GB) machine and its raw outputs audited before any empirical
claim is made.

## Questions and estimands

Q1. Do joint-covariance designs reduce the *conditional randomization risk*
of a real-model, three-dimensional, frozen-policy log-score-gradient proxy
under exactly B=3 reward purchases from G=6 generated responses?

Q2. Does the advantage persist when prompts change from simpler arithmetic to
harder modular computations, under online feedback restricted to selected
reward labels? Compare five fixed-budget policies on the **same** generated
six-response group, in a common chronological order:

1. `uniform`: all 20 size-three subsets equiprobable.
2. `cube_classic`: independent Python flight/ordered-landing cube realization;
   **not** a call into CRAN `BalancedSampling::cube`. Phase 4 separately
   audited the R implementation.
3. `scaled`: auxiliary-balance LP using diagonal residual scale only.
4. `joint_ewma`: learned full second moment and exact finite-subset LP.
5. `joint_frozen`: full second-moment LP frozen after warm-up.

All adaptive designs mix 25% of the uniform design for positive pair overlap.
`warmup=26` and `window=18` by default, and the same fixed `pi=0.5` for each
method. No parameter tuning on the confirmatory seed/record set is permitted.

## What is genuinely from the language model?

- Qwen2.5-0.5B-Instruct generates all six text continuations, with a frozen
  checkpoint and stochastic **unwarped** softmax sampling.
- For each actual sampled completion, teacher forcing computes the exact
  directional score of its log-probability under three fixed random ±1
  *vocabulary-wide token-logit-bias directions*:

  `s_k = sum_t [c_k(y_t) - E_{v~p_model(.|history_t)} c_k(v)] / max_new_tokens`.

  This is an exact score for that **restricted perturbation family**, **not**
  an estimate of a real model's full LoRA gradient and **not** clipped GRPO.
- The local arithmetic verifier labels each completion 0/1 correct; scoring
  demands an explicit final integer. Both prompts and answers are generated
  from known deterministic mathematical expressions.

## What the query budget DOES and DOES NOT mean

The full six rewards are evaluated once in a distinct `shadow_oracle` ledger,
*solely* to allow retrospective exact bias/risk calculations and paired
method comparisons. Each policy sees **only the selected three** rewards in
its online update; non-selected reward slots are `NaN`. The official logical
budget is exactly three labels per method and group. The full shadow ledger
means **there are no demonstrated wall-clock, dollar, or energy savings**.

For an actual expensive external reward model, a new selectively queried,
idempotency-aware scorer must be implemented. The provided shadow-oracle
program MUST NOT be used to assert real reduction in paid verifier calls.

## Primary and secondary quantities

Let M=(S - row-mean(S))/(G-1), truth R in {0,1}^G, and q the exact
size-B acquisition distribution. Let pi and P denote its first- and
second-order inclusions. Exact conditional-on-group linear randomization
risk is

`R.T @ [((P/(pi*pi.T))-1) * (M.T @ M)] @ R`.

On each acquired subset use model-assisted HT with zero predicted reward:
`Rhat_i = Z_i R_i/pi_i` (only purchased rewards are read).

Report per method: (i) exact linear conditional risk, (ii) realized linear
MSE; (iii) exact design expectation of squared error from **naively
standardizing the HT-reconstructed vector**, and (iv) the three-dimensional
exact design bias vector of that plug-in against full-reward standardization.

The latter explicitly measures a known nonlinear bias; its value should
never be called a design-unbiased GRPO gradient. There is no token-level KL,
no clipping derivative, and no parameter update in Phase 6A.

## Fixed schedule and comparisons

- Default exploratory run: 120 prompt groups, same six model outputs for all
  five methods, one generation seed (6103), 96 new tokens maximum.
- First half: simple two/three-step arithmetic; second half: harder modular
  arithmetic. This is a *task-composition change*, not proof of endogenous
  LLM policy drift.
- Same exact sampling budget B=3 and first marginals for every method.
- Paired group comparisons are descriptive. A single model seed and task list
  cannot supply cross-seed confidence intervals or broad generalization.
- Negative results and zero/negative covariate value must be preserved.
- For any future heldout claim: freeze code/settings, use unused seeds and a
  predeclared second task collection. No retuning on that holdout.

## Reproducibility and checkpoints

- The manifest pins the complete configuration and SHA-256 hashes of all
  imported algorithm modules. A source or parameter change requires a new
  output directory. The checkpoint envelope includes a checksum, run
  fingerprint, and sequence index.
- `generations/group_XXXXXX.json` commits one full Qwen-generated group.
- `shadow_oracle/group_XXXXXX.json` commits once per group, offline only.
- `acq_<policy>/group_XXXXXX.json` commits one purchase decision; it stores
  actual subset distribution, purchase indices and revealed labels.
- On restart, completed generation is skipped; the online learners are
  restored by lightweight replay of **already purchased** labels and saved
  inclusion probabilities. `joint_frozen` restores its pre-alert frozen
  covariance snapshot explicitly. Replayed state does not require Qwen/GPU.
- Writes are atomic and fsynced. A process crash can lose at most the group
  or decision currently in flight, not previously committed work. Corrupted
  or noncontiguous checkpoints cause an error, not silent recomputation.
- For true external paid services exactly-once billing cannot be guaranteed
  without provider idempotency and request reconciliation; this experiment
  uses only free local deterministic scoring.
- A per-run OS-held lock prevents simultaneous writers. Do not share one
  output directory across machines or change model files mid-run.

## Audit and claim boundary

`audit()` separately reconstructs the proposal distribution via the
pre-observation online history, checks deterministic selection, actual
observed rewards, fixed marginals, budgets, hashes and recomputes linear
risk from the quadratic. This is **internal independent-code-path audit**,
not external peer review.

`phase6a_group_policy_metrics.csv` contains every group-policy pair's
descriptive risk, observed squared error, subset-overlap diagnostics and
query counts; it is written from immutable committed acquisition records.

Even success cannot establish improved training convergence, optimizer
stability, policy accuracy, real-verifier cost savings or scalable general
applicability. Those are later Phase 6B/6C research questions.
