# 第四阶段研究交付：官方 R Cube 与独立持出检验

**日期：2026 年 10 月 23 日**

## 结论先行

你要求的三件工作**都完成了代码和实际实验**，但第三项的结果不够好：

1. **官方 R Cube 独立对照完成**：实际安装并运行 CRAN
   `BalancedSampling::cube`，5 组设计共 25,000 次抽样，固定预算及
   一阶边际经验检验正常。
2. **冻结参数的独立验证完成**：12 个从未用于 Phase 3 的种子、
   7 个新漂移／厚尾场景、7 个策略、每组 160 次决策，累计
   **94,080 条策略决策、282,240 次模拟 gold reward 查询**。
3. **改进漂移报警与稳健回退**：引入 IPW 矩阵范数截断、连续三次报警、
   独立校准阈值、历史估计的回退风险对比，以及最多 25% 的部分
   回退（而非直接全部切换）。新方法比上一阶段的“硬回退”有所
   改进，却仍**不如持续更新协方差、不强制回退**的策略。

根据**执行前写好的**内部准入条件，当前结论是：

> **暂不投入真实 LLM 后训练的 GPU 及验证器费用。**
> 继续免费／低成本研究漂移检测的跨分布稳定性；重新设计后必须
> 使用新持出样本，不能再次用这次的 12 个种子调试。

## 核心数字

| 持出实验后半段平均梯度风险（越低越好） | 结果 |
|---|---:|
| 始终在线更新联合协方差（Joint EWMA） | **0.5373** |
| 新的保守部分回退（Guarded Partial） | 0.5444 |
| 旧的完整漂移回退（Drift Gated） | 0.5566 |
| 固定旧协方差（Joint Frozen） | 0.5785 |
| 均匀购买 | 0.6488 |

新方法相对于始终联合更新方法的平均“风险改善”为 **−0.00710**，
12 个独立种子给出的描述性 95% 区间为
**[−0.01342，−0.00078]**，整体没有取得正改进。

两个**真实无变化的持出对照**，分别有 **3/12（25%）** 和
**2/12（16.7%）** 的独立实验发生漂移误报；事先规定的要求为
各场景低于 10%。这说明原来校准出来的报警阈值，并不能可靠迁移
到不同协方差结构或厚尾环境。

但新回退机制相比旧硬回退降低风险约 **0.01220**：这是有用的
工程改进，只是不足以战胜更简单的、一直适应学习的策略。

## 文件在哪里

| 路径 | 内容 |
|---|---|
| `docs/PHASE4_PROTOCOL_LOCKED.md` | 新方法、随机种子、阈值校准、七类场景和预先确定的准入标准 |
| `docs/PHASE4_INDEPENDENT_RESULTS.md` | 完整英文研究报告、两套实验表、失效分析及理论边界 |
| `results/phase4_real_R_cube/` | 官方 R `cube()` 产生的 25,000 个真实抽样指示向量及对照 JSON |
| `results/phase4_frozen_holdout_full/` | 94,080 条原始记录、32 种子校准和持出汇总 |
| `results/phase4_go_no_go.json` | 每个“进入真实 LLM”准入条件的机械审核结果 |
| `results/phase4_figures/` | 三张由原始结果生成的图 |
| `src/phase2_grpo/guarded_online.py` | 新检测器及保守回退方法的全部代码 |
| `src/phase2_grpo/holdout_world.py` | 严格定义的持出协方差／Student-t 世界 |
| `src/phase2_grpo/holdout_study.py` | 完整种子配对实验和结果统计 |
| `scripts/r_cube_reference_suite.py` | 实际调用 R/CRAN 官方 `cube()` 的比较程序 |

## Windows / Anaconda Prompt 复现

解压后**进入 `phase4_holdout_grpo` 项目目录**，再依次执行：

```bat
python -m pip install -e ".[figures]"
python -m unittest discover -s tests -q
python scripts\run_independent_holdout.py --quick --output results\phase4_quick_repeat
python scripts\run_independent_holdout.py --output results\phase4_holdout_repeat
python scripts\make_phase4_holdout_figures.py --input results\phase4_holdout_repeat --output results\phase4_figures_repeat
python scripts\evaluate_phase4_gates.py --holdout results\phase4_holdout_repeat --r-reference results\phase4_real_R_cube --output results\phase4_repeat_decision.json
```

完整持出实验此次约运行 **254 秒**，不需要 GPU、真正的 LLM
或者付费 verifier；不同 Windows 机器的求解器速度可能不同。
建议先运行 quick 版检查环境，全部结果已随压缩包提供，
**不需要重新运行才能阅读论文研究结论**。

如果要在自己电脑上从头运行官方 R 对照，需要另外安装 R、确保
命令行能调用 `Rscript`，然后执行：

```bat
Rscript -e "install.packages('BalancedSampling',repos='https://cloud.r-project.org')"
python scripts\r_cube_reference_suite.py --draws 5000 --output results\phase4_R_repeat
```

Windows 可能会使用官方预编译 R 包，或根据当前版本请求 RTools
编译工具。压缩包不附带生成环境的 Linux R 二进制文件。

## 数学上真正得到的保证

如果联合采样策略 (Q_J) 和回退采样策略 (Q_B) 有相同一阶边际、
固定样本量，则以比例 (\lambda) 混合后，其梯度误差风险满足

\[
R\big((1-\lambda)Q_J+\lambda Q_B\big)-R(Q_J)
=\lambda\big(R(Q_B)-R(Q_J)\big).
\]

所以部分回退确实把一次错误切换带来的**相对损害幅度**按比例
降低了；但如果 (Q_B) 比 (Q_J) 差，混合后的结果仍会更差，
因此这不是“绝对安全”定理。

## 下一步科研建议

优先研究适用于**自适应抽样、相关奖励和厚尾变化**的校准报警，
以及能够合理量化协方差估计误差的风险上界。现有数值结果告诉
我们，继续增加复杂回退规则并不一定比“持续在线学习”好。

这次保存了**完整正反结果**，其中的不成功部分同样应成为以后
论文的机制诊断和创新方向。只有新一轮独立实验真正通过事先
规定的条件，再决定是否采购实际 LLM 训练资源。
