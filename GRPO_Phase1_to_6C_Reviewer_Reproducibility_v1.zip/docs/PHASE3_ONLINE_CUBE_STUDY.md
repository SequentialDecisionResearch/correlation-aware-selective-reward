# Phase 3 technical note — classical Cube Method and online residual learning

**Evidence status:** 23 October 2026, new exploratory computational study,
run to completion in this environment. **No** actual LLM weights, real costly
verifier, training-policy updates, or preregistered inference are claimed.

## 1. New research question

Previous Phase 2 showed that a static estimated-correlated-reward joint LP is
an HT balancing LP after a tensor feature lift. Its real weakness is estimating
the relevant second moments online and maintaining acquisition performance
through a distribution change. Phase 3 therefore asks:

> With exactly B of G gold queries per group, can an online, overlap-aware
> residual-moment estimator outperform static/stale designs, and when does
> drift monitoring plus a simple safe-looking fallback actually help?

The word **safe-looking** is deliberate: the fallback here is an empirical
heuristic. There is no finite-sample guarantee that its risk improves over
adaptive joint selection. The experiment tests rather than assumes this.

## 2. Genuine classical balancing algorithms and provenance

`classic_cube.py` implements **both actual algorithmic phases** of the cube
approach introduced by Deville and Tillé:

1. **Flight:** starting from inclusion vector `pi`, find a nonzero null-space
   direction of the active HT constraints by SVD, move randomly in the two
   maximal feasible directions using probabilities that preserve conditional
   expectation. This retains all current balancing totals while possible.
2. **Landing:** if the active constraints no longer admit a nontrivial flight
   direction, **drop the last remaining auxiliary constraint** and continue
   with the martingale. Crucially, never drop the **sum of inclusion indicators
   equals B** constraint. Thus exact cardinality and first inclusion are
   preserved, while some less important auxiliary totals may lose balance.
3. For G<=8 in this study, enumerate all finite martingale branches to
   produce an explicit, verified exact subset distribution; pair inclusions
   are not guessed from empirical frequencies.

**Mathematical validity vs reference identity.** This is a full two-phase cube
sampler, not the Phase 2 *simplified paired landing*. Direction-ordering and
landing objectives can yield different valid cube designs. We **do not** claim
this Python method is bit-for-bit or distribution-identical to the independently
maintained `BalancedSampling::cube` routine. The latter is integrated by
`r_cube_bridge.py` + `scripts/r_cube_reference.R`, and separately audited with
`scripts/check_r_reference.py` and its R batch counterpart. **R is not present
in the executed Linux environment**, so no actual R CRAN output is falsely
reported. On a Windows machine with R, the R comparison is fully callable.

Documentation for the independent CRAN reference:
https://cran.r-project.org/web/packages/BalancedSampling/refman/BalancedSampling.html

Its description explicitly requires adding `pi` as the first auxiliary
balancing variable to retain fixed sample size, matching our size-constraint
priority. The CRAN implementation is covered by its own license (AGPL-3);
our project does not copy its R/C++ source or redistribute its binaries.

Mathematical attribution must include Deville & Tillé (2004), Chauvet & Tillé
(2006), and **Hasler, Eustache & Tillé (2026), _In Search of the Most Balanced
Sampling Design_**, which explicitly discusses combinatorial optimal design
formulations. The Phase 2 tensor-lift barrier remains in force.

## 3. Online estimating equation and positive pair inclusion

For history t, before purchasing any current reward, the policy computes an
exact-B distribution Q_t using only scores and moments from times <t.
The policy's base design is mixed with uniform exact-B exploration:

    Q_t = (1-epsilon) Q_t_base + epsilon Q_uniform, epsilon=0.25.

All Q_t_base have the same pi_i=B/G, so the mixture preserves them. With B>=2,
uniform pairs have pi_ij=B(B-1)/(G(G-1)). Thus, every pair's actual inclusion
is at least epsilon*B(B-1)/(G(G-1)). For G=6,B=3, the floor is 0.05.

After the chosen B rewards are revealed, only *masked* residuals `e_i` and
the **actual mixed** pair probabilities are supplied to the learner. Set

    H_t,ij = Z_ti Z_tj e_ti e_tj / pi_t,ij,
    Vhat_t_raw = (1-alpha)*Vhat_{t-1}_raw + alpha*H_t,

with diagonal convention pi_t,ii=pi_t,i. Provided acquisition does not see
current hidden e, **E[H_t,ij | F_(t-1)] = E[e_ti e_tj | F_(t-1)]**.
This is a direct existing IPW/HT identity, not new theory. The learner
projects a lightly diagonal-shrunk matrix to PSD (with explicit regularizer).
Under drift, its EWMA is biased toward the past. Pair ESS is computed from
observed HT weights and used as a gate, never as a magical proof of overlap.

**No-current-reward-leakage contract:** acquisition accepts only current
score vectors and the learner's historical state. A per-step `CountingOracle`
reveals only indices bought. Tests verify that changing any unpurchased value
does not change the estimator, and that a zero-pair-support input fails.

## 4. Drift detection and fallback protocol

- Keep 2w=36 newest IPW matrices, divide into two 18-step windows.
- Monitor the Frobenius difference between the two window means, normalized
  by the larger window Frobenius norm or 1.
- Threshold 1.30 signals drift. Reset off-diagonal EWMA and diagnostic
  histories, preserve estimated marginal second-moment scales, then return to
  diagonally scaled global balancing for 24 subsequent acquisition decisions.
- Before accepting joint LP, require pair ESS>=1.5 and a predicted full-moment
  risk advantage exceeding 1.5% of the estimated scaled-balancing risk.
- If these checks fail, acquire via the diagonally scaled score-balancing LP.
- Every nonuniform decision is finally mixed with 25% exact-B uniform
  exploration, preserving equal budgets and strict pair positivity.

**Statistical limitation:** this two-window threshold is NOT a calibrated
level-alpha test, CUSUM proof, confidence sequence, change-point guarantee,
or risk-safe policy improvement theorem. Due to adaptively changing Q_t, the
IPW observations are conditionally unbiased but not simply exchangeable.
Failure to detect severe shifts is a central result, not an implementation
error concealed by a theoretical assertion.

## 5. Exact comparison and study design

`online_study.py` uses six policies:

| Policy | Selection rules |
|---|---|
| `uniform` | Uniform size-B queries; still logs IPW history for diagnostics |
| `cube_classic` | Full flight/landing cube balancing online diagonally scaled score features |
| `scaled` | Globally optimized score balancing with historical diagonal moments |
| `joint_ewma` | Full estimated moment LP, continuously updated EWMA |
| `joint_frozen` | Full joint LP with covariance frozen immediately after shared warm-up |
| `drift_gated` | Online full moment LP, drift monitor, ESS/gain gate and fallbacks |

All six methods receive the same generated policy-score matrix, same latent
Gaussian reward residual vector, B=3 of G=6 query calls, pi_i=0.5, and
independent reproducible acquisition RNG streams. **True V_t is used only
in the evaluator and an oracle lower bound**, not by the policies, feature
selection, drift threshold, or fallback. Scores do not undergo policy
optimization. This is online *acquisition*, not online LLM training.

Full run: **5 scenarios × 8 seeds × 160 steps × 6 policies = 38,400 policy
decisions**, exactly **115,200 metered synthetic label purchases**, at
25% uniform design mixing. Every changed scenario switches covariance at
step 80; the stationary signed-factor control does not change.

Scenarios (old -> new):

1. signed -> signed (**no-change negative control**)
2. signed factor -> strong positive common factor
3. strong positive common factor -> signed factor
4. signed factor -> negative equicorrelation
5. two-block factor -> signed factor

The main estimand is **exact conditional one-step acquisition squared-gradient
risk** computed with evaluation-only V_t. The observed single-realization
squared-gradient error is also retained, but it is much noisier. The policy
does not optimize a real task reward or update a language model.

## 6. Full actual observed results (default threshold 1.30)

| Scenario, after step 80 | Uniform risk | Classical full Cube | Scaled balance | Joint EWMA | Frozen joint | Drift-gated |
|---|---:|---:|---:|---:|---:|---:|
| Stationary signed | 0.593 | 0.626 | 0.640 | **0.310** | 0.305 | 0.315 |
| Signed -> common | 0.714 | 0.541 | **0.366** | 0.466 | 0.756 | 0.446 |
| Common -> signed | 0.599 | 0.626 | 0.641 | **0.363** | 0.615 | 0.396 |
| Signed -> negative | 0.593 | 0.623 | 0.658 | 0.578 | 0.591 | 0.581 |
| Blocks -> signed | 0.599 | 0.628 | 0.649 | 0.332 | 0.408 | **0.321** |

Lower is better. Values are **averages of synthetic conditional risk**, not
standardized economic percentages. The table should be interpreted jointly
with the raw paired seeds and pre-switch results, which are preserved in
`online_trials.csv` and `online_summary.json`.

Additional paired post-switch gate minus adaptive evidence, written as
`Risk(joint EWMA)-Risk(gated)` (positive favors the gate):

| Scenario | Mean gate improvement over continuously updated joint |
|---|---:|
| Stationary signed | -0.00425 |
| Signed -> common | +0.01928 |
| Common -> signed | -0.03232 |
| Signed -> negative | -0.00327 |
| Blocks -> signed | +0.01077 |
| **Mean across all post-switch scenario steps** | **-0.00196** |

Thus **the gate does not have an overall improvement in this suite**.
It is encouraging in two transitions and counterproductive in three others,
including the stationary control. We must not claim it has solved safe online
acquisition under nonstationarity.

Detected post-switch change fraction across the 8 seeded runs was **12.5%**
for signed->common, **25%** for common->signed, **62.5%** for signed->negative,
and **0%** for blocks->signed. The no-change control had 0 post-switch
alerts. No pre-switch alerts occurred in these particular 8-seed trajectories.
This is **not proof of 0 false alarm rate** or reliable high-power detection.

The full study took **95.98 seconds** in the reference Linux environment.
Individual runtimes on Windows and different SciPy/HiGHS releases may differ.
This run used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and
Matplotlib 3.10.8 for the generated figures. The full package passed
**48 unit tests** and a separate **2,600-case first-order-marginal stress
test** (0 failures; maximum tested error 8.16e-11).

## 7. Post-hoc sensitivity check: a detector that fires more may be worse

After the primary experiment we lowered the drift threshold from **1.30 to
1.05** and reran all five scenarios with **four seeds** instead of eight,
keeping the other parameters unchanged. This is an **exploratory sensitivity
analysis** on overlapping development seeds, not an independent confirmatory
replication. Because the comparison has different numbers of seeds, only the
direction and magnitude of changes should be interpreted; the risk figures
are not a properly paired threshold-comparison estimate over identical eight
seeds.

| Scenario | Threshold 1.05: post-change alert fraction | Pre-change alerts per step | Risk: joint EWMA | Risk: drift gate |
|---|---:|---:|---:|---:|
| Stationary signed (no true change) | 100% (spurious) | 0.00938 | **0.323** | 0.477 |
| Signed -> common | 75% | 0.00938 | 0.460 | **0.431** |
| Common -> signed | 100% | 0.00938 | **0.349** | 0.498 |
| Signed -> negative | 100% | 0.00313 | **0.588** | 0.639 |
| Blocks -> signed | 75% | 0.00938 | **0.348** | 0.410 |

For the stationary control, a "post-change alert" is necessarily a *false*
alarm because there is no change at step 80. A smaller threshold increases
sensitivity but can produce **harmful fallback decisions and false alarms**.
This falsifies a blanket claim that more aggressive monitoring always creates
safe performance improvements. No detector guarantee is established.

Underlying records: `results/phase3_online_threshold_105_exploratory/`,
**19,200 online policy decisions and 57,600 synthetic oracle calls**, runtime
**48.30 seconds**. Reproduce with:

```bat
python scripts\run_online_study.py --drift-threshold 1.05 --seed-count 4 --output results\phase3_online_threshold_105_repeat
```

## 8. Experimental artifacts and exact reproduction

Executed outputs:

- `results/phase3_online_full/online_trials.csv` — all 38,400 decisions,
  true conditional risks, actual sampled subset, observed squared error,
  queries, pair ESS, propensity floor, monitor statistic, decisions and timing.
- `results/phase3_online_full/online_summary.json` — aggregate seed-cluster
  descriptive intervals and full recorded alert times for each scenario/seed.
- `results/phase3_online_quick/` — 1,920-row smoke experiment.
- `results/phase3_online_threshold_105_exploratory/` — completed post-hoc
  four-seed detector sensitivity study, including negative outcomes.
- `results/phase3_online_figures/` — exact-risk profile heatmap, correctly
  edge-normalized time trajectories, and detailed gate-decision fractions.

```bat
python -m pip install -e ".[figures]"
python -m unittest discover -s tests -q
python scripts\run_online_study.py --quick --output results\phase3_online_quick_repeat
python scripts\run_online_study.py --output results\phase3_online_full_repeat
python scripts\make_online_figures.py --input results\phase3_online_full_repeat\online_trials.csv --output results\phase3_online_figures_repeat
```

The default Python code uses a self-contained cube flight/landing algorithm.
Optional R verification, **only if R and BalancedSampling are installed**:

```bat
Rscript -e "install.packages('BalancedSampling', repos='https://cloud.r-project.org')"
python scripts\check_r_reference.py --draws 3000
```

The optional R audit is a **separate Monte Carlo reference comparison**. It
does not feed empirically estimated pair probabilities into unbiased training
as if they were known exactly, and it is not recorded as completed until you
actually execute it in an R-capable environment.

## 9. Publication decision gates

1. **No journal submission as a safe change detector yet.** This benchmark
   exposes considerable failure-to-detect and sometimes worse gate choices.
2. Extend the exploratory threshold sensitivity to cooldown and ESS/gain
   gates; then **lock** the complete specification before genuinely held-out
   seeds, profiles, task families and empirical pricing. Thresholds 1.30
   and 1.05 were both investigated during development.
3. Calibrate statistically valid sequential drift alarms under adaptive IPW,
   e.g. a martingale or confidence-sequence construction with actual support,
   boundedness/moment assumptions, and explicit delay/false-alarm tradeoff.
4. Derive a *valid* matrix-error radius for covariance-gated risk decisions;
   a heuristic empirical radius is insufficient for a theorem of safety.
5. Compare the actual official R reference Cube implementation once R is
   present. Include numerical tolerance, runtime and both balance and risk
   comparisons; no unsupported equivalence claim.
6. Move from exogenous scores to a live clipped/normalized GRPO optimizer,
   genuine expensive verifier and metered wall-clock/dollar outcome comparison.
7. If all these gates are addressed, reconsider journal selection with honest
   emphasis on online information acquisition and nonstationarity.

### Primary and reference sources

- Deville, J.-C. and Tillé, Y. (2004). *Efficient balanced sampling: the cube
  method*. **Biometrika** 91(4), 893–912.
  https://doi.org/10.1093/biomet/91.4.893
- Chauvet, G. and Tillé, Y. (2006). *A fast algorithm for balanced sampling*.
  **Computational Statistics** 21(1), 53–62.
- Official package documentation, *BalancedSampling::cube* (CRAN), describing
  fixed size by the first balancing variable and the flight algorithm:
  https://cran.r-project.org/web/packages/BalancedSampling/refman/BalancedSampling.html
- Hasler, C., Eustache, E. and Tillé, Y. (2026).
  *In Search of the Most Balanced Sampling Design* (preprint).
  https://arxiv.org/abs/2607.26544
