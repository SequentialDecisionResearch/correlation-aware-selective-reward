# Phase 2: balanced survey comparators, matched budgets, and falsification

**Evidence date:** 23 October 2026. **Status:** executed exploratory synthetic study; **not** preregistered and **not** a claim of real LLM post-training improvement.

## Scientific question

Condition on a fixed group of G policy-score vectors and a pre-query
predictor. Under an exact B-gold-verifier budget and fixed first-order
inclusion probabilities pi_i=B/G, does exploiting pairwise reward residual
moments improve the conditional one-step *unnormalized LOO* gradient-estimation
risk relative to strong classical auxiliary-balancing comparators?

This is **not** standard token-level clipped GRPO. The report is about the
linear score-function surrogate only.

## The exact novelty barrier

Let S be the d-by-G score matrix, M=S(I-11^T/G)/(G-1), V=E[ee^T|F0] be a
pre-query residual *second moment* matrix (not necessarily a centered
covariance), V=L L^T, and Z encode purchased rewards. For positive pi_i,

    T_i = vec(M[:,i] outer L[i,:]),

    E_Q ||sum_i (Z_i/pi_i-1) T_i||^2
      = E_Q ||M diag(Z/pi-1) L||_F^2
      = trace[ M (C_Q hadamard V) M^T ],

where C_Q,ij=pi_ij/(pi_i pi_j)-1. The last expression is the exact
acquisition error for fixed scores and residual second moments. Hence the
joint fixed-marginal coupling LP is precisely **an HT auxiliary balancing LP
with tensor-product features**. It is not independent new sampling theory.
This identity holds for *any PSD V*, beyond the six experimental families.

The difference between score-only, diagonally scaled, and full-tensor
balancing is choice/estimation of auxiliaries, **not** a different class of
static sampling mechanisms. Real novelty, if any, must be in how useful
features are learned under finite adaptive budgets, or in a GRPO-specific
objective that is not reducible to this generic linear acquisition risk.

## Methods: equal opportunity and accurate attribution

All acquisition designs buy exactly B out of G rewards and preserve identical
pi_i=B/G. The true target V is used **only for evaluation** and for a separately
labeled oracle lower bound. Implemented practical policies do not see it.

| Label in CSV | Method | Information at decision time |
|---|---|---|
| `uniform` | Uniform exact-B subset design | G, B |
| `cube` | Enumerated cube-*style* SVD flight with **simplified dependent-pair landing** | M; pi |
| `score` | Global LP for expected squared HT imbalance of M columns | M; pi |
| `scaled` | Global LP for HT imbalance of pilot-diagonally-scaled M | M; pi; pilot diagonal |
| `joint` | Plug-in global LP using full estimated PSD residual moments | M; pi; pilot Vhat |
| `oracle` | Infeasible full-true-V global LP, evaluation-only lower bound | true V, **not deployable** |

**Important:** `cube` is **not** an implementation of Deville and Tillé's
published optimally landed cube method; the fully optimized auxiliary LP is
a deliberately strong classical comparison, not a named historical algorithm.
It would be misleading to call the present study a complete benchmark against
published cube software, modern scalable balanced algorithms or DPP solvers.

## Factorial experiment actually run

- Group size G in {4,6,8}.
- Budget B in {1, floor(G/2), G-1}. B=1 and G-1 are no-coupling degrees-of-freedom controls.
- Six explicit positive-semidefinite residual second-moment families:
  independent; rho=0.3 common; rho=0.8 common; +/- signed common factor;
  negative equicorrelation rho=-0.75/(G-1); two-block factor structure.
- Heterogeneous standard deviations between 0.75 and 1.25.
- Matched pilot or drifted historical pilot (15% target, 85% competing PSD profile).
- N=120 or 600 historical pilot draws for interior budgets.
- 12 seeds for interior cells and 4 for boundary controls.
- 3 independent score dimensions, deterministic seed stream; all methods evaluated
  on the *same scores*, true V, B and pi in each cell.
- **1008 evaluated rows = 864 interior + 144 boundary**. The main exploratory
  report's matched, N=600, interior stratum has 216 cells; the 12 RNG seeds are
  treated as **clusters** for descriptive t intervals, not 216 independent tasks.

The `phase2_study.py` code is the precise experimental specification;
`results/phase2_full/all_trials.csv` is the complete raw output.

## Honest observed effects

Risk units are conditional squared-gradient *acquisition-risk* units;
**positive** `joint_vs_scaled = risk_scaled-risk_joint` favors joint.
Same verifier budget for every method means these are **not** call-cost savings.

| Residual profile | Matched pilot N=600, mean joint advantage over scaled balance |
|---|---:|
| Independent | 0.00000 (exact no-gain control) |
| Common rho=0.3 | -0.00446 |
| Common rho=0.8 | -0.00185 |
| Signed +/- factor | +0.60262 |
| Negative equicorrelation | +0.22715 |
| Two-block correlation | +0.21734 |

Main exploratory 216-cell mean: +0.17347; descriptive 12-seed-cluster
95% interval [0.12716, 0.21977]. The 12 RNG clusters do not establish
generalization across independent tasks, reward models, verifier types or
LLM checkpoints; profiles and specifications were selected during
exploratory development.

With **covariance drift**, matched comparison can reverse strongly:

| Profile | Matched N=600 | Drifted N=600 |
|---|---:|---:|
| Common rho=0.3 | -0.00446 | **-0.21034** |
| Common rho=0.8 | -0.00185 | **-0.24108** |
| Signed factor | +0.60262 | +0.40369 |
| Negative equicorrelation | +0.22715 | +0.09645 |
| Two blocks | +0.21734 | +0.08584 |

In **186 of all 1008 cells**, joint performed worse than diagonally scaled
balancing by more than 1e-9 risk units. This count includes interrelated
designed cells, not 1008 independent samples. Under fixed marginals, all
methods achieved numerical no-gain boundary/diagonal controls within
4.45e-15; this is a necessary correctness check, not a novelty contribution.

## What is and is not identified

Strict pi_i>0 supports design unbiasedness of augmented reward scores.
Estimating V_ij without parametric assumptions requires positive **pairwise**
pi_ij; B=1 cannot identify off-diagonal moments from its one-at-a-time labels.
The pooled moment estimator fits a stationary pilot unconditional V; it is not
proved to consistently estimate prompt-conditional V(F0). Its PSD projection
cannot replace missing overlap. Drift tests reveal sensitivity to misspecified
historical moments but do not give distribution-free safety guarantees.

The no-coupling B=1 and G-1 strata offer no cross-policy gain; they do **not**
make a valid exploration source for all desired pair moments.

## Verification and execution

Executed and saved on 2026-10-23:

    PYTHONPATH=src python3 -m unittest discover -s tests -q
    python3 scripts/run_balanced_study.py --output results/phase2_full
    MPLCONFIGDIR=/tmp/phase2-matplotlib python3 scripts/make_phase2_figures.py

- Unit tests: 35/35 PASS.
- Full factorial 1008-row synthetic study: PASS, 14.57s script internal timer;
  about 16.11s external wall time on the tested Linux environment.
- All common marginals and exact-B feasibility: checked per row.
- Matched oracle lower bound: checked per row.
- Tensor-balance equality: explicit regression test.
- Original near-boundary stress program: bundled for reproducibility.

Small G exact enumeration is exponential in G. Timings above do not extrapolate
to large-G transformers. Platform, solver and CPU differences change runtime.

## Scientific decision before a journal submission

1. **Do not submit as a new fixed-marginal sampling theory.** The tensor
   equivalence is a serious reduction to familiar survey balancing.
2. Implement an externally validated Deville--Tillé cube method (or established
   balanced-sampling package), under the *same* pi/B and with transparent
   auxiliary parity; additionally consider modern DPP methods with clear
   inclusion constraints.
3. Create held-out task families and locked preregistered hypotheses after
   exploratory selection; quantify training **reward, accuracy, verifier costs,
   wall time, stability**, not solely one-step gradient risk.
4. Connect selective acquisition to **actual clipped / normalized GRPO** and
   no-leakage live gold verifier through a metered interface.
5. Develop a nontrivial **online reward-covariance learning** or drift-adaptive
   selection guarantee that cannot simply be restated as an existing balanced
   sampling objective; compare learning costs and overlap.
6. Include failure cases, pilot pairwise ESS, and runtime overhead as first-class
   endpoints. Negative common-mode/drift behavior must be reported in the paper.

This extension is a credible and fully testable **pre-publication diagnostic
experiment**, **not** independently sufficient experimental support for a
method-plus-real-world LLM post-training article.

## Prior art positioning (verify formatting at manuscript submission)

- Deville and Tillé, *Efficient Balanced Sampling: The Cube Method*, Biometrika 91(4), 2004.
- Clémençon et al., *Optimal survey schemes for stochastic gradient descent with applications to M-estimation*, ESAIM: Probability and Statistics 23:310--337, 2019, DOI: 10.1051/ps/2018021.
- Zhang, Kjellström and Mandt, *Determinantal Point Processes for Mini-Batch Diversification*, Proceedings of Machine Learning Research **R15**, pp. 281--290, UAI 2017.
- Contemporary active U-statistics and GRPO/U-statistics papers appear in the
  earlier companion PDFs; do not conflate their observation assumptions.
