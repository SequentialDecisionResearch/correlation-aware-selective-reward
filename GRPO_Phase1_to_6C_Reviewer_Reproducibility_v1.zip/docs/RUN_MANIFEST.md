# Executed research-run manifest

> **Archive notice (23 October 2026):** The sections immediately below record
> the **original reconstructed foundation only**. The subsequent independent
> Phase 2 balanced-sampling extension has **35/35 combined passing tests**,
> **1,008 additional executed rows**, a 10+ page compiled third report, and
> two classical-inspired balancing baselines. Consult
> `PHASE2_BALANCING_STUDY.md` and `results/phase2_full/summary.json` for that
> newer study. Statements below that a classical comparator is absent apply
> to the older foundation **at the time of its own run**; an independently
> validated published cube landing implementation is still absent.

All runs below were performed on 2026-10-23 as internal synthetic diagnostics. They are not a certified external benchmark.

## Observed environment

- Python: 3.12.14
- NumPy: 2.3.5
- SciPy: 1.17.0
- Matplotlib: 3.10.8 (figure generation only)
- Document compilation: XeLaTeX, A4, two compilation passes per source

`pyproject.toml` declares supported minimum dependencies; the versions above record **the actual run environment** for comparison. Exact numerical LP solutions can vary at tolerances across SciPy/HiGHS releases.

## Execution commands and artifacts

1. `PYTHONPATH=src python3 -m unittest discover -s tests -v` → **26/26 pass**, including three additional strict input-validator regressions found during final review.
2. `python3 scripts/stress_marginals.py` → `results/marginal_stress.json`, **2,600/2,600 pass** with maximum discrepancy `8.154296434570674e-11`.
3. `PYTHONPATH=src python3 -m phase2_grpo --output results/full` → `results/full/{summary.json,design_grid.csv,toy_training.csv,counterexample.json}`.
4. `MPLCONFIGDIR=/tmp/phase2-matplotlib python3 scripts/make_figures.py` → `results/figures/controlled_coupling.png` and `results/figures/toy_training_differences.png`.

## Raw file definitions

- `results/full/design_grid.csv`: one row for each of the **132** `(G,B,rho,seed)` cases, with exact baseline risk, oracle-design risk, pilot-based risk, regret, marginal/second-moment diagnostics and LP subset count. Uses four actual random seeds per parameter setting.
- `results/full/toy_training.csv`: one row for each `(seed,method)` among six paired seeds, 160 updates, with toy terminal expected reward, mean query-gradient squared error and simulated oracle-call accounting.
- `results/full/counterexample.json`: exactly specified four-candidate construction and analytic/Monte Carlo risks.
- `results/full/summary.json`: computed aggregates and a **descriptive**, two-sided paired-*t* interval for terminal reward differences. This interval is not a powered inferential claim.
- `results/marginal_stress.json`: feasible-input generator and worst numerical error. These are **new** tests, not exact replications of the historical independent auditor's random stream.

## Scope ceiling

No current LLM model weights, external verifier endpoint, real cost accounting, feature-conditional `V(F0)` estimator, classical cube sampler, or DPP comparison is included. The source refuses arbitrary large exact-subset enumeration. Read the full PDFs for proof assumptions and publication stop conditions.
