# Phase 6 v1.2 — exploratory prompt/reward amendment (2026-10-25)

## Reason for amendment: observed real-Qwen failure

This amendment was made **after inspecting outputs** from the Qwen2.5-0.5B-
Instruct RTX 5070 pilot; it is *not* a prespecified independent evaluation.
With max_new_tokens=24, all 12 Phase6B sampled rewards were zero. With
max_new_tokens=96, the first real Phase6C group still had 6/6 zero rewards,
zero pre-clip gradient norm, and heldout parseability 0/6. On inspecting its
recorded completions, sample 5 answered the simple training expression
`(17 × 18) + 14` with the explicitly correct final sentence
`Therefore, the answer is 320.`, but v1.1 returned `PARSED None`, reward 0.
Other completions were unfinished, wrong, or did not explicitly designate a
final answer; they must **not** be assumed correct from intermediate digits.
The easy-task prompt also explained `mod` even when no modulo expression
appeared, plausibly distracting the 0.5B model.

## v1.2 decisions, frozen before new pilot data are collected

1. **Answer parser:** Accept `\boxed{N}`, `Answer: N`, `Final answer: N`,
   `answer is N`, or a bare integer (including an isolated final line). For
   responses with multiple explicit boxed or labeled answer markers, take
   the **last marker in generation order**. Never extract arbitrary
   intermediate numbers. An absent/incomplete final marker remains zero
   reward, even if a correct intermediate computation appears elsewhere.
2. **Arithmetic reward:** Binary `reward = 1` precisely when a final integer
   can be parsed and equals the deterministic gold integer. No fuzzy
   arithmetic, hidden chain-of-thought, or semantic grading is used.
3. **Strict format metric:** `format_compliant = 1` exactly when the **entire
   response**, after optional whitespace, is a single `\boxed{N}`. This
   intentionally differs from parseability and numeric correctness.
   `strict_format_correct` additionally requires that boxed N is correct.
   Thus `Therefore, the answer is 320.` yields numeric reward 1 but strict
   compliance 0. `\boxed{320}` yields both 1, and a truncated explanation
   with `17 × 18 = 306` yields neither.
4. **Prompt:** A concise common system instruction demands a single boxed
   integer and no explanation/code. Both Phase6A/C task prompts and the
   separate Phase6B holdout task prompts use the same answer-format rule.
   The easy arithmetic task family omits `mod` entirely; modular tasks still
   define nonnegative modulo.
5. **Statistical methods untouched:** Exact-B acquisition probabilities,
   five Phase6B designs, the conditional design estimand, the Phase6C
   `loo_ht` objective, LoRA optimizer, and logical-cost caveat are unchanged.
   No retrospective oracle reward is passed into the partially observed
   learner. Phase6B's full shadow reward remains for post-hoc auditing only.

## Independent diagnostic outputs

- Phase6B oracle journals store `full_rewards`, `full_parseable`,
  `full_format_compliant`, and `full_strict_format_correct` arrays.
  `phase6b_summary.json` reports all four rates by scenario/seed cell and
  across complete cells.
- Phase6C per-step journals store corresponding `shadow_full_*` arrays.
  The JSON summary and per-step CSV report separate accuracy, parseability,
  strict-format compliance, and strict-format correctness rates. Heldout
  evaluation reports all four, independently of acquisition policy.
- Internal audits replay scorer outputs from saved completions. New unit
  tests exercise the observed correct-natural-language response, irrelevant
  modulo-prompt suppression, strict-vs-relaxed distinctions, audit/restart,
  and policy-gradient mathematics.

## Version and checkpoint discipline

Changes to `phase6a_tasks.py`, `phase6a_model.py`, `phase6a_study.py`,
`phase6b_study.py`, `phase6c_model.py`, and `phase6c_training.py` alter
content-addressed run manifests. Existing Phase6A, 6B, 6C output roots from
v1.0/v1.1 **must remain historical and must not be resumed under v1.2**.
No original results, checkpoints, source files or user historical collections
need be deleted. Phase6B and Phase6C new manifests have schema version 2;
Phase6A's source/protocol manifest version is also incremented.

The originally inspected Phase6B `seed=8123` and Phase6C `seed=6207` can be
used *only for explicitly exploratory v1.2 calibration*. Do not report such
reused pilot seeds as sealed independent holdout evidence. After the protocol
stabilizes, preselect **new, uninspected** seeds/task families and run all
comparators without response-dependent tuning; archive the exact model
commit, complete parameters, task texts, parser code and audits. Code-level
manifest reproducibility is not an external trial preregistration.

## Windows 11 / RTX 5070 step-by-step smoke

From `(corr_grpo_phase6) C:\lsg\corr_grpo\phase4_holdout_grpo`:

```bat
python -m unittest discover -s tests -q
python scripts\run_phase6b.py --backend hf --groups 12 --seeds 8123 --scenarios word_to_mod --warmup 2 --window 3 --max-new-tokens 96 --output results\phase6b_qwen_v12_calibration96
```

Inspect `generation_quality_overall` in the Phase6B summary. Require
actual nonzero positives and adequate variation within groups before
running a costly Phase6C learning comparison. Strict format compliance can
remain low even when arithmetic answer accuracy is nonzero; report both.

If calibration is nondegenerate, a *new* Phase6C one-step GPU smoke is:

```bat
python scripts\run_phase6c.py --steps 6 --seed 6207 --warmup 2 --window 3 --max-new-tokens 96 --eval-every 2 --eval-size 6 --arms full --max-new-steps 1 --output results\phase6c_real_gpu_v12_smoke96
```

Check `nonzero_gradient_steps_by_arm["full"]` and both reward/format rates.
At one committed step the run is intentionally `complete:false`, and
`genuine_model_updates` stays false until a complete real-arm run with
positive gradients. Never promise nonzero rewards in advance: even v1.2
may require additional explicitly *exploratory* redesign or a larger model.

## Limitations

These arithmetic rewards are computed by a **cheap local exact verifier**;
the study tests *logical oracle query counts*, not actual annotation costs.
The exact final-answer parser can still miss unusual correct phrasings; it
is auditable and uniformly frozen before new evaluation. The pilot itself
is not evidence of an improvement of balancing or adaptive GRPO acquisition.
