# Phase 5 execution manifest

Run date: 2026-10-23. Environment: Linux host, CPython 3.12.14,
NumPy 2.3.5, SciPy 1.17.0, matplotlib 3.10.8.

**Provenance order:** frozen protocol -> implemented simulation/bridge ->
quick smoke run -> initial audit bug fixed (the bridge witness was
accidentally packaged as a one-element tuple, a reporting-only bug) ->
quick smoke and audit passed -> complete 16-seed holdout executed once ->
audit executed on full raw data -> results tables and descriptive figures.
The bridge's clipping derivative interpretation was corrected **before**
the full holdout completed. The online policy and simulator implementations
were unchanged after the full run began; their final source hashes match
the hashes recorded by the full-run summary.

## Actual execution results

| Step | Observation |
|---|---|
| Quick smoke trial | 1,600 decisions, 4,800 simulated query calls |
| Full frozen online trial | 76,800 decisions, 230,400 simulated query calls |
| Online full runtime | 186.14 seconds |
| Full audit | Passed; output `results/phase5_full/phase5_audit.json` |
| Final pre-packaging unit/regression tests | 63 passed |
| Exact nonlinear bridge | 64 independent synthetic groups x 5 budgets |
| LaTeX proof memorandum | Four-page PDF, compiled via pdflatex |
| Official R Cube | Available Phase-4 pre-existing reference, not rerun online |

## Audit limitations

The auditor independently parses raw rows and recomputes risk averages,
seed-blocked intervals, exact budgets and integrity constraints. It is
not a separate third-party implementation of the policy-selection LP or
of the simulator's construction of true moments; it does not re-derive
every saved conditional true risk from logged full subset probabilities.
The theory memo's concentration bound assumes bounded rewards and does
not apply without modification to the Gaussian or Student-t5 experiments.

The project has no real LLM verifier, actual training checkpoint,
generation throughput/dollar-accounting measurement or external
preregistration. These limitations apply to every reported result.
