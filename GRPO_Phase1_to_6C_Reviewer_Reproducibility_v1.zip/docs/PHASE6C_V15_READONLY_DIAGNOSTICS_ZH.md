# Phase 6C v1.5 — 已完成 LoRA 实验的只读诊断与固定压力测试

## 目标与旧结果保护

本补丁仅**增加三个文件**：

- `src/phase2_grpo/phase6c_diagnostics.py`：只读输入检验、压力题库、学习曲线和 LoRA 距离。
- `src/phase2_grpo/phase6c_diagnostic_eval.py`：读取已保存的模型状态，逐题重新评估并生成配对报告。
- `scripts/diagnose_phase6c.py`：命令行入口。

还包括本使用说明及 CPU 单元测试。**不修改原来的训练代码、模型文件、校准数据、LoRA 检查点、审计、manifest 或摘要文件。** 新结果全部保存在独立 `--output` 目录；程序拒绝将输出目录置于任何原始训练目录内部。

必须已有三个 `complete=true`、`genuine_model_updates=true`、审计通过的真实 GPU Phase 6C 训练结果，且它们只有训练随机种子不同。默认对下列三个运行进行分析：

```text
results\phase6c_cal2_seed6207
results\phase6c_cal2_seed6219
results\phase6c_cal2_seed6251
```

## Windows CMD 使用顺序

在 `C:\lsg\corr_grpo\phase4_holdout_grpo` 内，激活 `corr_grpo_phase6` 环境。

### A. CPU：验证旧数据并锁定全新压力测试（不运行模型）

```bat
python scripts\diagnose_phase6c.py --stage prepare --runs results\phase6c_cal2_seed6207 results\phase6c_cal2_seed6219 results\phase6c_cal2_seed6251 --output results\phase6c_v15_diagnostics --stress-per-stratum 32
```

应输出 `status: locked`、`stress_items: 96`、`stress_bank_sha256`。

`stress_bank.json` 会在**任何压力测试预测产生之前**固定，每类 32 题、共 96 题，三种子和三个方法共用：

1. `two_digit_carry_ood`：两个 80–99 的整数相加，个位必须进位。原校准及训练的两位数加数均在 11–79 之间。
2. `three_digit_double_carry`：三位整数加法，个位与十位均进位。
3. `three_term_add`：三个整数的组合加法。

题目由不依赖模型输出的固定确定性生成程序构造；实际训练/测试题目也经过精确提示文本及交换加数的重复检查。因为压力题库是在已经观察此前 Phase 6C 结果之后建立，所以它是**事后设计、首次压力结果之前冻结的探索性测试**，不是原论文预注册的确认性测试，也不允许根据压力结果重新选择题目。

### B. CPU：学习曲线与 LoRA 参数差异（不执行 Qwen 生成）

```bat
python scripts\diagnose_phase6c.py --stage inspect --output results\phase6c_v15_diagnostics
```

输出：

- `phase6c_learning_curve_stats.json`：0、10、20、…、60 步的梯形积分平均准确率（AULC）、预定阈值 75%/85%/90%/95% 的首次**被评估观察到**的达到步骤、达标种子数量及未达标截尾数量；种子层面配对 AULC 差异。
- `phase6c_checkpoint_learning_curves.csv`：全部种子、方法和检查点准确率。
- `phase6c_adapter_distances.json`：各个种子 Uniform、Joint EWMA、Full 之间的最终 LoRA 参数距离、相对于初始状态的距离和余弦；还计算实际 LoRA 权重更新 `B @ A * (alpha/r)` 的 Frobenius 距离，以避免 A/B 不同缩放但等效模型造成的误判。

请注意，A/B 参数距离本身不是函数空间距离，也不蕴含更好的泛化。**有效的 LoRA 更新距离更有解释价值。**

### C. GPU：逐题重放旧留出集，评估固定压力题库

先只运行一个评估事件验证 GPU 环境：

```bat
python scripts\diagnose_phase6c.py --stage evaluate --output results\phase6c_v15_diagnostics --max-new-evals 1
```

没有错误后，继续全部剩余事件：

```bat
python scripts\diagnose_phase6c.py --stage evaluate --output results\phase6c_v15_diagnostics
```

可随时停止再运行**相同命令**；已提交事件会被完整性验证后跳过。每个事件使用现有 `optimizer_states/after_step_XXXXXX.pt` 的 LoRA 参数，执行确定性贪心解码，**不反向传播、不训练，也不写入旧目录**。

逐题留出集：0、10、20、30、40、50、60 步。压力题库：仅在第 0 和 60 步评估。每个种子三种方法：7 个旧留出评估事件 + 2 个压力评估事件；三种子共 `3 × 3 × 9 = 81` 个事件。默认产生约 `3 × 3 × (7 × 24 + 2 × 96) = 3,240` 道 Qwen 贪心推断，这一步可能明显比 CPU 阶段慢，且需要 GPU。

**重要可复现性保护：** 旧留出集的每个重放评估必须与之前保存的正确数、可解析率和格式指标一致；若因模型版本/设备环境变化出现不同，程序报错暂停，不会悄悄将不一致结果当作原实验数据。

### D. CPU：合成逐题配对差异与压力测试分析

在全部事件完成后运行：

```bat
python scripts\diagnose_phase6c.py --stage report --output results\phase6c_v15_diagnostics
```

输出：

- `phase6c_item_predictions.csv`：每个种子、方法、评估时点、任务 ID、完整问题、真实答案、原始模型回答、解析出的答案、正确性及格式指标。
- `phase6c_item_pairs.csv`：相同题目、相同步骤、同一种子下的三方法配对结果，包括 Uniform 独有正确 / EWMA 独有正确及最终解析答案。总体准确率相同也可能有逐题分歧。
- `phase6c_stress_by_seed.csv`：每种压力难度、每个种子、每个方法在第 0 与第 60 步的正确数和准确率。
- `phase6c_diagnostic_summary.json`：按压力难度汇总的前后变化及 EWMA − Uniform 种子层面描述性区间、逐题分歧计数，另按种子列出**最终检查点**的逐题分歧（避免把多次评估同一道题错误地当作独立样本）。

## 研究解释边界

1. 新诊断不改变此前的 Phase 6B “线性草图设计风险下降 20.06%”结论，也不能自动将其解释为真实 LoRA 参数梯度方差减少。
2. 三个种子的最终准确率差全为 0 时，程序可机械地得到零宽度的样本 t 区间；**这不是总体等价性证明**。
3. 压力题的多种难度是新的探索性 OOD 测试。即使能区分方法，也需要独立种子和预先固定的下一阶段重复检验才可提出确认性泛化主张。
4. 通过检查点重新生成旧留出回答，本质是一次诊断重放。原始训练日志中的评估汇总仍然是训练时记录的唯一原始报告。
5. `--stress-per-stratum` 和 `--runs` 只在首次 `prepare` 时决定诊断清单；不要在同一输出目录尝试换题目、种子或配置。要建立新协议，请使用新的诊断输出目录。

## 验证与兼容性

可执行：

```bat
python -m unittest discover -s tests -q
```

开发环境的 CPU mock 测试覆盖：固定任务生成、题目不重叠、快照原封不动、断点恢复、逐题配对、LoRA A/B 规范变换不改变有效更新、摘要重新汇总和篡改拒绝。**真实 RTX 5070 + Qwen 检查点重放必须由你在本机运行；本交付没有假称已完成这一步 GPU 实测。**
