"""Calibration-2 replay, selection blindness and sparse-risk tests (NO GPU)."""

import csv
from pathlib import Path
import tempfile
import unittest

import numpy as np

from phase2_grpo.balanced import auxiliary_balance_lp
from phase2_grpo.design import uniform_design
from phase2_grpo.phase6a_model import FakeBackend
from phase2_grpo.phase6a_study import _design_bias_and_risk
from phase2_grpo.phase6b_calibration2 import (Calibration2Config,task_bank,run,
    FAMILIES)
from phase2_grpo.risk import acquisition_weight


class Calibration2Tests(unittest.TestCase):
    def config(self,**kwargs):
        base=dict(pilot_groups=3,eval_groups=8,pilot_seeds=(97101,97103),
                  eval_seeds=(97201,97207),families=("add_small","mod_small"),
                  warmup=2,window=3,max_new_tokens=16,backend="fake")
        base.update(kwargs)
        return Calibration2Config(**base)

    def scripted(self,cfg):
        gold={}
        for family in cfg.families:
            for seed in cfg.pilot_seeds:
                for task in task_bank(cfg.pilot_groups,seed,family,split="pilot"):
                    gold[task["prompt"]]=task["answer"]
        for seed in cfg.eval_seeds:
            for family in cfg.families:
                for task in task_bank(cfg.eval_groups,seed,family,split="eval"):
                    gold[task["prompt"]]=task["answer"]

        class PositiveFake(FakeBackend):
            def generate(self,task,seed,g,max_new_tokens):
                if "answer" in task:
                    raise AssertionError("gold leaked to generator")
                sample=super().generate(task,seed,g,max_new_tokens)
                answer=gold[task["prompt"]]
                sample["completions"]=[
                    f"\\boxed{{{answer}}}" if j<3 else
                    f"Therefore, the answer is {answer+1}." for j in range(g)]
                return sample
        return lambda _:PositiveFake()

    def test_benchmark_tasks_are_reproducible_and_no_extra_mod(self):
        for family in FAMILIES:
            a=task_bank(8,991,family,split="pilot")
            self.assertEqual(a,task_bank(8,991,family,split="pilot"))
            self.assertNotEqual(a,task_bank(8,991,family,split="eval"))
            self.assertTrue(all("\\boxed{N}" in row["prompt"] for row in a))
            if family!="mod_small":
                self.assertTrue(all("'mod'" not in row["prompt"] for row in a))

    def test_rejects_overlapping_seeds_and_invalid_gates(self):
        with self.assertRaises(ValueError):
            self.config(eval_seeds=(97101,))
        with self.assertRaises(ValueError):
            self.config(min_positive_rate=.8,max_positive_rate=.5)
        with self.assertRaises(ValueError):
            self.config(families=("unknown",))

    def test_pilot_selection_and_eval_resume_with_independent_audit(self):
        cfg=self.config()
        factory=self.scripted(cfg)
        with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
            self.assertFalse(run(cfg,b,stage="pilot",max_new_groups=2,
                                 backend_factory=factory)["pilot_complete"])
            self.assertEqual(run(cfg,b,stage="select")["status"],"pending_pilot")
            done=run(cfg,b,stage="pilot",backend_factory=factory)
            self.assertTrue(done["pilot_complete"])
            sel=run(cfg,b,stage="select")
            self.assertEqual(sel["status"],"selected")
            self.assertEqual(sel["selected_family"],"add_small")
            self.assertEqual(sel["family_statistics"]["add_small"]
                             ["multi_positive_fraction"],1.)
            partial=run(cfg,b,stage="evaluate",max_new_groups=2,
                        backend_factory=factory)
            self.assertFalse(partial["complete"])
            partial=run(cfg,b,stage="evaluate",max_new_decisions=3,
                        backend_factory=factory)
            self.assertFalse(partial["complete"])
            finished=run(cfg,b,stage="evaluate",backend_factory=factory)
            self.assertTrue(finished["complete"])
            self.assertTrue(finished["audit"]["pass"])
            self.assertEqual(finished["audit"]["checked_decisions"],2*8*5)
            self.assertEqual(finished["audit"]["checked_pilot_groups"],2*2*3)
            self.assertEqual(finished["evaluation_multi_positive_group_fraction"],1.)
            self.assertEqual(finished["rows_available"],2*8*5)
            self.assertTrue(finished["meaningful_cross_reward_interactions"])
            with (Path(b)/"calibration2_eval_policy_rows.csv").open(
                    encoding="utf-8",newline="") as stream:
                self.assertEqual(len(list(csv.DictReader(stream))),2*8*5)

            run(cfg,a,stage="pilot",backend_factory=factory)
            run(cfg,a,stage="select")
            complete_a=run(cfg,a,stage="evaluate",backend_factory=factory)
            self.assertEqual(complete_a["paired_vs_uniform"],
                             finished["paired_vs_uniform"])
            with self.assertRaisesRegex(RuntimeError,"checkpoint/config mismatch"):
                run(self.config(min_diverse_group_fraction=.5),b,stage="summary")

    def test_no_eligible_family_blocks_evaluation(self):
        cfg=self.config()
        class AlwaysWrong(FakeBackend):
            def generate(self,task,seed,g,max_new_tokens):
                sample=super().generate(task,seed,g,max_new_tokens)
                sample["completions"]=["\\boxed{-9999999}"]*g
                return sample
        with tempfile.TemporaryDirectory() as folder:
            run(cfg,folder,stage="pilot",backend_factory=lambda _:AlwaysWrong())
            selection=run(cfg,folder,stage="select")
            self.assertEqual(selection["status"],"no_eligible_family")
            with self.assertRaisesRegex(RuntimeError,"evaluation is BLOCKED"):
                run(cfg,folder,stage="evaluate")

    def test_one_hot_reward_risk_is_invariant_under_fixed_marginals(self):
        rng=np.random.default_rng(89)
        score=rng.normal(size=(3,6))
        uniform=uniform_design(6,3)
        balanced=auxiliary_balance_lp(uniform.marginals,3,score)
        self.assertTrue(np.allclose(uniform.marginals,balanced.marginals))
        for k in range(6):
            reward=np.eye(6)[k]
            risks=[float(reward@acquisition_weight(score,d)@reward)
                   for d in (uniform,balanced)]
            self.assertAlmostEqual(risks[0],risks[1],places=11)


if __name__=="__main__":
    unittest.main()
