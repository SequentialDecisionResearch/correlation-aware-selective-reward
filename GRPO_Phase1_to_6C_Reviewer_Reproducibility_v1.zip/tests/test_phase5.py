"""Regression tests for Phase 5 locked worlds, bridge, and theory witness."""

import unittest

import numpy as np

from phase2_grpo.phase5_bridge import (_bridge_group, finite_interaction,
                                        group_gradient)
from phase2_grpo.phase5_study import (PHASE5_POLICIES, PHASE5_SEEDS,
                                      PHASE5_WORLDS, phase5_world)
from phase2_grpo.holdout_world import CALIBRATION_SEEDS, HOLDOUT_SEEDS
from phase2_grpo.online_study import SEEDS
from phase2_grpo.design import uniform_design
from phase2_grpo.optimization import optimize_coupling
from phase2_grpo.risk import acquisition_risk
from phase2_grpo.geometry import gradient_map


class Phase5ProtocolTests(unittest.TestCase):
    def test_new_seeds_are_disjoint(self):
        old = set(SEEDS) | set(CALIBRATION_SEEDS) | set(HOLDOUT_SEEDS)
        self.assertFalse(old.intersection(PHASE5_SEEDS))
        self.assertEqual(len(set(PHASE5_SEEDS)), len(PHASE5_SEEDS))

    def test_all_new_worlds_have_valid_moments(self):
        for name in PHASE5_WORLDS:
            for t in (0, 36, 52, 68, 79, 92, 112, 159):
                state = phase5_world(name, t)
                self.assertEqual(state.moment.shape, (6, 6))
                self.assertGreater(np.linalg.eigvalsh(state.moment).min(), 0)
                self.assertTrue(np.allclose(state.moment, state.moment.T))

    def test_stationary_control_diagonal(self):
        v = phase5_world('stationary_independent', 155).moment
        self.assertTrue(np.allclose(v, np.diag(np.diag(v))))
        self.assertEqual(len(PHASE5_POLICIES), 5)

    def test_invalid_world_or_step_rejected(self):
        with self.assertRaises(ValueError):
            phase5_world('not_a_world', 3)
        with self.assertRaises(ValueError):
            phase5_world('stationary_independent', 160)

    def test_linear_exact_design_unbiased_budgets(self):
        rng = np.random.default_rng(79)
        scores = rng.normal(size=(3, 6))
        r = rng.normal(size=6)
        ratios = np.exp(rng.normal(size=6)*.2)
        for budget in range(1, 6):
            result = _bridge_group(scores, r, ratios, budget)
            self.assertLess(result['linear']['exact_design_bias_norm'], 1e-11)
            self.assertGreaterEqual(result['normalized']['exact_design_mean_square_error'], 0)

    def test_interaction_obstruction_for_group_normalization(self):
        scores = np.array([
            [.4, -.9, .8, 1.1, -.2, .3],
            [-.8, .25, -.15, .7, .6, -.9],
            [.7, .4, -.6, -.3, .9, .2]])
        rewards = np.array([-1.2, -.8, .3, .9, -.35, 1.1])
        increments = np.array([.25, -.33, .42, -.27, 0., 0.])
        normal = finite_interaction(scores, rewards, increments, (0,1,2,3))
        self.assertGreater(np.linalg.norm(normal), 1e-8)
        # A truly additive (linear) function must have a vanishing mixed
        # finite difference of order >=2; this tests the proof mechanism.
        linear = np.zeros(3)
        from itertools import combinations
        ids = (0,1,2,3)
        for count in range(len(ids)+1):
            for subset in combinations(ids, count):
                changed = rewards.copy()
                for i in subset:
                    changed[i] += increments[i]
                linear += (-1.)**(len(ids)-len(subset)) * (scores @ changed)
        self.assertLess(np.linalg.norm(linear), 1e-12)

    def test_clipped_gradient_is_zero_on_flat_branch(self):
        scores = np.eye(3,6)
        r = np.array([3.,1.,0.,0.,0.,0.])
        normalized = (r-r.mean()) / np.sqrt(np.mean((r-r.mean())**2))
        ratios = np.array([1.5, 1., 1., 1., 1., 1.])
        result = group_gradient(scores,r,ratios)
        self.assertGreater(normalized[0],0)
        self.assertAlmostEqual(result[0],0.,places=12)
        self.assertTrue(np.allclose(group_gradient(scores,r,np.ones(6)),
                                    group_gradient(scores,r)))

    def test_independent_finite_support_risk_calculation(self):
        rng = np.random.default_rng(20261023)
        for trial in range(12):
            scores = rng.normal(size=(3,6))
            a = rng.normal(size=(6,6))
            v = (a @ a.T) / 6 + .1*np.eye(6)
            pi = np.full(6,.5)
            design = (uniform_design(6,3) if trial%2 else
                      optimize_coupling(scores,v,pi,3)[0])
            m = gradient_map(scores)
            risk_direct = 0.
            for z,p in zip(design.subsets, design.probs):
                a_vec = z / design.marginals - 1.
                risk_direct += float(p*np.trace(
                    m @ (np.outer(a_vec,a_vec)*v) @ m.T))
            self.assertAlmostEqual(risk_direct,
                                   acquisition_risk(scores,v,design),places=10)

    def test_fixed_marginal_coupling_ignores_only_diagonal_error(self):
        rng = np.random.default_rng(256)
        scores = rng.normal(size=(3,6))
        raw = rng.normal(size=(6,6))
        v = raw @ raw.T / 6 + np.eye(6)
        pi = np.full(6,.5)
        q0=uniform_design(6,3)
        q1=optimize_coupling(scores,v,pi,3)[0]
        changed=v + np.diag(np.array([.2,.3,.4,.2,.5,.6]))
        diff0=acquisition_risk(scores,v,q1)-acquisition_risk(scores,v,q0)
        diff1=acquisition_risk(scores,changed,q1)-acquisition_risk(scores,changed,q0)
        self.assertAlmostEqual(diff0,diff1,places=10)


if __name__ == '__main__':
    unittest.main()
