"""Offline QA for calibrated Phase6C. Real HF/PEFT GPU still needs smoke."""

import csv
import json
from pathlib import Path
import pickle
import sys
import tempfile
import types
import unittest
from contextlib import nullcontext
from unittest.mock import patch

import numpy as np

from phase2_grpo.phase6b_calibration2 import task_bank
from phase2_grpo.phase6c_calibrated_tasks import _key, calibrated_tasks
from phase2_grpo.phase6c_objectives import Phase6CConfig
from phase2_grpo.phase6c_training import locked, run
from phase2_grpo.phase6c_model import RealLoRAPolicy


EVIDENCE="a"*64


def config(**changes):
    base={"steps":6,"seed":6207,"warmup":2,"window":3,"eval_every":2,
          "eval_size":6,"max_new_tokens":64,"task_family":"two_digit_add",
          "calibration_evidence_sha256":EVIDENCE}
    base.update(changes)
    return Phase6CConfig(**base)


class CalibratedTaskTests(unittest.TestCase):
    def test_split_reproducible_no_cross_family_or_eval_leakage(self):
        c=config(steps=60,eval_size=30)
        training,heldout=calibrated_tasks(c)
        self.assertEqual((len(training),len(heldout)),(60,30))
        self.assertEqual((training,heldout),calibrated_tasks(c))
        t_keys={_key(t) for t in training}
        h_keys={_key(t) for t in heldout}
        self.assertEqual((len(t_keys),len(h_keys)),(60,30))
        self.assertFalse(t_keys & h_keys)
        baseline=set()
        for seed in (9217,9241):
            baseline.update(_key(t) for t in task_bank(6,seed,"two_digit_add",split="pilot"))
        for seed in (9323,9349,9371):
            baseline.update(_key(t) for t in task_bank(60,seed,"two_digit_add",split="eval"))
        self.assertFalse((t_keys|h_keys)&baseline)
        self.assertTrue(all(t["level"]=="two_digit_add" for t in training+heldout))

    def test_calibrated_config_and_source_manifest_are_locked(self):
        with self.assertRaises(ValueError):
            Phase6CConfig(task_family="two_digit_add")
        with self.assertRaises(ValueError):
            Phase6CConfig(task_family="legacy",calibration_evidence_sha256=EVIDENCE)
        self.assertEqual(locked(config())["schema"],3)
        self.assertEqual(locked(Phase6CConfig())["schema"],2)
        self.assertIn("src/phase2_grpo/phase6c_calibrated_tasks.py",
                      locked(config())["source_sha256"])

    def test_calibration_evidence_gate(self):
        import importlib.util
        script=Path(__file__).resolve().parents[1]/"scripts"/"run_phase6c_calibrated.py"
        spec=importlib.util.spec_from_file_location("calibrated_cli",script)
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for name,document in (
                ("calibration2_selection.json",{"status":"selected","selected_family":"two_digit_add"}),
                ("calibration2_summary.json",{"selected_family":"two_digit_add", "complete":True,
                     "backend":"hf","evaluation_groups_complete":180,"rows_available":900}),
                ("calibration2_audit.json",{"pass":True,"checked_decisions":900,
                     "expected":900,"checked_pilot_groups":84})):
                (root/name).write_text(json.dumps(document),encoding="utf-8")
            value=module.verified_calibration_evidence(root)
            self.assertEqual(len(value),64)
            (root/"calibration2_audit.json").write_text('{"pass":false}',encoding="utf-8")
            with self.assertRaises(RuntimeError):
                module.verified_calibration_evidence(root)

    def test_real_policy_heldout_accepts_selected_family_level(self):
        tokens=np.array([[10,11]],dtype=np.int64)
        calls=[]
        class StubModel:
            def eval(self):pass
            def train(self):pass
            def generate(self,**kwargs):
                calls.append(kwargs)
                return np.array([[10,11,12]])
        class StubTokenizer:
            eos_token_id=12
            def decode(self,tokens,skip_special_tokens=True):
                return "\\boxed{37}"
        fake=types.SimpleNamespace(model=StubModel(),tokenizer=StubTokenizer(),
            torch=types.SimpleNamespace(inference_mode=nullcontext,
                                        ones_like=np.ones_like),
            cfg=types.SimpleNamespace(max_new_tokens=64),
            _prompt=lambda text:tokens)
        result=RealLoRAPolicy.evaluate(fake,[{"level":"two_digit_add",
                          "prompt":"20+17","answer":37}])
        self.assertEqual(result["accuracy"],1.)
        self.assertEqual(result["accuracy_by_level"],{"two_digit_add":1.})
        self.assertIn("attention_mask",calls[0])


class FakeCalibratedPolicy:
    """Deliberately not a real LoRA model; only verifies trainer plumbing."""
    def __init__(self,cfg):
        self.cfg=cfg;self.weight=0.
        self.info={"backend_type":"test_fake_only","seed":cfg.seed}
        self.gold,_=calibrated_tasks(cfg)

    def generate(self,task,index):
        if "answer" in task:
            raise AssertionError("gold answer disclosed to generator")
        answer=self.gold[index]["answer"]
        samples=[{"text":f"\\boxed{{{answer if j%2==0 else answer+1}}}",
                  "token_ids":[j+1],"old_logp":[-1.]}
                 for j in range(self.cfg.g)]
        scores=np.random.default_rng(index+937).normal(size=(3,self.cfg.g))
        return {"samples":samples,"score_features":scores.tolist(),
                "backend":"test_fake_only"}

    def update(self,task,samples,coeff):
        if "answer" in task:raise AssertionError("gold leaked into optimizer")
        delta=0.01*(1.+abs(float(np.sum(coeff))))
        self.weight+=delta
        return {"loss_per_epoch":[self.weight],"grad_norm_per_epoch":[delta],
                "adapter_delta_l2":delta,"genuine_lora_optimizer_steps":0}

    def evaluate(self,heldout):
        return {"accuracy":self.weight,"heldout_count":len(heldout),
                "accuracy_by_level":{"two_digit_add":self.weight}}

    def checkpoint_payload(self,step):
        return {"completed_steps":step,"weight":self.weight}

    def restore(self,state,step):
        if state["completed_steps"]!=step:raise RuntimeError("state mismatch")
        self.weight=state["weight"]


class CalibratedJournalTests(unittest.TestCase):
    def test_three_arms_resume_observed_only_audit(self):
        c=config()
        def fake_save(state,stream):pickle.dump(state,stream)
        def fake_load(path,**kwargs):
            with open(path,"rb") as stream:return pickle.load(stream)
        torch_stub=types.SimpleNamespace(save=fake_save,load=fake_load)
        with patch.dict(sys.modules,{"torch":torch_stub}):
            with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
                completed=run(c,a,policy_factory=FakeCalibratedPolicy)
                self.assertTrue(completed["complete"])
                self.assertTrue(completed["audit"]["pass"])
                self.assertFalse(completed["genuine_model_updates"])
                self.assertEqual(completed["nonzero_weight_delta_steps_by_arm"],
                     {"full":6,"uniform":6,"joint_ewma":6})
                partial=run(c,b,max_new_steps=2,policy_factory=FakeCalibratedPolicy)
                self.assertFalse(partial["complete"])
                continued=run(c,b,max_new_steps=7,policy_factory=FakeCalibratedPolicy)
                self.assertFalse(continued["complete"])
                result=run(c,b,policy_factory=FakeCalibratedPolicy)
                self.assertEqual(completed["initial_heldout"],result["initial_heldout"])
                self.assertEqual(completed["final_heldout"],result["final_heldout"])
                self.assertEqual(completed["total_logical_reward_queries"],result["total_logical_reward_queries"])
                self.assertTrue(result["audit"]["pass"])
                with (Path(b)/"phase6c_learning_curves.csv").open(encoding="utf-8",newline="") as stream:
                    self.assertEqual(len(list(csv.DictReader(stream))),18)


if __name__=="__main__":
    unittest.main()
