"""Sealed holdout separation, true moments, and damage-limited mixtures."""

import tempfile
import unittest

import numpy as np

from phase2_grpo.design import uniform_design
from phase2_grpo.guarded_online import (
    GuardedOnlineAcquirer,GuardSpec,ClippedWindowMonitor,maximum_patience_score)
from phase2_grpo.holdout_world import (
    HOLDOUT_SEEDS,CALIBRATION_SEEDS,HOLDOUT_SCENARIOS,world_state,draw_residual)
from phase2_grpo.holdout_study import run_holdout
from phase2_grpo.online_study import OnlineConfig,SEEDS


class Phase4MethodTests(unittest.TestCase):
    def test_disjoint_seeds_and_unseen_regimes(self):
        self.assertFalse(set(SEEDS)&set(HOLDOUT_SEEDS))
        self.assertFalse(set(CALIBRATION_SEEDS)&set(HOLDOUT_SEEDS))
        self.assertEqual(len(HOLDOUT_SCENARIOS),7)
        for scenario in HOLDOUT_SCENARIOS:
            for t in (0,35,79,80,95,119,159):
                state=world_state(scenario,t)
                self.assertGreater(np.linalg.eigvalsh(state.moment).min(),0)

    def test_student_t_scale_mixture_has_target_covariance(self):
        # Monte Carlo error tolerance is deliberately wider than a formal CI.
        state=world_state("stationary_heavy_tail",90)
        rng=np.random.default_rng(876)
        samples=np.stack([draw_residual(rng,state) for _ in range(9000)])
        error=np.linalg.norm(samples.T@samples/len(samples)-state.moment,"fro")
        self.assertLess(error,0.55)

    def test_monitor_clips_unbounded_ipw_event(self):
        d=uniform_design(4,2)
        m=ClippedWindowMonitor(4,3,clip_matrix_norm=12)
        z=np.array([1,0,1,0],dtype=bool)
        obs=np.array([1e80,np.nan,-1e80,np.nan])
        m.update(obs,z,d)
        self.assertLessEqual(np.linalg.norm(m.history[-1],"fro"),12.000001)

    def test_alarm_patience_and_cooldown(self):
        cfg=OnlineConfig(horizon=80,warmup=6,window=3,cooldown=8,
                         seeds=(17,),scenarios=("stationary_signed",))
        spec=GuardSpec(drift_threshold=.20,patience=2,clip_matrix_norm=200)
        model=GuardedOnlineAcquirer(cfg,spec)
        d=uniform_design(6,3)
        z=np.array([1,1,1,0,0,0],dtype=bool)
        for k in range(12):
            val=0. if k<5 else 10.
            visible=np.array([val,val,val,np.nan,np.nan,np.nan])
            model.observe(visible,z,d)
        self.assertTrue(model.alert_times)
        self.assertGreater(model.cooldown_left,0)
        self.assertLessEqual(model.spec.max_rollback,.25)

    def test_patience_statistic_is_maximum_running_minimum(self):
        self.assertEqual(maximum_patience_score([.1,.8,.7,.9,.4],3),.7)

    def test_quick_study_is_explicitly_not_confirmatory(self):
        with tempfile.TemporaryDirectory() as temp:
            summary=run_holdout(temp,quick=True)
            self.assertTrue(summary["quick_smoke_only"])
            self.assertEqual(summary["rows"],2240)
            self.assertEqual(summary["metered_synthetic_calls"],6720)


if __name__=="__main__":
    unittest.main()
