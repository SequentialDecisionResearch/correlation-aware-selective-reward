"""Offline test suite: no network, LLM weights, GPU or paid verifiers."""

import csv
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from phase2_grpo.design import uniform_design
from phase2_grpo.phase6a_checkpoint import Checkpoints
from phase2_grpo.phase6a_model import FakeBackend, decision_seed, group_seed, token_signs
from phase2_grpo.phase6a_study import (Phase6AConfig, _design_bias_and_risk,
                                       audit, collect, evaluate, summarize)
from phase2_grpo.phase6a_tasks import final_integer, make_tasks, score_answer


class Phase6ATests(unittest.TestCase):
    def config(self, **kwargs):
        base = dict(groups=12, master_seed=881, warmup=2, window=3,
                    max_new_tokens=16, backend="fake")
        base.update(kwargs)
        return Phase6AConfig(**base)

    def test_tasks_are_reproducible_and_require_explicit_final_number(self):
        tasks = make_tasks(count=11, seed=9, schedule="easy_to_hard")
        self.assertEqual(tasks,make_tasks(count=11, seed=9, schedule="easy_to_hard"))
        self.assertEqual([x["level"] for x in tasks].count("easy"),5)
        self.assertEqual(final_integer("step 18, 21 and then \\boxed{-17}"),-17)
        self.assertEqual(final_integer("the intermediate integers were 18 and 21"),None)
        self.assertEqual(score_answer(tasks[0],f"\\boxed{{{tasks[0]['answer']}}}")["reward"],1.)

    def test_v12_natural_final_answer_vs_strict_boxed_compliance(self):
        task={"answer":320}
        user_example="17 * 18 = 306. Therefore, the answer is 320."
        natural=score_answer(task,user_example)
        self.assertEqual(natural["reward"],1.)
        self.assertEqual(natural["parsed_answer"],320)
        self.assertTrue(natural["parseable"])
        self.assertFalse(natural["format_compliant"])
        self.assertEqual(natural["answer_format"],"labeled")
        self.assertFalse(natural["strict_format_correct"])

        boxed=score_answer(task,"\\boxed{320}")
        self.assertEqual(boxed["reward"],1.)
        self.assertTrue(boxed["format_compliant"])
        self.assertTrue(boxed["strict_format_correct"])
        self.assertEqual(final_integer("\\boxed{306} ... the answer is 320."),320)
        self.assertEqual(final_integer("Answer: 320"),320)
        self.assertEqual(final_integer("-17"),-17)
        self.assertEqual(final_integer("17 * 18 = 306, then add 14 to get 320"),None)
        wrong=score_answer(task,"Therefore, the answer is 319.")
        self.assertTrue(wrong["parseable"])
        self.assertEqual(wrong["reward"],0.)

    def test_v12_easy_prompt_has_no_irrelevant_mod_instruction(self):
        tasks=make_tasks(count=8,seed=6207,schedule="interleaved")
        for task in tasks:
            self.assertIn("No steps, explanations, or code.",task["prompt"])
            self.assertIn("\\boxed{N}",task["prompt"])
            if task["level"]=="easy":
                self.assertNotIn("mod",task["prompt"].lower())
            else:
                self.assertIn("nonnegative remainder",task["prompt"])

    def test_source_and_run_fingerprint_blocks_changed_config(self):
        with tempfile.TemporaryDirectory() as path:
            cfg = self.config()
            collect(cfg,path,max_new_groups=1)
            with self.assertRaisesRegex(RuntimeError,"checkpoint/config mismatch"):
                collect(self.config(master_seed=882),path,max_new_groups=1)

    def test_generation_resume_only_generates_missing_groups(self):
        with tempfile.TemporaryDirectory() as path:
            cfg = self.config()
            machines=[]
            def factory(_cfg):
                backend=FakeBackend()
                machines.append(backend)
                return backend
            self.assertEqual(collect(cfg,path,max_new_groups=4,backend_factory=factory)
                             ["completed_groups"],4)
            self.assertEqual(machines[-1].calls,4)
            self.assertEqual(collect(cfg,path,backend_factory=factory)
                             ["completed_groups"],12)
            self.assertEqual(machines[-1].calls,8)
            self.assertEqual(collect(cfg,path,backend_factory=factory)
                             ["completed_groups"],12)
            self.assertEqual(len(machines),2)

    def test_crash_during_generation_retains_completed_groups(self):
        cfg=self.config()
        class CrashAtThird(FakeBackend):
            def generate(self,task,seed,g,max_new_tokens):
                if self.calls == 2:
                    raise RuntimeError("simulated power loss")
                return super().generate(task,seed,g,max_new_tokens)
        with tempfile.TemporaryDirectory() as path:
            with self.assertRaisesRegex(RuntimeError,"simulated power loss"):
                collect(cfg,path,backend_factory=lambda _:CrashAtThird())
            cp=Checkpoints(path,self._locked(cfg))
            self.assertEqual(cp.contiguous_count("generations",cfg.groups),2)
            self.assertEqual(collect(cfg,path)["completed_groups"],12)
            self.assertTrue(evaluate(cfg,path)["complete"])
            self.assertTrue(audit(cfg,path)["pass"])

    def test_resume_makes_same_results_as_uninterrupted(self):
        cfg=self.config()
        with tempfile.TemporaryDirectory() as path_a, tempfile.TemporaryDirectory() as path_b:
            collect(cfg,path_a)
            self.assertTrue(evaluate(cfg,path_a)["complete"])
            s_a=summarize(cfg,path_a)
            self.assertTrue(audit(cfg,path_a)["pass"])
            collect(cfg,path_b,max_new_groups=3)
            collect(cfg,path_b)
            self.assertFalse(evaluate(cfg,path_b,max_new_decisions=7)["complete"])
            self.assertFalse(evaluate(cfg,path_b,max_new_decisions=11)["complete"])
            self.assertTrue(evaluate(cfg,path_b)["complete"])
            s_b=summarize(cfg,path_b)
            self.assertEqual(s_a,s_b)
            self.assertTrue(audit(cfg,path_b)["pass"])
            cp_a=Checkpoints(path_a,self._locked(cfg))
            cp_b=Checkpoints(path_b,self._locked(cfg))
            for method in ("uniform","cube_classic","scaled","joint_ewma","joint_frozen"):
                for i in range(cfg.groups):
                    self.assertEqual(cp_a.load(f"acq_{method}",i),
                                     cp_b.load(f"acq_{method}",i))
            self.assertEqual(evaluate(cfg,path_b)["new_decisions"],0)

    @staticmethod
    def _locked(cfg):
        from phase2_grpo.phase6a_study import locked_config
        return locked_config(cfg)

    def test_checkpoint_detects_modified_bytes(self):
        with tempfile.TemporaryDirectory() as path:
            cfg=self.config()
            collect(cfg,path,max_new_groups=2)
            cp=Checkpoints(path,self._locked(cfg))
            doc_path=cp.path("generations",0)
            doc=json.loads(doc_path.read_text(encoding="utf-8"))
            doc["payload"]["completions"][0]="TAMPERED"
            doc_path.write_text(json.dumps(doc),encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError,"integrity failure"):
                cp.load("generations",0)

    def test_exact_normalized_bridge_is_finite(self):
        design=uniform_design(6,3)
        scores=np.array([[1,2,3,4,5,6],[-2,2,-1,1,-3,3],[1,0,1,0,1,0]],float)
        reward=np.array([1,0,0,1,0,1],float)
        bias,mse=_design_bias_and_risk(scores,reward,design)
        self.assertEqual(len(bias),3)
        self.assertTrue(np.all(np.isfinite(bias)))
        self.assertGreaterEqual(mse,0.)

    def test_selection_seed_is_policy_specific(self):
        self.assertNotEqual(group_seed(42,0),group_seed(42,1))
        self.assertNotEqual(decision_seed(42,"uniform",0),
                            decision_seed(42,"scaled",0))

    def test_logit_bias_score_identity_by_finite_difference(self):
        logits=np.array([-.8,1.4,.4,.7],float)
        signs=token_signs(4)[:,0]
        token=2
        def logp(alpha):
            z=logits+alpha*signs
            return z[token]-np.log(np.sum(np.exp(z)))
        eps=1e-6
        empirical=(logp(eps)-logp(-eps))/(2*eps)
        probabilities=np.exp(logits)/np.sum(np.exp(logits))
        analytical=signs[token]-probabilities@signs
        self.assertAlmostEqual(empirical,analytical,places=8)

    def test_nontrivial_oracle_risk_csv_and_audit(self):
        # A deterministic *testing only* stand-in deliberately includes
        # some correct and incorrect labels, exercising the nonzero-risk
        # formulas. It is NEVER presented as an actual LLM evaluation.
        cfg = self.config(groups=8)
        answer_by_id = {t["id"]: t["answer"] for t in make_tasks(
            count=cfg.groups, seed=cfg.master_seed, schedule=cfg.schedule)}

        class VariedFake(FakeBackend):
            def generate(self, task, seed, g, max_new_tokens):
                sample = super().generate(task, seed, g, max_new_tokens)
                answer = answer_by_id[task["id"]]
                for j in range(g):
                    sample["completions"][j] = f"\\boxed{{{answer + int(j % 2)}}}"
                return sample

        with tempfile.TemporaryDirectory() as path:
            collect(cfg, path, backend_factory=lambda _: VariedFake())
            self.assertTrue(evaluate(cfg, path)["complete"])
            s = summarize(cfg, path)
            self.assertGreater(s["by_policy"]["uniform"]["linear_design_risk_exact"], 0.)
            self.assertGreater(s["by_policy"]["uniform"]["normalized_design_mse_exact"], 0.)
            with (Path(path)/"phase6a_group_policy_metrics.csv").open(
                    encoding="utf-8", newline="") as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(len(rows), cfg.groups * 5)
            self.assertTrue(audit(cfg, path)["pass"])


if __name__ == "__main__":
    unittest.main()
