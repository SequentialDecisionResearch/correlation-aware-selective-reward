"""Online acquisition must preserve pair support and never reveal gold early."""

import unittest

import numpy as np

from phase2_grpo.classic_cube import cube_full_flight_landing
from phase2_grpo.design import uniform_design
from phase2_grpo.online_moments import OnlineSecondMoment, mix_design
from phase2_grpo.online_study import OnlineConfig, OnlineAcquirer, run_online_study
from phase2_grpo.risk import augmented_rewards


class OnlineStudyTests(unittest.TestCase):
    def test_exploration_increases_pair_positivity_without_extra_calls(self):
        base=uniform_design(6,3)
        candidate,_=cube_full_flight_landing(
            np.full(6,.5),3,np.random.default_rng(9).normal(size=(3,6)))
        mixed=mix_design(candidate,base,.2)
        np.testing.assert_allclose(mixed.marginals,np.full(6,.5))
        self.assertGreaterEqual(
            np.min(mixed.pair_inclusions[np.triu_indices(6,1)]),.04-1e-10)
        self.assertEqual(mixed.B,3)
        with self.assertRaises(ValueError):
            mix_design(base,uniform_design(6,2),.5)

    def test_exact_moment_ipw_in_expectation_over_uniform(self):
        d=uniform_design(4,2)
        e=np.array([1.,-2.,3.,-4.])
        # Enumeration verifies the uncentered pair-product design identity.
        expected=np.zeros((4,4))
        for z,p in zip(d.subsets,d.probs):
            x=z*e
            expected+=p*np.outer(x,x)/d.pair_inclusions
        np.testing.assert_allclose(expected,np.outer(e,e),atol=1e-12)

    def test_nan_unqueried_does_not_change_estimator(self):
        base=uniform_design(4,2)
        mask=np.array([1,0,1,0],dtype=bool)
        a=OnlineSecondMoment(4,window=3)
        b=OnlineSecondMoment(4,window=3)
        o=np.array([2.,np.nan,-3.,np.nan])
        x=np.array([2.,9e100,-3.,-9e100])
        a.update(o,mask,base)
        b.update(x,mask,base)
        np.testing.assert_allclose(a.fitted,b.fitted)
        z=augmented_rewards(o,np.zeros(4),mask,base.marginals)
        np.testing.assert_allclose(z, np.array([4.,0.,-6.,0.]))

    def test_no_pair_support_fails_loudly(self):
        d=uniform_design(4,1)
        moment=OnlineSecondMoment(4,window=3)
        with self.assertRaises(ValueError):
            moment.update(np.array([3.,np.nan,np.nan,np.nan]),
                          np.array([1,0,0,0],dtype=bool),d)

    def test_drift_alarm_is_history_only_and_resets_stale_offdiagonals(self):
        design=uniform_design(4,2)
        mask=np.array([1,1,0,0],dtype=bool)
        monitor=OnlineSecondMoment(4,window=3,drift_threshold=.5)
        for _ in range(3):
            report=monitor.update(np.array([0.,0.,np.nan,np.nan]),mask,design)
            self.assertFalse(report.detected)
        for _ in range(2):
            report=monitor.update(np.array([10.,10.,np.nan,np.nan]),mask,design)
            self.assertFalse(report.detected)
        triggered=monitor.update(np.array([10.,10.,np.nan,np.nan]),mask,design)
        self.assertTrue(triggered.detected)
        self.assertEqual(monitor.change_events,[6])
        self.assertEqual(len(monitor.contributions),0)
        np.testing.assert_allclose(monitor.ewma,np.diag(np.diag(monitor.ewma)))

    def test_detector_can_be_disabled_without_changing_moment_updates(self):
        d=uniform_design(4,2)
        sel=np.array([1,1,0,0],dtype=bool)
        m=OnlineSecondMoment(4,window=3,drift_threshold=.5)
        for step in range(6):
            value=0. if step < 3 else 10.
            report=m.update(np.array([value,value,np.nan,np.nan]),sel,d,
                            allow_detection=False)
        self.assertTrue(report.sufficient_history)
        self.assertFalse(report.detected)
        self.assertGreater(report.statistic,.5)
        self.assertEqual(m.change_events,[])
        self.assertEqual(len(m.contributions),6)

    def test_policy_prequery_design_and_equal_budget(self):
        cfg=OnlineConfig(horizon=80,warmup=10,window=9,
                         seeds=(17,),scenarios=("stationary_signed",))
        agent=OnlineAcquirer("drift_gated",cfg)
        score=np.random.default_rng(13).normal(size=(3,6))
        for _ in range(15):
            d,_=agent.propose(score)
            np.testing.assert_allclose(d.marginals,np.full(6,.5),atol=1e-7)
            selected=d.draw(np.random.default_rng(29))
            observed=np.full(6,np.nan)
            observed[selected.astype(bool)]=1.0
            agent.observe(observed,selected.astype(bool),d)
        self.assertEqual(agent.t,15)

    def test_quick_study_has_complete_same_budget_comparisons(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            summary=run_online_study(folder,quick=True)
            self.assertEqual(summary["rows"],1920)
            self.assertEqual(summary["total_verifier_calls"],5760)
            self.assertEqual(len(summary["methods"]),6)
            self.assertIn("signed_to_common",summary["drift_detector"])


if __name__=="__main__":
    unittest.main()
