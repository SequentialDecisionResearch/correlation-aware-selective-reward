import unittest
import numpy as np

from phase2_grpo.calibration import PooledMomentCalibrator
from phase2_grpo.design import uniform_design
from phase2_grpo.oracle import CountingOracle
from phase2_grpo.simulation import pilot_moment_fit, design_grid, toy_training


class CalibrationAndExperimentTests(unittest.TestCase):
    def test_unit_normal_second_moment_no_log_bias(self):
        rng = np.random.default_rng(43)
        r = rng.normal(size=(6000, 2))
        n = len(r)
        fit = PooledMomentCalibrator().fit(r, np.ones_like(r, bool),
                                          np.ones_like(r),
                                          np.ones((n, 2, 2)))
        np.testing.assert_allclose(np.diag(fit.raw), [1.,1.], atol=.06)
        self.assertTrue(fit.pair_supported.all())

    def test_ipw_pair_recovery_from_exactB_samples(self):
        rng = np.random.default_rng(55)
        v = np.eye(4)*.7 + .3*np.ones((4,4))
        d = uniform_design(4,2)
        fit = pilot_moment_fit(v, d, n=6000, rng=rng)
        self.assertTrue(fit.pair_supported.all())
        self.assertLess(np.linalg.norm(fit.raw-v, "fro"), .3)

    def test_B_one_has_unidentified_pairs(self):
        rng = np.random.default_rng(7)
        d = uniform_design(4,1)
        g, n = 4, 100
        mask = np.array([d.draw(rng) for _ in range(n)], bool)
        obs = np.full((n,g), np.nan)
        obs[mask] = rng.normal(size=int(mask.sum()))
        pi = np.broadcast_to(d.marginals,(n,g))
        pi2 = np.broadcast_to(d.pair_inclusions,(n,g,g))
        fit = PooledMomentCalibrator().fit(obs, mask, pi, pi2)
        self.assertFalse(fit.pair_supported[0,1])
        with self.assertRaises(ValueError):
            PooledMomentCalibrator().fit(obs, mask, pi, pi2, require_all_pairs=True)

    def test_oracle_access_count_and_mask(self):
        oracle = CountingOracle(np.array([10.,20.,30.,40.]))
        np.testing.assert_array_equal(np.isnan(oracle.purchased_vector()), [1,1,1,1])
        oracle.reveal(np.array([0,3],dtype=int))
        self.assertEqual(oracle.calls,2)
        np.testing.assert_allclose(oracle.purchased_vector()[[0,3]], [10,40])
        self.assertTrue(np.isnan(oracle.purchased_vector()[1:3]).all())
        with self.assertRaises(ValueError):
            oracle.reveal(np.array([3]))

    def test_design_grid_and_training_execute_distinct_seeds(self):
        grid = design_grid(seed_list=(11, 29), pilot_n=150)
        self.assertEqual({r["seed"] for r in grid},{11,29})
        self.assertTrue(all(r["design_regret"] >= -1e-7 for r in grid))
        train = toy_training(seed_list=(11, 29), steps=25)
        self.assertEqual(len(train),4)
        self.assertTrue(all(x["training_calls"] == x["steps"]*3 for x in train))
        self.assertTrue(all(not x["is_real_llm"] for x in train))


if __name__ == "__main__":
    unittest.main()

