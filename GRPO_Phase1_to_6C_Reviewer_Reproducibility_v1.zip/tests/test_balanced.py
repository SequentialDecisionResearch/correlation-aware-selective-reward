"""Strict same-first-order-marginal tests for balanced comparators."""

import unittest

import numpy as np

from phase2_grpo.balanced import (auxiliary_balance_lp, balance_risk,
                                  cube_flight_dependent_landing,
                                  tensor_auxiliary)
from phase2_grpo.design import ExactBDesign, all_subsets, uniform_design
from phase2_grpo.geometry import gradient_map
from phase2_grpo.optimization import optimize_coupling
from phase2_grpo.risk import acquisition_risk


class BalancedDesignTests(unittest.TestCase):
    def test_cube_exact_marginals_and_budget(self):
        rng = np.random.default_rng(20261023)
        for G, B in ((4, 2), (6, 2), (6, 3), (8, 3)):
            subsets = all_subsets(G, B)
            probs = rng.dirichlet(np.full(15, 0.6))
            zeta = probs @ subsets[rng.integers(len(subsets), size=15)]
            aux = rng.normal(size=(2, G))
            d = cube_flight_dependent_landing(zeta, B, aux)
            np.testing.assert_allclose(d.marginals, zeta, atol=1e-8)
            self.assertTrue(np.all(d.subsets.sum(axis=1) == B))
            self.assertAlmostEqual(d.probs.sum(), 1., places=11)

    def test_global_balancing_cannot_be_worse_than_uniform_for_its_criterion(self):
        rng = np.random.default_rng(401)
        for G, B in ((4, 2), (6, 3), (8, 4)):
            zeta = np.full(G, B / G)
            aux = rng.normal(size=(3, G))
            base = uniform_design(G, B)
            d = auxiliary_balance_lp(zeta, B, aux)
            np.testing.assert_allclose(d.marginals, zeta, atol=1e-8)
            self.assertLessEqual(balance_risk(d, aux), balance_risk(base, aux) + 1e-9)

    def test_common_mode_score_balance_recovers_zero_risk(self):
        # Same-marginal perfect balancing exists (1 from each score-sign group).
        G, B = 4, 2
        scores = np.array([[-3., -3., 3., 3.]])
        m = gradient_map(scores)
        d = auxiliary_balance_lp(np.full(G, .5), B, m)
        self.assertAlmostEqual(balance_risk(d, m), 0., places=9)
        self.assertAlmostEqual(acquisition_risk(scores, np.ones((G, G)), d), 0., places=9)

    def test_tensor_features_equal_actual_acquisition_risk(self):
        rng = np.random.default_rng(111)
        for G, B in ((4, 2), (5, 2), (6, 3)):
            scores = rng.normal(size=(3, G))
            U = rng.normal(size=(G, G))
            V = U @ U.T
            zeta = np.full(G, B / G)
            aug = tensor_auxiliary(scores, V)
            base = uniform_design(G, B)
            np.testing.assert_allclose(balance_risk(base, aug),
                                       acquisition_risk(scores, V, base), atol=1e-9)
            lp1 = auxiliary_balance_lp(zeta, B, aug)
            lp2, _ = optimize_coupling(scores, V, zeta, B)
            np.testing.assert_allclose(acquisition_risk(scores, V, lp1),
                                       acquisition_risk(scores, V, lp2), atol=1e-8)

    def test_nonuniform_marginals_and_rejected_leak(self):
        zeta = np.array([.3, .7, .4, .6])
        auxiliary = np.array([[2., -1., 0., 3.], [1., 1., -2., -2.]])
        a = auxiliary_balance_lp(zeta, 2, auxiliary)
        b = cube_flight_dependent_landing(zeta, 2, auxiliary)
        np.testing.assert_allclose(a.marginals, zeta, atol=1e-8)
        np.testing.assert_allclose(b.marginals, zeta, atol=1e-8)
        with self.assertRaises(ValueError):
            auxiliary_balance_lp(zeta, 2, np.array([[np.nan, 1., 2., 3.]]))


if __name__ == "__main__":
    unittest.main()
