"""CPU-only Phase6D identities, frozen-data controls, and replay invariants.

Real Qwen/LoRA autograd must also pass the user's CUDA smoke run; it is not
mocked or asserted to have run by this CPU unit-test suite.
"""

from dataclasses import asdict
import importlib.util
from pathlib import Path
import re
import tempfile
import unittest

import numpy as np

from phase2_grpo.design import ExactBDesign, uniform_design
from phase2_grpo.geometry import gradient_map
from phase2_grpo.phase6a_checkpoint import Checkpoints, atomic_json
from phase2_grpo.phase6a_tasks import ANSWER_INSTRUCTION
from phase2_grpo.phase6c_diagnostics import file_sha
from phase2_grpo.phase6c_objectives import ARMS, Phase6CConfig, advantage
from phase2_grpo.phase6d_gradient_risk import (
    centered_loo_gram, evaluate_fixed_designs, gram_alignment, risk_exact)
from phase2_grpo.phase6d_alignment import (
    event_path, gradients_lora, locked, prepare, read_event, report, run)


def perturbed_design():
    base=uniform_design(6,3)
    z=base.subsets
    first=0
    complement=int(np.flatnonzero(np.all(z==1-z[first],axis=1))[0])
    second=1
    other=int(np.flatnonzero(np.all(z==1-z[second],axis=1))[0])
    assert len({first,complement,second,other})==4
    p=base.probs.copy()
    p[[first,complement]]+=.025
    p[[second,other]]-=.025
    adaptive=ExactBDesign(z,p,"paired_complement_perturbation")
    assert np.allclose(adaptive.marginals,.5)
    return base,adaptive


class GradientRiskIdentityTests(unittest.TestCase):
    def test_exact_risk_matches_training_loo_ht_for_every_subset(self):
        rng=np.random.default_rng(211)
        h=rng.normal(size=(6,13))
        r=np.array([1.,0.,1.,0.,1.,0.])
        u,j=perturbed_design()
        gram=centered_loo_gram(h@h.T)
        m=(h-h.mean(axis=0))/(len(h)-1)
        self.assertTrue(np.allclose(gram,m@m.T))
        for design in (u,j):
            analytic=risk_exact(gram,r,design)
            truth=m.T@r
            direct=0.
            estimate=np.zeros_like(truth)
            for z,q in zip(design.subsets,design.probs):
                selected=z.astype(bool)
                visible=np.full(6,np.nan)
                visible[selected]=r[selected]
                coeff=advantage(visible,selected,design.marginals,objective="loo_ht")
                learned=h.T@coeff/6
                ht=m.T@(r*z/design.marginals)
                self.assertTrue(np.allclose(learned,ht,atol=1e-12))
                estimate+=q*learned
                direct+=q*float(np.sum((ht-truth)**2))
            self.assertTrue(np.allclose(estimate,truth))
            self.assertAlmostEqual(analytic["risk"],direct,places=10)
            self.assertAlmostEqual(analytic["risk_enumerated"],
                                   analytic["risk_quadratic"],places=10)

    def test_sketch_identical_to_true_gradient_preserves_risks(self):
        rng=np.random.default_rng(212)
        gradients=rng.normal(size=(6,3))
        rewards=np.array([0.,1.,1.,0.,0.,1.])
        u,j=perturbed_design()
        result=evaluate_fixed_designs(gradients@gradients.T,
                                      gradients.T,rewards,u,j)
        self.assertAlmostEqual(result["alignment"]["centered_gram_alignment"],1.)
        for design in ("uniform","joint_ewma"):
            self.assertAlmostEqual(result["risks"]["real_lora"][design]["risk"],
                result["risks"]["phase6b_sketch"][design]["risk"],places=10)

    def test_true_and_sketch_geometry_not_assumed_equal(self):
        rng=np.random.default_rng(213)
        a=rng.normal(size=(6,11))
        b=rng.normal(size=(3,6))
        u,j=perturbed_design()
        result=evaluate_fixed_designs(a@a.T,b,np.array([0,1,1,0,1,0]),u,j)
        self.assertLess(result["alignment"]["centered_gram_alignment"],.99)
        zero=risk_exact(centered_loo_gram(a@a.T),np.zeros(6),u)
        self.assertEqual(zero["risk"],0.)
        self.assertIsNone(gram_alignment(np.zeros((6,6)),np.eye(6))
                          ["centered_gram_alignment"])

    def test_reject_wrong_marginals_or_invalid_gram(self):
        u,j=perturbed_design()
        base=np.eye(6)
        with self.assertRaises(ValueError):
            centered_loo_gram(np.full((6,6),np.nan))
        with self.assertRaises(ValueError):
            evaluate_fixed_designs(base,np.ones((3,6)),np.ones(6),
                ExactBDesign(u.subsets,np.eye(1,20,0).ravel()),j)

    @unittest.skipUnless(importlib.util.find_spec("torch") is not None,
                         "PyTorch absent in local test runtime; CUDA smoke required")
    def test_real_autograd_path_on_tiny_cpu_model(self):
        import torch
        class TinyPolicy:
            def __init__(self):
                self.torch=torch
                self.device=torch.device("cpu")
                self.model=torch.nn.Linear(3,4,bias=False)
                self.cfg=type("Cfg",(),{"max_new_tokens":8})()

            def _prompt(self,text):
                return torch.tensor([[1,2,3]],dtype=torch.long)

            def _token_logprobs(self,prompt,continuation,*,requires_grad):
                x=torch.stack((continuation.float(),
                    continuation.float()*0.1,
                    torch.ones_like(continuation,dtype=torch.float)),dim=-1)
                logits=self.model(x)
                logp=logits.log_softmax(-1).gather(1,
                    (continuation%4).unsqueeze(1)).squeeze(1)
                return logits,logp

        torch.manual_seed(4)
        policy=TinyPolicy()
        samples=[];expected=[]
        for i in range(6):
            tokens=[i+1,i+2]
            y=torch.tensor(tokens)
            with torch.no_grad():
                _,logp=policy._token_logprobs(None,y,requires_grad=False)
            samples.append({"token_ids":tokens,"old_logp":logp.tolist()})
            _,logp2=policy._token_logprobs(None,y,requires_grad=True)
            g=torch.autograd.grad(logp2.sum()/8,list(policy.model.parameters()))
            expected.append(torch.cat([z.reshape(-1) for z in g]).numpy())
        gram,info=gradients_lora(policy,{"prompt":"test"},samples)
        x=np.stack(expected)
        self.assertTrue(np.allclose(gram,x@x.T,rtol=1e-6))
        self.assertEqual(info["trainable_parameters"],12)
        samples[0]["old_logp"][0]+=1.0
        with self.assertRaisesRegex(RuntimeError,"off-policy likelihood"):
            gradients_lora(policy,{"prompt":"test"},samples)


class FrozenMockPolicy:
    info={"backend_type":"hf_lora","mock":"phase6d_replay_only"}

    def __init__(self,cfg):
        self.cfg=cfg

    def restore(self,state,step):
        if state["completed_steps"]!=step:
            raise AssertionError("checkpoint not restored")

    def generate(self,task,index):
        a,b=map(int,re.search(r"Compute exactly: (\d+) \+ (\d+)",task["prompt"]).groups())
        correct=a+b
        samples=[{"text":f"\\boxed{{{correct+(i%2)}}}",
                  "token_ids":[1,2],"old_logp":[-.1,-.2]}
                 for i in range(self.cfg.g)]
        scores=np.array([[i*i+1 for i in range(6)],
                         [i-2 for i in range(6)],
                         [float((i+index)%3) for i in range(6)]])
        return {"samples":samples,"score_features":scores.tolist(),
                "backend":"CPU_FAKE_TEST_ONLY"}


def fake_real_gradient(policy,task,samples):
    x=np.array([[1+i,2-i,(i*i)%5] for i in range(6)],float)
    return x@x.T,{"trainable_parameters":3,"cpu_fixture_not_real_autograd":True}


class FrozenCheckpointReplayTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.old=self.root/"old6c"
        self.out=self.root/"fresh6d"
        cfg=Phase6CConfig(steps=4,seed=7,warmup=1,eval_every=2,
            eval_size=4,train_schedule="interleaved",task_family="two_digit_add",
            calibration_evidence_sha256="a"*64,device="cpu")
        tasks=[{"id":i,"level":"two_digit_add",
            "prompt":f"Compute exactly: {i+11} + {i+15}. {ANSWER_INSTRUCTION}",
            "answer":2*i+26} for i in range(4)]
        evaluation={"accuracy":1.,"heldout_count":4}
        u=uniform_design(6,3)
        for arm in ARMS:
            cp=Checkpoints(self.old/"arms"/arm,
                           {"config":asdict(cfg),"arm":arm})
            cp.save("model_info",0,FrozenMockPolicy.info)
            cp.save("tasks",0,{"train":tasks,"heldout":tasks})
            cp.save("baseline_eval",0,evaluation)
            for step in (0,1,2,3,4):
                state=cp.directory/"optimizer_states"/f"after_step_{step:06d}.pt"
                state.parent.mkdir(parents=True,exist_ok=True)
                state.write_bytes(f"TEST_ONLY_{arm}_{step}".encode())
                if step==0:
                    cp.save("initial_state",0,{"state_sha256":file_sha(state)})
                else:
                    cp.save("train_steps",step-1,{
                        "design":{"subsets":u.subsets.tolist(),
                                  "probs":u.probs.tolist()},
                        "selected":[True,True,True,False,False,False],
                        "paid_rewards":[1,0,1],
                        "state_sha256":file_sha(state),
                        "heldout_evaluation":evaluation if step in (2,4) else None})
        summary={"phase":"6C","complete":True,"genuine_model_updates":True,
                 "config":asdict(cfg),"progress":{a:4 for a in ARMS},
                 "real_backend_by_arm":{a:True for a in ARMS},
                 "final_heldout":{a:evaluation for a in ARMS}}
        atomic_json(self.old/"phase6c_summary.json",summary)
        atomic_json(self.old/"phase6c_audit.json",
                    {"pass":True,"checked_train_steps":12,"expected":12})

    def test_end_to_end_resume_replay_and_unchanged_training(self):
        before={str(p):file_sha(p) for p in self.old.rglob("*") if p.is_file()}
        prepared=prepare([self.old],self.out,snapshots=(0,2),
            source_arms=("uniform","joint_ewma"),
            families=("two_digit_add","three_digit_double_carry"),
            groups_per_family=1)
        self.assertEqual(prepared["groups_expected"],8)
        self.assertEqual(prepared,prepare([self.old],self.out,snapshots=(0,2),
            source_arms=("uniform","joint_ewma"),
            families=("two_digit_add","three_digit_double_carry"),
            groups_per_family=1))
        inputs,bank=locked(self.out)
        tasks=bank["tasks_by_seed"]["7"]
        self.assertEqual(len(tasks),2)
        for t in tasks:
            self.assertNotIn(t["prompt"],
                ["Compute exactly: 11 + 15. "+ANSWER_INSTRUCTION])
        kwargs={"policy_factory":FrozenMockPolicy,
                "state_loader":lambda p:{"completed_steps":int(p.stem[-6:])},
                "gradient_fn":fake_real_gradient}
        self.assertFalse(run(self.out,max_new_groups=1,**kwargs)["complete"])
        self.assertEqual(run(self.out,**kwargs)["total_expected_groups"],8)
        self.assertEqual(run(self.out,**kwargs)["new_groups"],0)
        result=report(self.out)
        self.assertEqual(result["checked_groups"],8)
        self.assertEqual(report(self.out),result)
        file=event_path(self.out,7,"uniform",0,0)
        record=read_event(file,m=inputs,bank=bank,seed=7,arm="uniform",step=0,index=0)
        self.assertEqual(record["risk_result"]["risks"]["real_lora"]["gain_uniform_minus_joint"],0.)
        after={str(p):file_sha(p) for p in self.old.rglob("*") if p.is_file()}
        self.assertEqual(before,after)
        record["rewards"][0]=999
        atomic_json(file,record)
        with self.assertRaisesRegex(RuntimeError,"corrupt Phase6D record"):
            report(self.out)

    def test_output_may_not_write_inside_original_runs(self):
        with self.assertRaisesRegex(ValueError,"outside original"):
            prepare([self.old],self.old/"forbidden",snapshots=(0,),
                    groups_per_family=1)


if __name__=="__main__":
    unittest.main()
