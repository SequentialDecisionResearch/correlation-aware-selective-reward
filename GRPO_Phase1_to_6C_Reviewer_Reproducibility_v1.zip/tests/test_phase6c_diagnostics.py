"""CPU-only invariants for v1.5 diagnostic tools (no GPU needed)."""

import contextlib
from dataclasses import asdict
import json
from pathlib import Path
import re
import tempfile
import unittest

import numpy as np

from phase2_grpo.phase6a_checkpoint import Checkpoints, atomic_json
from phase2_grpo.phase6a_tasks import ANSWER_INSTRUCTION
from phase2_grpo.phase6c_diagnostics import (PROTOCOL, STRATA, adapter_metrics,
    cluster_interval, effective_lora_metrics, file_sha, inspect,
    locked_inputs, prepare, stress_bank)
from phase2_grpo.phase6c_diagnostic_eval import (evaluate, read_event, report, event_path)
from phase2_grpo.phase6c_objectives import ARMS, Phase6CConfig


class DiagnosticInvariantTests(unittest.TestCase):
    def test_stress_bank_frozen_unique_no_two_digit_overlap(self):
        a,b=stress_bank(32),stress_bank(32)
        self.assertEqual(a,b)
        self.assertEqual(len(a["tasks"]),96)
        self.assertEqual({r["level"] for r in a["tasks"]},set(STRATA))
        for row in a["tasks"]:
            self.assertIn("\\boxed{N}",row["prompt"])
            self.assertEqual(row["answer"],sum(map(int,re.findall(r"\d+",row["expression"]))))
            if row["level"]=="two_digit_carry_ood":
                self.assertTrue(all(int(x)>=80 for x in re.findall(r"\d+",row["expression"])))
        self.assertEqual(len({x["expression"] for x in a["tasks"]}),96)

    def test_adapter_distance_exact_and_checks(self):
        initial={"a":np.array([1.,0.]),"b":np.array([[0.]])}
        uniform={"a":np.array([2.,0.]),"b":np.array([[0.]])}
        joint={"a":np.array([0.,2.]),"b":np.array([[1.]])}
        full={"a":np.array([1.,1.]),"b":np.array([[0.]])}
        values=adapter_metrics(initial,uniform,joint,full)
        self.assertAlmostEqual(values["uniform_vs_joint_ewma"]["l2"],3.)
        self.assertEqual(values["adapter_parameter_count"],3)
        with self.assertRaises(ValueError):
            adapter_metrics(initial,uniform,{"wrong":np.array([1.])},full)
        with self.assertRaises(ValueError):
            adapter_metrics(initial,uniform,{"a":np.array([np.nan,0]),"b":np.array([[1.]])},full)

    def test_effective_delta_invariant_to_lora_gauge(self):
        def weights(a,b):
            return {"x.lora_A.weight":np.asarray(a,dtype=float).reshape((1,2)),
                    "x.lora_B.weight":np.asarray(b,dtype=float).reshape((2,1))}
        original=weights([1.,0.],[0.,0.])
        u=weights([1.,0.],[2.,0.])
        j=weights([2.,0.],[1.,0.])
        f=weights([1.,1.],[1.,0.])
        self.assertGreater(adapter_metrics(original,u,j,f)["uniform_vs_joint_ewma"]["l2"],0.)
        self.assertAlmostEqual(effective_lora_metrics(original,u,j,f,scaling=2.)
                               ["uniform_vs_joint_ewma"]["effective_delta_l2"],0.)
        self.assertGreater(effective_lora_metrics(original,u,j,f,scaling=2.)
                           ["uniform_vs_full"]["effective_delta_l2"],0.)

    def test_zero_width_interval_warns_not_equivalence(self):
        stat=cluster_interval([0.,0.,0.])
        self.assertEqual(stat["descriptive_seed_t95"],[0.,0.])
        self.assertTrue(stat["empirically_zero_variance"])
        self.assertIn("NOT",stat["warning"])


class FakeTokenizer:
    eos_token_id=5
    def __init__(self,owner):
        self.owner=owner
    def decode(self,seq,skip_special_tokens=True):
        return f"\\boxed{{{self.owner.answer}}}"


class FakeTorch:
    inference_mode=staticmethod(contextlib.nullcontext)
    ones_like=staticmethod(np.ones_like)


class FakeModel:
    def __init__(self,owner):
        self.owner=owner
    def eval(self):
        pass
    def generate(self,*,input_ids,**kwargs):
        return np.concatenate((input_ids,np.array([[7]])),axis=1)


class FakePolicy:
    info={"backend_type":"hf_lora", "mock":"diagnostic_only"}
    def __init__(self,cfg):
        self.cfg=cfg
        self.torch=FakeTorch()
        self.model=FakeModel(self)
        self.tokenizer=FakeTokenizer(self)
        self.answer=0
    def _prompt(self,prompt):
        vals=list(map(int,re.findall(r"\d+",prompt.split(". ")[0])))
        self.answer=sum(vals)
        return np.array([[1,2,3]],dtype=np.int64)
    def restore(self,state,step):
        if state["completed_steps"]!=step:
            raise ValueError("bad mock state")


class DiagnosticCheckpointTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.old=self.root/"phase6c_seed7"
        self.out=self.root/"v15_diagnostics"
        self.cfg=Phase6CConfig(steps=4,seed=7,warmup=1,eval_every=2,
            eval_size=4,train_schedule="interleaved",task_family="two_digit_add",
            calibration_evidence_sha256="a"*64,device="cpu")
        tasks=[{"id":i,"level":"two_digit_add","prompt":
                f"Compute exactly: {i+11} + {i+15}. {ANSWER_INSTRUCTION}",
                "answer":2*i+26} for i in range(4)]
        def scores():
            return {"accuracy":1.,"correct":4,"heldout_count":4,
                    "parseable_fraction":1.,"format_compliance_fraction":1.,
                    "strict_format_correct_fraction":1.}
        for arm in ARMS:
            cp=Checkpoints(self.old/"arms"/arm,{"config":asdict(self.cfg),"arm":arm})
            cp.save("model_info",0,FakePolicy.info)
            cp.save("tasks",0,{"train":tasks,"heldout":tasks})
            cp.save("baseline_eval",0,scores())
            for step in (0,2,4):
                p=cp.directory/"optimizer_states"/f"after_step_{step:06d}.pt"
                p.parent.mkdir(parents=True,exist_ok=True)
                p.write_bytes(f"FAKE_TEST_STATE_{step}_{arm}".encode())
                if step==0:
                    cp.save("initial_state",0,{"state_sha256":file_sha(p)})
            for index in range(4):
                step=index+1
                p=cp.directory/"optimizer_states"/f"after_step_{step:06d}.pt"
                cp.save("train_steps",index,{
                    "heldout_evaluation":scores() if step%2==0 else None,
                    "state_sha256":file_sha(p) if p.exists() else "not_eval_step"})
        summary={"phase":"6C","complete":True,"genuine_model_updates":True,
                 "config":asdict(self.cfg),"progress":{a:4 for a in ARMS},
                 "real_backend_by_arm":{a:True for a in ARMS},
                 "final_heldout":{a:scores() for a in ARMS}}
        atomic_json(self.old/"phase6c_summary.json",summary)
        atomic_json(self.old/"phase6c_audit.json",
                    {"pass":True,"checked_train_steps":12,"expected":12})

    def test_prepare_inspect_and_resume_do_not_mutate_original(self):
        first=prepare([self.old],self.out,per_stratum=8)
        self.assertEqual(first["stress_items"],24)
        self.assertEqual(prepare([self.old],self.out,per_stratum=8),first)
        before={str(p):file_sha(p) for p in self.old.rglob("*") if p.is_file()}
        def loader(path):
            arm=path.parents[1].name
            step=int(path.stem.removeprefix("after_step_"))
            base=np.array([[0.],[0.]])
            if step:
                base=base+{"full":np.array([[0.],[1.]]),
                           "uniform":np.array([[1.],[0.]]),
                           "joint_ewma":np.array([[0.],[2.]])}[arm]
            return {"adapter":{"q_proj.lora_A.weight":np.array([[1.,0.]]),
                               "q_proj.lora_B.weight":base}}
        result=inspect(self.out,loader=loader)
        self.assertGreater(result["final_adapter_distances_l2"][0],0.)
        self.assertGreater(result["effective_update_distances_l2"][0],0.)
        self.assertEqual(result["auc_adaptive_minus_uniform"]["mean"],0.)
        self.assertEqual(evaluate(self.out,max_new_evals=1,
            policy_factory=FakePolicy,
            state_loader=lambda p:{"completed_steps":int(p.stem.removeprefix("after_step_"))})
            ["new_events"],1)
        output=evaluate(self.out,policy_factory=FakePolicy,
            state_loader=lambda p:{"completed_steps":int(p.stem.removeprefix("after_step_"))})
        self.assertTrue(output["complete"])
        result=report(self.out)
        self.assertEqual(result["status"],"complete")
        self.assertEqual(result["paired_item_rows"],60)
        self.assertEqual(report(self.out),result)
        after={str(p):file_sha(p) for p in self.old.rglob("*") if p.is_file()}
        self.assertEqual(before,after)
        with self.assertRaisesRegex(ValueError,"inside an original"):
            prepare([self.old],self.old/"diagnostic",per_stratum=8)

    def test_rejects_tampered_event_and_stress_lock(self):
        prepare([self.old],self.out,per_stratum=8)
        manifest,bank=locked_inputs(self.out)
        path=event_path(self.out,7,"uniform","heldout",0)
        path.parent.mkdir(parents=True,exist_ok=True)
        atomic_json(path,{"sha256":"bad","items":[]})
        with self.assertRaisesRegex(RuntimeError,"invalid diagnostic"):
            read_event(path,seed=7,arm="uniform",panel="heldout",step=0,
                       expected_count=4,bank_sha=manifest["stress_bank_sha256"])
        bank["tasks"][0]["answer"]+=1
        atomic_json(self.out/"stress_bank.json",bank)
        with self.assertRaisesRegex(RuntimeError,"modified"):
            locked_inputs(self.out)


if __name__=="__main__":
    unittest.main()
