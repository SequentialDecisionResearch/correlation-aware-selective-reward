import unittest
import numpy as np

from phase2_grpo.design import (ExactBDesign, all_subsets, check_marginals,
                                dependent_round_once, feasible_fixed_marginals,
                                max_entropy_fixed_marginals, uniform_design)
from phase2_grpo.optimization import optimize_coupling, bernoulli_sqrt_marginals
from phase2_grpo.risk import acquisition_risk


class DesignOptimizationTests(unittest.TestCase):
    def test_uniform_inclusions(self):
        d = uniform_design(6, 3)
        np.testing.assert_allclose(d.marginals, np.full(6, .5))
        off = d.pair_inclusions[np.triu_indices(6, 1)]
        np.testing.assert_allclose(off, 3*2/(6*5))

    def test_lp_same_marginal_not_worse(self):
        rng = np.random.default_rng(7)
        for g, b in ((4, 2), (6, 2), (6, 3), (7, 4)):
            zeta = np.full(g, b/g)
            scores = rng.normal(size=(3, g))
            a = rng.normal(size=(g, g))
            v = a @ a.T
            base = uniform_design(g, b)
            optimized, status = optimize_coupling(scores, v, zeta, b)
            self.assertEqual(status["status"], "global_optimum_over_enumerated_subsets")
            np.testing.assert_allclose(optimized.marginals, zeta, atol=1e-8)
            self.assertLessEqual(acquisition_risk(scores, v, optimized),
                                 acquisition_risk(scores, v, base) + 1e-8)

    def test_B_one_and_Gminus1_unique_coupling(self):
        rng = np.random.default_rng(101)
        g = 6
        v = rng.normal(size=(g,g)); v = v @ v.T
        scores = rng.normal(size=(2,g))
        for b in (1, g-1):
            zeta = np.full(g, b/g)
            a, _ = optimize_coupling(scores, v, zeta, b)
            baseline = uniform_design(g,b)
            self.assertAlmostEqual(acquisition_risk(scores, v, a),
                                   acquisition_risk(scores, v, baseline), places=8)

    def test_no_offdiag_no_coupling_gain(self):
        scores = np.array([[0., 2., 1., -1.]])
        v = np.eye(4)
        zeta = np.full(4, .5)
        d, _ = optimize_coupling(scores, v, zeta, 2)
        self.assertAlmostEqual(acquisition_risk(scores, v, d),
                               acquisition_risk(scores, v, uniform_design(4,2)), places=8)

    def test_explicit_boundary_marginals(self):
        # Feasible 2-of-5 design with one always-selected candidate.
        zeta = np.array([1., .4, .3, .2, .1])
        for method in (feasible_fixed_marginals, max_entropy_fixed_marginals):
            d = method(zeta, 2)
            np.testing.assert_allclose(d.marginals, zeta, atol=1e-8)
            self.assertTrue(np.all(d.subsets.sum(axis=1)==2))

    def test_randomized_near_boundary_feasible(self):
        rng = np.random.default_rng(20261021)
        for g in range(3, 11):
            for b in range(1, g):
                subsets = all_subsets(g, b)
                for _ in range(10):
                    ids = rng.integers(len(subsets), size=12)
                    q = rng.dirichlet(np.full(12, .08))
                    zeta = q @ subsets[ids]
                    candidate = feasible_fixed_marginals(zeta, b)
                    np.testing.assert_allclose(candidate.marginals, zeta, atol=2e-7)

    def test_dependent_rounding_marginals_and_size(self):
        rng = np.random.default_rng(44)
        zeta = np.array([.9, .6, .2, .1, .2])
        z = np.array([dependent_round_once(zeta, 2, rng) for _ in range(12_000)])
        self.assertTrue(np.all(z.sum(axis=1)==2))
        np.testing.assert_allclose(z.mean(axis=0), zeta, atol=.025)

    def test_strict_validation(self):
        with self.assertRaises(ValueError):
            check_marginals(np.array([.1, .5, .8]), 2)
        with self.assertRaises(ValueError):
            ExactBDesign(np.array([[1,0,1],[0,1,1]]), np.array([.4,.4]))
        with self.assertRaises(ValueError):
            all_subsets(40, 20)

    def test_reject_fractional_or_nonfinite_subset_before_cast(self):
        with self.assertRaises(ValueError):
            ExactBDesign(np.array([[.7, 0., 1.], [0., 1., 1.]]), np.array([.5, .5]))
        with self.assertRaises(ValueError):
            ExactBDesign(np.array([[np.nan, 1.], [1., 0.]]), np.array([.5, .5]))

    def test_cost_aware_square_root(self):
        a = np.array([1., 4., 9.])
        pi = bernoulli_sqrt_marginals(a, budget=1.5)
        np.testing.assert_allclose(pi.sum(), 1.5, atol=1e-8)
        np.testing.assert_allclose(pi/ pi[0], np.array([1.,2.,3.]), atol=1e-5)
        self.assertEqual(float(bernoulli_sqrt_marginals(a, budget=3).sum()), 3.)

    def test_square_root_rejects_nonfinite_data(self):
        with self.assertRaises(ValueError):
            bernoulli_sqrt_marginals(np.array([np.nan, 1.]), budget=1.0)
        with self.assertRaises(ValueError):
            bernoulli_sqrt_marginals(np.array([1., 2.]), budget=np.inf)


if __name__ == "__main__":
    unittest.main()

