"""Heldout and policy-gradient QA, without Torch, GPU or model weights."""

import csv
from contextlib import nullcontext
from pathlib import Path
import pickle
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np

from phase2_grpo.design import uniform_design
from phase2_grpo.geometry import gradient_map
from phase2_grpo.phase6a_model import FakeBackend
from phase2_grpo.phase6b_study import (Phase6BConfig, b_tasks, run, audit, summarize)
from phase2_grpo.phase6b_study import locked as locked6b
from phase2_grpo.phase6c_objectives import (Phase6CConfig, full_advantage,
             advantage, expected_ht_gradient, policy_score_gradient)
from phase2_grpo.phase6c_training import run as run6c
from phase2_grpo.phase6c_training import locked as locked6c
from phase2_grpo.phase6c_analysis import aggregate as aggregate6c
from phase2_grpo.phase6c_model import RealLoRAPolicy
from phase2_grpo.phase6a_tasks import make_tasks


class Phase6BTests(unittest.TestCase):
    def config(self):
        return Phase6BConfig(groups=8, seeds=(8123,8249),
               scenarios=("word_to_mod","interleaved_control"),
               warmup=2,window=3,max_new_tokens=16,backend="fake")

    def test_heldout_corpus_is_deterministic_and_two_schedules_distinct(self):
        x=b_tasks(10,8123,"word_to_mod")
        self.assertEqual(x,b_tasks(10,8123,"word_to_mod"))
        self.assertEqual(x[0]["level"],"easy")
        self.assertEqual(x[6]["level"],"hard")
        self.assertNotEqual(x,b_tasks(10,8123,"interleaved_control"))
        self.assertTrue(all("\\boxed{N}" in t["prompt"] for t in x))
        self.assertEqual(locked6b(self.config())["schema"],2)

    def test_6b_resume_replays_identical_design_decisions(self):
        cfg=self.config()
        with tempfile.TemporaryDirectory() as path_a,tempfile.TemporaryDirectory() as path_b:
            a=run(cfg,path_a,backend_factory=lambda c:FakeBackend())
            self.assertTrue(a["complete"])
            self.assertTrue(a["audit"]["pass"])
            partial=run(cfg,path_b,max_new_groups=9,backend_factory=lambda c:FakeBackend())
            self.assertFalse(partial["complete"])
            partial=run(cfg,path_b,max_new_decisions=13,backend_factory=lambda c:FakeBackend())
            self.assertFalse(partial["complete"])
            b=run(cfg,path_b,backend_factory=lambda c:FakeBackend())
            self.assertTrue(b["complete"])
            self.assertTrue(b["audit"]["pass"])
            self.assertEqual(a["paired_vs_uniform"],b["paired_vs_uniform"])
            self.assertEqual(a["rows_available"],4*8*5)
            self.assertEqual(a["generation_quality_overall"],
                             b["generation_quality_overall"])
            self.assertIn("format_compliant_fraction",
                          a["generation_quality_overall"])
            with (Path(path_b)/"phase6b_group_policy_metrics.csv").open(
                    encoding="utf-8",newline="") as stream:
                self.assertEqual(len(list(csv.DictReader(stream))),4*8*5)

    def test_6b_nonzero_reward_conditional_risk(self):
        cfg=Phase6BConfig(groups=8,seeds=(8123,),
                 scenarios=("word_to_mod",),warmup=2,window=3,
                 max_new_tokens=16,backend="fake")
        gold={t["id"]:t["answer"] for t in b_tasks(8,8123,"word_to_mod")}
        class MixedFake(FakeBackend):
            def generate(self,task,seed,g,max_new_tokens):
                sample=super().generate(task,seed,g,max_new_tokens)
                for j in range(g):
                    sample["completions"][j]=f"\\boxed{{{gold[task['id']]+j%2}}}"
                return sample
        with tempfile.TemporaryDirectory() as path:
            result=run(cfg,path,backend_factory=lambda _:MixedFake())
            self.assertTrue(result["audit"]["pass"])
            self.assertAlmostEqual(result["generation_quality_overall"]
                         ["reward_positive_fraction"],0.5)
            self.assertAlmostEqual(result["generation_quality_overall"]
                         ["format_compliant_fraction"],1.)
            with (Path(path)/"phase6b_group_policy_metrics.csv").open(
                  encoding="utf-8",newline="") as stream:
                rows=list(csv.DictReader(stream))
            self.assertGreater(sum(float(r["linear_design_risk_exact"]) for r in rows),0)


class Phase6CMathematicsTests(unittest.TestCase):
    def setUp(self):
        self.scores=np.array([[1,3,2,-1,5,2],[-2,3,1,4,0,2],[1,1,0,0,-1,3.]],float)
        self.rewards=np.array([1.,0.,1.,0.,0.,1.])
        self.design=uniform_design(6,3)

    def test_full_feedback_loo_equals_gradient_map(self):
        actual=policy_score_gradient(self.scores,full_advantage(
            self.rewards,objective="loo_ht"))
        self.assertTrue(np.allclose(actual,gradient_map(self.scores)@self.rewards))

    def test_exact_finite_design_average_is_unbiased_for_loo(self):
        actual=expected_ht_gradient(self.scores,self.rewards,self.design,
                                    objective="loo_ht")
        target=gradient_map(self.scores)@self.rewards
        self.assertTrue(np.allclose(actual,target,atol=1e-12))

    def test_normalized_plugin_is_not_unbiased(self):
        avg=expected_ht_gradient(self.scores,self.rewards,self.design,
                                 objective="normalized_plugin")
        target=policy_score_gradient(self.scores,full_advantage(
            self.rewards,objective="normalized_plugin"))
        self.assertGreater(float(np.linalg.norm(avg-target)),1e-3)

    def test_never_use_hidden_unselected_rewards(self):
        visible=np.array([1.,np.nan,0.,np.nan,1.,np.nan])
        sel=np.array([1,0,1,0,1,0],bool)
        coeff=advantage(visible,sel,self.design.marginals,objective="loo_ht")
        self.assertTrue(np.all(np.isfinite(coeff)))
        modified=visible.copy()
        modified[~sel]=100.
        with self.assertRaises(ValueError):
            advantage(modified,sel,self.design.marginals,objective="loo_ht")

    def test_phase6c_config_freezes_statistical_choice(self):
        self.assertEqual(Phase6CConfig().objective,"loo_ht")
        self.assertEqual(locked6c(Phase6CConfig())["schema"],2)
        with self.assertRaises(ValueError):
            Phase6CConfig(objective="unknown")


class Phase6CJournalIntegrationTests(unittest.TestCase):
    """Exercise real trainer orchestration with an explicitly fake test policy.

    The fake serializer replaces torch.save/load ONLY inside this test; it
    cannot establish the real Qwen/PEFT forward-backward integration.
    """

    class FakePolicy:
        def __init__(self,cfg):
            self.cfg=cfg
            self.weight=0.
            self.info={"backend_type":"test_fake_only","test_seed":cfg.seed}
            self.gold=make_tasks(count=cfg.steps,seed=cfg.seed,
                                 schedule=cfg.train_schedule)

        def generate(self,task,index):
            answer=self.gold[index]["answer"]
            samples=[{"text":(f"Therefore, the answer is {answer}." if j==0
                            else f"\\boxed{{{answer+(j%2)}}}"),
                      "token_ids":[j+1],"old_logp":[-1.]}
                     for j in range(self.cfg.g)]
            features=np.random.default_rng(index+910).normal(size=(3,self.cfg.g))
            return {"samples":samples,"score_features":features.tolist(),
                    "backend":"test_fake_only"}

        def update(self,task,samples,coeff):
            if "answer" in task:
                raise AssertionError("gold answer leaked into trainable policy")
            self.weight+=.01*float(np.dot(np.arange(1,len(coeff)+1),coeff))+.1
            return {"loss_per_epoch":[self.weight],
                    "grad_norm_per_epoch":[abs(self.weight)],
                    "genuine_lora_optimizer_steps":0}

        def evaluate(self,heldout):
            return {"heldout_count":len(heldout),"correct":0,
                    "accuracy":self.weight,"parseable_fraction":1.,
                    "format_compliance_fraction":1.,
                    "strict_format_correct_fraction":0.}

        def checkpoint_payload(self,step):
            return {"completed_steps":step,"fake_weight":self.weight}

        def restore(self,payload,n):
            if payload["completed_steps"]!=n:
                raise RuntimeError("test step mismatch")
            self.weight=payload["fake_weight"]

    def test_6c_resume_checkpoints_and_audit(self):
        cfg=Phase6CConfig(steps=6,warmup=2,window=3,eval_every=2,
                          eval_size=4,max_new_tokens=16)
        def fake_save(state,stream):
            pickle.dump(state,stream)
        def fake_load(path,**kwargs):
            with open(path,"rb") as stream:
                return pickle.load(stream)
        stub=types.SimpleNamespace(save=fake_save,load=fake_load)
        with patch.dict(sys.modules,{"torch":stub}):
            with tempfile.TemporaryDirectory() as first,tempfile.TemporaryDirectory() as second:
                a=run6c(cfg,first,policy_factory=self.FakePolicy)
                self.assertTrue(a["complete"])
                self.assertTrue(a["audit"]["pass"])
                self.assertFalse(a["genuine_model_updates"])
                self.assertIn("nonzero_gradient_steps_by_arm",a)
                n=run6c(cfg,second,max_new_steps=4,policy_factory=self.FakePolicy)
                self.assertFalse(n["complete"])
                n=run6c(cfg,second,max_new_steps=5,policy_factory=self.FakePolicy)
                self.assertFalse(n["complete"])
                b=run6c(cfg,second,policy_factory=self.FakePolicy)
                self.assertTrue(b["complete"])
                self.assertTrue(b["audit"]["pass"])
                self.assertEqual(a["final_heldout"],b["final_heldout"])
                self.assertEqual(a["total_logical_reward_queries"],
                                 b["total_logical_reward_queries"])
                self.assertAlmostEqual(a["training_shadow_parseable_fraction_by_arm"]
                                       ["full"],1.)
                self.assertGreater(a["training_shadow_reward_positive_fraction_by_arm"]
                                   ["full"],0.)
                self.assertLess(a["training_shadow_format_compliance_fraction_by_arm"]
                                ["full"],1.)
                with (Path(second)/"phase6c_learning_curves.csv").open(
                        encoding="utf-8",newline="") as stream:
                    self.assertEqual(len(list(csv.DictReader(stream))),3*6)

    def test_multiseed_aggregate_rejects_fake_by_default(self):
        cfg=Phase6CConfig(steps=4,warmup=1,window=3,eval_every=2,
                          eval_size=4,max_new_tokens=16)
        def fake_save(state,stream):pickle.dump(state,stream)
        def fake_load(path,**kwargs):
            with open(path,"rb") as stream:return pickle.load(stream)
        stub=types.SimpleNamespace(save=fake_save,load=fake_load)
        with patch.dict(sys.modules,{"torch":stub}):
            with tempfile.TemporaryDirectory() as root:
                a=Path(root)/"seed1";b=Path(root)/"seed2"
                from dataclasses import replace
                run6c(cfg,a,policy_factory=self.FakePolicy)
                run6c(replace(cfg,seed=cfg.seed+1),b,policy_factory=self.FakePolicy)
                with self.assertRaisesRegex(RuntimeError,"not real LoRA"):
                    aggregate6c([a,b],Path(root)/"summary")
                result=aggregate6c([a,b],Path(root)/"summary",
                                    allow_fake_qa=True)
                self.assertEqual(result["n_seeds"],2)
                with self.assertRaisesRegex(ValueError,"repeated seed"):
                    aggregate6c([a,a],Path(root)/"summary",allow_fake_qa=True)

    def test_6c_detects_corrupt_optimizer_and_cross_arm_model_change(self):
        cfg=Phase6CConfig(steps=4,warmup=1,window=3,eval_every=2,
                          eval_size=4,max_new_tokens=16)
        def fake_save(state,stream):pickle.dump(state,stream)
        def fake_load(path,**kwargs):
            with open(path,"rb") as stream:return pickle.load(stream)
        stub=types.SimpleNamespace(save=fake_save,load=fake_load)
        with patch.dict(sys.modules,{"torch":stub}):
            with tempfile.TemporaryDirectory() as root:
                run6c(cfg,root,stage="train",arms=("full",),
                      max_new_steps=2,policy_factory=self.FakePolicy)
                class ChangedFake(self.FakePolicy):
                    def __init__(self,cfg):
                        super().__init__(cfg)
                        self.info["new_external_model_version"]="different"
                with self.assertRaisesRegex(RuntimeError,"ACROSS 6C"):
                    run6c(cfg,root,stage="train",arms=("uniform",),
                          policy_factory=ChangedFake)
                broken=Path(root)/"arms"/"full"/"optimizer_states"/"after_step_000002.pt"
                broken.write_bytes(b"deliberately corrupted test checkpoint")
                with self.assertRaisesRegex(RuntimeError,"corrupt"):
                    run6c(cfg,root,stage="train",arms=("full",),
                          policy_factory=self.FakePolicy)


class Phase6CHeldoutMaskTests(unittest.TestCase):
    def test_greedy_heldout_generation_has_explicit_attention_mask(self):
        inputs=np.array([[11,12]],dtype=np.int64)
        calls=[]

        class StubModel:
            def eval(self):pass
            def train(self):pass
            def generate(self,**kwargs):
                calls.append(kwargs)
                return np.array([[11,12,13]],dtype=np.int64)

        class StubTokenizer:
            eos_token_id=13
            def decode(self,tokens,skip_special_tokens):
                return "\\boxed{7}"

        fake=types.SimpleNamespace(model=StubModel(),tokenizer=StubTokenizer(),
              torch=types.SimpleNamespace(inference_mode=nullcontext,
                                          ones_like=np.ones_like),
              _prompt=lambda prompt:inputs,
              cfg=types.SimpleNamespace(max_new_tokens=64))
        result=RealLoRAPolicy.evaluate(fake,[
              {"prompt":"3+4", "level":"easy", "answer":7}])
        self.assertEqual(result["accuracy"],1.)
        self.assertEqual(result["format_compliance_fraction"],1.)
        self.assertEqual(result["strict_format_correct_fraction"],1.)
        self.assertEqual(len(calls),1)
        self.assertIn("attention_mask",calls[0])
        np.testing.assert_array_equal(calls[0]["attention_mask"],np.ones_like(inputs))


if __name__=="__main__":
    unittest.main()
