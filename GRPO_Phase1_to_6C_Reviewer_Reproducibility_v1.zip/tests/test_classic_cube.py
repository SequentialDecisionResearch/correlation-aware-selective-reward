"""Exact finite-G invariants for complete cube flight + ordered landing."""

import unittest

import numpy as np

from phase2_grpo.classic_cube import cube_full_flight_landing
from phase2_grpo.balanced import balance_risk
from phase2_grpo.design import uniform_design
from phase2_grpo.r_cube_bridge import reference_available, reference_cube_draw


class CubeMethodTests(unittest.TestCase):
    def test_genuine_flight_and_landing_marginals(self):
        rng = np.random.default_rng(10)
        for g, b in ((4, 1), (4, 2), (6, 3), (8, 4), (8, 7)):
            pi = np.full(g, b/g)
            aux = rng.normal(size=(3,g))
            design, log = cube_full_flight_landing(pi, b, aux)
            self.assertTrue(np.all(design.subsets.sum(axis=1)==b))
            np.testing.assert_allclose(design.marginals, pi, atol=1e-10)
            self.assertLess(log.largest_marginal_error, 1e-10)
            self.assertGreater(log.landing_branch_events, 0)

    def test_heterogeneous_marginals(self):
        pi = np.array([.15,.25,.30,.45,.55,.75,.55])
        self.assertAlmostEqual(float(pi.sum()),3.0)
        design, _ = cube_full_flight_landing(pi,3,np.array([[1,-1,2,0,-2,1,0]]))
        np.testing.assert_allclose(design.marginals,pi,atol=1e-9)
        self.assertTrue(np.all(design.subsets.sum(axis=1)==3))

    def test_when_exact_balance_feasible_cube_respects_it(self):
        # Example with exact cancellation: all first-half and second-half
        # items have equal HT contributions; no claim for impossible balance.
        pi = np.full(4,.5)
        aux = np.array([[1.,-1.,1.,-1.]])
        design, _ = cube_full_flight_landing(pi,2,aux)
        self.assertLess(balance_risk(design,aux),1e-8)

    def test_invalid_probability_and_auxiliary(self):
        with self.assertRaises(ValueError):
            cube_full_flight_landing(np.array([.5,.5,1.0,0.]),2,np.ones((1,4)))
        with self.assertRaises(ValueError):
            cube_full_flight_landing(np.ones(4)*.5,2,np.ones((2,3)))

    def test_official_r_reference_optional_but_never_fake(self):
        if not reference_available():
            with self.assertRaises(RuntimeError):
                reference_cube_draw(np.full(4,.5),2,np.ones((1,4)),123)
            return
        pi=np.full(4,.5)
        z=reference_cube_draw(pi,2,np.array([[1.,2.,3.,4.]]),123)
        self.assertEqual(int(z.sum()),2)
        self.assertTrue(np.all((z==0)|(z==1)))


if __name__=="__main__":
    unittest.main()
