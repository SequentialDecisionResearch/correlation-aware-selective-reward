import unittest
import numpy as np

from phase2_grpo.design import ExactBDesign, uniform_design
from phase2_grpo.geometry import gradient_map, full_gradient
from phase2_grpo.risk import (acquisition_risk, augmented_rewards,
                              conditional_query_covariance,
                              confidence_gated_design, fixed_size_additive_gap)
from phase2_grpo.simulation import deterministic_counterexample


class GeometryAndRiskTests(unittest.TestCase):
    def test_centering_and_scale(self):
        scores = np.array([[1., 2., 7., -3.], [3., 1., 5., 1.]])
        m = gradient_map(scores)
        np.testing.assert_allclose(m.sum(axis=1), 0, atol=1e-14)
        np.testing.assert_allclose(m, (scores-scores.mean(axis=1, keepdims=True))/3)

    def test_full_feedback_loo_is_on_policy_unbiased(self):
        rng = np.random.default_rng(21)
        theta = np.array([0.4, -0.2, 0.1])
        p = np.exp(theta) / np.exp(theta).sum()
        means = np.array([-0.2, 0.9, 0.6])
        target = p * (means - p @ means)
        estimates = []
        for _ in range(4500):
            a = rng.choice(3, size=5, p=p)
            scores = np.eye(3)[a].T - p[:, None]
            estimates.append(full_gradient(scores, means[a]))
        np.testing.assert_allclose(np.mean(estimates, axis=0), target, atol=.02)

    def test_design_unbiased_for_arbitrary_wrong_predictor(self):
        reward = np.array([3., -2., 5., 4.])
        predictor = np.array([-900., 13., 0., 120.])
        design = uniform_design(4, 2)
        recon = np.zeros(4)
        for z, prob in zip(design.subsets, design.probs):
            obs = np.full(4, np.nan)
            obs[z.astype(bool)] = reward[z.astype(bool)]
            recon += prob * augmented_rewards(obs, predictor, z, design.marginals)
        np.testing.assert_allclose(recon, reward, atol=1e-12)

    def test_no_unpurchased_reward_leak(self):
        selected = np.array([1, 0, 1, 0], dtype=bool)
        obs1 = np.array([4., np.nan, 9., np.nan])
        obs2 = np.array([4., 1e20, 9., -1e20])
        pred = np.array([0.4, 0.5, 0.6, 0.7])
        pi = np.full(4, .5)
        np.testing.assert_array_equal(augmented_rewards(obs1, pred, selected, pi),
                                      augmented_rewards(obs2, pred, selected, pi))

    def test_covariance_formula_conditioned_on_fixed_residual(self):
        rng = np.random.default_rng(5)
        score = rng.normal(size=(3, 5))
        design = uniform_design(5, 2)
        m = gradient_map(score)
        v = np.array([1., 2., -1., 3., .5])
        V = np.outer(v, v)
        x = []
        for z in design.subsets:
            estimate = m @ (z * v / design.marginals)
            x.append(estimate)
        x = np.asarray(x)
        centered = x - m @ v
        empirical = (centered.T * design.probs) @ centered
        predicted = conditional_query_covariance(score, np.zeros((5, 5)), V, design)
        np.testing.assert_allclose(empirical, predicted, atol=1e-12)

    def test_covariance_rejects_zero_first_order_inclusion(self):
        design = ExactBDesign(np.array([[1, 1, 0]]), np.array([1.]))
        with self.assertRaises(ValueError):
            conditional_query_covariance(np.array([[1., 2., 3.]]),
                                         np.eye(3), np.eye(3), design)

    def test_independent_bernoulli_offdiagonal_is_zero(self):
        pi = np.array([.2, .4, .7])
        pi2 = np.outer(pi, pi)
        np.fill_diagonal(pi2, pi)
        cq = pi2 / np.outer(pi, pi) - 1
        np.testing.assert_allclose(cq[np.triu_indices(3, 1)], 0)

    def test_balanced_counterexample(self):
        evidence = deterministic_counterexample(repetitions=12_000)
        self.assertAlmostEqual(evidence["analytic_good_risk"], 0)
        self.assertAlmostEqual(evidence["analytic_bad_risk"], 16)
        self.assertLess(abs(evidence["mc_bad_risk"] - 16), 1)

    def test_additive_no_gain_sufficient_form(self):
        u = np.array([1., -4., 2., 3., 1.5])
        coeff = u[:, None] + u[None, :]
        self.assertLess(fixed_size_additive_gap(coeff), 1e-11)
        rng = np.random.default_rng(9)
        p1 = uniform_design(5, 2)
        # Any exact B distribution with uniform marginals has same sum.
        weighted = []
        for z in p1.subsets:
            weighted.append(sum(coeff[i, j] * z[i] * z[j]
                                for i in range(5) for j in range(i+1, 5)))
        self.assertAlmostEqual(float(p1.probs @ weighted), (2-1) * u.sum() * 2 / 5)

    def test_confidence_gate_requires_actual_bound(self):
        score = np.array([[0., 0., 1., 1.]]) * 3
        v = np.ones((4, 4))
        base = uniform_design(4, 2)
        improved = ExactBDesign(np.array([[1,0,1,0], [0,1,0,1]]),
                                np.array([.5, .5]))
        chosen, note = confidence_gated_design(score, v, improved, base, 0)
        self.assertTrue(note["accepted"])
        self.assertIs(chosen, improved)
        chosen, note = confidence_gated_design(score, v, improved, base, 100)
        self.assertFalse(note["accepted"])
        self.assertIs(chosen, base)


if __name__ == "__main__":
    unittest.main()

