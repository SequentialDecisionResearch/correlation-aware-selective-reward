import tempfile
import unittest

import numpy as np

from phase2_grpo.phase2_study import (PROFILES, covariance_profile,
                                       drifted_pilot_cov, one_cell, run_phase2)


class Phase2StudyTests(unittest.TestCase):
    def test_all_covariance_profiles_psd(self):
        for G in (4, 6, 8, 12):
            for name in PROFILES:
                v = covariance_profile(G, name)
                self.assertGreaterEqual(np.linalg.eigvalsh(v).min(), -1e-9)
                np.testing.assert_allclose(np.diag(v),
                                           (1 + .25 * np.linspace(-1, 1, G)) ** 2)

    def test_drift_covariance_is_distinct_and_psd(self):
        current = covariance_profile(6, "common_strong")
        past = drifted_pilot_cov(6, "common_strong", current)
        self.assertGreater(np.linalg.norm(current - past), .5)
        self.assertGreaterEqual(np.linalg.eigvalsh(past).min(), -1e-8)

    def test_independence_and_boundary_zero_gain(self):
        for profile, G, B in (("independent", 8, 4),
                              ("signed_factor", 6, 1),
                              ("common_strong", 6, 5)):
            row = one_cell(G, B, profile, pilot_n=100, drift=False, seed=67)
            self.assertLess(abs(row["joint_vs_uniform"]), 1e-7)
            self.assertLess(abs(row["joint_vs_scaled"]), 1e-7)

    def test_quick_study_writes_self_consistent_results(self):
        with tempfile.TemporaryDirectory() as destination:
            summary = run_phase2(destination, quick=True)
            self.assertEqual(summary["rows_total"], 48)
            self.assertEqual(summary["rows_interior"], 16)
            self.assertLess(summary["no_gain_max_abs"], 1e-7)
            self.assertEqual(summary["joint_vs_scaled_on_main"]["seed_clusters"], 2)


if __name__ == "__main__":
    unittest.main()
