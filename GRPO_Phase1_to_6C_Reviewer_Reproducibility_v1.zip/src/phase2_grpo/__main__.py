"""Command-line entry point, e.g. python -m phase2_grpo --output results."""

import argparse
import json

from .simulation import run_all


def main():
    parser = argparse.ArgumentParser(description="Run auditable synthetic diagnostics")
    parser.add_argument("--output", default="results")
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run_all(args.output, quick=args.quick), indent=2))


if __name__ == "__main__":
    main()

