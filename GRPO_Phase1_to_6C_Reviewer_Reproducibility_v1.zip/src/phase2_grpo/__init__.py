"""Phase 2 of correlation-aware reward acquisition.

The package studies an *unnormalized, one-step, on-policy LOO* estimator.
It is not an implementation of token-level clipped GRPO or noisy-label
correction. Mathematics and empirical claims are deliberately separated.
"""

__version__ = "0.2.0"

