"""Geometry of the unnormalized leave-one-out group policy gradient."""

import numpy as np


def gradient_map(scores: np.ndarray) -> np.ndarray:
    """Map rewards R to the full-feedback LOO score-gradient M @ R.

    scores has shape (d, G), and G >= 2. The identity is
        M = (S - column_mean(S)) / (G-1).
    No reward is accessed in constructing M.
    """
    scores = np.asarray(scores, dtype=float)
    if scores.ndim != 2 or scores.shape[1] < 2:
        raise ValueError("scores must have shape (d,G), with G>=2")
    if not np.all(np.isfinite(scores)):
        raise ValueError("scores must be finite")
    return (scores - scores.mean(axis=1, keepdims=True)) / (scores.shape[1] - 1)


def full_gradient(scores: np.ndarray, rewards: np.ndarray) -> np.ndarray:
    m = gradient_map(scores)
    rewards = np.asarray(rewards, dtype=float)
    if rewards.shape != (m.shape[1],):
        raise ValueError("rewards must have one entry per candidate")
    return m @ rewards


def gradient_gram(scores: np.ndarray) -> np.ndarray:
    m = gradient_map(scores)
    return m.T @ m

