"""Frozen real-Qwen generation and exact token-bias log-score sketches.

The three score dimensions are genuine directional derivatives of the
log-probability of each observed completion under the frozen base-model
softmax for a *hypothetical token-logit-bias parameter family*.  They are
NOT the gradients of LoRA weights or a full GRPO optimizer.

The fake backend exists ONLY for deterministic unit/restart tests.  Fake
results must not be described as language-model results.
"""

import hashlib
import json
from pathlib import Path
from typing import Protocol

import numpy as np

from .phase6a_tasks import SYSTEM_PROMPT


SKETCH_SEED = 6026
SKETCH_DIM = 3


class GenerationBackend(Protocol):
    def info(self) -> dict: ...
    def generate(self, task: dict, group_seed: int, g: int, max_new_tokens: int) -> dict: ...


def group_seed(master: int, index: int) -> int:
    raw = f"phase6a|generation|{master}|{index}".encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "little") % (2**63 - 1)


def decision_seed(master: int, policy: str, index: int) -> int:
    raw = f"phase6a|selection|{master}|{policy}|{index}".encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "little") % (2**63 - 1)


def token_signs(vocab_size: int) -> np.ndarray:
    rng = np.random.default_rng(SKETCH_SEED)
    return rng.choice(np.array([-1., 1.], dtype=np.float32),
                      size=(vocab_size, SKETCH_DIM))


class FakeBackend:
    """Pure deterministic simulator for testing checkpoint mechanics."""

    def __init__(self):
        self.calls = 0

    def info(self) -> dict:
        return {"backend": "fake", "model": "NO_REAL_LLM", "version": 1}

    def generate(self, task: dict, group_seed: int, g: int, max_new_tokens: int) -> dict:
        self.calls += 1
        rng = np.random.default_rng(group_seed)
        outputs, features, lengths = [], [], []
        for _ in range(g):
            # Even the fake backend receives no answer key. This only tests
            # mechanics and may produce almost exclusively incorrect answers.
            if "answer" in task:
                raise AssertionError("generation backend received sealed gold answer")
            value = int(rng.integers(-60,700))
            outputs.append(f"\\boxed{{{value}}}")
            features.append(rng.normal(size=SKETCH_DIM).tolist())
            lengths.append(min(5, max_new_tokens))
        return {"completions": outputs, "score_features": np.asarray(features).T.tolist(),
                "completion_tokens": lengths, "backend": "fake"}


class HuggingFaceQwenBackend:
    def __init__(self, model_name: str, *, revision: str = "main",
                 device: str = "cuda", local_files_only: bool = False):
        try:
            import torch
            import transformers
            from transformers import AutoTokenizer, AutoModelForCausalLM
        except ImportError as exc:
            raise RuntimeError("install the [llm] extra and CUDA PyTorch first") from exc
        self.torch = torch
        self.transformers_version = transformers.__version__
        self.model_name = model_name
        self.revision = revision
        self.device = torch.device(device)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA unavailable: check RTX 5070 driver / WSL / PyTorch build")
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_name, revision=revision, local_files_only=local_files_only,
            trust_remote_code=False)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name, revision=revision, local_files_only=local_files_only,
            trust_remote_code=False, torch_dtype="auto")
        self.model.to(self.device)
        self.model.eval()
        if self.tokenizer.eos_token_id is None:
            raise RuntimeError("model tokenizer must define EOS")
        signs = token_signs(int(self.model.config.vocab_size))
        self.signs = torch.from_numpy(signs).to(device=self.device, dtype=torch.float32)
        self._info = {
            "backend": "hf", "model": model_name, "requested_revision": revision,
            "resolved_commit": getattr(self.model.config, "_commit_hash", None),
            "tokenizer_commit": getattr(self.tokenizer, "_commit_hash", None),
            "transformers": self.transformers_version,
            "torch": torch.__version__, "cuda_build": torch.version.cuda,
            "vocab_size": int(self.model.config.vocab_size),
            "sketch_seed": SKETCH_SEED, "sketch_dim": SKETCH_DIM,
            "device_type": self.device.type,
            "model_config_sha256": hashlib.sha256(json.dumps(
                self.model.config.to_dict(), sort_keys=True, default=str
            ).encode()).hexdigest(),
        }
        local = Path(model_name)
        if local.is_dir():
            files = sorted(list(local.glob("*.safetensors")) +
                           list(local.glob("pytorch_model*.bin")))
            if not files:
                raise RuntimeError("local model directory lacks weights (.safetensors/.bin)")
            hashes = {}
            for path in files:
                h = hashlib.sha256()
                with path.open("rb") as stream:
                    for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                        h.update(block)
                hashes[path.name] = h.hexdigest()
            self._info["local_weight_sha256"] = hashes
        elif self._info["resolved_commit"] is None:
            raise RuntimeError("cannot pin remote model revision; download a fixed snapshot")

    def info(self) -> dict:
        return self._info.copy()

    def _sketch(self, input_ids, prompt_length: int, scale: int) -> list[float]:
        """Score in logit-bias directions under the *unwarped* policy.

        For each token t and sign direction c_k over vocabulary,
          d/d alpha_k log p_alpha(y_t|history)|alpha=0
             = c_k(y_t) - sum_v p(v|history)c_k(v).
        Sum over completion tokens; scale by the fixed max_new_tokens.
        """
        torch = self.torch
        if input_ids.shape[1] <= prompt_length:
            return [0.] * SKETCH_DIM
        with torch.inference_mode():
            all_logits = self.model(input_ids=input_ids[:, :-1], use_cache=False).logits
            cond_logits = all_logits[0, prompt_length - 1:].float()
            taken = input_ids[0, prompt_length:].long()
            if cond_logits.shape[0] != taken.shape[0]:
                raise RuntimeError("autoregressive logit/token alignment failure")
            expected = torch.softmax(cond_logits, dim=-1) @ self.signs
            observed = self.signs[taken]
            projected = (observed - expected).sum(dim=0) / float(scale)
            answer = projected.cpu().numpy().astype(float).tolist()
        if not np.all(np.isfinite(answer)):
            raise RuntimeError("nonfinite frozen-policy gradient sketch")
        return answer

    def generate(self, task: dict, group_seed: int, g: int, max_new_tokens: int) -> dict:
        torch = self.torch
        messages = [{"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": task["prompt"]}]
        ids = self.tokenizer.apply_chat_template(messages, tokenize=True,
                   add_generation_prompt=True, return_tensors="pt").to(self.device)
        input_length = int(ids.shape[1])
        torch.manual_seed(int(group_seed))
        if self.device.type == "cuda":
            torch.cuda.manual_seed_all(int(group_seed))
        with torch.inference_mode():
            # FULL base softmax: no top-k, top-p or temperature distortion.
            # The score sketch therefore refers to the same sampled policy.
            sequences = self.model.generate(
                input_ids=ids, attention_mask=torch.ones_like(ids),
                do_sample=True, num_beams=1, num_return_sequences=g,
                top_k=0, top_p=1.0, temperature=1.0,
                repetition_penalty=1.0, max_new_tokens=max_new_tokens,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id)
        outputs, columns, lengths = [], [], []
        for row in sequences:
            continuation = row[input_length:]
            eos = (continuation == self.tokenizer.eos_token_id).nonzero(as_tuple=False)
            if eos.numel():
                continuation = continuation[:int(eos[0].item()) + 1]
            if not len(continuation):
                raise RuntimeError("empty completion token sequence")
            full = torch.cat([ids[0], continuation]).unsqueeze(0)
            text = self.tokenizer.decode(continuation, skip_special_tokens=True)
            outputs.append(text)
            columns.append(self._sketch(full, input_length, max_new_tokens))
            lengths.append(int(len(continuation)))
        return {"completions": outputs,
                "score_features": np.array(columns, dtype=float).T.tolist(),
                "completion_tokens": lengths, "backend": "hf"}
