"""Phase-2 same-marginal survey-baseline and correlation falsification study.

This is a *new exploratory synthetic* study, not real GRPO or a preregistered
independent confirmation. Primary comparator is a pilot-diagonal-score
balancing LP. All methods use the same uniform first-order marginals and
purchase exactly B of G gold rewards. True V is evaluation-only.
"""

from collections import defaultdict
from dataclasses import dataclass
import csv
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.stats import t as student_t

from .balanced import (auxiliary_balance_lp, balance_risk,
                       cube_flight_dependent_landing, tensor_auxiliary)
from .design import uniform_design
from .geometry import gradient_map
from .optimization import optimize_coupling
from .risk import acquisition_risk
from .simulation import pilot_moment_fit


SEEDS = (11, 29, 47, 83, 101, 127, 149, 173, 191, 223, 251, 283)
PROFILES = ("independent", "common_weak", "common_strong",
            "signed_factor", "negative_equicorr", "two_blocks")


@dataclass(frozen=True)
class StudyConfig:
    group_sizes: tuple[int, ...] = (4, 6, 8)
    pilot_counts: tuple[int, ...] = (120, 600)
    seeds: tuple[int, ...] = SEEDS
    profiles: tuple[str, ...] = PROFILES
    include_drift: bool = True


def _standardize_cov(corr: np.ndarray, g: int) -> np.ndarray:
    """Require and enforce a valid PSD correlation, then known scale spread."""
    corr = np.asarray(corr, float)
    if corr.shape != (g, g) or np.linalg.eigvalsh(corr).min() < -1e-9:
        raise ValueError("invalid correlation matrix")
    scale = 1 + .25 * np.linspace(-1, 1, g)
    return scale[:, None] * corr * scale[None, :]


def covariance_profile(g: int, profile: str) -> np.ndarray:
    """Explicit deterministic PSD families; no current reward observations."""
    I = np.eye(g)
    if profile == "independent":
        corr = I
    elif profile == "common_weak":
        corr = .70 * I + .30 * np.ones((g, g))
    elif profile == "common_strong":
        corr = .20 * I + .80 * np.ones((g, g))
    elif profile == "signed_factor":
        f = np.where(np.arange(g) < g // 2, 1., -1.)
        corr = .20 * I + .80 * np.outer(f, f)
    elif profile == "negative_equicorr":
        rho = -.75 / (g - 1)
        corr = (1 - rho) * I + rho * np.ones((g, g))
    elif profile == "two_blocks":
        f = np.where(np.arange(g) < g // 2, 1., 0.)
        h = 1 - f
        corr = .20 * I + .80 * (np.outer(f, f) + np.outer(h, h))
    else:
        raise ValueError(f"unknown covariance profile: {profile}")
    return _standardize_cov(corr, g)


def drifted_pilot_cov(g: int, profile: str, target: np.ndarray) -> np.ndarray:
    """A genuine negative-transfer stress: historical covariance may differ."""
    competing = ("signed_factor" if profile != "signed_factor"
                 else "common_strong")
    old = covariance_profile(g, competing)
    return .15 * target + .85 * old  # convex PSD mixture


def _seed_stream(g: int, b: int, profile_index: int, pilot_n: int,
                 drift: bool, seed: int):
    bundle = np.random.SeedSequence([20261023, g, b, profile_index,
                                     pilot_n, int(drift), seed])
    score_stream, pilot_stream = [np.random.default_rng(q) for q in bundle.spawn(2)]
    return score_stream, pilot_stream


def one_cell(g: int, b: int, profile: str, pilot_n: int, drift: bool,
             seed: int) -> dict:
    """Evaluate exact conditional risk; acquisition sees pilot Vhat only."""
    if profile not in PROFILES:
        raise ValueError("unknown profile")
    if pilot_n < 2 or g < 3 or not 1 <= b < g:
        raise ValueError("invalid numerical experiment configuration")
    score_rng, pilot_rng = _seed_stream(g, b, PROFILES.index(profile),
                                        pilot_n, drift, seed)
    scores = score_rng.normal(size=(3, g))
    M = gradient_map(scores)
    true_V = covariance_profile(g, profile)
    historical_V = (drifted_pilot_cov(g, profile, true_V) if drift
                    else true_V)
    base = uniform_design(g, b)
    pi = base.marginals
    fit = pilot_moment_fit(historical_V, base, n=pilot_n, rng=pilot_rng)

    def timed(fn):
        start = perf_counter()
        result = fn()
        return result, perf_counter() - start

    cube, t_cube = timed(lambda: cube_flight_dependent_landing(pi, b, M))
    score_bal, t_score = timed(lambda: auxiliary_balance_lp(pi, b, M))
    scaled_aux = M * np.sqrt(np.maximum(np.diag(fit.psd), 0.))[None, :]
    scale_bal, t_scale = timed(lambda: auxiliary_balance_lp(pi, b, scaled_aux))
    practical, t_joint = timed(lambda: optimize_coupling(scores, fit.psd, pi, b))
    oracle, t_oracle = timed(lambda: optimize_coupling(scores, true_V, pi, b))
    practical = practical[0]
    oracle = oracle[0]
    designs = {"uniform": base, "cube": cube, "score": score_bal,
               "scaled": scale_bal, "joint": practical, "oracle": oracle}
    risk = {name: acquisition_risk(scores, true_V, design)
            for name, design in designs.items()}
    if risk["oracle"] > min(risk.values()) + 1e-7:
        raise AssertionError("evaluation oracle LP is not a lower bound")
    for design in designs.values():
        if np.max(np.abs(design.marginals - pi)) > 1e-7:
            raise AssertionError("same-marginal experiment invariant broken")
    if (b in (1, g - 1) or profile == "independent"):
        if max(abs(risk[name] - risk["uniform"]) for name in risk) > 1e-6:
            raise AssertionError("a mathematically known zero-gain control failed")
    # Stronger benchmark is already optimal for the *score imbalance* target.
    if balance_risk(score_bal, M) > balance_risk(base, M) + 1e-8:
        raise AssertionError("auxiliary balancing LP failed own objective")
    return {
        "G": g, "B": b, "profile": profile,
        "pilot_n": pilot_n, "drifted_pilot": int(drift), "seed": seed,
        **{f"risk_{name}": float(value) for name, value in risk.items()},
        "joint_vs_uniform": float(risk["uniform"] - risk["joint"]),
        "joint_vs_scaled": float(risk["scaled"] - risk["joint"]),
        "joint_vs_score": float(risk["score"] - risk["joint"]),
        "joint_vs_cube": float(risk["cube"] - risk["joint"]),
        "joint_regret_to_oracle": float(risk["joint"] - risk["oracle"]),
        "scaled_vs_uniform": float(risk["uniform"] - risk["scaled"]),
        "cube_vs_uniform": float(risk["uniform"] - risk["cube"]),
        "fitted_V_fro_error": float(np.linalg.norm(fit.psd - true_V, "fro")),
        "fraction_pair_supported": float(np.mean(fit.pair_supported[np.triu_indices(g, 1)])),
        "min_pair_ess": float(fit.pair_effective_n[np.triu_indices(g, 1)].min()),
        "time_cube_s": t_cube, "time_score_lp_s": t_score,
        "time_scaled_lp_s": t_scale, "time_joint_lp_s": t_joint,
        "time_oracle_lp_s": t_oracle,
        "source_of_true_V": "evaluation_only",
    }


def _paired_seed_ci(rows: list[dict], metric: str) -> dict:
    """Treat seed (not each correlated factorial row) as independent cluster."""
    per_seed: defaultdict[int, list[float]] = defaultdict(list)
    for row in rows:
        per_seed[int(row["seed"])].append(float(row[metric]))
    values = np.array([np.mean(v) for _, v in sorted(per_seed.items())])
    if not len(values):
        raise ValueError("empty experiment stratum")
    mean = float(values.mean())
    half = (float(student_t.ppf(.975, len(values) - 1)
                  * values.std(ddof=1) / np.sqrt(len(values)))
            if len(values) > 1 else float("nan"))
    return {"seed_clusters": int(len(values)), "rows": len(rows),
            "mean": mean, "descriptive_t95": [mean - half, mean + half],
            "positive_seed_fraction": float(np.mean(values > 1e-8))}


def _save_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run_phase2(destination: str | Path, quick: bool = False) -> dict:
    config = (StudyConfig(group_sizes=(4, 6), pilot_counts=(100,),
                          seeds=(11, 29), profiles=PROFILES[:4],
                          include_drift=False) if quick else StudyConfig())
    result_rows = []
    start = perf_counter()
    for G in config.group_sizes:
        for B in sorted({1, G // 2, G - 1}):
            is_boundary = B in (1, G - 1)
            pilots = (config.pilot_counts[-1],) if is_boundary else config.pilot_counts
            seeds = config.seeds[:4] if is_boundary else config.seeds
            drifts = (False,) if is_boundary or not config.include_drift else (False, True)
            for profile in config.profiles:
                for pilot_n in pilots:
                    for drift in drifts:
                        for seed in seeds:
                            result_rows.append(one_cell(G, B, profile, pilot_n,
                                                        drift, seed))
    elapsed = perf_counter() - start
    folder = Path(destination)
    folder.mkdir(parents=True, exist_ok=True)
    _save_csv(folder / "all_trials.csv", result_rows)

    interior = [r for r in result_rows if r["B"] not in (1, r["G"] - 1)]
    boundary = [r for r in result_rows if r["B"] in (1, r["G"] - 1)]
    main = [r for r in interior if r["pilot_n"] == config.pilot_counts[-1]
            and r["drifted_pilot"] == 0]
    by_profile = {}
    for profile in config.profiles:
        chosen = [r for r in main if r["profile"] == profile]
        by_profile[profile] = {
            "joint_minus_scaled": _paired_seed_ci(chosen, "joint_vs_scaled"),
            "joint_minus_uniform": _paired_seed_ci(chosen, "joint_vs_uniform"),
            "scaled_minus_uniform": _paired_seed_ci(chosen, "scaled_vs_uniform"),
        }
    summary = {
        "label": "exploratory_synthetic_phase2_not_llm",
        "run_seconds": elapsed, "rows_total": len(result_rows),
        "rows_interior": len(interior), "rows_boundary": len(boundary),
        "balanced_baselines": ["cube_flight_with_pair_landing",
                                "global_score_balance_LP", "global_diagonal_scaled_balance_LP"],
        "primary_exploratory_comparator": "joint_vs_diagonal_scaled_balance_LP",
        "joint_vs_scaled_on_main": _paired_seed_ci(main, "joint_vs_scaled"),
        "joint_vs_uniform_on_main": _paired_seed_ci(main, "joint_vs_uniform"),
        "by_profile_main": by_profile,
        "main_definition": "interior B=G//2, maximum pilot n, matched pilot V, seed-cluster intervals",
        "no_gain_max_abs": max(abs(r["joint_vs_uniform"]) for r in result_rows
                                if r["B"] in (1, r["G"] - 1)
                                or r["profile"] == "independent"),
        "known_tensor_balance_identity": "exact for every PSD V by construction; tested separately",
        "limitations": ["not true Deville-Tille cube landing", "not a real verifier",
                        "no full modern clipped GRPO training", "t intervals descriptive",
                        "method/feature/parameter grids selected during exploratory development"],
    }
    (folder / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary
