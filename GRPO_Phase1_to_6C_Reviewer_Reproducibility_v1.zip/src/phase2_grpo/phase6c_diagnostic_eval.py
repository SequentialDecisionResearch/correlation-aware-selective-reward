"""GPU replay and paired item-level evaluation for immutable Phase6C states."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from .phase6a_checkpoint import digest
from .phase6a_tasks import score_answer
from .phase6c_diagnostics import (PROTOCOL, STRATA, cluster_interval,
    csv_once, evaluation_steps, locked_inputs, open_existing_checkpoint,
    read_json, stored_state, write_once)
from .phase6c_objectives import ARMS, Phase6CConfig


def event_path(output: Path, seed: int, arm: str, panel: str, step: int) -> Path:
    return (Path(output)/"events"/f"seed{seed}"/arm/
            f"{panel}_step{step:06d}.json")


def read_event(path: Path, *, seed: int, arm: str, panel: str, step: int,
               expected_count: int, bank_sha: str) -> dict | None:
    if not path.exists():
        return None
    result=read_json(path)
    checksum=result.pop("sha256",None)
    if (checksum!=digest(result) or result.get("protocol")!=PROTOCOL or
            result.get("seed")!=seed or result.get("arm")!=arm or
            result.get("panel")!=panel or result.get("step")!=step or
            result.get("bank_sha256")!=bank_sha or
            len(result.get("items",[]))!=expected_count):
        raise RuntimeError(f"invalid diagnostic evaluation event: {path}")
    result["sha256"]=checksum
    return result


def evaluated_items(policy, tasks: list[dict]) -> list[dict]:
    """Score only AFTER decoding, never supply answer to the model prompt."""
    torch=policy.torch
    policy.model.eval()
    output=[]
    for task in tasks:
        prompt=policy._prompt(task["prompt"])
        with torch.inference_mode():
            sequence=policy.model.generate(
                input_ids=prompt,attention_mask=torch.ones_like(prompt),
                do_sample=False,num_beams=1,
                max_new_tokens=policy.cfg.max_new_tokens,
                pad_token_id=policy.tokenizer.eos_token_id,
                eos_token_id=policy.tokenizer.eos_token_id)
        response=policy.tokenizer.decode(sequence[0,prompt.shape[1]:],
                                         skip_special_tokens=True)
        scored=score_answer(task,response)
        output.append({"task_id":task["id"],"stratum":task["level"],
                       "prompt":task["prompt"],"answer":task["answer"],
                       "response":response,"parsed_answer":scored["parsed_answer"],
                       "correct":bool(scored["reward"]),
                       "parseable":bool(scored["parseable"]),
                       "format_compliant":bool(scored["format_compliant"]),
                       "strict_format_correct":bool(scored["strict_format_correct"])})
    return output


def validate_against_original(cp, step: int, rows: list[dict]) -> None:
    saved=(cp.load("baseline_eval",0) if step==0 else
           cp.load("train_steps",step-1)["heldout_evaluation"])
    if saved is None:
        raise RuntimeError("historical evaluation missing")
    counts={"correct":sum(x["correct"] for x in rows),
            "parseable_fraction":sum(x["parseable"] for x in rows)/len(rows),
            "format_compliance_fraction":sum(x["format_compliant"] for x in rows)/len(rows),
            "strict_format_correct_fraction":
                sum(x["strict_format_correct"] for x in rows)/len(rows)}
    for key,value in counts.items():
        if not np.isclose(value,saved[key],atol=1e-12,rtol=0):
            raise RuntimeError(f"evaluation replay differs from original at step={step}: {key} "
                               f"new={value}, saved={saved[key]}; stop before analysis")


def evaluate(output: Path, *, max_new_evals: int | None = None,
             policy_factory=None, state_loader=None) -> dict:
    if max_new_evals is not None and max_new_evals<0:
        raise ValueError("max-new-evals must be nonnegative")
    manifest,bank=locked_inputs(output)
    if policy_factory is None:
        from .phase6c_model import RealLoRAPolicy
        policy_factory=RealLoRAPolicy
    if state_loader is None:
        import torch
        state_loader=lambda path:torch.load(path,map_location="cpu",weights_only=True)
    done=0
    created=0
    total=0
    for run in manifest["runs"]:
        cfg=Phase6CConfig(**run["config"])
        root=Path(run["root"])
        steps=evaluation_steps(cfg)
        for arm in ARMS:
            cp=open_existing_checkpoint(root,arm)
            bank_tasks=cp.load("tasks",0)["heldout"]
            plan=[("heldout",step,bank_tasks) for step in steps]
            plan.extend(("stress",step,bank["tasks"]) for step in (0,cfg.steps))
            plan.sort(key=lambda x:(x[1],x[0]))
            model=None
            try:
                for panel,step,tasks in plan:
                    total+=1
                    path=event_path(output,cfg.seed,arm,panel,step)
                    saved=read_event(path,seed=cfg.seed,arm=arm,panel=panel,
                                     step=step,expected_count=len(tasks),
                                     bank_sha=manifest["stress_bank_sha256"])
                    if saved is not None:
                        done+=1
                        continue
                    if max_new_evals is not None and created>=max_new_evals:
                        # Other events are still pending; don't claim complete.
                        return {"complete":False,"previous_events":done,
                                "new_events":created,"note":"rerun to resume"}
                    if model is None:
                        model=policy_factory(cfg)
                        recorded_info=cp.load("model_info",0)
                        if model.info!=recorded_info:
                            raise RuntimeError("Qwen runtime/base-model fingerprint changed")
                    state=state_loader(stored_state(cp,step))
                    model.restore(state,step)
                    rows=evaluated_items(model,tasks)
                    if panel=="heldout":
                        validate_against_original(cp,step,rows)
                    core={"protocol":PROTOCOL,"seed":cfg.seed,"arm":arm,
                          "panel":panel,"step":step,
                          "source_state_sha256":
                            cp.load("initial_state",0)["state_sha256"] if step==0
                            else cp.load("train_steps",step-1)["state_sha256"],
                          "bank_sha256":manifest["stress_bank_sha256"],
                          "items":rows}
                    write_once(path,{**core,"sha256":digest(core)})
                    created+=1
                    print(f"COMMITTED DIAGNOSTIC seed{cfg.seed} {arm} {panel} step{step}",flush=True)
            finally:
                if model is not None:
                    del model
                    try:
                        import torch
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()
                    except ImportError:
                        pass
    return {"complete":True,"existing_events":done,"new_events":created,
            "total_expected_events":total}


def report(output: Path) -> dict:
    manifest,bank=locked_inputs(output)
    item_rows=[]
    pairs=[]
    stress_records=[]
    for run in manifest["runs"]:
        cfg=Phase6CConfig(**run["config"])
        for panel,steps in (("heldout",evaluation_steps(cfg)),
                            ("stress",[0,cfg.steps])):
            for step in steps:
                per_arm={}
                for arm in ARMS:
                    cp=open_existing_checkpoint(Path(run["root"]),arm)
                    n=cfg.eval_size if panel=="heldout" else len(bank["tasks"])
                    record=read_event(event_path(output,cfg.seed,arm,panel,step),
                                      seed=cfg.seed,arm=arm,panel=panel,
                                      step=step,expected_count=n,
                                      bank_sha=manifest["stress_bank_sha256"])
                    if record is None:
                        raise RuntimeError(f"diagnostic GPU evaluation incomplete: seed{cfg.seed} {arm} {panel} step{step}")
                    source_expected=(cp.load("initial_state",0)["state_sha256"] if step==0
                                     else cp.load("train_steps",step-1)["state_sha256"])
                    if record["source_state_sha256"]!=source_expected:
                        raise RuntimeError("checkpoint changed after event recording")
                    stored_state(cp,step)
                    per_arm[arm]=record["items"]
                    for x in record["items"]:
                        item_rows.append({"seed":cfg.seed,"panel":panel,"step":step,
                                          "arm":arm,**x})
                for ix in range(len(per_arm["full"])):
                    f,u,j=(per_arm[a][ix] for a in ARMS)
                    identity=("task_id","prompt","answer","stratum")
                    if any(any(x[k]!=f[k] for k in identity) for x in (u,j)):
                        raise RuntimeError("per-item cross-arm comparison not paired")
                    pairs.append({"seed":cfg.seed,"panel":panel,"step":step,
                        "task_id":f["task_id"],"stratum":f["stratum"],
                        "answer":f["answer"],"full_correct":f["correct"],
                        "uniform_correct":u["correct"],"joint_ewma_correct":j["correct"],
                        "ewma_minus_uniform":int(j["correct"])-int(u["correct"]),
                        "uniform_only_correct":bool(u["correct"] and not j["correct"]),
                        "ewma_only_correct":bool(j["correct"] and not u["correct"]),
                        "full_prediction":f["parsed_answer"],
                        "uniform_prediction":u["parsed_answer"],
                        "joint_ewma_prediction":j["parsed_answer"]})
                if panel=="stress":
                    for arm in ARMS:
                        for family in STRATA:
                            members=[x for x in per_arm[arm] if x["stratum"]==family]
                            if len(members)!=bank["per_stratum"]:
                                raise RuntimeError("stress stratum size mismatch")
                            stress_records.append({"seed":cfg.seed,"arm":arm,
                                "step":step,"stratum":family,
                                "correct":sum(x["correct"] for x in members),
                                "count":len(members),
                                "accuracy":sum(x["correct"] for x in members)/len(members)})
    csv_once(Path(output)/"phase6c_item_predictions.csv",item_rows,
             ["seed","panel","step","arm","task_id","stratum","prompt",
              "answer","response","parsed_answer","correct","parseable",
              "format_compliant","strict_format_correct"])
    csv_once(Path(output)/"phase6c_item_pairs.csv",pairs,
             ["seed","panel","step","task_id","stratum","answer",
              "full_correct","uniform_correct","joint_ewma_correct",
              "ewma_minus_uniform","uniform_only_correct","ewma_only_correct",
              "full_prediction","uniform_prediction","joint_ewma_prediction"])
    csv_once(Path(output)/"phase6c_stress_by_seed.csv",stress_records,
             ["seed","arm","step","stratum","correct","count","accuracy"])
    stress_by={(x["seed"],x["arm"],x["step"],x["stratum"]):x
               for x in stress_records}
    stress_summary={}
    for family in STRATA:
        stats={}
        for arm in ARMS:
            improvements=[stress_by[(r["seed"],arm,r["config"]["steps"],family)]["accuracy"]-
                          stress_by[(r["seed"],arm,0,family)]["accuracy"]
                          for r in manifest["runs"]]
            finals=[stress_by[(r["seed"],arm,r["config"]["steps"],family)]["accuracy"]
                    for r in manifest["runs"]]
            stats[arm]={"final":cluster_interval(finals),
                        "improvement":cluster_interval(improvements)}
        gaps=[stress_by[(r["seed"],"joint_ewma",r["config"]["steps"],family)]["accuracy"]-
              stress_by[(r["seed"],"uniform",r["config"]["steps"],family)]["accuracy"]
              for r in manifest["runs"]]
        stats["ewma_minus_uniform_paired"]=cluster_interval(gaps)
        stress_summary[family]=stats
    disagreement={}
    seed_final_disagreements=[]
    for panel in ("heldout","stress"):
        subset=[r for r in pairs if r["panel"]==panel]
        disagreement[panel]={"uniform_only_correct":sum(r["uniform_only_correct"] for r in subset),
                            "ewma_only_correct":sum(r["ewma_only_correct"] for r in subset),
                            "paired_item_records":len(subset),
                            "note":"repeated checkpoints are NOT independent samples"}
        for run in manifest["runs"]:
            final=[r for r in subset if r["seed"]==run["seed"] and
                   r["step"]==run["config"]["steps"]]
            seed_final_disagreements.append({"seed":run["seed"],"panel":panel,
                "uniform_only_correct":sum(r["uniform_only_correct"] for r in final),
                "ewma_only_correct":sum(r["ewma_only_correct"] for r in final),
                "both_correct":sum(r["uniform_correct"] and r["joint_ewma_correct"] for r in final),
                "both_wrong":sum(not r["uniform_correct"] and not r["joint_ewma_correct"] for r in final),
                "paired_tasks":len(final)})
    result={"protocol":PROTOCOL,"status":"complete", "seeds":[r["seed"] for r in manifest["runs"]],
            "stress_bank_sha256":manifest["stress_bank_sha256"],
            "paired_disagreement":disagreement,
            "paired_final_disagreement_by_seed":seed_final_disagreements,
            "stress":stress_summary,
            "claim_boundary":"post-hoc exploratory stress; three seed clusters; no equivalence guarantee"}
    write_once(Path(output)/"phase6c_diagnostic_summary.json",result)
    return {"status":"complete","item_predictions":len(item_rows),
            "paired_item_rows":len(pairs),"stress_strata":list(STRATA),
            "paired_disagreement":disagreement}
