"""Independent frozen-algorithm Qwen holdout, with crash-safe stage journals.

The 6B task bank is DISJOINT from the 6A arithmetic task generator.  It
compares sampling designs on genuinely generated text, not on synthetic
gradients.  Its complete reward ledger is retrospective and free; no actual
paid-verifier saving or model update is claimed.
"""

from dataclasses import asdict, dataclass
import csv
import hashlib
from pathlib import Path
import platform
from types import SimpleNamespace
from typing import Callable

import numpy as np
import scipy
from scipy.stats import t as student_t

from .design import ExactBDesign
from .geometry import gradient_map
from .online_study import OnlineAcquirer
from .phase6a_checkpoint import Checkpoints, atomic_json, digest, run_lock
from .phase6a_model import FakeBackend, HuggingFaceQwenBackend, group_seed, decision_seed
from .phase6a_study import (METHODS, _backend, _check_generation, _record_one,
                            _restore_agent, _policy_config, source_hashes)
from .phase6a_tasks import ANSWER_INSTRUCTION, score_answer


SCENARIOS = ("word_to_mod", "interleaved_control")
SEEDS = (8123, 8249, 8311)


@dataclass(frozen=True)
class Phase6BConfig:
    groups: int = 80
    seeds: tuple[int, ...] = SEEDS
    scenarios: tuple[str, ...] = SCENARIOS
    g: int = 6
    b: int = 3
    warmup: int = 20
    window: int = 12
    exploration: float = .25
    max_new_tokens: int = 96
    backend: str = "hf"
    model: str = "Qwen/Qwen2.5-0.5B-Instruct"
    model_revision: str = "main"
    device: str = "cuda"
    local_files_only: bool = False

    def __post_init__(self):
        if (self.groups < 2 or self.g != 6 or self.b != 3 or
                not 1 <= self.warmup < self.groups or self.window < 3 or
                not 0 < self.exploration < 1 or not 2 <= self.max_new_tokens <= 1024 or
                self.backend not in ("hf", "fake") or not self.model or
                not self.model_revision or not self.seeds or
                len(set(self.seeds)) != len(self.seeds) or
                any(int(s) < 0 for s in self.seeds) or
                not self.scenarios or len(set(self.scenarios)) != len(self.scenarios) or
                any(s not in SCENARIOS for s in self.scenarios)):
            raise ValueError("invalid Phase 6B locked config")


def b_tasks(count: int, seed: int, scenario: str) -> list[dict]:
    """Original disjoint holdout prompts, with fully deterministic gold keys."""
    if scenario not in SCENARIOS:
        raise ValueError("unknown 6B holdout scenario")
    tasks = []
    for index in range(count):
        rng = np.random.default_rng(np.random.SeedSequence([20261106, seed, index]))
        a, b, c, d = [int(v) for v in rng.integers(4, 24, size=4)]
        hard = (index >= count // 2 if scenario == "word_to_mod" else index % 2 == 1)
        if not hard:
            answer = a * b - c + d
            prompt = (f"A shop starts with {a} boxes, each containing {b} items. "
                      f"It sells {c} items and then receives {d} more individual "
                      "items. How many items does it have now?")
        else:
            modulus = int(rng.integers(29, 101))
            answer = (a*a + b*c - d) % modulus
            prompt = (f"Find the nonnegative remainder when {a} squared plus "
                      f"{b} times {c} minus {d} is divided by {modulus}.")
        prompt += " " + ANSWER_INSTRUCTION
        tasks.append({"id": index, "level": "hard" if hard else "easy",
                      "answer": int(answer), "prompt": prompt, "scenario": scenario})
    return tasks


def cell_cfg(cfg: Phase6BConfig, seed: int, scenario: str) -> Phase6BConfig:
    if seed not in cfg.seeds or scenario not in cfg.scenarios:
        raise ValueError("case not in locked study")
    return cfg


def cell_name(seed: int, scenario: str) -> str:
    return f"{scenario}_seed{seed}"


def _hashes() -> dict:
    base = Path(__file__).resolve()
    root = base.parents[2]
    hashes = source_hashes()
    for name in ("src/phase2_grpo/phase6b_study.py", "scripts/run_phase6b.py"):
        hashes[name] = hashlib.sha256((root/name).read_bytes()).hexdigest()
    return hashes


def locked(cfg: Phase6BConfig) -> dict:
    config = asdict(cfg)
    # Checkpoints compares the manifest *after* a JSON round-trip: lists
    # must be lists already, not tuples that silently serialize as lists.
    config["seeds"] = list(cfg.seeds)
    config["scenarios"] = list(cfg.scenarios)
    return {"phase": "6B", "schema": 2, "config": config,
            "code_sha256": _hashes(),
            "versions": {"python": platform.python_version(), "numpy": np.__version__,
                         "scipy": scipy.__version__},
            "heldout_seed_status": "prespecified_distinct_from_phase6A_6103",
            "protocol": "all_algorithms_frozen_B3_G6_no_weight_updates",
            "reward_protocol": "v1.2_last_explicit_answer_box_or_label_or_bare",
            "format_protocol": "v1.2_strict_boxed_only_separately_reported"}


def _cell_cp(cfg: Phase6BConfig, root: Path, seed: int, scenario: str):
    base = root / "cells" / cell_name(seed, scenario)
    manifest = locked(cfg)
    manifest.update({"seed": seed, "scenario": scenario})
    cp = Checkpoints(base, manifest)
    tasks = b_tasks(cfg.groups, seed, scenario)
    saved = cp.load("tasks", 0)
    if saved is None:
        cp.save("tasks", 0, {"tasks": tasks})
    elif saved["tasks"] != tasks:
        raise RuntimeError("Phase6B holdout task journal mismatch")
    return cp, tasks


def _case_collect(cfg, root, seed, scenario, *, max_new=None,
                  backend_factory=_backend, progress=None):
    cp, tasks = _cell_cp(cfg, root, seed, scenario)
    n = cp.contiguous_count("generations", cfg.groups)
    if n == cfg.groups or max_new == 0:
        return n, 0
    backend = backend_factory(cfg)
    info = backend.info()
    # All sealed heldout seeds/scenarios must use the SAME model checkpoint,
    # not merely the same mutable Hub revision name (e.g. "main").
    global_cp = Checkpoints(root, locked(cfg))
    global_info = global_cp.load("model_fingerprint", 0)
    if global_info is None:
        global_cp.save("model_fingerprint", 0, info)
    elif global_info != info:
        raise RuntimeError("model changed ACROSS independent holdout cells")
    saved_info = cp.load("backend_info", 0)
    if saved_info is None:
        cp.save("backend_info", 0, info)
    elif info != saved_info:
        raise RuntimeError("Qwen backend changed during Phase6B restart")
    limit = cfg.groups if max_new is None else min(cfg.groups, n+max_new)
    for j in range(n, limit):
        public = {k: tasks[j][k] for k in ("id", "level", "prompt")}
        sample = backend.generate(public, group_seed(seed, j), cfg.g,
                                  cfg.max_new_tokens)
        _check_generation(sample, cfg)
        cp.save("generations", j, sample)
        if progress:
            progress(cell_name(seed,scenario), "generated", j+1, cfg.groups)
    return limit, limit-n


def _case_evaluate(cfg, root, seed, scenario, *, max_new=None, progress=None):
    cp, tasks = _cell_cp(cfg, root, seed, scenario)
    if cp.contiguous_count("generations", cfg.groups) != cfg.groups:
        return 0, False
    # The retrospective ledger is separate from the learner. This cheap
    # verifier computes ALL answers only for exact conditional evaluation.
    count = cp.contiguous_count("shadow_oracle", cfg.groups)
    for j in range(count, cfg.groups):
        sample = cp.load("generations", j)
        scored=[score_answer(tasks[j],c) for c in sample["completions"]]
        cp.save("shadow_oracle", j, {"full_rewards": [x["reward"] for x in scored],
            "full_parseable": [x["parseable"] for x in scored],
            "full_format_compliant": [x["format_compliant"] for x in scored],
            "full_strict_format_correct": [x["strict_format_correct"] for x in scored],
            "generator_sha256": digest(sample)})
    acquired = 0
    # The original 6A decision routine expects a per-run `master_seed`.
    # Here every heldout seed is its own independent run; neither reuse
    # Phase6A's seed nor accidentally share sampled subsets across cells.
    seed_cfg = SimpleNamespace(**asdict(cfg), master_seed=seed)
    for method in METHODS:
        n = cp.contiguous_count(f"acq_{method}", cfg.groups)
        agent = _restore_agent(cp, method, seed_cfg, n)
        for j in range(n, cfg.groups):
            if max_new is not None and acquired >= max_new:
                return acquired, False
            sample = cp.load("generations", j)
            oracle = cp.load("shadow_oracle", j)
            if oracle["generator_sha256"] != digest(sample):
                raise RuntimeError("holdout oracle/generator join corrupted")
            row = _record_one(agent, method, j, seed_cfg, sample, oracle, tasks[j])
            cp.save(f"acq_{method}", j, row)
            acquired += 1
            if progress and (j+1) % 10 == 0:
                progress(cell_name(seed,scenario), method, j+1, cfg.groups)
    return acquired, True


def run(cfg: Phase6BConfig, root: str | Path, *, stage: str = "all",
        max_new_groups: int | None = None, max_new_decisions: int | None = None,
        backend_factory: Callable = _backend, progress=None) -> dict:
    if stage not in ("all", "collect", "evaluate", "summary", "audit"):
        raise ValueError("invalid stage")
    if max_new_groups is not None and max_new_groups < 0:
        raise ValueError("negative generation limit")
    if max_new_decisions is not None and max_new_decisions < 0:
        raise ValueError("negative acquisition limit")
    root = Path(root)
    with run_lock(root):
        Checkpoints(root, locked(cfg))
        remaining_g, remaining_d = max_new_groups, max_new_decisions
        counts = {}
        if stage in ("all", "collect", "evaluate"):
            for scenario in cfg.scenarios:
                for seed in cfg.seeds:
                    key = cell_name(seed, scenario)
                    g, newly = (cfg.groups, 0)
                    if stage in ("all", "collect"):
                        g, newly = _case_collect(cfg, root, seed, scenario,
                            max_new=remaining_g, backend_factory=backend_factory,
                            progress=progress)
                        if remaining_g is not None:
                            remaining_g -= newly
                    d, complete = (0, False)
                    if stage in ("all", "evaluate"):
                        d, complete = _case_evaluate(cfg, root, seed, scenario,
                            max_new=remaining_d, progress=progress)
                        if remaining_d is not None:
                            remaining_d -= d
                    counts[key] = {"generated":g, "new_generations":newly,
                                   "new_decisions":d, "evaluated":complete}
        if stage in ("all", "summary", "audit"):
            result = summarize(cfg, root)
            if stage in ("all", "audit") and result["complete"]:
                result["audit"] = audit(cfg, root)
            return result
        return {"phase":"6B", "progress":counts}


def _records(cfg, root):
    for scenario in cfg.scenarios:
        for seed in cfg.seeds:
            cp, _ = _cell_cp(cfg, root, seed, scenario)
            n = {method:cp.contiguous_count(f"acq_{method}",cfg.groups)
                 for method in METHODS}
            yield scenario,seed,cp,n


def summarize(cfg: Phase6BConfig, root: str | Path) -> dict:
    root=Path(root)
    progress={}
    rows=[]
    generation_quality={}
    gains={method:{} for method in METHODS if method!="uniform"}
    complete=True
    for scenario,seed,cp,count in _records(cfg,root):
        key=cell_name(seed,scenario)
        progress[key]=count
        complete &= all(v==cfg.groups for v in count.values())
        if not all(v==cfg.groups for v in count.values()):
            continue
        quality_counts={"reward_positive":0,"parseable":0,
                        "format_compliant":0,"strict_format_correct":0}
        for i in range(cfg.groups):
            gold=cp.load("shadow_oracle",i)
            for label,field in (("reward_positive","full_rewards"),
                                ("parseable","full_parseable"),
                                ("format_compliant","full_format_compliant"),
                                ("strict_format_correct","full_strict_format_correct")):
                quality_counts[label]+=sum(gold[field])
        total=cfg.groups*cfg.g
        generation_quality[key]={
            "sampled_completions":total,
            **{f"{label}_fraction":float(n/total) for label,n in quality_counts.items()}}
        for i in range(cfg.groups):
            ref=cp.load("acq_uniform",i)["linear_design_risk_exact"]
            for method in METHODS:
                record=cp.load(f"acq_{method}",i)
                rows.append({"scenario":scenario,"seed":seed,"group":i,
                    "level":record["level"],"policy":method,
                    "linear_design_risk_exact":record["linear_design_risk_exact"],
                    "normalized_design_mse_exact":record["normalized_design_mse_exact"],
                    "normalized_mse_realized":record["normalized_mse_realized"],
                    "logical_paid_queries":record["logical_paid_queries"]})
                if method!="uniform":
                    gains[method].setdefault(seed,[]).append(
                        ref-record["linear_design_risk_exact"])
    result={"phase":"6B","complete":bool(complete),"progress":progress,
            "config":asdict(cfg),"rows_available":len(rows),
            "generation_quality_by_cell":generation_quality,
            "evaluation_protocol":"v1.2_last_explicit_answer_box_or_label_or_bare",
            "strict_format_definition":"whole response exactly a boxed integer (whitespace allowed)",
            "statistical_status":"descriptive heldout seed-cluster t intervals; no population guarantee",
            "full_shadow_oracle_is_free":"no actual scorer cost savings"}
    if generation_quality:
        total=sum(v["sampled_completions"] for v in generation_quality.values())
        result["generation_quality_overall"]={
            "sampled_completions":total,
            **{f"{field}_fraction":float(sum(
                cell[f"{field}_fraction"]*cell["sampled_completions"]
                for cell in generation_quality.values())/total)
               for field in ("reward_positive","parseable", "format_compliant",
                             "strict_format_correct")}}
    if rows:
        file=root/"phase6b_group_policy_metrics.csv"
        with file.open("w",encoding="utf-8",newline="") as stream:
            w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    if complete:
        result["paired_vs_uniform"]={}
        for method,by_seed in gains.items():
            means=np.asarray([np.mean(by_seed[s]) for s in cfg.seeds])
            m=float(means.mean())
            half=(float(student_t.ppf(.975,len(means)-1)*means.std(ddof=1)/
                        np.sqrt(len(means))) if len(means)>1 else None)
            result["paired_vs_uniform"][method]={"mean_gain":m,
                  "seed_cluster_t95":None if half is None else [m-half,m+half],
                  "positive_seed_fraction":float(np.mean(means>0)),
                  "per_seed_mean_gain":dict(zip(map(str,cfg.seeds),means.tolist()))}
        result["logical_reward_queries_all_policies"]=(
            len(cfg.seeds)*len(cfg.scenarios)*cfg.groups*cfg.b*len(METHODS))
    atomic_json(root/"phase6b_summary.json",result)
    return result


def audit(cfg: Phase6BConfig, root: str | Path) -> dict:
    """Independent replay of decisions using observed-only online histories."""
    root=Path(root)
    violations=[]; checked=0
    for scenario,seed,cp,counts in _records(cfg,root):
        if not all(v==cfg.groups for v in counts.values()):
            raise RuntimeError("audit requires complete 6B cases")
        tasks=b_tasks(cfg.groups,seed,scenario)
        for method in METHODS:
            agent=OnlineAcquirer(method,_policy_config(cfg))
            for i in range(cfg.groups):
                try:
                    rec=cp.load(f"acq_{method}",i)
                    gen=cp.load("generations",i)
                    gold=cp.load("shadow_oracle",i)
                    if rec["generator_sha256"]!=digest(gen) or rec["oracle_sha256"]!=digest(gold):
                        raise AssertionError("record binds wrong oracle/generation")
                    rescored=[score_answer(tasks[i],txt)
                              for txt in gen["completions"]]
                    for field,property_name in (("full_rewards","reward"),
                            ("full_parseable","parseable"),
                            ("full_format_compliant","format_compliant"),
                            ("full_strict_format_correct","strict_format_correct")):
                        if gold[field]!=[x[property_name] for x in rescored]:
                            raise AssertionError("reward/format scorer replay mismatch")
                    design,meta=agent.propose(np.asarray(gen["score_features"],float))
                    saved=ExactBDesign(np.asarray(rec["design"]["subsets"]),
                                      np.asarray(rec["design"]["probs"]),"audit")
                    actual={tuple(z):float(p) for z,p in zip(saved.subsets,saved.probs)}
                    expected={tuple(z):float(p) for z,p in zip(design.subsets,design.probs)}
                    if set(actual)!=set(expected) or any(abs(actual[z]-expected[z])>2e-7 for z in actual):
                        raise AssertionError("candidate design mismatch")
                    selected=np.asarray(rec["selected"],bool)
                    draw=design.draw(np.random.default_rng(decision_seed(seed,method,i)))
                    if not np.array_equal(draw,selected) or int(selected.sum())!=cfg.b:
                        raise AssertionError("RNG/budget mismatch")
                    rewards=np.asarray(gold["full_rewards"],float)
                    if not np.array_equal(np.asarray(rec["paid_rewards"]),rewards[selected]):
                        raise AssertionError("purchased rewards inconsistent")
                    scores=np.asarray(gen["score_features"],float)
                    m=gradient_map(scores); pi=saved.marginals
                    pairs=saved.pair_inclusions
                    risk=float(max(0.,rewards@((pairs/np.outer(pi,pi)-1)*(m.T@m))@rewards))
                    if not np.isclose(risk,rec["linear_design_risk_exact"],atol=1e-8):
                        raise AssertionError("independent risk mismatch")
                    seen=np.full(cfg.g,np.nan);seen[selected]=rewards[selected]
                    agent.observe(seen,selected,saved)
                    checked+=1
                except Exception as exc:
                    violations.append(f"{scenario}/{seed}/{method}/{i}: {exc}")
                    break
    result={"pass":not violations,"checked_decisions":checked,
            "expected":len(cfg.scenarios)*len(cfg.seeds)*len(METHODS)*cfg.groups,
            "violations":violations,"scope":"internal replay; not external scientific peer audit"}
    atomic_json(root/"phase6b_audit.json",result)
    if violations:
        raise AssertionError("Phase 6B audit failed: "+violations[0])
    return result
