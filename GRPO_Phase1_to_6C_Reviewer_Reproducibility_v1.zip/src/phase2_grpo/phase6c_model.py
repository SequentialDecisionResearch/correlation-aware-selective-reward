"""Real 0.5B Qwen + PEFT LoRA policy optimizer (lazy GPU dependencies).

All arms use the SAME token-level on-policy surrogate implementation.
Only the availability of reward labels and the resulting advantages change.
With update_epochs=1, PPO ratios start at exactly one; the gradient is the
unclipped LOO policy-gradient estimator. For multiple epochs, token-level
PPO clipping is applied and exact design-unbiasedness no longer follows.
"""

import hashlib
import json
from pathlib import Path

import numpy as np

from .phase6a_model import SKETCH_DIM, SKETCH_SEED, token_signs, group_seed
from .phase6a_tasks import SYSTEM_PROMPT, score_answer


class RealLoRAPolicy:
    def __init__(self, cfg):
        try:
            import torch
            import transformers
            import peft
            from transformers import AutoTokenizer, AutoModelForCausalLM
            from peft import LoraConfig, get_peft_model, TaskType
        except ImportError as exc:
            raise RuntimeError("Phase 6C requires torch, transformers, peft") from exc
        if cfg.device.startswith("cuda") and not torch.cuda.is_available():
            raise RuntimeError("CUDA required; run check_phase6a_env.py first")
        self.torch=torch
        self.peft=peft
        self.device=torch.device(cfg.device)
        torch.manual_seed(cfg.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(cfg.seed)
        self.tokenizer=AutoTokenizer.from_pretrained(
            cfg.model,revision=cfg.model_revision,
            local_files_only=cfg.local_files_only,trust_remote_code=False)
        dtype=(torch.bfloat16 if self.device.type=="cuda" and
               torch.cuda.is_bf16_supported() else
               torch.float16 if self.device.type=="cuda" else torch.float32)
        base=AutoModelForCausalLM.from_pretrained(
            cfg.model,revision=cfg.model_revision,
            local_files_only=cfg.local_files_only,
            trust_remote_code=False,torch_dtype=dtype)
        for param in base.parameters():
            param.requires_grad_(False)
        base.config.use_cache=False
        lora=LoraConfig(r=cfg.lora_rank,lora_alpha=cfg.lora_alpha,
                        lora_dropout=0.0,bias="none",task_type=TaskType.CAUSAL_LM,
                        target_modules=["q_proj","v_proj"])
        self.model=get_peft_model(base,lora).to(self.device)
        self.optimizer=torch.optim.AdamW(
            [p for p in self.model.parameters() if p.requires_grad],
            lr=cfg.learning_rate,weight_decay=0.)
        trainable=sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        if trainable<=0:
            raise RuntimeError("PEFT did not create trainable LoRA parameters")
        vocab=int(self.model.config.vocab_size)
        self.signs=torch.from_numpy(token_signs(vocab)).to(self.device)
        self.cfg=cfg
        self.info={"backend_type":"hf_lora", "trainable_lora_parameters":trainable,
                   "base_model":cfg.model,"requested_revision":cfg.model_revision,
                   "resolved_commit":getattr(base.config,"_commit_hash",None),
                   "tokenizer_commit":getattr(self.tokenizer,"_commit_hash",None),
                   "torch":torch.__version__,"transformers":transformers.__version__,
                   "peft":peft.__version__,"dtype":str(dtype),
                   "device":str(self.device),"sketch_dim":SKETCH_DIM,
                   "sketch_seed":SKETCH_SEED,
                   "config_sha256":hashlib.sha256(json.dumps(
                       base.config.to_dict(),sort_keys=True,default=str
                   ).encode()).hexdigest()}
        if self.tokenizer.eos_token_id is None:
            raise RuntimeError("Qwen EOS required")
        local=Path(cfg.model)
        if local.is_dir():
            files=sorted(list(local.glob("*.safetensors"))+
                         list(local.glob("pytorch_model*.bin")))
            if not files:
                raise RuntimeError("local Qwen model directory missing weights")
            hashes={}
            for file in files:
                h=hashlib.sha256()
                with file.open("rb") as stream:
                    for block in iter(lambda:stream.read(4*1024*1024),b""):
                        h.update(block)
                hashes[file.name]=h.hexdigest()
            self.info["local_weights_sha256"]=hashes
        elif self.info["resolved_commit"] is None:
            raise RuntimeError("unresolved Qwen model commit")

    def _prompt(self, prompt: str):
        message=[{"role":"system","content":SYSTEM_PROMPT},
                 {"role":"user","content":prompt}]
        return self.tokenizer.apply_chat_template(
            message,tokenize=True,add_generation_prompt=True,
            return_tensors="pt").to(self.device)

    def _token_logprobs(self, prompt_ids, continuation, *, requires_grad):
        torch=self.torch
        full=torch.cat((prompt_ids[0],continuation)).unsqueeze(0)
        p=int(prompt_ids.shape[1])
        logits=self.model(input_ids=full[:,:-1],use_cache=False).logits[0,p-1:].float()
        if logits.shape[0]!=len(continuation):
            raise RuntimeError("token-logprob alignment failure")
        selected=logits.log_softmax(dim=-1).gather(
            1,continuation.unsqueeze(1)).squeeze(1)
        return logits,selected

    def generate(self, task: dict, step: int):
        if "answer" in task:
            raise AssertionError("training generator must not be given answer key")
        torch=self.torch
        prompt=self._prompt(task["prompt"])
        self.model.eval()
        seed=group_seed(self.cfg.seed,step)
        torch.manual_seed(seed)
        if self.device.type=="cuda":
            torch.cuda.manual_seed_all(seed)
        with torch.inference_mode():
            seq=self.model.generate(input_ids=prompt,
                attention_mask=torch.ones_like(prompt),do_sample=True,
                num_beams=1,num_return_sequences=self.cfg.g,
                temperature=1.,top_p=1.,top_k=0,repetition_penalty=1.,
                max_new_tokens=self.cfg.max_new_tokens,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id)
        samples=[];features=[]
        for full in seq:
            y=full[prompt.shape[1]:]
            ends=(y==self.tokenizer.eos_token_id).nonzero(as_tuple=False)
            if ends.numel():
                y=y[:int(ends[0].item())+1]
            if len(y)==0:
                raise RuntimeError("empty generated completion")
            with torch.inference_mode():
                logits,old=self._token_logprobs(prompt,y,requires_grad=False)
                projection=self.signs[y]-(logits.softmax(-1)@self.signs)
                feat=(projection.sum(0)/self.cfg.max_new_tokens).cpu().tolist()
            text=self.tokenizer.decode(y,skip_special_tokens=True)
            samples.append({"text":text,"token_ids":y.cpu().tolist(),
                            "old_logp":old.cpu().tolist()})
            features.append(feat)
        self.model.train()
        return {"samples":samples,"score_features":np.asarray(features).T.tolist(),
                "backend":"hf_lora_current_policy"}

    def update(self, task: dict, samples: list, advantages: np.ndarray) -> dict:
        """Actual LoRA parameter updates; never uses unpurchased reward labels."""
        torch=self.torch
        if len(samples)!=self.cfg.g or len(advantages)!=self.cfg.g:
            raise ValueError("group length mismatch")
        prompt=self._prompt(task["prompt"])
        total_losses=[]; grad_norms=[]
        # Eval mode is deliberate: policy-gradient autograd works in eval
        # mode, and disabling stochastic dropout keeps the old/current
        # on-policy likelihood ratio at one on the first update epoch.
        self.model.eval()
        trainable=[p for p in self.model.parameters() if p.requires_grad]
        before=[p.detach().clone() for p in trainable]
        for _ in range(self.cfg.update_epochs):
            self.optimizer.zero_grad(set_to_none=True)
            loss_sum=0.
            for i,sample in enumerate(samples):
                y=torch.tensor(sample["token_ids"],dtype=torch.long,device=self.device)
                _,logp=self._token_logprobs(prompt,y,requires_grad=True)
                old=torch.tensor(sample["old_logp"],dtype=torch.float32,device=self.device)
                if len(old)!=len(logp):
                    raise RuntimeError("generated old/current logprob mismatch")
                ratio=torch.exp(torch.clamp(logp-old,-15.,15.))
                coefficient=float(advantages[i])
                s1=ratio*coefficient
                s2=ratio.clamp(1-self.cfg.clip_epsilon,1+self.cfg.clip_epsilon)*coefficient
                # Fixed token denominator: identical across arms and groups.
                loss=-torch.minimum(s1,s2).sum()/(self.cfg.g*self.cfg.max_new_tokens)
                loss.backward()
                loss_sum+=float(loss.detach().cpu())
            norm=torch.nn.utils.clip_grad_norm_(
                [p for p in self.model.parameters() if p.requires_grad],1.)
            if not bool(torch.isfinite(norm)):
                raise RuntimeError("nonfinite training gradient: no checkpoint written")
            self.optimizer.step()
            total_losses.append(loss_sum)
            grad_norms.append(float(norm.detach().cpu()))
        self.model.eval()
        delta_sq=sum(float((p.detach().float()-initial.float()).square().sum().cpu())
                     for p,initial in zip(trainable,before))
        return {"loss_per_epoch":total_losses,"grad_norm_per_epoch":grad_norms,
                "adapter_delta_l2":delta_sq**0.5,
                "genuine_lora_optimizer_steps":self.cfg.update_epochs}

    def evaluate(self, heldout: list[dict]) -> dict:
        torch=self.torch
        correct=0;parseable=0;format_compliant=0;strict_format_correct=0
        by_level={}
        self.model.eval()
        for task in heldout:
            prompt=self._prompt(task["prompt"])
            with torch.inference_mode():
                # With Qwen, pad_token_id == eos_token_id. Transformers
                # cannot safely infer the mask, so explicitly supply it
                # during HELDOUT evaluation, just as in group generation.
                sequence=self.model.generate(input_ids=prompt,
                    attention_mask=torch.ones_like(prompt),do_sample=False,
                    num_beams=1,max_new_tokens=self.cfg.max_new_tokens,
                    pad_token_id=self.tokenizer.eos_token_id,
                    eos_token_id=self.tokenizer.eos_token_id)
            response=self.tokenizer.decode(sequence[0,prompt.shape[1]:],
                                          skip_special_tokens=True)
            scored=score_answer(task,response)
            correct+=int(scored["reward"])
            parseable+=int(scored["parseable"])
            format_compliant+=int(scored["format_compliant"])
            strict_format_correct+=int(scored["strict_format_correct"])
            level=task["level"]
            if level not in by_level:
                by_level[level]={"correct":0,"count":0}
            by_level[level]["count"]+=1
            by_level[level]["correct"]+=int(scored["reward"])
        self.model.train()
        return {"heldout_count":len(heldout),"correct":correct,
                "accuracy":float(correct/len(heldout)),
                "parseable_fraction":float(parseable/len(heldout)),
                "format_compliance_fraction":float(format_compliant/len(heldout)),
                "strict_format_correct_fraction":float(strict_format_correct/len(heldout)),
                "accuracy_by_level":{level:(float(v["correct"]/v["count"])
                   if v["count"] else None) for level,v in by_level.items()},
                "count_by_level":{level:v["count"] for level,v in by_level.items()}}

    def checkpoint_payload(self, step: int) -> dict:
        torch=self.torch
        from peft import get_peft_model_state_dict
        return {"completed_steps":step,
                "adapter":{k:v.detach().cpu() for k,v in
                           get_peft_model_state_dict(self.model).items()},
                "optimizer":self.optimizer.state_dict(),
                "torch_rng":torch.get_rng_state(),
                "cuda_rng":torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}

    def restore(self, state: dict, completed: int) -> None:
        torch=self.torch
        from peft import get_peft_model_state_dict, set_peft_model_state_dict
        if state.get("completed_steps")!=completed:
            raise RuntimeError("LoRA training checkpoint step mismatch")
        set_peft_model_state_dict(self.model,state["adapter"])
        loaded=get_peft_model_state_dict(self.model)
        if set(loaded)!=set(state["adapter"]) or any(
                not torch.equal(loaded[k].detach().cpu(),v)
                for k,v in state["adapter"].items()):
            raise RuntimeError("LoRA adapter restoration verification failed")
        self.optimizer.load_state_dict(state["optimizer"])
        # Move restored moment tensors to GPU. Preserve AdamW's scalar `step`
        # device: for default capturable=False PyTorch may require CPU step
        # tensors, and load_state_dict already handles that convention.
        for moment in self.optimizer.state.values():
            for key,value in moment.items():
                if key!="step" and torch.is_tensor(value):
                    moment[key]=value.to(self.device)
        torch.set_rng_state(state["torch_rng"])
        if self.device.type=="cuda":
            torch.cuda.set_rng_state_all(state["cuda_rng"])
