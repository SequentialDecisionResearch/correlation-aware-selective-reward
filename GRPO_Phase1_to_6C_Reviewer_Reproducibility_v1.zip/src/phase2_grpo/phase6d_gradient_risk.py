"""Exact finite-design risks in sketch and REAL LoRA-gradient Gram spaces.

For each completion i, h_i = grad_theta sum_t log pi_theta(y_it)/T.
For six completions the full-feedback LOO gradient is M @ r, where
M = (H - column_mean(H)) / (G-1). Reward acquisition uses the same
Horvitz-Thompson linear LOO functional at pi_i = B/G.

All computations below use only G-by-G matrices once the expensive real
per-completion model gradients have been obtained. No fictitious projection
from token-space sketches into parameter-space gradients is asserted.
"""

from __future__ import annotations

import math

import numpy as np

from .design import ExactBDesign
from .geometry import gradient_map


def centered_loo_gram(raw_gram: np.ndarray) -> np.ndarray:
    raw=np.asarray(raw_gram,np.float64)
    if (raw.ndim!=2 or raw.shape[0]<2 or raw.shape[0]!=raw.shape[1] or
            not np.all(np.isfinite(raw)) or
            not np.allclose(raw,raw.T,atol=1e-7,rtol=1e-6)):
        raise ValueError("invalid completion-gradient Gram")
    g=len(raw)
    proj=np.eye(g)-np.ones((g,g))/g
    result=(proj@raw@proj)/((g-1)**2)
    return (result+result.T)/2


def risk_exact(loo_gram: np.ndarray, rewards: np.ndarray,
               design: ExactBDesign) -> dict:
    """Compare covariance formula to EXACT enumeration of all 20 subsets."""
    gram=np.asarray(loo_gram,np.float64)
    r=np.asarray(rewards,np.float64)
    if (gram.shape!=(design.G,design.G) or r.shape!=(design.G,) or
            not np.all(np.isfinite(gram)) or not np.all(np.isfinite(r))):
        raise ValueError("risk dimensionality or finiteness failure")
    pi=design.marginals
    if np.min(pi)<=0:
        raise ValueError("design must include every item with positive probability")
    p2=design.pair_inclusions
    correction=p2/np.outer(pi,pi)-1
    risk_quadratic=float(r@((correction*gram)@r))
    errors=(design.subsets/pi[None,:]-1)*r[None,:]
    risk_enum=float(np.sum(design.probs*np.einsum(
        "si,ij,sj->s",errors,gram,errors,optimize=True)))
    if not math.isclose(risk_quadratic,risk_enum,rel_tol=5e-5,
                        abs_tol=2e-11*max(1.,abs(risk_enum))):
        raise RuntimeError("analytical vs enumerated HT risk mismatch")
    bias=(design.probs[:,None]*errors).sum(axis=0)
    gradient_bias_sq=float(bias@gram@bias)
    if gradient_bias_sq>1e-12*max(1.,risk_enum):
        raise RuntimeError("HT gradient fails conditional unbiasedness")
    full_norm_sq=float(r@gram@r)
    return {"risk":max(0.,risk_enum),"risk_quadratic":risk_quadratic,
            "risk_enumerated":risk_enum,"full_gradient_norm_sq":max(0.,full_norm_sq),
            "conditional_gradient_bias_norm":math.sqrt(max(0.,gradient_bias_sq))}


def gram_alignment(true_loo_gram: np.ndarray,
                   sketch_loo_gram: np.ndarray) -> dict:
    a=np.asarray(true_loo_gram,np.float64)
    b=np.asarray(sketch_loo_gram,np.float64)
    if a.shape!=b.shape or not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError("incompatible gradient Gram spaces")
    aa=float(np.sum(a*a));bb=float(np.sum(b*b))
    ab=float(np.sum(a*b))
    cka=ab/math.sqrt(aa*bb) if aa>0 and bb>0 else None
    return {"centered_gram_alignment":
                float(np.clip(cka,0,1)) if cka is not None else None,
            "true_loo_gram_frobenius":math.sqrt(max(0.,aa)),
            "sketch_loo_gram_frobenius":math.sqrt(max(0.,bb))}


def evaluate_fixed_designs(real_completion_gram: np.ndarray,
                           score_features: np.ndarray,rewards: np.ndarray,
                           uniform: ExactBDesign, adaptive: ExactBDesign) -> dict:
    """Both designs face EXACT same completions, gold, and true gradients."""
    proxy=gradient_map(score_features)
    sketch_gram=proxy.T@proxy
    real_gram=centered_loo_gram(real_completion_gram)
    if (uniform.G!=6 or adaptive.G!=6 or uniform.B!=3 or adaptive.B!=3 or
            np.max(np.abs(uniform.marginals-.5))>1e-8 or
            np.max(np.abs(adaptive.marginals-.5))>1e-8):
        raise ValueError("Phase6D must compare G=6 B=3 with identical 0.5 marginals")
    risks={}
    for name,gram in (("real_lora",real_gram),("phase6b_sketch",sketch_gram)):
        ur=risk_exact(gram,rewards,uniform)
        ar=risk_exact(gram,rewards,adaptive)
        gain=ur["risk"]-ar["risk"]
        risks[name]={"uniform":ur,"joint_ewma":ar,
                     "gain_uniform_minus_joint":gain,
                     "relative_gain":gain/ur["risk"] if ur["risk"]>1e-18 else None,
                     "uniform_risk_zero":ur["risk"]<=1e-18}
    true_gain=risks["real_lora"]["gain_uniform_minus_joint"]
    sketch_gain=risks["phase6b_sketch"]["gain_uniform_minus_joint"]
    return {"risks":risks,"alignment":gram_alignment(real_gram,sketch_gram),
            "risk_gain_sign_agrees":bool((true_gain>0 and sketch_gain>0) or
                                          (true_gain<0 and sketch_gain<0)),
            "real_loo_gram":real_gram.tolist(),
            "sketch_loo_gram":sketch_gram.tolist()}
