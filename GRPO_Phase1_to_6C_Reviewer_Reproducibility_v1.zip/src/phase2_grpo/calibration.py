"""IPW estimation of a *pooled* residual second-moment matrix.

This estimates E[e e^T] across exchangeable groups, not V(F0) for each
individual prompt. General conditional calibration is deliberately open.
"""

from dataclasses import dataclass

import numpy as np


@dataclass
class MomentFit:
    raw: np.ndarray
    psd: np.ndarray
    pair_supported: np.ndarray
    pair_effective_n: np.ndarray
    observations: int
    projection_fro_error: float


def nearest_psd(a: np.ndarray, eigen_floor: float = 0.0) -> np.ndarray:
    a = np.asarray(a, dtype=float)
    eigval, eigvec = np.linalg.eigh((a + a.T) / 2)
    return (eigvec * np.maximum(eigval, eigen_floor)) @ eigvec.T


class PooledMomentCalibrator:
    """Design-based matrix estimation with first/second inclusion weighting.

    `observed_residuals` is N x G with NaN for unpurchased entries. Group-level
    inclusion probabilities may change across records and are recorded in
    `pi` and `pi2`. No imputation of unseen residuals is performed.
    """

    def fit(self, observed_residuals: np.ndarray, selected: np.ndarray,
            pi: np.ndarray, pi2: np.ndarray,
            require_all_pairs: bool = False) -> MomentFit:
        r = np.asarray(observed_residuals, dtype=float)
        z = np.asarray(selected, dtype=bool)
        pi = np.asarray(pi, dtype=float)
        pi2 = np.asarray(pi2, dtype=float)
        if r.ndim != 2 or z.shape != r.shape or pi.shape != r.shape:
            raise ValueError("residuals, masks, and inclusion probabilities must be N x G")
        n, g = r.shape
        if n < 2 or pi2.shape != (n, g, g):
            raise ValueError("pair inclusion data must be N x G x G")
        if np.any(pi <= 0) or np.any(pi > 1) or not np.all(np.isfinite(pi)):
            raise ValueError("first order positivity missing")
        if np.any(pi2 < 0) or not np.all(np.isfinite(pi2)):
            raise ValueError("invalid pair inclusion probabilities")
        if not np.all(np.isfinite(r[z])):
            raise ValueError("every queried residual must be finite")
        # Never use unqueried entries; they may deliberately contain NaN/inf.
        e = np.zeros_like(r)
        e[z] = r[z]
        raw = np.zeros((g, g))
        ess = np.zeros((g, g))
        support = np.zeros((g, g), dtype=bool)
        for i in range(g):
            for j in range(g):
                p = pi[:, i] if i == j else pi2[:, i, j]
                jointly = z[:, i] & z[:, j]
                if np.any(jointly & (p <= 0)):
                    raise ValueError("observed pair with zero declared inclusion probability")
                eligible = p > 0
                support[i, j] = bool(np.all(eligible))
                if not support[i, j]:
                    if require_all_pairs:
                        raise ValueError(f"pair ({i},{j}) lacks full support")
                    raw[i, j] = 0.0  # numerical placeholder, not an identified estimate
                    continue
                w = jointly.astype(float) / p
                raw[i, j] = float(np.dot(w, e[:, i] * e[:, j]) / n)
                ess[i, j] = float(w.sum() ** 2 / (np.dot(w, w) + 1e-20))
        raw = (raw + raw.T) / 2
        positive = nearest_psd(raw, 1e-10)
        return MomentFit(raw=raw, psd=positive, pair_supported=support,
                         pair_effective_n=ess, observations=n,
                         projection_fro_error=float(np.linalg.norm(raw-positive, "fro")))

