"""Pre-specified independent Phase-4 evaluation with disjoint seeds/worlds.

The calibration sample is restricted to stationary Phase-3 profiles and new
calibration seeds; the holdout uses disjoint seeds and entirely new covariance
transition functions. Once evaluated, no post-hoc retuning is permitted.
"""

import csv
from dataclasses import asdict, replace
import hashlib
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.stats import t as student_t

from .guarded_online import (GuardedOnlineAcquirer, GuardSpec,
                             maximum_patience_score)
from .holdout_world import (CALIBRATION_SEEDS, HOLDOUT_SCENARIOS,
                            HOLDOUT_SEEDS, WorldState, draw_residual,world_state)
from .online_study import OnlineAcquirer, OnlineConfig, POLICIES
from .oracle import CountingOracle
from .optimization import optimize_coupling
from .geometry import gradient_map
from .phase2_study import covariance_profile
from .risk import acquisition_risk, augmented_rewards


HOLDOUT_POLICIES=POLICIES+("guarded_partial",)
CAL_PROFILES=("signed_factor","common_strong","negative_equicorr","two_blocks")
LOCKED_SPEC=GuardSpec(drift_threshold=99.,patience=3,max_rollback=.25,
                      uncertainty_rollback=.10,alert_rollback=.05,
                      guard_window=24,clip_matrix_norm=18.,effect_clip=50.,
                      empirical_z=2.)
CALIBRATION_TAIL_RISK=.10


def calibration_experiment(config: OnlineConfig,
                           seeds: tuple[int,...] = CALIBRATION_SEEDS) -> dict:
    """Calibration uses independent, stationary only, synthetic pilot worlds.

    Return one threshold pre-frozen for ALL holdout scenarios. Empirical
    family-wise calibration applies only to its sampled stationary pilot
    distribution, and is not a valid confidence-sequence threshold.
    """
    results=[]
    for run,seed in enumerate(seeds):
        profile=CAL_PROFILES[run%len(CAL_PROFILES)]
        v=covariance_profile(config.g,profile)
        streams=np.random.SeedSequence([20261102,seed]).spawn(3)
        sr,rr,pr=(np.random.default_rng(x) for x in streams)
        agent=GuardedOnlineAcquirer(config,LOCKED_SPEC)
        distribution="student_t5" if run%4==3 else "normal"
        for t in range(config.horizon):
            scores=sr.normal(size=(3,config.g))
            state=WorldState(v,distribution,False,None)
            e=draw_residual(rr,state)
            design,_=agent.propose(scores)
            selected=design.draw(pr).astype(bool)
            obs=np.full(config.g,np.nan)
            obs[selected]=e[selected]
            agent.observe(obs,selected,design)
        stat=maximum_patience_score(agent.monitor.score_history,
                                     LOCKED_SPEC.patience,
                                     initial_step=config.warmup)
        results.append({"seed":seed,"profile":profile,
                        "distribution":distribution,"max_patience_stat":stat})
    vals=np.array([r["max_patience_stat"] for r in results])
    # Standard finite-sample empirical quantile; cannot claim an exact
    # per-trajectory false-positive level on a different distribution.
    threshold=float(np.quantile(vals,1-CALIBRATION_TAIL_RISK))
    return {"calibration_only":True,"calibration_seeds":list(seeds),
            "disjoint_from_holdout":not bool(set(seeds)&set(HOLDOUT_SEEDS)),
            "sampled_null_profiles":list(CAL_PROFILES),
            "target_empirical_null_trajectory_alert_probability":CALIBRATION_TAIL_RISK,
            "monitor_patience":LOCKED_SPEC.patience,
            "threshold":threshold,"per_trajectory":results,
            "limitations":"empirical stationary-null quantile, not sequential level-alpha guarantee"}


def _one_holdout(seed: int, scenario: str, config: OnlineConfig,
                 guard_spec: GuardSpec) -> list[dict]:
    rng_seeds=np.random.SeedSequence([20261103,seed,
                        list(HOLDOUT_SCENARIOS).index(scenario)]).spawn(2+len(HOLDOUT_POLICIES))
    score_rng,reward_rng,*policy_rng=(np.random.default_rng(s) for s in rng_seeds)
    agents={name:OnlineAcquirer(name,config) for name in POLICIES}
    agents["guarded_partial"]=GuardedOnlineAcquirer(config,guard_spec)
    randoms=dict(zip(HOLDOUT_POLICIES,policy_rng))
    rows=[]
    for step in range(config.horizon):
        state=world_state(scenario,step,config.horizon,config.g)
        score=score_rng.normal(size=(3,config.g))
        hidden=draw_residual(reward_rng,state)
        m=gradient_map(score)
        oracle,_=optimize_coupling(score,state.moment,
                                  agents["uniform"].pi,config.b)
        r_oracle=acquisition_risk(score,state.moment,oracle)
        for name in HOLDOUT_POLICIES:
            agent=agents[name]
            design,meta=agent.propose(score)
            risk=acquisition_risk(score,state.moment,design)
            if risk+1e-7<r_oracle:
                raise AssertionError("oracle risk violated")
            z=design.draw(randoms[name]).astype(bool)
            oracle_calls=CountingOracle(hidden)
            bought=oracle_calls.reveal(np.flatnonzero(z))
            if oracle_calls.calls!=config.b:
                raise AssertionError("unequal or unmetered gold-query budget")
            visible=np.full(config.g,np.nan)
            visible[z]=bought
            ht=augmented_rewards(visible,np.zeros(config.g),z,design.marginals)
            realized=float(np.linalg.norm(m@(ht-hidden))**2)
            diagnostics=agent.observe(visible,z,design)
            rows.append({"seed":seed,"scenario":scenario,"step":step,
                         "phase":"later" if step>=config.horizon//2 else "early",
                         "true_onset":state.onset,"true_change":int(state.change_truth),
                         "distribution":state.distribution,"policy":name,
                         "decision":meta["decision"],
                         "true_risk":float(risk),"oracle_risk":float(r_oracle),
                         "realized_squared_error":realized,
                         "gold_queries":oracle_calls.calls,
                         "monitor_statistic":float(diagnostics["drift_score"]),
                         "drift_alert":int(diagnostics["alert"]),
                         "pair_ess":float(meta["pair_ess_before"]),
                         "rollback_fraction":float(meta.get("rollback_fraction",1.
                                             if "fallback" in meta["decision"] else 0.)),
                         "baseline_advantage_upper":float(meta.get("evidence_upper",float("nan"))),
                         "selected_subset":"".join(str(int(a)) for a in z),
                         "min_pair_propensity":float(design.pair_inclusions[
                             np.triu_indices(config.g,1)].min())})
    return rows


def _ci_by_seed(deltas: dict[int,list[float]]) -> dict:
    arr=np.array([np.mean(x) for _,x in sorted(deltas.items())])
    mean=float(arr.mean())
    half=(float(student_t.ppf(.975,len(arr)-1)*arr.std(ddof=1)/np.sqrt(len(arr)))
          if len(arr)>1 else float("nan"))
    return {"seed_count":len(arr),"mean_paired_gain":mean,
            "descriptive_t95":[mean-half,mean+half],
            "positive_seed_fraction":float(np.mean(arr>0))}


def summarize_holdout(rows: list[dict], config: OnlineConfig,
                      spec: GuardSpec,calibration: dict) -> dict:
    summary={"label":"Phase4_one_time_frozen_independent_holdout_no_llm",
             "new_worlds":list(HOLDOUT_SCENARIOS),"holdout_seeds":list(HOLDOUT_SEEDS),
             "methods":list(HOLDOUT_POLICIES),"rows":len(rows),
             "metered_synthetic_calls":sum(r["gold_queries"] for r in rows),
             "model_parameters_frozen_from_phase3":asdict(config),
             "guard_frozen_before_holdout":asdict(spec),
             "calibration_threshold":calibration["threshold"],
             "internally_locked_in_source_before_first_holdout_execution":True,
             "external_preregistration":False,
             "limitations":["no real LLM, reward-model or PPO/GRPO parameter updates",
               "synthetic risk uses oracle second moment for evaluation only",
               "empirical calibration is not a finite-sample false-alarm guarantee",
               "confidence intervals are descriptive even for independent holdout seeds"]}
    cells={}
    for scenario in HOLDOUT_SCENARIOS:
        for stage in ("early","later"):
            part=[r for r in rows if r["scenario"]==scenario and r["phase"]==stage]
            indexed={name:{(r["seed"],r["step"]):r["true_risk"]
                           for r in part if r["policy"]==name}
                     for name in HOLDOUT_POLICIES}
            for name in HOLDOUT_POLICIES:
                data=[r for r in part if r["policy"]==name]
                gains={}
                loss_vs_joint={}
                for r in data:
                    key=(r["seed"],r["step"])
                    gains.setdefault(r["seed"],[]).append(
                        indexed["uniform"][key]-r["true_risk"])
                    loss_vs_joint.setdefault(r["seed"],[]).append(
                        indexed["joint_ewma"][key]-r["true_risk"])
                cells[f"{scenario}|{stage}|{name}"]={
                    "mean_conditional_gradient_risk":float(np.mean([r["true_risk"] for r in data])),
                    "paired_gain_vs_uniform":_ci_by_seed(gains),
                    "paired_gain_vs_joint_ewma":_ci_by_seed(loss_vs_joint),
                    "mean_realized_squared_error":float(np.mean([
                        r["realized_squared_error"] for r in data])),
                    "mean_rollback_fraction":float(np.mean([
                        r["rollback_fraction"] for r in data]))}
    summary["strata"]=cells
    detector={}
    for scenario in HOLDOUT_SCENARIOS:
        per_seed=[]
        for seed in HOLDOUT_SEEDS:
            group=[r for r in rows if r["scenario"]==scenario and r["seed"]==seed
                   and r["policy"]=="guarded_partial"]
            onset=group[0]["true_onset"]
            alarms=[r["step"] for r in group if r["drift_alert"]]
            prior=[x for x in alarms if onset is None or x<onset]
            after=[x for x in alarms if onset is not None and x>=onset]
            per_seed.append({"seed":seed,"alarms":alarms,
                             "pre_onset_false_alarms":prior,
                             "first_post_onset_delay":min(after)-onset if after else None})
        detector[scenario]={"per_seed":per_seed,
              "any_alarm_fraction":float(np.mean([bool(x["alarms"]) for x in per_seed])),
              "pre_onset_false_alarm_seed_fraction":float(np.mean([
                  bool(x["pre_onset_false_alarms"]) for x in per_seed])),
              "post_onset_detection_fraction":float(np.mean([
                  x["first_post_onset_delay"] is not None for x in per_seed]))}
    summary["guard_detector"]=detector
    return summary


def run_holdout(output: str|Path, *, quick:bool=False) -> dict:
    """Calibration is completed/frozen before visiting ANY holdout label."""
    if quick:
        cfg=OnlineConfig(horizon=80,warmup=12,window=9,cooldown=12,
                         seeds=(17,),scenarios=("stationary_signed",))
        calibration_seeds=CALIBRATION_SEEDS[:4]
        eval_seeds=HOLDOUT_SEEDS[:2]
        eval_scenarios=HOLDOUT_SCENARIOS[:2]
    else:
        cfg=OnlineConfig()  # exact frozen Phase-3 experiment parameters
        calibration_seeds=CALIBRATION_SEEDS
        eval_seeds=HOLDOUT_SEEDS
        eval_scenarios=HOLDOUT_SCENARIOS
    started=perf_counter()
    cal=calibration_experiment(cfg,calibration_seeds)
    spec=replace(LOCKED_SPEC,drift_threshold=cal["threshold"])
    calibration_seconds=perf_counter()-started
    # The method and detector threshold are now frozen. No holdout peek is
    # allowed to change either one; the summary records negative outcomes.
    rows=[]
    for scenario in eval_scenarios:
        for seed in eval_seeds:
            rows.extend(_one_holdout(seed,scenario,cfg,spec))
    # Summary helper consumes fixed full lists; quick uses the same labels
    # but is not independent confirmatory inference.
    # do not mutate the global sealed lists; pass a pure filtered view below
    if quick:
        summary=_quick_summary(rows,cfg,spec,cal,eval_seeds,eval_scenarios)
    else:
        summary=summarize_holdout(rows,cfg,spec,cal)
    summary["calibration_seconds"]=calibration_seconds
    summary["wall_seconds"]=perf_counter()-started
    summary["quick_smoke_only"]=quick
    files=("guarded_online.py","holdout_world.py","holdout_study.py")
    summary["source_sha256_at_execution"]={
        f:hashlib.sha256((Path(__file__).parent/f).read_bytes()).hexdigest()
        for f in files}
    path=Path(output)
    path.mkdir(parents=True,exist_ok=True)
    (path/"calibration.json").write_text(json.dumps(cal,indent=2),encoding="utf-8")
    (path/"holdout_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    with (path/"holdout_trials.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader();w.writerows(rows)
    return summary


def _quick_summary(rows,config,spec,cal,seeds,scenarios):
    return {"label":"quick_smoke_only_not_independent_evidence",
            "rows":len(rows),"seeds":list(seeds),"scenarios":list(scenarios),
            "methods":list(HOLDOUT_POLICIES),
            "metered_synthetic_calls":sum(r["gold_queries"] for r in rows),
            "calibration_threshold":cal["threshold"],
            "guard_spec":asdict(spec)}
