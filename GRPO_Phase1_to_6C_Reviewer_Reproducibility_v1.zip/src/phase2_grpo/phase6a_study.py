"""Phase 6A: frozen LLM, budgeted reward acquisition and resumable audit.

Real Qwen completions and *actual model logit-score features* replace Phase 5
synthetic gradients.  There is NO weight update, no clipped GRPO, and no
actual expensive external reward call.  Full verifier labels are computed
once as a sealed retrospective shadow oracle; policies only observe B labels.
"""

from dataclasses import asdict, dataclass
import csv
import hashlib
from pathlib import Path
import platform
from typing import Callable

import numpy as np
import scipy

from .design import ExactBDesign
from .geometry import gradient_map
from .online_study import OnlineAcquirer, OnlineConfig
from .risk import acquisition_weight, augmented_rewards
from .phase6a_checkpoint import Checkpoints, atomic_json, digest, run_lock
from .phase6a_model import (FakeBackend, HuggingFaceQwenBackend,
                           group_seed, decision_seed)
from .phase6a_tasks import make_tasks, score_answer


METHODS = ("uniform", "cube_classic", "scaled", "joint_ewma", "joint_frozen")
BRIDGE_EPS = 1e-6


@dataclass(frozen=True)
class Phase6AConfig:
    groups: int = 120
    master_seed: int = 6103
    g: int = 6
    b: int = 3
    warmup: int = 26
    window: int = 18
    exploration: float = .25
    max_new_tokens: int = 96
    schedule: str = "easy_to_hard"
    backend: str = "hf"
    model: str = "Qwen/Qwen2.5-0.5B-Instruct"
    model_revision: str = "main"
    device: str = "cuda"
    local_files_only: bool = False

    def __post_init__(self):
        if (self.groups < 1 or self.g != 6 or self.b != 3 or
                self.warmup < 1 or self.window < 3 or
                self.max_new_tokens < 2 or self.max_new_tokens > 1024 or
                not 0 < self.exploration < 1 or
                self.schedule not in ("interleaved", "easy_to_hard") or
                self.backend not in ("hf", "fake") or not self.model or
                not self.model_revision):
            raise ValueError("invalid Phase6A configuration")


def source_hashes() -> dict[str, str]:
    base = Path(__file__).parent
    filenames = ("phase6a_study.py", "phase6a_model.py", "phase6a_checkpoint.py",
                 "phase6a_tasks.py", "online_study.py", "online_moments.py",
                 "design.py", "balanced.py", "classic_cube.py", "optimization.py",
                 "risk.py", "geometry.py", "calibration.py")
    hashes = {name: hashlib.sha256((base / name).read_bytes()).hexdigest()
              for name in filenames}
    for name in ("scripts/run_phase6a.py", "pyproject.toml"):
        hashes[name] = hashlib.sha256((base.parent.parent / name).read_bytes()).hexdigest()
    return hashes


def locked_config(cfg: Phase6AConfig) -> dict:
    return {"phase": "6A", "protocol_version": 2, "parameters": asdict(cfg),
            "source_sha256": source_hashes(),
            "answer_protocol":"v1.2_last_explicit_answer_box_or_label_or_bare",
            "format_protocol":"v1.2_strict_boxed_only_separately_reported",
            "runtime_versions": {"python": platform.python_version(),
                                 "numpy": np.__version__, "scipy": scipy.__version__},
            "methods": list(METHODS),
            "study_type": "real_LLM_generation_no_parameter_updates",
            "verifier_budget_type": "logical_counterfactual_not_wallclock_savings",
            "score_type": "frozen_model_token_logit_bias_directions_not_LoRA_gradient"}


def _policy_config(cfg: Phase6AConfig) -> OnlineConfig:
    return OnlineConfig(g=cfg.g, b=cfg.b, warmup=cfg.warmup,
                        horizon=max(80, cfg.groups, cfg.window * 4, 2*cfg.warmup+2),
                        window=cfg.window, exploration=cfg.exploration)


def _backend(cfg: Phase6AConfig):
    if cfg.backend == "fake":
        return FakeBackend()
    return HuggingFaceQwenBackend(cfg.model, revision=cfg.model_revision,
                                  device=cfg.device,
                                  local_files_only=cfg.local_files_only)


def _setup(cfg: Phase6AConfig, output: str | Path) -> tuple[Checkpoints, list[dict]]:
    cp = Checkpoints(output, locked_config(cfg))
    tasks = make_tasks(count=cfg.groups, seed=cfg.master_seed, schedule=cfg.schedule)
    original = cp.load("tasks", 0)
    if original is None:
        cp.save("tasks", 0, {"tasks": tasks})
    elif original.get("tasks") != tasks:
        raise RuntimeError("task sequence mismatch in resumed run")
    return cp, tasks


def _check_generation(value: dict, cfg: Phase6AConfig) -> None:
    if not isinstance(value, dict) or value.get("backend") != cfg.backend:
        raise ValueError("generation backend mismatch")
    completions = value.get("completions")
    lengths = value.get("completion_tokens")
    scores = np.asarray(value.get("score_features"), dtype=float)
    if (not isinstance(completions, list) or len(completions) != cfg.g or
            any(not isinstance(x, str) for x in completions) or
            not isinstance(lengths, list) or len(lengths) != cfg.g or
            any(not isinstance(x, int) or x < 1 or x > cfg.max_new_tokens for x in lengths)
            or scores.shape != (3, cfg.g) or not np.all(np.isfinite(scores))):
        raise ValueError("invalid generation payload")


def collect(cfg: Phase6AConfig, output: str | Path, *,
            max_new_groups: int | None = None,
            backend_factory: Callable[[Phase6AConfig], object] = _backend,
            progress: Callable[[str, int, int], None] | None = None) -> dict:
    """Generate and commit each six-completion group exactly once."""
    if max_new_groups is not None and max_new_groups < 0:
        raise ValueError("max_new_groups must be nonnegative")
    with run_lock(Path(output)):
        cp, tasks = _setup(cfg, output)
        done = cp.contiguous_count("generations", cfg.groups)
        if done == cfg.groups or max_new_groups == 0:
            return {"completed_groups": done, "total_groups": cfg.groups}
        generator = backend_factory(cfg)
        info = generator.info()
        old_info = cp.load("backend_info", 0)
        if old_info is None:
            cp.save("backend_info", 0, info)
        elif old_info != info:
            raise RuntimeError("model/framework fingerprint changed since checkpoint")
        end = min(cfg.groups, done + max_new_groups) if max_new_groups is not None else cfg.groups
        for index in range(done, end):
            public_task = {k: tasks[index][k] for k in ("id", "level", "prompt")}
            sample = generator.generate(public_task, group_seed(cfg.master_seed, index),
                                        cfg.g, cfg.max_new_tokens)
            _check_generation(sample, cfg)
            cp.save("generations", index, sample)
            if progress is not None:
                progress("generated", index + 1, cfg.groups)
        return {"completed_groups": end, "total_groups": cfg.groups}


def _normalize(rewards: np.ndarray) -> np.ndarray:
    x = np.asarray(rewards, dtype=float)
    return (x - x.mean()) / (np.sqrt(np.mean(np.square(x - x.mean()))) + BRIDGE_EPS)


def _design_bias_and_risk(scores: np.ndarray, truth: np.ndarray,
                          design: ExactBDesign) -> tuple[list[float], float]:
    """Exact (not MC) standardized plug-in bias/risk over all design subsets."""
    m = gradient_map(scores)
    reference = m @ _normalize(truth)
    expected = np.zeros_like(reference)
    expected_sq_error = 0.
    for subset, probability in zip(design.subsets, design.probs):
        if probability <= 0:
            continue
        selected = subset.astype(bool)
        visible = np.full(len(truth), np.nan)
        visible[selected] = truth[selected]
        reconstructed = augmented_rewards(visible, np.zeros(len(truth)),
                                          selected, design.marginals)
        delta = m @ _normalize(reconstructed) - reference
        expected += float(probability) * delta
        expected_sq_error += float(probability) * float(delta @ delta)
    return expected.tolist(), float(expected_sq_error)


def _restore_agent(cp: Checkpoints, policy: str, cfg: Phase6AConfig,
                   completed: int) -> OnlineAcquirer:
    agent = OnlineAcquirer(policy, _policy_config(cfg))
    for index in range(completed):
        item = cp.load(f"acq_{policy}", index)
        assert item is not None
        d = item["design"]
        design = ExactBDesign(np.asarray(d["subsets"], np.int8),
                              np.asarray(d["probs"], float), "replayed")
        mask = np.asarray(item["selected"], dtype=bool)
        if int(mask.sum()) != cfg.b or np.max(np.abs(design.marginals - cfg.b / cfg.g)) > 1e-7:
            raise RuntimeError("historical subset/budget corrupted")
        observed = np.full(cfg.g, np.nan)
        observed[mask] = np.asarray(item["paid_rewards"], dtype=float)
        agent.observe(observed, mask, design)
        # Freezing occurs at propose(), not at observe(). Without restoring
        # this state, joint_frozen would silently re-freeze later on resume.
        frozen = item["frozen_moments_after"]
        agent.frozen_moments = (None if frozen is None else
                                np.asarray(frozen, dtype=float))
    if agent.t != completed:
        raise RuntimeError("state replay lost decisions")
    return agent


def _compute_oracle(cp: Checkpoints, tasks: list[dict], cfg: Phase6AConfig) -> None:
    """A separate, retrospective FULL oracle for EVALUATION ONLY.

    This is *not* a record of paid calls. The verifier is free and local.
    A genuine paid reward API would require a separate idempotent ledger.
    """
    done = cp.contiguous_count("shadow_oracle", cfg.groups)
    for index in range(done, cfg.groups):
        generated = cp.load("generations", index)
        if generated is None:
            raise RuntimeError("cannot evaluate before all groups are generated")
        results = [score_answer(tasks[index], c) for c in generated["completions"]]
        cp.save("shadow_oracle", index, {"full_rewards": [r["reward"] for r in results],
                    "parsed_answers": [r["parsed_answer"] for r in results],
                    "generator_sha256": digest(generated)})


def _record_one(agent: OnlineAcquirer, method: str, index: int,
                cfg: Phase6AConfig, generated: dict, oracle: dict,
                task: dict) -> dict:
    scores = np.asarray(generated["score_features"], dtype=float)
    design, meta = agent.propose(scores)  # no oracle label has entered policy state
    if (int(design.B) != cfg.b or design.G != cfg.g or
            np.max(np.abs(design.marginals - cfg.b/cfg.g)) > 1e-7):
        raise AssertionError("fixed-B / first-order marginals not preserved")
    if np.min(design.pair_inclusions[np.triu_indices(cfg.g, 1)]) <= 0:
        raise AssertionError("lack of second-order support")
    rng = np.random.default_rng(decision_seed(cfg.master_seed, method, index))
    selected = design.draw(rng).astype(bool)
    purchased = np.flatnonzero(selected)
    # The retrospectively computed full scores live on the EVALUATION side.
    # Only purchased labels are forwarded to the agent.
    truth = np.asarray(oracle["full_rewards"], dtype=float)
    paid = truth[purchased]
    masked = np.full(cfg.g, np.nan)
    masked[selected] = paid
    m = gradient_map(scores)
    estimate = augmented_rewards(masked, np.zeros(cfg.g), selected, design.marginals)
    realized_linear = float(np.linalg.norm(m @ (estimate-truth))**2)
    # CONDITIONAL on the actual fixed group: no true-covariance simulator.
    weight = acquisition_weight(scores, design)
    exact_linear_risk = float(max(0., truth @ weight @ truth))
    nonlinear_bias, exact_nonlinear_risk = _design_bias_and_risk(scores, truth, design)
    realized_nonlinear = float(np.linalg.norm(m @ (_normalize(estimate)-_normalize(truth)))**2)
    diagnostic = agent.observe(masked, selected, design)
    return {
        "index": index, "level": task["level"], "policy": method,
        "decision": meta["decision"], "selected": selected.astype(int).tolist(),
        "paid_rewards": paid.tolist(), "logical_paid_queries": int(len(purchased)),
        "shadow_queries": cfg.g,  # reported separately, NOT cost savings
        "design": {"subsets": design.subsets.tolist(), "probs": design.probs.tolist()},
        "generator_sha256": digest(generated), "oracle_sha256": digest(oracle),
        "scores_sha256": digest(generated["score_features"]),
        "linear_mse_realized": realized_linear,
        "linear_design_risk_exact": exact_linear_risk,
        "normalized_mse_realized": realized_nonlinear,
        "normalized_design_mse_exact": exact_nonlinear_risk,
        "normalized_design_bias_vector_exact": nonlinear_bias,
        "min_pair_inclusion": float(np.min(design.pair_inclusions[
                                  np.triu_indices(cfg.g, 1)])),
        "pair_ess_before": float(meta["pair_ess_before"]),
        "drift_alert": int(diagnostic["alert"]),
        "frozen_moments_after": (None if agent.frozen_moments is None else
                                 agent.frozen_moments.tolist()),
        "model_updates": 0,
    }


def evaluate(cfg: Phase6AConfig, output: str | Path, *,
             max_new_decisions: int | None = None,
             progress: Callable[[str, int, int], None] | None = None) -> dict:
    """Replay logged observations, then continue policy decisions exactly."""
    if max_new_decisions is not None and max_new_decisions < 0:
        raise ValueError("max_new_decisions must be nonnegative")
    with run_lock(Path(output)):
        cp, tasks = _setup(cfg, output)
        if cp.contiguous_count("generations", cfg.groups) != cfg.groups:
            raise RuntimeError("finish --stage collect before --stage evaluate")
        _compute_oracle(cp, tasks, cfg)
        new = 0
        for method in METHODS:
            done = cp.contiguous_count(f"acq_{method}", cfg.groups)
            agent = _restore_agent(cp, method, cfg, done)
            for index in range(done, cfg.groups):
                if max_new_decisions is not None and new >= max_new_decisions:
                    return {"new_decisions": new, "complete": False}
                generated = cp.load("generations", index)
                oracle = cp.load("shadow_oracle", index)
                assert generated is not None and oracle is not None
                if oracle["generator_sha256"] != digest(generated):
                    raise RuntimeError("shadow oracle not tied to current generation")
                record = _record_one(agent, method, index, cfg, generated,
                                     oracle, tasks[index])
                cp.save(f"acq_{method}", index, record)
                new += 1
                if progress is not None:
                    progress(method, index + 1, cfg.groups)
        return {"new_decisions": new, "complete": True}


def summarize(cfg: Phase6AConfig, output: str | Path) -> dict:
    """Summary from committed decisions ONLY; no new oracle/model calls."""
    cp, tasks = _setup(cfg, output)
    progress = {name: cp.contiguous_count(f"acq_{name}", cfg.groups) for name in METHODS}
    completed = all(n == cfg.groups for n in progress.values())
    summary = {"phase": "6A", "complete": completed,
               "actual_llm_backend": cfg.backend == "hf", "actual_training": False,
               "config": asdict(cfg), "decisions_by_policy": progress,
               "committed_generations": cp.contiguous_count("generations", cfg.groups),
               "logical_paid_reward_queries": cfg.b * sum(progress.values()),
               "shadow_full_oracle_evaluations": cfg.g * cp.contiguous_count(
                   "shadow_oracle", cfg.groups),
               "claim_limit": "fixed-model, low-dimensional score sketch, exact local arithmetic labels; no LLM optimizer or real paid-verifier cost reduction"}
    if not completed:
        atomic_json(Path(output)/"phase6a_summary.json", summary)
        return summary
    records = {method: [cp.load(f"acq_{method}", i) for i in range(cfg.groups)]
               for method in METHODS}
    # Inspectable per-group evidence, without editing committed decisions.
    # Columns make every paired method contrast reproducible independently.
    rows = []
    for index in range(cfg.groups):
        for method in METHODS:
            record = records[method][index]
            rows.append({"group": index, "level": record["level"],
                         "policy": method, "decision": record["decision"],
                         "linear_design_risk_exact": record["linear_design_risk_exact"],
                         "linear_mse_realized": record["linear_mse_realized"],
                         "normalized_design_mse_exact": record["normalized_design_mse_exact"],
                         "normalized_mse_realized": record["normalized_mse_realized"],
                         "pair_ess_before": record["pair_ess_before"],
                         "min_pair_inclusion": record["min_pair_inclusion"],
                         "logical_paid_queries": record["logical_paid_queries"]})
    csv_path = Path(output)/"phase6a_group_policy_metrics.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    measures = ("linear_mse_realized", "linear_design_risk_exact",
                "normalized_mse_realized", "normalized_design_mse_exact")
    summary["by_policy"] = {}
    for method, items in records.items():
        summary["by_policy"][method] = {
            **{k: float(np.mean([x[k] for x in items])) for k in measures},
            "normalized_bias_norm_of_mean": float(np.linalg.norm(np.mean(
                [x["normalized_design_bias_vector_exact"] for x in items], axis=0))),
            "logical_paid_queries": cfg.b * len(items),
            "mean_min_pair_inclusion": float(np.mean([x["min_pair_inclusion"] for x in items]))}
    summary["by_task_level"] = {}
    for level in ("easy", "hard"):
        summary["by_task_level"][level] = {}
        for name in METHODS:
            subset = [x for x in records[name] if x["level"] == level]
            summary["by_task_level"][level][name] = {
                "groups": len(subset), **{k: float(np.mean([r[k] for r in subset]))
                                             if subset else None for k in measures}}
    summary["paired_group_risk_gain_uniform_minus_joint"] = float(np.mean([
        records["uniform"][i]["linear_design_risk_exact"]-
        records["joint_ewma"][i]["linear_design_risk_exact"]
        for i in range(cfg.groups)]))
    summary["paired_group_risk_gain_scaled_minus_joint"] = float(np.mean([
        records["scaled"][i]["linear_design_risk_exact"]-
        records["joint_ewma"][i]["linear_design_risk_exact"]
        for i in range(cfg.groups)]))
    summary["task_levels"] = {level: sum(x["level"] == level for x in tasks)
                              for level in ("easy", "hard")}
    summary["inference_only"] = True
    summary["independent_seed_replications"] = 1
    summary["no_statistical_significance_claim"] = True
    atomic_json(Path(output)/"phase6a_summary.json", summary)
    return summary


def audit(cfg: Phase6AConfig, output: str | Path) -> dict:
    """Independent replay of all acquisition proposals and subset statistics.

    No model reload or GPU is needed. Every selected subset must be one of
    the recorded design's possibilities, the design must replay exactly, and
    an independently implemented pair-covariance quadratic matches risk.
    """
    with run_lock(Path(output)):
        cp, tasks = _setup(cfg, output)
        if cp.contiguous_count("generations", cfg.groups) != cfg.groups:
            raise RuntimeError("audit requires complete generation")
        if cp.contiguous_count("shadow_oracle", cfg.groups) != cfg.groups:
            raise RuntimeError("audit requires complete shadow oracle")
        violations = []
        checked = 0
        for method in METHODS:
            n = cp.contiguous_count(f"acq_{method}", cfg.groups)
            if n != cfg.groups:
                raise RuntimeError(f"audit requires complete {method} records")
            agent = OnlineAcquirer(method, _policy_config(cfg))
            for i in range(cfg.groups):
                row = cp.load(f"acq_{method}", i)
                gen = cp.load("generations", i)
                truth = cp.load("shadow_oracle", i)
                assert row and gen and truth
                try:
                    if row["index"] != i or row["policy"] != method:
                        raise AssertionError("incorrect sequence identity")
                    if (row["generator_sha256"] != digest(gen) or
                            row["oracle_sha256"] != digest(truth) or
                            row["scores_sha256"] != digest(gen["score_features"])):
                        raise AssertionError("external artifact hash mismatch")
                    if truth["generator_sha256"] != digest(gen):
                        raise AssertionError("oracle-generate join mismatch")
                    scores = np.asarray(gen["score_features"], float)
                    designed, meta = agent.propose(scores)
                    q = np.asarray(row["design"]["probs"], float)
                    zsupport = np.asarray(row["design"]["subsets"], int)
                    saved = ExactBDesign(zsupport, q, "audit")
                    # No silent acceptance of a non-reproducible optimizer.
                    by_subset = {tuple(z): p for z,p in zip(designed.subsets.tolist(),
                                                               designed.probs.tolist())}
                    for z,p in zip(saved.subsets.tolist(),saved.probs.tolist()):
                        if not np.isclose(by_subset.pop(tuple(z), -1.), p, atol=2e-7):
                            raise AssertionError("recomputed design differs")
                    if any(abs(p)>2e-7 for p in by_subset.values()):
                        raise AssertionError("recomputed support differs")
                    if meta["decision"] != row["decision"]:
                        raise AssertionError("recomputed decision differs")
                    selected = np.asarray(row["selected"],bool)
                    if int(selected.sum()) != cfg.b or not any(
                            np.array_equal(s,selected) and p>0
                            for s,p in zip(saved.subsets,saved.probs)):
                        raise AssertionError("invalid purchased subset")
                    expected_draw = designed.draw(np.random.default_rng(
                        decision_seed(cfg.master_seed,method,i)))
                    if not np.array_equal(selected,expected_draw):
                        raise AssertionError("selection RNG does not replay")
                    rewards = np.asarray(truth["full_rewards"],float)
                    paid = np.asarray(row["paid_rewards"],float)
                    if (len(paid)!=cfg.b or not np.array_equal(paid,rewards[selected])
                            or row["logical_paid_queries"]!=cfg.b):
                        raise AssertionError("reward metering/selected labels mismatch")
                    pi = saved.marginals
                    pairs = saved.pair_inclusions
                    m = (scores-scores.mean(axis=1,keepdims=True))/(cfg.g-1)
                    w = (pairs/np.outer(pi,pi)-1.)*(m.T@m)
                    exact = float(max(0.,rewards@w@rewards))
                    if not np.isclose(exact,row["linear_design_risk_exact"],atol=1e-8):
                        raise AssertionError("risk quadratic fails independent check")
                    visible = np.zeros(cfg.g)
                    visible[selected]=paid/pi[selected]
                    realized = float(np.linalg.norm(m@(visible-rewards))**2)
                    if not np.isclose(realized,row["linear_mse_realized"],atol=1e-8):
                        raise AssertionError("realized squared error inconsistent")
                    masked = np.full(cfg.g,np.nan)
                    masked[selected]=paid
                    agent.observe(masked,selected,saved)
                    checked+=1
                except Exception as exc:
                    violations.append(f"{method} step={i}: {exc}")
                    break
        result = {"phase":"6A", "pass":not violations,
                  "checked_policy_decisions":checked,
                  "expected_decisions":len(METHODS)*cfg.groups,
                  "violations":violations,
                  "scope":"internal independent reconstruction; not external peer audit"}
        atomic_json(Path(output)/"phase6a_audit.json",result)
        if violations:
            raise AssertionError("Phase6A audit FAILED: "+violations[0])
        return result
