"""Exact-size subset designs and stable finite-dimensional optimization.

The finite subset LP is intentionally bounded by max_subsets; there is no
claim of polynomial-time global optimization for arbitrary group size.
"""

from dataclasses import dataclass
from itertools import combinations
from math import comb

import numpy as np
from scipy.optimize import linprog, minimize
from scipy.special import logsumexp


def check_marginals(zeta: np.ndarray, budget: int, tol: float = 1e-9) -> np.ndarray:
    zeta = np.asarray(zeta, dtype=float)
    if zeta.ndim != 1 or not np.all(np.isfinite(zeta)):
        raise ValueError("zeta must be a finite one-dimensional vector")
    if not isinstance(budget, (int, np.integer)) or not (1 <= budget <= len(zeta)):
        raise ValueError("budget must be an integer in [1,G]")
    if np.any(zeta < -tol) or np.any(zeta > 1 + tol):
        raise ValueError("zeta outside [0,1]")
    if abs(float(zeta.sum()) - budget) > tol:
        raise ValueError("fixed-size marginals must sum exactly to budget")
    # Floating-point convex mixtures can produce 1+2e-16 or -2e-16.
    # Only machine-scale boundary noise is clamped; no global renormalization
    # or tolerance-based alteration of substantive target marginals occurs.
    if np.any(zeta < -1e-12) or np.any(zeta > 1 + 1e-12):
        raise ValueError("boundary violation; correct input upstream")
    cleaned = np.clip(zeta, 0.0, 1.0)
    if abs(float(cleaned.sum()) - budget) > tol:
        raise ValueError("clipping changed the fixed-size constraint")
    return cleaned


def all_subsets(group_size: int, budget: int, max_subsets: int = 100_000) -> np.ndarray:
    group_size, budget = int(group_size), int(budget)
    if group_size < 2 or not 1 <= budget <= group_size:
        raise ValueError("invalid G or B")
    count = comb(group_size, budget)
    if count > max_subsets:
        raise ValueError(f"enumeration would require {count} subsets; bound is {max_subsets}")
    subsets = np.zeros((count, group_size), dtype=np.int8)
    for row, indices in enumerate(combinations(range(group_size), budget)):
        subsets[row, list(indices)] = 1
    return subsets


@dataclass(frozen=True)
class ExactBDesign:
    subsets: np.ndarray
    probs: np.ndarray
    label: str = "user_design"

    def __post_init__(self):
        # Validate before casting: a fractional input such as 0.7 must not
        # silently become a seemingly legal binary subset.
        original = np.asarray(self.subsets, dtype=float)
        if not np.all(np.isfinite(original)) or np.any((original != 0) & (original != 1)):
            raise ValueError("subset entries must be exactly binary 0/1")
        z = original.astype(np.int8)
        q = np.asarray(self.probs, dtype=float)
        if z.ndim != 2 or z.shape[0] == 0 or z.shape[1] < 2:
            raise ValueError("subsets must be a nonempty matrix with G>=2")
        if q.shape != (len(z),) or not np.all(np.isfinite(q)):
            raise ValueError("probabilities have incompatible shape or nonfinite values")
        if np.any((z != 0) & (z != 1)) or np.any(q < 0):
            raise ValueError("subsets must be binary; probabilities nonnegative")
        if np.any(z.sum(axis=1) != z[0].sum()) or not 1 <= int(z[0].sum()) <= z.shape[1]:
            raise ValueError("subsets do not have one exact size B")
        if abs(float(q.sum()) - 1) > 1e-9:
            raise ValueError("probabilities must sum to one (no silent normalization)")
        object.__setattr__(self, "subsets", z.copy())
        object.__setattr__(self, "probs", q.copy())

    @property
    def G(self) -> int:
        return self.subsets.shape[1]

    @property
    def B(self) -> int:
        return int(self.subsets[0].sum())

    @property
    def marginals(self) -> np.ndarray:
        return self.probs @ self.subsets

    @property
    def pair_inclusions(self) -> np.ndarray:
        return (self.subsets.T * self.probs) @ self.subsets

    def draw(self, rng: np.random.Generator) -> np.ndarray:
        return self.subsets[int(rng.choice(len(self.probs), p=self.probs))].copy()


def uniform_design(group_size: int, budget: int) -> ExactBDesign:
    subsets = all_subsets(group_size, budget)
    q = np.full(len(subsets), 1.0 / len(subsets))
    return ExactBDesign(subsets, q, "uniform_exact_B")


def feasible_fixed_marginals(zeta: np.ndarray, budget: int) -> ExactBDesign:
    """Find a provably feasible q with explicit residual check, for small G."""
    zeta = check_marginals(zeta, budget)
    subsets = all_subsets(len(zeta), budget)
    # Boundary cardinalities admit closed-form, well-conditioned mixtures.
    if budget == 1:
        return ExactBDesign(subsets, zeta.copy(), "singleton_exact_marginals")
    if budget == len(zeta) - 1:
        q = np.array([1.0 - zeta[np.flatnonzero(row == 0)[0]] for row in subsets])
        return ExactBDesign(subsets, q, "omit_one_exact_marginals")
    eq = np.vstack([np.ones(len(subsets)), subsets[:, :-1].T])
    rhs = np.r_[1.0, zeta[:-1]]
    result = linprog(np.zeros(len(subsets)), A_eq=eq, b_eq=rhs,
                     bounds=(0, None), method="highs",
                     options={"primal_feasibility_tolerance": 1e-10,
                              "dual_feasibility_tolerance": 1e-10})
    if not result.success:
        raise RuntimeError(f"feasible marginal LP failed: {result.message}")
    q = np.maximum(result.x, 0.0)
    q = q / q.sum()
    design = ExactBDesign(subsets, q, "feasible_lp")
    if np.max(np.abs(design.marginals - zeta)) > 1e-7:
        raise RuntimeError("marginal reconstruction failure")
    return design


def max_entropy_fixed_marginals(zeta: np.ndarray, budget: int) -> ExactBDesign:
    """Baseline maximizing subset entropy at the *same* marginals.

    On boundary vectors, use the verified feasible LP rather than allow a
    diverging exponential-family dual. Optimization is deterministic.
    """
    zeta = check_marginals(zeta, budget)
    subsets = all_subsets(len(zeta), budget)
    if np.any(zeta < 1e-7) or np.any(zeta > 1 - 1e-7):
        base = feasible_fixed_marginals(zeta, budget)
        return ExactBDesign(base.subsets, base.probs, "boundary_feasible_baseline")
    a = subsets[:, :-1].astype(float)

    def objective(lam):
        raw = a @ lam
        lse = logsumexp(raw)
        probs = np.exp(raw - lse)
        value = lse - zeta[:-1] @ lam
        jac = probs @ a - zeta[:-1]
        return float(value), jac

    result = minimize(objective, np.zeros(len(zeta) - 1), jac=True,
                      method="BFGS", options={"gtol": 1e-11, "maxiter": 2000})
    raw = a @ result.x
    q = np.exp(raw - logsumexp(raw))
    design = ExactBDesign(subsets, q, "maximum_entropy_fixed_marginals")
    if np.max(np.abs(design.marginals - zeta)) > 5e-7:
        base = feasible_fixed_marginals(zeta, budget)
        return ExactBDesign(base.subsets, base.probs, "fallback_feasible_baseline")
    return design


def dependent_round_once(zeta: np.ndarray, budget: int, rng: np.random.Generator) -> np.ndarray:
    """Martingale pair rounding: exact B a.s., E[Z_i]=zeta_i.

    This gives individual subsets, not an explicit q distribution or pi_ij.
    It is intended only as a large-G sampling fallback, not a full LP solver.
    """
    x = check_marginals(zeta, budget).copy()
    for _ in range(len(x)):
        fractional = np.flatnonzero((x > 1e-12) & (x < 1 - 1e-12))
        if len(fractional) < 2:
            break
        i, j = fractional[:2]
        up = min(1.0 - x[i], x[j])
        down = min(x[i], 1.0 - x[j])
        if rng.random() < down / (up + down):
            x[i] += up
            x[j] -= up
        else:
            x[i] -= down
            x[j] += down
    # Only numerical tolerance is repaired; never reshuffle larger errors.
    z = np.rint(x).astype(np.int8)
    if z.sum() != budget or np.max(np.abs(x - z)) > 5e-9:
        raise RuntimeError("dependent rounding failed to produce exact-size subset")
    return z

