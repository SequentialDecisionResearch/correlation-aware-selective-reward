"""Deville--Tille cube flight AND ordered-constraint-dropping landing.

This is an independent, transparent, finite-G Python realization of the
published two-phase cube *principle*, using the first balancing variable
for exact sample size. During landing, balancing constraints are discarded
from last to first while the cardinality row is NEVER discarded. It is a
complete flight/landing sampler, unlike the earlier simplified pair landing.

For small G we enumerate the entire branching distribution so its marginal
and pair-inclusion probabilities are exact, rather than empirical frequencies.
Random null-space choices and alternative landing objectives can result in
different cube designs. For an independent implementation comparison see the
optional R BalancedSampling::cube bridge in r_cube_bridge.py; identical draws
or identical distributions are NOT claimed across software implementations.

References: Deville & Tille (Biometrika 2004); Chauvet & Tille (2006);
CRAN BalancedSampling::cube documentation (first balancing variable=pi).
"""

from collections import defaultdict
from dataclasses import dataclass

import numpy as np

from .design import ExactBDesign, check_marginals


@dataclass(frozen=True)
class CubeDiagnostics:
    flight_drop_events: int
    landing_branch_events: int
    largest_marginal_error: float
    distinct_subsets: int
    visited_tree_nodes: int


def cube_full_flight_landing(
    pi: np.ndarray, budget: int, auxiliaries: np.ndarray,
    *, max_nodes: int = 120_000, tol: float = 1e-11,
) -> tuple[ExactBDesign, CubeDiagnostics]:
    """Enumerate a true flight/landing cube construction for modest G.

    Inputs: auxiliaries shape (p,G), each column the target HT auxiliary
    contribution. Constraints are sum Z_i = B (first, preserved to the end)
    followed by the p auxiliary HT totals, dropped from the *last* column
    first during landing (in the R convention: last auxiliary variable).

    At every martingale split E[x_next | x] = x, so the prescribed first
    marginals are retained without Monte Carlo estimation. The exact subset
    distribution additionally provides pair inclusion probabilities.
    """
    pi = check_marginals(pi, budget)
    if np.any(pi <= 0):
        raise ValueError("positive first-order inclusion is required")
    a = np.asarray(auxiliaries, dtype=float)
    if a.ndim != 2 or a.shape[1] != len(pi) or not np.all(np.isfinite(a)):
        raise ValueError("auxiliaries must be finite p-by-G")
    if not isinstance(max_nodes, int) or max_nodes < 3:
        raise ValueError("invalid node limit")
    # The first equality enforces fixed B; all other equalities are optional.
    constraints = np.vstack((np.ones((1, len(pi))), a / pi[None, :]))
    leaves: defaultdict[tuple[int, ...], float] = defaultdict(float)
    num_nodes = 0
    drop_events = 0
    landing_events = 0

    def walk(x: np.ndarray, mass: float, retained: int) -> None:
        nonlocal num_nodes, drop_events, landing_events
        num_nodes += 1
        if num_nodes > max_nodes:
            raise RuntimeError("cube full flight/landing enumeration exceeded max_nodes")
        x = np.where(x < tol, 0., np.where(x > 1 - tol, 1., x))
        fractional = np.flatnonzero((x > tol) & (x < 1 - tol))
        if len(fractional) == 0:
            bits = np.rint(x).astype(np.int8)
            if int(bits.sum()) != budget:
                raise ArithmeticError("cube did not preserve the budget")
            leaves[tuple(bits.tolist())] += mass
            return
        if len(fractional) < 2:
            raise ArithmeticError("one fractional value violates integer sum")

        k = retained
        direction = None
        while k >= 1:
            sub = constraints[:k, fractional]
            _, sing, vh = np.linalg.svd(sub, full_matrices=True)
            threshold = 1e-10 * max(1.0, float(sing[0]) if len(sing) else 0.)
            rank = int(np.sum(sing > threshold))
            if len(fractional) > rank:
                direction = np.zeros(len(pi))
                direction[fractional] = vh[-1]
                if np.linalg.norm(sub @ direction[fractional]) > 2e-8:
                    raise ArithmeticError("null-space flight direction not null")
                break
            if k == 1:
                raise ArithmeticError("constant sample-size constraint is infeasible")
            k -= 1  # full landing: drop last remaining auxiliary row
            drop_events += 1
        assert direction is not None
        if k < len(constraints):
            landing_events += 1

        up_limits, down_limits = [], []
        for i in fractional:
            u = direction[i]
            if abs(u) < 1e-12:
                continue
            if u > 0:
                up_limits.append((1 - x[i]) / u)
                down_limits.append(x[i] / u)
            else:
                up_limits.append(x[i] / -u)
                down_limits.append((1 - x[i]) / -u)
        up, down = float(min(up_limits)), float(min(down_limits))
        if up < tol or down < tol:
            raise ArithmeticError("degenerate cube martingale step")
        weight_up = down / (up + down)
        walk(x + up * direction, mass * weight_up, k)
        walk(x - down * direction, mass * (1.0 - weight_up), k)

    walk(pi.copy(), 1.0, constraints.shape[0])
    support = np.asarray(list(leaves), dtype=np.int8)
    q = np.asarray([leaves[tuple(row)] for row in support], dtype=float)
    if abs(float(q.sum()) - 1) > 1e-8:
        raise ArithmeticError("cube branch probabilities do not sum to one")
    q /= q.sum()
    design = ExactBDesign(support, q, "cube_full_flight_ordered_drop_landing")
    error = float(np.max(np.abs(design.marginals - pi)))
    if error > 1e-7:
        raise ArithmeticError("cube first-order inclusion probabilities changed")
    return design, CubeDiagnostics(drop_events, landing_events,
                                    error, len(support), num_nodes)
