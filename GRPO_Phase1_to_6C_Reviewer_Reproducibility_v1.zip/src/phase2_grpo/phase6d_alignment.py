"""Phase6D: frozen-model, reward-blind proposal, real-gradient exact-risk experiment.

Snapshot-conditioned, exploratory mechanism diagnostics. No optimizer updates,
no writes to Phase6B/6C/v1.5 results, and no reward-conditioned task selection.
"""

from __future__ import annotations

from pathlib import Path
import math
import re

import numpy as np

from .design import uniform_design
from .phase6a_checkpoint import digest
from .phase6a_tasks import ANSWER_INSTRUCTION, score_answer
from .phase6b_calibration2 import task_bank
from .phase6c_diagnostics import (file_sha, load_run, open_existing_checkpoint,
    read_json, stored_state, stress_bank, write_once, csv_once, cluster_interval)
from .phase6c_objectives import Phase6CConfig
from .phase6c_training import _agent_replay
from .phase6d_gradient_risk import evaluate_fixed_designs


PROTOCOL = "phase6d_v1_frozen_real_lora_gradient_20261025"
FAMILIES = ("two_digit_add", "three_digit_double_carry")
SOURCES = ("uniform", "joint_ewma")
PAIR = re.compile(r"^Compute exactly: (\d+) \+ (\d+)\.")


def _pair(task: dict) -> tuple[int,int] | None:
    match=PAIR.match(task["prompt"])
    return tuple(sorted(map(int,match.groups()))) if match else None


def frozen_task_banks(runs: list[dict], groups_per_family: int,
                      families: tuple[str,...]) -> dict:
    """Freeze tasks without consulting observed rewards, predictions or risks."""
    if not 1<=groups_per_family<=64 or not families or any(f not in FAMILIES for f in families):
        raise ValueError("invalid Phase6D family count/configuration")
    reserved=set()
    # Original training/heldout tasks from each sealed seed, plus the entire
    # calibration family space inspected at fixed original pilot/eval seeds.
    for run in runs:
        cp=open_existing_checkpoint(Path(run["root"]),"uniform")
        for t in cp.load("tasks",0)["train"]+cp.load("tasks",0)["heldout"]:
            key=_pair(t)
            if key is not None:
                reserved.add(key)
    for split,seeds,count in (("pilot",(9217,9241),6),
                              ("eval",(9323,9349,9371),60)):
        for seed in seeds:
            for t in task_bank(count,seed,"two_digit_add",split=split):
                reserved.add(_pair(t))
    # Phase6C v1.5 has already evaluated independent OOD arithmetic tasks.
    # Reject the complete 64-per-stratum deterministic superset, not only
    # the first 32 usually used in its published three-seed stress panel.
    for t in stress_bank(64)["tasks"]:
        key=_pair(t)
        if key is not None:
            reserved.add(key)
    banks={}
    for run in runs:
        seed=run["seed"]
        tasks=[]
        for family in families:
            used=set()
            index=0
            while len(used)<groups_per_family:
                if index>20000:
                    raise RuntimeError("insufficient unseen Phase6D tasks")
                if family=="two_digit_add":
                    # Candidate index is stable as count grows; deliberately
                    # do not inspect model rewards to filter any candidate.
                    t=task_bank(1,seed+5_000_000+index,"two_digit_add",split="eval")[0]
                    key=_pair(t)
                    expression=t["prompt"].split("Compute exactly: ",1)[1].split(".",1)[0]
                    answer=int(t["answer"])
                else:
                    rng=np.random.default_rng(np.random.SeedSequence(
                        [20261025,603,seed,index]))
                    a,b=map(int,rng.integers(150,900,size=2))
                    index+=1
                    if a%10+b%10<10 or (a//10)%10+(b//10)%10+1<10:
                        continue
                    key=tuple(sorted((a,b)))
                    expression,answer=f"{a} + {b}",a+b
                index+=1 if family=="two_digit_add" else 0
                if key in reserved or key in used:
                    continue
                used.add(key)
                reserved.add(key)
                tasks.append({"id":f"seed{seed}_{family}_{len(used)-1:03d}",
                    "family":family,"level":family,
                    "prompt":f"Compute exactly: {expression}. {ANSWER_INSTRUCTION}",
                    "answer":int(answer)})
        banks[str(seed)]=tasks
    return {"protocol":PROTOCOL,"groups_per_family":groups_per_family,
            "families":list(families),"tasks_by_seed":banks,
            "split":"prospectively frozen for this exploratory mechanism diagnostic",
            "exclusion":"Phase6C train/heldout, Phase6B pilot/eval, v1.5 stress supersets, commuted sums"}


def prepare(paths: list[str|Path], output: Path, *, snapshots=(0,30,60),
            source_arms=SOURCES, families=FAMILIES, groups_per_family=4) -> dict:
    if not paths or len(paths)!=len(set(map(str,paths))):
        raise ValueError("provide distinct completed Phase6C runs")
    roots=[Path(x).resolve() for x in paths]
    target=Path(output).resolve()
    if any(target==r or target.is_relative_to(r) for r in roots):
        raise ValueError("Phase6D output must be outside original training run directories")
    runs=[load_run(root) for root in roots]
    runs.sort(key=lambda r:r["seed"])
    if len({r["seed"] for r in runs})!=len(runs):
        raise ValueError("repeated seed")
    template=None
    for r in runs:
        cfg=dict(r["config"])
        cfg.pop("seed")
        if template is None:
            template=cfg
        elif cfg!=template:
            raise RuntimeError("Phase6C runs not comparable beyond seed")
    snapshots=tuple(int(i) for i in snapshots)
    source_arms=tuple(source_arms)
    families=tuple(families)
    if (not snapshots or len(set(snapshots))!=len(snapshots) or
            min(snapshots)<0 or max(snapshots)>template["steps"] or
            not source_arms or len(set(source_arms))!=len(source_arms) or
            any(a not in SOURCES for a in source_arms) or
            len(set(families))!=len(families)):
        raise ValueError("invalid snapshot, source-arm or family list")
    bank=frozen_task_banks(runs,groups_per_family,families)
    checkpoint_sha={}
    for run in runs:
        for arm in source_arms:
            cp=open_existing_checkpoint(Path(run["root"]),arm)
            for step in snapshots:
                state=stored_state(cp,step)
                checkpoint_sha[f"{run['seed']}:{arm}:{step}"]=file_sha(state)
    manifest={"protocol":PROTOCOL,"schema":1,"runs":runs,
              "common_config_excluding_seed":template,
              "snapshots":list(snapshots),"source_arms":list(source_arms),
              "families":list(families),"groups_per_family":groups_per_family,
              "task_bank_sha256":digest(bank),
              "source_states_sha256":checkpoint_sha,
              "scientific_boundary":"exploratory frozen snapshot CONDITIONAL risk; no SGD or post-training superiority claim"}
    write_once(Path(output)/"phase6d_task_bank.json",bank)
    write_once(Path(output)/"phase6d_manifest.json",manifest)
    return {"status":"locked","seed_count":len(runs),
            "source_arms":list(source_arms),"snapshots":list(snapshots),
            "groups_per_seed":len(bank["tasks_by_seed"][str(runs[0]["seed"]) ]),
            "groups_expected":len(runs)*len(source_arms)*len(snapshots)*
                len(bank["tasks_by_seed"][str(runs[0]["seed"]) ]),
            "task_bank_sha256":digest(bank)}


def locked(output: Path) -> tuple[dict,dict]:
    m=read_json(Path(output)/"phase6d_manifest.json")
    b=read_json(Path(output)/"phase6d_task_bank.json")
    if m.get("protocol")!=PROTOCOL or b.get("protocol")!=PROTOCOL or m["task_bank_sha256"]!=digest(b):
        raise RuntimeError("Phase6D locked task bank/manifest corrupted")
    for run in m["runs"]:
        root=Path(run["root"])
        if (file_sha(root/"phase6c_summary.json")!=run["summary_sha256"] or
                file_sha(root/"phase6c_audit.json")!=run["audit_sha256"]):
            raise RuntimeError("original Phase6C run changed after Phase6D lock")
        for arm,expected in run["arm_manifest_sha256"].items():
            if file_sha(root/"arms"/arm/"manifest.json")!=expected:
                raise RuntimeError("original Phase6C arm manifest changed")
    return m,b


def gradients_lora(policy,task: dict, samples: list[dict]) -> tuple[np.ndarray,dict]:
    """True per-completion on-policy LoRA autograd; NEVER optimizer.step()."""
    torch=policy.torch
    policy.model.eval()  # matches training's dropout-free surrogate evaluation
    params=[p for p in policy.model.parameters() if p.requires_grad]
    if not params:
        raise RuntimeError("no LoRA parameters requiring gradients")
    prompt=policy._prompt(task["prompt"])
    rows=[];logp_discrepancy=[];unused=[]
    for sample in samples:
        y=torch.tensor(sample["token_ids"],device=policy.device,dtype=torch.long)
        _,logp=policy._token_logprobs(prompt,y,requires_grad=True)
        old=np.asarray(sample["old_logp"],dtype=np.float64)
        new=logp.detach().cpu().numpy().astype(np.float64)
        if old.shape!=new.shape:
            raise RuntimeError("generated logprob and gradient-token sequence disagree")
        discrepancy=float(np.max(np.abs(old-new)))
        if discrepancy>1e-2:
            raise RuntimeError(f"off-policy likelihood: old/new logprob difference {discrepancy}")
        logp_discrepancy.append(discrepancy)
        objective=logp.sum()/policy.cfg.max_new_tokens
        g=torch.autograd.grad(objective,params,allow_unused=True)
        unused.append(sum(x is None for x in g))
        row=torch.cat([(x.detach().float().reshape(-1).cpu() if x is not None
                         else torch.zeros_like(p,device="cpu",dtype=torch.float32).reshape(-1))
                       for x,p in zip(g,params)]).numpy()
        if not np.all(np.isfinite(row)):
            raise RuntimeError("nonfinite actual LoRA gradient")
        rows.append(row)
    x=np.asarray(rows,dtype=np.float64)
    if not np.any(x):
        raise RuntimeError("all computed LoRA gradients are zero")
    gram=x@x.T
    return gram,{"trainable_parameters":x.shape[1],
                 "per_completion_grad_norms":np.sqrt(np.einsum("ij,ij->i",x,x)).tolist(),
                 "max_old_new_logp_discrepancy":max(logp_discrepancy),
                 "unused_parameter_tensors_by_completion":unused}


def event_path(output: Path,seed: int,arm: str,step: int,index: int) -> Path:
    return (Path(output)/"groups"/f"seed{seed}"/arm/
            f"step{step:06d}"/f"group_{index:06d}.json")


def read_event(path: Path, *, m: dict, bank: dict, seed: int,
               arm: str,step: int,index: int) -> dict | None:
    if not path.is_file():
        return None
    record=read_json(path)
    sha=record.pop("sha256",None)
    if (sha!=digest(record) or record.get("protocol")!=PROTOCOL or
            record.get("seed")!=seed or record.get("source_arm")!=arm or
            record.get("snapshot")!=step or record.get("group_index")!=index or
            record.get("task_bank_sha256")!=m["task_bank_sha256"] or
            record.get("task")!=bank["tasks_by_seed"][str(seed)][index]):
        raise RuntimeError(f"corrupt Phase6D record: {path}")
    record["sha256"]=sha
    return record


def run(output: Path, *, max_new_groups: int | None=None,
        policy_factory=None, state_loader=None, gradient_fn=None) -> dict:
    """Frozen model, real autograd, no optimizer.step(); resumable by group."""
    if max_new_groups is not None and max_new_groups<0:
        raise ValueError("max-new-groups must be nonnegative")
    m,bank=locked(output)
    if policy_factory is None:
        from .phase6c_model import RealLoRAPolicy
        policy_factory=RealLoRAPolicy
    if state_loader is None:
        import torch
        state_loader=lambda path:torch.load(path,map_location="cpu",weights_only=True)
    gradient_fn=gradient_fn or gradients_lora
    previous=0;created=0;total=0
    for source in m["runs"]:
        seed=source["seed"]
        cfg=Phase6CConfig(**source["config"])
        root=Path(source["root"])
        tasks=bank["tasks_by_seed"][str(seed)]
        moment_cp=open_existing_checkpoint(root,"joint_ewma")
        for arm in m["source_arms"]:
            cp=open_existing_checkpoint(root,arm)
            policy=None
            try:
                for step in m["snapshots"]:
                    state_hash=m["source_states_sha256"][f"{seed}:{arm}:{step}"]
                    # Check the original checkpoint hash even if every group
                    # has previously been committed in this diagnostic.
                    state=stored_state(cp,step)
                    if file_sha(state)!=state_hash:
                        raise RuntimeError("frozen source adapter changed")
                    if policy is not None:
                        policy.restore(state_loader(state),step)
                    moments=_agent_replay(moment_cp,cfg,"joint_ewma",step)
                    for index,task in enumerate(tasks):
                        total+=1
                        path=event_path(output,seed,arm,step,index)
                        prior=read_event(path,m=m,bank=bank,seed=seed,
                                         arm=arm,step=step,index=index)
                        if prior is not None:
                            previous+=1
                            continue
                        if max_new_groups is not None and created>=max_new_groups:
                            return {"complete":False,"existing_groups":previous,
                                    "new_groups":created,"note":"rerun to resume"}
                        if policy is None:
                            policy=policy_factory(cfg)
                            if policy.info!=cp.load("model_info",0):
                                raise RuntimeError("Qwen source model fingerprint changed")
                            policy.restore(state_loader(state),step)
                        public={"id":task["id"],"level":task["level"],
                                "prompt":task["prompt"]}
                        generated=policy.generate(public,index)
                        samples=generated["samples"]
                        scores=np.asarray(generated["score_features"],dtype=float)
                        if len(samples)!=cfg.g or scores.shape!=(3,cfg.g):
                            raise RuntimeError("generated score-feature shape mismatch")
                        # Build both sampling distributions before seeing any
                        # current-task reward. Reuse the SAME frozen history
                        # and generated samples for a conditional comparison.
                        u=uniform_design(cfg.g,cfg.b)
                        j,metadata=moments.propose(scores)
                        real_gram,grad_info=gradient_fn(policy,public,samples)
                        scored=[score_answer(task,s["text"]) for s in samples]
                        rewards=np.asarray([s["reward"] for s in scored],float)
                        results=evaluate_fixed_designs(real_gram,scores,rewards,u,j)
                        core={"protocol":PROTOCOL,"seed":seed,"source_arm":arm,
                            "snapshot":step,"group_index":index,"task":task,
                            "task_bank_sha256":m["task_bank_sha256"],
                            "source_state_sha256":state_hash,
                            "history_arm":"joint_ewma",
                            "current_gold_hidden_at_proposal":True,
                            "generated":generated,
                            "rewards":rewards.tolist(),
                            "parseable":[x["parseable"] for x in scored],
                            "gradient_diagnostics":grad_info,
                            "real_completion_gradient_gram":np.asarray(real_gram).tolist(),
                            "designs":{
                                "uniform":{"subsets":u.subsets.tolist(),"probs":u.probs.tolist()},
                                "joint_ewma":{"subsets":j.subsets.tolist(),"probs":j.probs.tolist(),
                                              "decision":metadata["decision"]}},
                            "risk_result":results}
                        write_once(path,{**core,"sha256":digest(core)})
                        created+=1
                        print(f"COMMITTED PHASE6D seed{seed} {arm} checkpoint{step} "
                              f"group{index+1}/{len(tasks)}",flush=True)
            finally:
                if policy is not None:
                    del policy
                    try:
                        import torch
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()
                    except ImportError:
                        pass
    return {"complete":True,"previous_groups":previous,"new_groups":created,
            "total_expected_groups":total}


def report(output: Path) -> dict:
    """Independently recompute exact risks from recorded six-by-six Grams."""
    m,bank=locked(output)
    rows=[]
    for source in m["runs"]:
        cfg=Phase6CConfig(**source["config"])
        seed=source["seed"]
        root=Path(source["root"])
        moment_cp=open_existing_checkpoint(root,"joint_ewma")
        for arm in m["source_arms"]:
            cp=open_existing_checkpoint(root,arm)
            for step in m["snapshots"]:
                state_sha=m["source_states_sha256"][f"{seed}:{arm}:{step}"]
                if file_sha(stored_state(cp,step))!=state_sha:
                    raise RuntimeError("frozen checkpoint no longer matches Phase6D lock")
                moments=_agent_replay(moment_cp,cfg,"joint_ewma",step)
                for index,task in enumerate(bank["tasks_by_seed"][str(seed)]):
                    path=event_path(output,seed,arm,step,index)
                    rec=read_event(path,m=m,bank=bank,seed=seed,arm=arm,
                                   step=step,index=index)
                    if rec is None:
                        raise RuntimeError("Phase6D GPU groups incomplete; run --stage run")
                    if rec["source_state_sha256"]!=state_sha:
                        raise RuntimeError("group bound to wrong model checkpoint")
                    generated=rec["generated"]
                    values=[score_answer(task,x["text"])["reward"]
                            for x in generated["samples"]]
                    if values!=rec["rewards"]:
                        raise RuntimeError("reward verifier replay mismatch")
                    scores=np.asarray(generated["score_features"],float)
                    expected_u=uniform_design(cfg.g,cfg.b)
                    expected_j,_=moments.propose(scores)
                    for method,expected in (("uniform",expected_u),
                                            ("joint_ewma",expected_j)):
                        actual=rec["designs"][method]
                        qa={tuple(z):float(p) for z,p in zip(actual["subsets"],actual["probs"])}
                        qb={tuple(z):float(p) for z,p in zip(expected.subsets,expected.probs)}
                        if set(qa)!=set(qb) or any(abs(qa[k]-qb[k])>2e-7 for k in qa):
                            raise RuntimeError("unverifiable ex-ante sampling design")
                    rebuilt=evaluate_fixed_designs(
                        np.asarray(rec["real_completion_gradient_gram"],float),
                        scores,np.asarray(values,float),expected_u,expected_j)
                    for space in ("real_lora","phase6b_sketch"):
                        for label in ("uniform","joint_ewma"):
                            observed=rec["risk_result"]["risks"][space][label]["risk"]
                            recomputed=rebuilt["risks"][space][label]["risk"]
                            if not math.isclose(observed,recomputed,abs_tol=1e-9,
                                                rel_tol=1e-5):
                                raise RuntimeError("exact-risk analytical replay mismatch")
                    true=rebuilt["risks"]["real_lora"]
                    sketch=rebuilt["risks"]["phase6b_sketch"]
                    rows.append({"seed":seed,"source_arm":arm,"snapshot":step,
                        "group_index":index,"family":task["family"],
                        "positive_rewards":int(sum(values)),
                        "mixed_reward_group":int(0<sum(values)<cfg.g),
                        "design_pair_gap":float(np.max(np.abs(
                            expected_u.pair_inclusions-expected_j.pair_inclusions))),
                        "real_uniform_risk":true["uniform"]["risk"],
                        "real_joint_ewma_risk":true["joint_ewma"]["risk"],
                        "real_gain":true["gain_uniform_minus_joint"],
                        "sketch_uniform_risk":sketch["uniform"]["risk"],
                        "sketch_joint_ewma_risk":sketch["joint_ewma"]["risk"],
                        "sketch_gain":sketch["gain_uniform_minus_joint"],
                        "sketch_predicted_positive_true_negative":int(
                            sketch["gain_uniform_minus_joint"]>1e-12 and
                            true["gain_uniform_minus_joint"]< -1e-12),
                        "true_positive_sketch_predicted_negative":int(
                            true["gain_uniform_minus_joint"]>1e-12 and
                            sketch["gain_uniform_minus_joint"]< -1e-12),
                        "centered_gram_alignment":rebuilt["alignment"]["centered_gram_alignment"]})
    if not rows:
        raise RuntimeError("no Phase6D groups")
    csv_once(Path(output)/"phase6d_group_risk_comparison.csv",rows,list(rows[0]))
    strata={}
    for family in m["families"]:
        for snapshot in m["snapshots"]:
            for arm in m["source_arms"]:
                chosen=[r for r in rows if r["family"]==family and
                        r["source_arm"]==arm and r["snapshot"]==snapshot]
                if not chosen:
                    continue
                per_seed=[]
                for seed in [r["seed"] for r in m["runs"]]:
                    subset=[r for r in chosen if r["seed"]==seed]
                    base=sum(r["real_uniform_risk"] for r in subset)
                    gain=sum(r["real_gain"] for r in subset)
                    proxy_base=sum(r["sketch_uniform_risk"] for r in subset)
                    proxy_gain=sum(r["sketch_gain"] for r in subset)
                    per_seed.append({"seed":seed,
                        "true_relative_risk_gain":gain/base if base>1e-18 else None,
                        "sketch_relative_risk_gain":proxy_gain/proxy_base
                            if proxy_base>1e-18 else None,
                        "groups":len(subset),
                        "positive_groups":sum(r["positive_rewards"]>0 for r in subset),
                        "mixed_reward_groups":sum(r["mixed_reward_group"] for r in subset),
                        "nonuniform_design_groups":sum(r["design_pair_gap"]>1e-8 for r in subset),
                        "sketch_positive_true_negative_groups":sum(
                            r["sketch_predicted_positive_true_negative"] for r in subset),
                        "true_positive_sketch_negative_groups":sum(
                            r["true_positive_sketch_predicted_negative"] for r in subset),
                        "sign_matches":sum((r["real_gain"]>0 and r["sketch_gain"]>0) or
                                            (r["real_gain"]<0 and r["sketch_gain"]<0)
                                            for r in subset),
                        "mean_gram_alignment":float(np.mean([r["centered_gram_alignment"]
                            for r in subset if r["centered_gram_alignment"] is not None]))
                            if any(r["centered_gram_alignment"] is not None for r in subset)
                            else None})
                true_rates=[r["true_relative_risk_gain"] for r in per_seed]
                sketch_rates=[r["sketch_relative_risk_gain"] for r in per_seed]
                name=f"{family}/{arm}/checkpoint{snapshot}"
                strata[name]={"per_seed":per_seed,
                    "true_risk_reduction_by_seed":cluster_interval(true_rates)
                        if all(v is not None for v in true_rates) else None,
                    "sketch_risk_reduction_by_seed":cluster_interval(sketch_rates)
                        if all(v is not None for v in sketch_rates) else None,
                    "insufficient_information_when_uniform_risk_zero":
                        any(v is None for v in true_rates+sketch_rates)}
    result={"phase":"6D","protocol":PROTOCOL,"complete":True,
            "checked_groups":len(rows),"expected":len(m["runs"])*len(m["source_arms"])*
              len(m["snapshots"])*len(bank["tasks_by_seed"][str(m["runs"][0]["seed"])]),
            "risk_definition":"exact conditional squared error of first-order LOO-HT LoRA policy gradient at the frozen source model; not downstream SGD outcome",
            "comparison_unit":"fixed snapshot, source arm, seed, task, SAME 6 continuations and reward vector; 20 exact B=3 subsets",
            "statistical_status":"exploratory; seed-cluster descriptive intervals, repeated groups/checkpoints not independent",
            "audit_scope":"saved Gram/reward/design/checkpoint replay; GPU autograd NOT independently recomputed",
            "strata":strata}
    write_once(Path(output)/"phase6d_summary.json",result)
    return {"complete":True,"checked_groups":len(rows),"strata_count":len(strata)}
