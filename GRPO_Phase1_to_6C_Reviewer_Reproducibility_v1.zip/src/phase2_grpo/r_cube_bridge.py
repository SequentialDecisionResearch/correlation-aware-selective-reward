"""Optional, independently maintained R BalancedSampling::cube comparator.

This module delegates to the **actual CRAN package** when R and the package
are installed. It never silently substitutes a Python approximation. R draws
are for an independent implementation cross-check. Their empirical inclusion
probabilities are not exact finite-draw inclusion probabilities.

R source: https://cran.r-project.org/package=BalancedSampling
"""

import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np

from .design import check_marginals


R_SCRIPT = Path(__file__).resolve().parents[2] / "scripts" / "r_cube_reference.R"


def reference_available(rscript: str = "Rscript") -> bool:
    """Check both R executable and the official BalancedSampling package."""
    if shutil.which(rscript) is None:
        return False
    check = subprocess.run(
        [rscript, "-e", "quit(status=ifelse(requireNamespace('BalancedSampling', quietly=TRUE),0,42))"],
        capture_output=True, text=True, check=False, timeout=30,
    )
    return check.returncode == 0


def reference_cube_draw(
    pi: np.ndarray, budget: int, auxiliaries: np.ndarray, seed: int,
    *, rscript: str = "Rscript", timeout_s: int = 40,
) -> np.ndarray:
    """One sample from *BalancedSampling::cube*, using actual R-side code.

    First R balance column is pi, as required by the documented exact-size
    convention; further columns are the pre-query auxiliary features.
    Both Python and R methods choose size-B subsets, but need not share RNG
    or the identical design distributions.
    """
    pi = check_marginals(pi, budget)
    a = np.asarray(auxiliaries, float)
    if a.ndim != 2 or a.shape[1] != len(pi) or not np.all(np.isfinite(a)):
        raise ValueError("auxiliaries must be a finite p-by-G array")
    if not isinstance(seed, (int, np.integer)) or not 0 <= seed < 2**31:
        raise ValueError("seed must be a nonnegative R-supported integer")
    if not reference_available(rscript):
        raise RuntimeError("Rscript + CRAN BalancedSampling required; install explicitly")

    with tempfile.TemporaryDirectory(prefix="grpo_cube_ref_") as scratch:
        directory = Path(scratch)
        inputs = directory / "cube_input.csv"
        selected = directory / "selected.txt"
        # Each R row represents one unit. The first auxiliary *is* pi.
        matrix = np.column_stack((pi, pi, a.T))
        np.savetxt(inputs, matrix, delimiter=",", fmt="%.17g")
        result = subprocess.run(
            [rscript, str(R_SCRIPT), str(inputs), str(selected), str(seed)],
            capture_output=True, text=True, check=False, timeout=timeout_s,
        )
        if result.returncode:
            raise RuntimeError("R BalancedSampling::cube failed: " + result.stderr[-1500:])
        raw = selected.read_text(encoding="utf-8").strip()
        indices = [int(line) for line in raw.splitlines()] if raw else []
    if len(set(indices)) != budget or any(i < 0 or i >= len(pi) for i in indices):
        raise AssertionError("R reference broke exact-B selection or unique indices")
    z = np.zeros(len(pi), dtype=np.int8)
    z[indices] = 1
    return z
