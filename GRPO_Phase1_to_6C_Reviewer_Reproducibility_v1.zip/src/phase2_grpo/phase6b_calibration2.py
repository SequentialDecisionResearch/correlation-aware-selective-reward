"""Phase6B Calibration-2: exploratory task selection then sealed policy comparison.

The pilot may inspect binary rewards ONLY to select a task family. A separate
namespace and untouched evaluation seeds are used to compare five fixed-budget
acquisition designs. All stages have atomic per-group checkpoints and audits.
This extension does not modify v1.2 Phase6A/6B/6C source fingerprints.
"""

from dataclasses import asdict, dataclass
import csv
import hashlib
from pathlib import Path
import platform
from types import SimpleNamespace
from typing import Callable

import numpy as np
import scipy
from scipy.stats import t as student_t

from .design import ExactBDesign
from .geometry import gradient_map
from .online_study import OnlineAcquirer
from .phase6a_checkpoint import Checkpoints, atomic_json, digest, run_lock
from .phase6a_model import FakeBackend, group_seed, decision_seed
from .phase6a_study import (METHODS, _backend, _check_generation, _record_one,
                             _restore_agent, _policy_config, source_hashes)
from .phase6a_tasks import ANSWER_INSTRUCTION, score_answer


FAMILIES = ("add_small", "subtract_small", "multiply_single", "two_digit_add",
            "multiply_then_add", "mod_small", "word_single")
PILOT_SEEDS = (9217, 9241)
EVAL_SEEDS = (9323, 9349, 9371)


@dataclass(frozen=True)
class Calibration2Config:
    pilot_groups: int = 6
    eval_groups: int = 60
    pilot_seeds: tuple[int, ...] = PILOT_SEEDS
    eval_seeds: tuple[int, ...] = EVAL_SEEDS
    families: tuple[str, ...] = FAMILIES
    g: int = 6
    b: int = 3
    warmup: int = 12
    window: int = 9
    exploration: float = .25
    max_new_tokens: int = 64
    min_positive_rate: float = .15
    max_positive_rate: float = .85
    min_diverse_group_fraction: float = .20
    backend: str = "hf"
    model: str = "Qwen/Qwen2.5-0.5B-Instruct"
    model_revision: str = "main"
    device: str = "cuda"
    local_files_only: bool = False

    def __post_init__(self):
        if (self.pilot_groups < 3 or self.eval_groups < 3 or
                self.g != 6 or self.b != 3 or
                self.warmup < 1 or self.warmup >= self.eval_groups or
                self.window < 3 or not 0 < self.exploration < 1 or
                not 2 <= self.max_new_tokens <= 1024 or
                not 0 <= self.min_positive_rate < self.max_positive_rate <= 1 or
                not 0 <= self.min_diverse_group_fraction <= 1 or
                self.backend not in ("hf", "fake") or not self.model or
                not self.model_revision or not self.pilot_seeds or
                not self.eval_seeds or not self.families or
                len(set(self.pilot_seeds)) != len(self.pilot_seeds) or
                len(set(self.eval_seeds)) != len(self.eval_seeds) or
                set(self.pilot_seeds) & set(self.eval_seeds) or
                any(int(s) < 0 for s in self.pilot_seeds+self.eval_seeds) or
                len(set(self.families)) != len(self.families) or
                any(f not in FAMILIES for f in self.families)):
            raise ValueError("invalid, overlapping, or unidentifiable calibration configuration")


def task_bank(count: int, seed: int, family: str, *, split: str) -> list[dict]:
    """Independently seeded deterministic prompts; answers never sent to LLM."""
    if family not in FAMILIES or split not in ("pilot", "eval") or count < 1:
        raise ValueError("invalid family, split, or task count")
    namespace = 105 if split == "pilot" else 205
    tasks=[]
    for i in range(count):
        rng=np.random.default_rng(np.random.SeedSequence(
            [20261025, namespace, FAMILIES.index(family), seed, i]))
        if family == "add_small":
            a,b=map(int,rng.integers(1,10,size=2))
            expr,answer=f"{a} + {b}",a+b
        elif family == "subtract_small":
            a=int(rng.integers(12,42));b=int(rng.integers(1,a))
            expr,answer=f"{a} - {b}",a-b
        elif family == "multiply_single":
            a,b=map(int,rng.integers(2,10,size=2))
            expr,answer=f"{a} × {b}",a*b
        elif family == "two_digit_add":
            a,b=map(int,rng.integers(11,80,size=2))
            expr,answer=f"{a} + {b}",a+b
        elif family == "multiply_then_add":
            a,b,c=map(int,rng.integers(2,15,size=3))
            expr,answer=f"({a} × {b}) + {c}",a*b+c
        elif family == "mod_small":
            a,b=map(int,rng.integers(8,80,size=2))
            modulus=int(rng.integers(3,19))
            expr,answer=f"({a} + {b}) mod {modulus}",(a+b)%modulus
        else:
            a,b,c=map(int,rng.integers(2,20,size=3))
            expr,answer=(f"A basket contains {a} red apples and {b} green apples. "
                         f"After {c} more apples are added, how many apples are there?"),a+b+c
        prompt=(f"Compute exactly: {expr}." if family != "word_single"
                else expr)
        if family == "mod_small":
            prompt += " Here 'mod' denotes the nonnegative remainder."
        prompt += " " + ANSWER_INSTRUCTION
        tasks.append({"id":i,"family":family,"level":family,
                      "prompt":prompt,"answer":int(answer)})
    return tasks


def _locked(cfg: Calibration2Config) -> dict:
    base=Path(__file__).resolve().parents[2]
    hashes=source_hashes()
    for name in ("src/phase2_grpo/phase6b_calibration2.py",
                 "scripts/run_phase6b_calibration2.py"):
        hashes[name]=hashlib.sha256((base/name).read_bytes()).hexdigest()
    config=asdict(cfg)
    for key in ("pilot_seeds","eval_seeds","families"):
        config[key]=list(config[key])
    return {"phase":"6B_Calibration2","schema":1,"config":config,
            "source_sha256":hashes,
            "versions":{"python":platform.python_version(),
                        "numpy":np.__version__,"scipy":scipy.__version__},
            "status":"post_v12_exploratory_selection_then_independent_evaluation",
            "reward_protocol":"v1.2_explicit_final_integer",
            "selection":"maximize_2_to_4_reward_groups_with_frozen_thresholds",
            "fixed_marginals":cfg.b/cfg.g}


def _cp(cfg,root,split,seed,family,selection=None):
    if split == "pilot":
        directory=root/"pilot"/f"{family}_seed{seed}"
        manifest={**_locked(cfg),"split":"pilot","seed":seed,"family":family}
        count=cfg.pilot_groups
    else:
        if selection is None or family!=selection["selected_family"]:
            raise ValueError("independent evaluation requires frozen family selection")
        directory=root/"eval"/f"seed{seed}"
        manifest={**_locked(cfg),"split":"eval","seed":seed,"family":family,
                  "selection_sha256":digest(selection)}
        count=cfg.eval_groups
    cp=Checkpoints(directory,manifest)
    tasks=task_bank(count,seed,family,split=split)
    old=cp.load("tasks",0)
    if old is None:
        cp.save("tasks",0,{"tasks":tasks})
    elif old["tasks"] != tasks:
        raise RuntimeError("task bank changed during resume")
    return cp,tasks


def _backend_checked(cfg,root,backend_factory):
    backend=backend_factory(cfg)
    info=backend.info()
    cp=Checkpoints(root,_locked(cfg))
    old=cp.load("model_info",0)
    if old is None:
        cp.save("model_info",0,info)
    elif old!=info:
        raise RuntimeError("Qwen model fingerprint changed across pilot/evaluation")
    return backend


def _generation_seed(split,seed,family):
    return int(np.random.SeedSequence(
        [20261025,105 if split=="pilot" else 205,seed,FAMILIES.index(family)]
    ).generate_state(1)[0])


def _generate_case(cfg,root,split,seed,family,selection,remaining,backend_factory,
                   backend_state,progress):
    cp,tasks=_cp(cfg,root,split,seed,family,selection)
    count=len(tasks)
    completed=cp.contiguous_count("generations",count)
    oracle_done=cp.contiguous_count("shadow_oracle",count)
    if oracle_done>completed:
        raise RuntimeError("oracle exists without matching generation")
    if completed<count and (remaining is None or remaining>0):
        if backend_state[0] is None:
            backend_state[0]=_backend_checked(cfg,root,backend_factory)
        backend=backend_state[0]
        backend_info=backend.info()
        recorded=cp.load("backend_info",0)
        if recorded is None:cp.save("backend_info",0,backend_info)
        elif recorded!=backend_info:
            raise RuntimeError("model changed while resuming a cell")
        end=count if remaining is None else min(count,completed+remaining)
        base_seed=_generation_seed(split,seed,family)
        for i in range(completed,end):
            public={k:tasks[i][k] for k in ("id","level","prompt")}
            if "answer" in public:
                raise AssertionError("gold leaked to generation backend")
            sample=backend.generate(public,group_seed(base_seed,i),cfg.g,cfg.max_new_tokens)
            _check_generation(sample,cfg)
            cp.save("generations",i,sample)
            if progress:progress(split,seed,family,"generated",i+1,count)
        newly=end-completed
        completed=end
    else:
        newly=0
    # Cheap oracle is written only after generation; never forwarded to policy.
    for i in range(oracle_done,completed):
        sample=cp.load("generations",i)
        scored=[score_answer(tasks[i],c) for c in sample["completions"]]
        cp.save("shadow_oracle",i,{
            "full_rewards":[s["reward"] for s in scored],
            "full_parseable":[s["parseable"] for s in scored],
            "full_format_compliant":[s["format_compliant"] for s in scored],
            "generator_sha256":digest(sample)})
    return newly,completed


def _pilot_stats(cfg,root):
    records={};complete=True
    for family in cfg.families:
        ks=[];parsed=[];strict=[]
        for seed in cfg.pilot_seeds:
            cp,_=_cp(cfg,root,"pilot",seed,family)
            n=cp.contiguous_count("shadow_oracle",cfg.pilot_groups)
            complete &= n==cfg.pilot_groups
            for i in range(n):
                oracle=cp.load("shadow_oracle",i)
                ks.append(int(sum(oracle["full_rewards"])))
                parsed.extend(oracle["full_parseable"])
                strict.extend(oracle["full_format_compliant"])
        groups=len(ks)
        records[family]={"groups":groups,"samples":groups*cfg.g,
            "positives_per_group":ks,
            "reward_positive_fraction":float(sum(ks)/(groups*cfg.g)) if groups else None,
            "multi_positive_fraction":float(sum(2<=k<=4 for k in ks)/groups) if groups else None,
            "one_positive_fraction":float(sum(k==1 for k in ks)/groups) if groups else None,
            "all_zero_fraction":float(sum(k==0 for k in ks)/groups) if groups else None,
            "parseable_fraction":float(np.mean(parsed)) if parsed else None,
            "strict_format_fraction":float(np.mean(strict)) if strict else None}
    return bool(complete),records


def _choose_family(cfg,stats):
    """Pure, prespecified gate/ranking; reused by selection audit."""
    eligible=[family for family in cfg.families if
        cfg.min_positive_rate<=stats[family]["reward_positive_fraction"]<=cfg.max_positive_rate
        and stats[family]["multi_positive_fraction"]>=cfg.min_diverse_group_fraction]
    if not eligible:
        selection={"status":"no_eligible_family","selected_family":None,
                   "eligible_families":[],"family_statistics":stats,
                   "reason":"all prespecified reward-diversity gates failed; DO NOT use heldout"}
    else:
        # Deterministic tie break by the prespecified family order.
        winner=max(eligible,key=lambda family:(
            stats[family]["multi_positive_fraction"],
            -abs(stats[family]["reward_positive_fraction"]-.5),
            -cfg.families.index(family)))
        selection={"status":"selected","selected_family":winner,
                   "eligible_families":eligible,"family_statistics":stats,
                   "selection_rule":"max_multi_positive;then_closeness_to_half;then_fixed_order"}
    return selection


def _freeze_selection(cfg,root):
    complete,stats=_pilot_stats(cfg,root)
    if not complete:
        return {"status":"pending_pilot","family_statistics":stats}
    cp=Checkpoints(root,_locked(cfg))
    old=cp.load("selection",0)
    if old is not None:
        if old!=_choose_family(cfg,stats):
            raise RuntimeError("frozen selection disagrees with replayed pilot")
        return old
    selection=_choose_family(cfg,stats)
    cp.save("selection",0,selection)
    atomic_json(root/"calibration2_selection.json",selection)
    return selection


def _load_selection(cfg,root):
    cp=Checkpoints(root,_locked(cfg))
    value=cp.load("selection",0)
    if value is None or value["status"]!="selected":
        raise RuntimeError("pilot selection absent/ineligible; evaluation is BLOCKED")
    return value


def _evaluate_case(cfg,root,seed,selection,remaining,progress):
    family=selection["selected_family"]
    cp,tasks=_cp(cfg,root,"eval",seed,family,selection)
    n=cp.contiguous_count("generations",cfg.eval_groups)
    if n<cfg.eval_groups or cp.contiguous_count("shadow_oracle",cfg.eval_groups)<cfg.eval_groups:
        return 0,False
    policy_cfg=SimpleNamespace(**asdict(cfg),groups=cfg.eval_groups,master_seed=seed)
    acquired=0
    for method in METHODS:
        done=cp.contiguous_count(f"acq_{method}",cfg.eval_groups)
        agent=_restore_agent(cp,method,policy_cfg,done)
        for i in range(done,cfg.eval_groups):
            if remaining is not None and acquired>=remaining:
                return acquired,False
            sample=cp.load("generations",i)
            oracle=cp.load("shadow_oracle",i)
            if oracle["generator_sha256"]!=digest(sample):
                raise RuntimeError("oracle/generation checksum join failed")
            row=_record_one(agent,method,i,policy_cfg,sample,oracle,tasks[i])
            cp.save(f"acq_{method}",i,row)
            acquired+=1
            if progress and (i+1)%10==0:progress("eval",seed,family,method,i+1,cfg.eval_groups)
    return acquired,True


def summarize(cfg,root):
    root=Path(root)
    pilot_complete,pilot=_pilot_stats(cfg,root)
    cp=Checkpoints(root,_locked(cfg))
    selection=cp.load("selection",0)
    metrics=[];progress={};seed_gains={method:{} for method in METHODS if method!="uniform"}
    eval_complete=bool(selection and selection["status"]=="selected")
    group_data=[]
    if eval_complete:
        family=selection["selected_family"]
        for seed in cfg.eval_seeds:
            cell,tasks=_cp(cfg,root,"eval",seed,family,selection)
            progress[str(seed)]={method:cell.contiguous_count(f"acq_{method}",cfg.eval_groups)
                                 for method in METHODS}
            eval_complete &= all(n==cfg.eval_groups for n in progress[str(seed)].values())
            if not all(n==cfg.eval_groups for n in progress[str(seed)].values()):
                continue
            for i in range(cfg.eval_groups):
                oracle=cell.load("shadow_oracle",i)
                k=int(sum(oracle["full_rewards"]))
                uniform=cell.load("acq_uniform",i)["linear_design_risk_exact"]
                group_data.append({"seed":seed,"group":i,"positive_rewards":k,
                                   "multi_positive":int(2<=k<cfg.g)})
                for method in METHODS:
                    row=cell.load(f"acq_{method}",i)
                    gain=float(uniform-row["linear_design_risk_exact"])
                    design=ExactBDesign(np.asarray(row["design"]["subsets"]),
                                        np.asarray(row["design"]["probs"]),"summary")
                    standard=ExactBDesign(np.asarray(cell.load("acq_uniform",i)["design"]["subsets"]),
                                          np.asarray(cell.load("acq_uniform",i)["design"]["probs"]),"summary_uniform")
                    pair_gap=float(np.max(np.abs(design.pair_inclusions-
                                                  standard.pair_inclusions)))
                    metrics.append({"seed":seed,"group":i,"family":family,"policy":method,
                        "positive_rewards":k,"multi_positive":int(2<=k<cfg.g),
                        "exact_linear_risk":row["linear_design_risk_exact"],
                        "gain_vs_uniform":gain,"max_pair_prob_gap_vs_uniform":pair_gap,
                        "decision":row["decision"],"logical_paid_queries":row["logical_paid_queries"]})
                    if method!="uniform":seed_gains[method].setdefault(seed,[]).append(gain)
    result={"phase":"6B_Calibration2","backend":cfg.backend,
            "complete":bool(eval_complete),"pilot_complete":pilot_complete,
            "selected_family":None if selection is None else selection["selected_family"],
            "selection_status":None if selection is None else selection["status"],
            "pilot_statistics":pilot,"evaluation_progress":progress,
            "evaluation_groups_complete":len(group_data),
            "evaluation_multi_positive_group_fraction":(float(np.mean(
                [g["multi_positive"] for g in group_data])) if group_data else None),
            "evaluation_one_positive_group_fraction":(float(np.mean(
                [g["positive_rewards"]==1 for g in group_data])) if group_data else None),
            "rows_available":len(metrics),
            "statistical_status":"exploratory calibrated family; heldout seed-cluster descriptive intervals only",
            "oracle_cost_boundary":"locally computed exact verifier; logical query budgets only"}
    if metrics:
        with (root/"calibration2_eval_policy_rows.csv").open("w",newline="",encoding="utf-8") as stream:
            writer=csv.DictWriter(stream,fieldnames=list(metrics[0]));writer.writeheader();writer.writerows(metrics)
    if eval_complete:
        result["paired_vs_uniform"]={}
        for method,by_seed in seed_gains.items():
            averages=np.asarray([float(np.mean(by_seed[seed])) for seed in cfg.eval_seeds])
            mean=float(averages.mean())
            half=(float(student_t.ppf(.975,len(averages)-1)*averages.std(ddof=1)/
                        np.sqrt(len(averages))) if len(averages)>1 else None)
            result["paired_vs_uniform"][method]={"mean_gain":mean,
                "seed_cluster_t95":None if half is None else [mean-half,mean+half],
                "per_seed_mean_gain":{str(seed):float(v) for seed,v in zip(cfg.eval_seeds,averages)},
                "gain_interpretable_only_when_multi_positive_groups_present":True}
        result["meaningful_cross_reward_interactions"]=(sum(g["multi_positive"]
             for g in group_data)>0)
    atomic_json(root/"calibration2_summary.json",result)
    return result


def audit(cfg,root):
    root=Path(root)
    selection=_load_selection(cfg,root)
    family=selection["selected_family"]
    checked=0;violations=[]
    # Calibration itself is audited, including the decision rule: no hidden
    # evaluation labels or manual post-selection alteration can choose a family.
    pilot_complete,pilot_stats=_pilot_stats(cfg,root)
    if not pilot_complete or _choose_family(cfg,pilot_stats)!=selection:
        raise AssertionError("pilot selection fails deterministic replay")
    checked_pilot=0
    for candidate in cfg.families:
        for pilot_seed in cfg.pilot_seeds:
            pilot_cp,pilot_tasks=_cp(cfg,root,"pilot",pilot_seed,candidate)
            if pilot_cp.contiguous_count("generations",cfg.pilot_groups)!=cfg.pilot_groups:
                raise AssertionError("pilot generations incomplete")
            for i in range(cfg.pilot_groups):
                generated=pilot_cp.load("generations",i)
                oracle=pilot_cp.load("shadow_oracle",i)
                rescored=[score_answer(pilot_tasks[i],text) for text in generated["completions"]]
                for field,key in (("full_rewards","reward"),
                                  ("full_parseable","parseable"),
                                  ("full_format_compliant","format_compliant")):
                    if oracle[field]!=[x[key] for x in rescored]:
                        raise AssertionError("pilot oracle differs from scorer replay")
                if oracle["generator_sha256"]!=digest(generated):
                    raise AssertionError("pilot generation/oracle binding corrupted")
                checked_pilot+=1
    for seed in cfg.eval_seeds:
        cp,tasks=_cp(cfg,root,"eval",seed,family,selection)
        if any(cp.contiguous_count(f"acq_{method}",cfg.eval_groups)!=cfg.eval_groups
               for method in METHODS):
            raise RuntimeError("audit requires complete independent evaluation")
        policy_cfg=SimpleNamespace(**asdict(cfg),groups=cfg.eval_groups,master_seed=seed)
        for method in METHODS:
            agent=OnlineAcquirer(method,_policy_config(policy_cfg))
            for i in range(cfg.eval_groups):
                try:
                    row=cp.load(f"acq_{method}",i)
                    sample=cp.load("generations",i)
                    oracle=cp.load("shadow_oracle",i)
                    rescored=[score_answer(tasks[i],x) for x in sample["completions"]]
                    for field,kind in (("full_rewards","reward"),
                                       ("full_parseable","parseable"),
                                       ("full_format_compliant","format_compliant")):
                        if oracle[field]!=[s[kind] for s in rescored]:
                            raise AssertionError("oracle scoring discrepancy")
                    if (oracle["generator_sha256"]!=digest(sample) or
                            row["oracle_sha256"]!=digest(oracle) or
                            row["generator_sha256"]!=digest(sample)):
                        raise AssertionError("broken generation/oracle join")
                    scores=np.asarray(sample["score_features"],float)
                    proposal,_=agent.propose(scores)
                    design=ExactBDesign(np.asarray(row["design"]["subsets"]),
                                        np.asarray(row["design"]["probs"]),"audit")
                    if (set(map(tuple,proposal.subsets))!=set(map(tuple,design.subsets)) or
                            np.max(np.abs(proposal.pair_inclusions-design.pair_inclusions))>2e-7):
                        raise AssertionError("online proposal mismatch")
                    selected=np.asarray(row["selected"],bool)
                    expected=proposal.draw(np.random.default_rng(decision_seed(
                        seed,method,i))).astype(bool)
                    if not np.array_equal(selected,expected) or selected.sum()!=cfg.b:
                        raise AssertionError("selection RNG or budget changed")
                    rewards=np.asarray(oracle["full_rewards"],float)
                    if not np.array_equal(rewards[selected],row["paid_rewards"]):
                        raise AssertionError("purchased rewards mismatch")
                    m=gradient_map(scores);pi=design.marginals
                    pair=design.pair_inclusions
                    v=float(max(0.,rewards@((pair/np.outer(pi,pi)-1)*(m.T@m))@rewards))
                    if not np.isclose(v,row["linear_design_risk_exact"],atol=1e-8):
                        raise AssertionError("exact risk differs from independent audit")
                    observed=np.full(cfg.g,np.nan);observed[selected]=rewards[selected]
                    agent.observe(observed,selected,design)
                    checked+=1
                except Exception as exc:
                    violations.append(f"{seed}/{method}/{i}: {exc}")
                    break
    result={"pass":not violations,"checked_decisions":checked,
            "checked_pilot_groups":checked_pilot,
            "expected":len(cfg.eval_seeds)*cfg.eval_groups*len(METHODS),
            "violations":violations,
            "scope":"internal audit only; not independent scientific replication"}
    atomic_json(root/"calibration2_audit.json",result)
    if violations:raise AssertionError("Calibration-2 audit failure: "+violations[0])
    return result


def run(cfg,root,*,stage="all",max_new_groups=None,max_new_decisions=None,
        backend_factory:Callable=_backend,progress=None):
    if stage not in ("all","pilot","select","evaluate","summary","audit"):
        raise ValueError("unknown calibration2 stage")
    if (max_new_groups is not None and max_new_groups<0 or
            max_new_decisions is not None and max_new_decisions<0):
        raise ValueError("negative execution budget")
    root=Path(root)
    with run_lock(root):
        Checkpoints(root,_locked(cfg))
        backend_state=[None]
        if stage in ("all","pilot"):
            remaining=max_new_groups
            for family in cfg.families:
                for seed in cfg.pilot_seeds:
                    new,_=_generate_case(cfg,root,"pilot",seed,family,None,
                        remaining,backend_factory,backend_state,progress)
                    if remaining is not None:remaining-=new
            if stage=="pilot":return summarize(cfg,root)
        if stage in ("all","select"):
            selected=_freeze_selection(cfg,root)
            if stage=="select":return selected
            if selected["status"]!="selected":return summarize(cfg,root)
        if stage in ("all","evaluate"):
            selection=_load_selection(cfg,root)
            remaining=max_new_groups
            for seed in cfg.eval_seeds:
                new,_=_generate_case(cfg,root,"eval",seed,
                    selection["selected_family"],selection,remaining,
                    backend_factory,backend_state,progress)
                if remaining is not None:remaining-=new
            remaining=max_new_decisions
            for seed in cfg.eval_seeds:
                new,_=_evaluate_case(cfg,root,seed,selection,remaining,progress)
                if remaining is not None:remaining-=new
        if stage=="audit":return audit(cfg,root)
        result=summarize(cfg,root)
        if stage in ("all","evaluate") and result["complete"]:
            result["audit"]=audit(cfg,root)
        return result
