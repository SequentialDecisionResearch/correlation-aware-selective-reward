"""Calibrated-on-development-nulls drift monitor and damage-limited fallback.

This is an EMPIRICAL calibration, not a sequential type-I guarantee.
The risk contrast uses historical masked IPW observations; its standard-
error multiplier is an informal stability diagnostic, not a confidence
sequence valid under drift and adaptive sampling.
"""

from collections import deque
from dataclasses import dataclass

import numpy as np

from .balanced import auxiliary_balance_lp
from .design import ExactBDesign, uniform_design
from .geometry import gradient_map
from .online_moments import OnlineSecondMoment, mix_design
from .online_study import OnlineConfig
from .optimization import optimize_coupling
from .risk import acquisition_weight


@dataclass(frozen=True)
class GuardSpec:
    drift_threshold: float
    patience: int = 3
    max_rollback: float = .25
    uncertainty_rollback: float = .10
    alert_rollback: float = .05
    guard_window: int = 24
    clip_matrix_norm: float = 18.
    effect_clip: float = 50.
    empirical_z: float = 2.0

    def __post_init__(self):
        if (not np.isfinite(self.drift_threshold) or self.drift_threshold <= 0
                or self.patience < 2 or self.guard_window < 6
                or not 0 <= self.alert_rollback <= self.max_rollback <= 1
                or not 0 <= self.uncertainty_rollback <= self.max_rollback
                or self.clip_matrix_norm <= 0 or self.effect_clip <= 0
                or self.empirical_z < 0):
            raise ValueError("invalid frozen guard specification")


class ClippedWindowMonitor:
    """Bilinear IPW change contrast, bounded per-step for robustness.

    Monitoring a clipped series may miss a genuine change. Clipping does not
    alter the separate un-clipped arithmetic estimator for E[e_i e_j].
    """

    def __init__(self, g: int, window: int, clip_matrix_norm: float):
        self.g = g
        self.window = window
        self.bound = clip_matrix_norm
        self.history: deque[np.ndarray] = deque(maxlen=2*window)
        self.score_history: list[float] = []
        self.last_score = 0.

    def update(self, observed: np.ndarray, selected: np.ndarray,
               design: ExactBDesign) -> float:
        z = np.asarray(selected, dtype=bool)
        e = np.zeros(self.g)
        e[z] = np.asarray(observed, float)[z]
        joint = design.pair_inclusions
        if np.min(joint) <= 0:
            raise ValueError("monitor requires strictly positive pair support")
        h = np.outer(e,e) / joint
        if not np.all(np.isfinite(h)):
            raise ValueError("nonfinite IPW contrast: residual magnitude exceeds numeric limits")
        peak=float(np.max(np.abs(h)))
        if peak>0:
            # Scale BEFORE Frobenius norm, so large but finite residuals do
            # not silently overflow to infinity and get converted to zero.
            unit=h/peak
            stable_norm=float(np.linalg.norm(unit,"fro"))
            if peak>self.bound/stable_norm:
                h=unit*(self.bound/stable_norm)
        self.history.append(h)
        if len(self.history) < 2*self.window:
            self.score_history.append(0.)
            return 0.
        data = np.stack(tuple(self.history))
        left = data[:self.window].mean(axis=0)
        right = data[self.window:].mean(axis=0)
        self.last_score = float(np.linalg.norm(right-left, "fro") /
                                max(1., np.linalg.norm(left,"fro"),
                                    np.linalg.norm(right,"fro")))
        self.score_history.append(self.last_score)
        return self.last_score

    def reset_window(self):
        self.history.clear()


class GuardedOnlineAcquirer:
    """One-step acquisition API; accepts no hidden current residual at propose.

    Baseline and joint share exact-B marginals, therefore mixing them caps
    exposure to a harmful baseline switch linearly in its probability weight.
    It does not cap absolute risk without a separate bound on moments.
    """

    def __init__(self, config: OnlineConfig, spec: GuardSpec):
        self.cfg = config
        self.spec = spec
        self.uniform = uniform_design(config.g, config.b)
        self.pi = self.uniform.marginals
        self.model = OnlineSecondMoment(config.g, window=config.window,
                                        drift_threshold=999.)
        self.monitor = ClippedWindowMonitor(config.g, config.window,
                                            spec.clip_matrix_norm)
        self.t = 0
        self.cooldown_left = 0
        self.streak = 0
        self.alert_times: list[int] = []

    def _baseline_support_evidence(self, scores: np.ndarray,
                                   baseline: ExactBDesign,
                                   candidate: ExactBDesign) -> tuple[bool,float,float]:
        # Positive contrast means joint is better, negative means baseline.
        weight = acquisition_weight(scores, baseline) - acquisition_weight(scores, candidate)
        history = list(self.model.contributions)[-self.spec.guard_window:]
        if len(history) < 12:
            return False, float("nan"), float("nan")
        x = np.array([float(np.sum(h*weight)) for h in history])
        x = np.clip(x, -self.spec.effect_clip, self.spec.effect_clip)
        mean = float(x.mean())
        upper = float(mean + self.spec.empirical_z*x.std(ddof=1)/np.sqrt(len(x)))
        return bool(upper < 0.), mean, upper

    def propose(self, scores: np.ndarray) -> tuple[ExactBDesign, dict]:
        if self.t < self.cfg.warmup:
            return self.uniform, {"decision":"warmup_uniform",
                                  "rollback_fraction":0., "evidence_upper":float("nan"),
                                  "pair_ess_before":self.model.min_pair_ess()}
        m = gradient_map(scores)
        vhat = self.model.fitted
        auxiliary = m*np.sqrt(np.maximum(np.diag(vhat),0.))[None,:]
        baseline = auxiliary_balance_lp(self.pi,self.cfg.b,auxiliary)
        joint,_ = optimize_coupling(scores,vhat,self.pi,self.cfg.b)
        ess = self.model.min_pair_ess()
        certified,_,upper = self._baseline_support_evidence(scores,baseline,joint)
        fraction=0.
        if self.cooldown_left > 0:
            fraction=(self.spec.max_rollback if certified
                      else self.spec.alert_rollback)
            decision="post_alert_evidence_rollback" if certified else "post_alert_minimal_mix"
            self.cooldown_left -= 1
        elif ess < self.cfg.min_pair_ess:
            fraction=self.spec.uncertainty_rollback
            decision="low_pair_ess_limited_mix"
        else:
            decision="adaptive_joint"
        proposed = mix_design(joint,baseline,fraction) if fraction>0 else joint
        mixed=mix_design(proposed,self.uniform,self.cfg.exploration)
        np.testing.assert_allclose(mixed.marginals,self.pi,atol=1e-8)
        return mixed, {"decision":decision,"rollback_fraction":fraction,
                       "evidence_upper":upper,"pair_ess_before":ess}

    def observe(self, observed: np.ndarray, selected: np.ndarray,
                design: ExactBDesign) -> dict:
        report=self.model.update(observed,selected,design,allow_detection=False)
        statistic=self.monitor.update(observed,selected,design)
        self.t += 1
        eligible=(len(self.monitor.history)==2*self.cfg.window)
        if eligible and statistic>self.spec.drift_threshold:
            self.streak+=1
        else:
            self.streak=0
        alarm=(self.streak>=self.spec.patience and self.cooldown_left==0)
        if alarm:
            self.alert_times.append(self.t)
            self.cooldown_left=self.cfg.cooldown
            self.streak=0
            self.monitor.reset_window()
            # Drop potentially obsolete off-diagonal residual moments.
            # The diagonal keeps its last positive scale; records are cleared
            # as a transparent conservative response to the alert.
            self.model.ewma=np.diag(np.maximum(np.diag(self.model.ewma),.1))
            self.model.contributions.clear()
            self.model.weights.clear()
        return {"drift_score":statistic,"alert":int(alarm),
                "pair_ess_after":report.min_pair_ess}


def maximum_patience_score(scores: list[float], patience: int,
                           initial_step: int = 0) -> float:
    """Max all-step threshold yielding a sustained patience-run alarm."""
    a=np.asarray(scores,dtype=float)[initial_step:]
    if len(a)<patience:
        return 0.
    return float(max(min(a[i:i+patience]) for i in range(len(a)-patience+1)))
