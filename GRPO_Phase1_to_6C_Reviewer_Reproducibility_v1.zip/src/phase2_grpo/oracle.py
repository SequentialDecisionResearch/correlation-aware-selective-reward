"""Audit-friendly oracle access contract for controlled simulation."""

import numpy as np


class CountingOracle:
    """Full outcomes reside privately in the test world; requests are metered.

    Optimizers accept public candidate scores and Vhat, never this object.
    This is an interface test, not a security sandbox for adversarial Python.
    """

    def __init__(self, rewards: np.ndarray):
        self._rewards = np.asarray(rewards, dtype=float).copy()
        if self._rewards.ndim != 1 or not np.all(np.isfinite(self._rewards)):
            raise ValueError("oracle rewards must be a finite vector")
        self._seen = np.zeros(len(self._rewards), dtype=bool)
        self.calls = 0

    def reveal(self, indices: np.ndarray) -> np.ndarray:
        indices = np.asarray(indices)
        if indices.ndim != 1 or not np.issubdtype(indices.dtype, np.integer):
            raise ValueError("indices must be an integer vector")
        if np.any(indices < 0) or np.any(indices >= len(self._seen)):
            raise ValueError("index outside candidate set")
        if len(set(indices.tolist())) != len(indices) or np.any(self._seen[indices]):
            raise ValueError("duplicate reward purchase")
        self._seen[indices] = True
        self.calls += len(indices)
        return self._rewards[indices].copy()

    def purchased_vector(self) -> np.ndarray:
        result = np.full(len(self._seen), np.nan)
        result[self._seen] = self._rewards[self._seen]
        return result

    @property
    def queried_mask(self) -> np.ndarray:
        return self._seen.copy()

