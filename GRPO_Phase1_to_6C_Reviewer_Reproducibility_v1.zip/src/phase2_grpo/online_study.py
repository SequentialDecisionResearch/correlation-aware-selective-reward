"""Online synthetic GRPO *surrogate* acquisition under residual drift.

The online estimator receives only acquired e_i with the actual mixture
propensities. True V and the full latent reward vector are sequestered in
the evaluation driver. All methods share the same scores, residual world,
group size, exact budget and prescribed marginal pi=B/G.

This is not token-level clipped GRPO and not actual LLM fine-tuning.
"""

import csv
from dataclasses import dataclass
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.stats import t as student_t

from .balanced import auxiliary_balance_lp
from .classic_cube import cube_full_flight_landing
from .design import ExactBDesign, uniform_design
from .geometry import gradient_map
from .online_moments import OnlineSecondMoment, mix_design
from .optimization import optimize_coupling
from .oracle import CountingOracle
from .risk import acquisition_risk, augmented_rewards
from .phase2_study import covariance_profile


POLICIES = ("uniform", "cube_classic", "scaled", "joint_ewma",
            "joint_frozen", "drift_gated")
SCENARIOS = {
    "stationary_signed": ("signed_factor", "signed_factor"),
    "signed_to_common": ("signed_factor", "common_strong"),
    "common_to_signed": ("common_strong", "signed_factor"),
    "signed_to_negative": ("signed_factor", "negative_equicorr"),
    "blocks_to_signed": ("two_blocks", "signed_factor"),
}
SEEDS = (17, 29, 41, 53, 67, 79, 97, 109)


@dataclass(frozen=True)
class OnlineConfig:
    g: int = 6
    b: int = 3
    horizon: int = 160
    warmup: int = 26
    window: int = 18
    cooldown: int = 24
    exploration: float = .25
    min_pair_ess: float = 1.5
    min_gain_fraction: float = .015
    drift_threshold: float = 1.30
    seeds: tuple[int, ...] = SEEDS
    scenarios: tuple[str, ...] = tuple(SCENARIOS)

    def __post_init__(self):
        if (self.g < 4 or not 2 <= self.b < self.g - 1
                or self.horizon < 4 * self.window
                or self.warmup < 1 or self.warmup >= self.horizon // 2
                or not 0 < self.exploration < 1 or self.cooldown < 1
                or self.window < 3 or self.min_pair_ess < 0
                or self.drift_threshold <= 0 or self.min_gain_fraction < 0
                or not self.seeds or not self.scenarios):
            raise ValueError("invalid online experimental configuration")
        if any(s not in SCENARIOS for s in self.scenarios):
            raise ValueError("unknown covariance scenario")


class OnlineAcquirer:
    """Acquisition policy, state and diagnostics; has NO true covariance API."""

    def __init__(self, method: str, config: OnlineConfig):
        if method not in POLICIES:
            raise ValueError("unknown online policy")
        self.method = method
        self.cfg = config
        self.uniform = uniform_design(config.g, config.b)
        self.pi = self.uniform.marginals
        self.model = OnlineSecondMoment(config.g, window=config.window,
                                        drift_threshold=config.drift_threshold)
        self.t = 0
        self.cooldown_left = 0
        self.frozen_moments: np.ndarray | None = None
        self.alert_times: list[int] = []

    def propose(self, scores: np.ndarray) -> tuple[ExactBDesign, dict]:
        """Build the acquisition Q BEFORE any current gold reward is seen."""
        if self.method == "uniform":
            return self.uniform, {"decision": "uniform", "predicted_gap": 0.,
                                  "pair_ess_before": self.model.min_pair_ess()}
        if self.t < self.cfg.warmup:
            return self.uniform, {"decision": "warmup_uniform", "predicted_gap": 0.,
                                  "pair_ess_before": self.model.min_pair_ess()}
        fit = self.model.fitted
        if self.method == "joint_frozen":
            if self.frozen_moments is None:
                self.frozen_moments = fit.copy()
            fit = self.frozen_moments
        m = gradient_map(scores)
        scaled = m * np.sqrt(np.maximum(np.diag(fit), 0.))[None, :]
        label = self.method
        gap = 0.
        ess = self.model.min_pair_ess()

        if self.method == "cube_classic":
            proposal, _ = cube_full_flight_landing(self.pi, self.cfg.b, scaled)
            label = "cube_full_flight_landing"
        elif self.method == "scaled":
            proposal = auxiliary_balance_lp(self.pi, self.cfg.b, scaled)
            label = "scaled_auxiliary_LP"
        elif self.method in ("joint_ewma", "joint_frozen"):
            proposal, _ = optimize_coupling(scores, fit, self.pi, self.cfg.b)
            label = self.method
        elif self.method == "drift_gated":
            baseline = auxiliary_balance_lp(self.pi, self.cfg.b, scaled)
            candidate, _ = optimize_coupling(scores, fit, self.pi, self.cfg.b)
            risk_base = acquisition_risk(scores, fit, baseline)
            risk_new = acquisition_risk(scores, fit, candidate)
            gap = float(risk_base - risk_new)
            if self.cooldown_left > 0:
                proposal, label = baseline, "drift_cooldown_fallback"
                self.cooldown_left -= 1
            elif ess < self.cfg.min_pair_ess:
                proposal, label = baseline, "insufficient_pair_ess_fallback"
            elif gap <= self.cfg.min_gain_fraction * max(risk_base, 1e-9):
                proposal, label = baseline, "small_predicted_gain_fallback"
            else:
                proposal, label = candidate, "joint_accepted"
        else:
            raise AssertionError("method routing is incomplete")

        chosen = mix_design(proposal, self.uniform, self.cfg.exploration)
        if np.max(np.abs(chosen.marginals - self.pi)) > 1e-7:
            raise AssertionError("candidate changed common marginals")
        pair = chosen.pair_inclusions
        if np.min(pair[np.triu_indices(self.cfg.g, 1)]) <= 0:
            raise AssertionError("exploration mixture lacks pair positivity")
        return chosen, {"decision": label, "predicted_gap": gap,
                        "pair_ess_before": ess}

    def observe(self, observed: np.ndarray, z: np.ndarray,
                design: ExactBDesign) -> dict:
        """Update exclusively with queried labels and pair propensities."""
        report = self.model.update(observed, z, design,
                                   allow_detection=self.method == "drift_gated")
        self.t += 1
        if report.detected:
            self.alert_times.append(self.t)
            self.cooldown_left = self.cfg.cooldown
        return {"drift_score": report.statistic,
                "alert": int(report.detected),
                "pair_ess_after": report.min_pair_ess}


def _one_scenario(seed: int, scenario: str,
                  config: OnlineConfig) -> list[dict]:
    start, finish = SCENARIOS[scenario]
    changed = start != finish
    child_seed = np.random.SeedSequence([20261024, seed,
                                        list(SCENARIOS).index(scenario)])
    scores_rng, reward_rng, *policy_rng = [np.random.default_rng(v)
                                          for v in child_seed.spawn(2 + len(POLICIES))]
    randoms = dict(zip(POLICIES, policy_rng))
    agents = {name: OnlineAcquirer(name, config) for name in POLICIES}
    before = covariance_profile(config.g, start)
    after = covariance_profile(config.g, finish)
    switch_at = config.horizon // 2
    rows = []
    for step in range(config.horizon):
        true_v = before if step < switch_at else after
        score = scores_rng.normal(size=(3, config.g))
        # Hidden *world* e is identical across comparison policies.
        latent_e = reward_rng.multivariate_normal(np.zeros(config.g), true_v)
        oracle_design, _ = optimize_coupling(score, true_v,
                                             agents["uniform"].pi, config.b)
        oracle_risk = acquisition_risk(score, true_v, oracle_design)
        m = gradient_map(score)
        for policy in POLICIES:
            agent = agents[policy]
            start_time = perf_counter()
            design, metadata = agent.propose(score)
            decision_seconds = perf_counter() - start_time
            true_risk = acquisition_risk(score, true_v, design)
            if true_risk + 1e-7 < oracle_risk:
                raise AssertionError("oracle lower bound violated")
            rng = randoms[policy]
            z = design.draw(rng)
            reward_oracle = CountingOracle(latent_e)
            index = np.flatnonzero(z)
            purchased = reward_oracle.reveal(index)
            if reward_oracle.calls != config.b:
                raise AssertionError("unmetered or extra verifier call")
            visible = np.full(config.g, np.nan)
            visible[index] = purchased
            augmented = augmented_rewards(visible, np.zeros(config.g),
                                          z.astype(bool), design.marginals)
            # This error calculation uses latent truth only in EVALUATION.
            observed_mse = float(np.linalg.norm(m @ (augmented - latent_e))**2)
            diagnostics = agent.observe(visible, z.astype(bool), design)
            rows.append({
                "seed": seed, "scenario": scenario,
                "change_truth": int(changed), "switch_at": switch_at,
                "step": step, "phase": "before" if step < switch_at else "after",
                "true_profile": start if step < switch_at else finish,
                "policy": policy, "decision": metadata["decision"],
                "true_risk": float(true_risk), "oracle_risk": float(oracle_risk),
                "regret_oracle": float(true_risk - oracle_risk),
                "observed_squared_gradient_error": observed_mse,
                "verified_queries": reward_oracle.calls,
                "predicted_gap": float(metadata["predicted_gap"]),
                "pair_ess_before": float(metadata["pair_ess_before"]),
                "pair_ess_after": float(diagnostics["pair_ess_after"]),
                "drift_score": float(diagnostics["drift_score"]),
                "alert": diagnostics["alert"],
                "proposal_seconds": decision_seconds,
                "selected_subset": "".join(str(int(x)) for x in z),
                "min_pair_propensity": float(design.pair_inclusions[
                    np.triu_indices(config.g, 1)].min()),
                "estimated_from": "past_purchased_residuals_only",
            })
    return rows


def _seed_ci(values: dict[int, list[float]]) -> dict:
    av = np.asarray([np.mean(val) for _, val in sorted(values.items())], float)
    mean = float(av.mean())
    half = (float(student_t.ppf(.975, len(av) - 1) * av.std(ddof=1) / np.sqrt(len(av)))
            if len(av) > 1 else float("nan"))
    return {"seed_clusters": len(av), "mean": mean,
            "descriptive_t95": [mean-half, mean+half],
            "positive_seed_fraction": float(np.mean(av > 0))}


def summarize_online(rows: list[dict], config: OnlineConfig) -> dict:
    summary = {"label": "exploratory_synthetic_online_no_llm",
               "rows": len(rows), "independent_seeds": len(config.seeds),
               "scenarios": list(config.scenarios), "methods": list(POLICIES),
               "horizon": config.horizon, "change_time": config.horizon//2,
               "B": config.b, "G": config.g, "epsilon": config.exploration,
               "warmup": config.warmup, "monitor_window": config.window,
               "drift_threshold_heuristic": config.drift_threshold,
               "minimum_pair_ESS": config.min_pair_ess,
               "total_verifier_calls": sum(r["verified_queries"] for r in rows),
               "limitations": ["not a real clipped GRPO optimization",
                               "no real verifier latency or prices",
                               "change detector threshold not a level-alpha test",
                               "confidence intervals descriptive after exploratory design",
                               "original R BalancedSampling implementation not called by Python cube study"]}
    sections = {}
    for scenario in config.scenarios:
        for phase in ("before", "after"):
            group = [r for r in rows if r["scenario"]==scenario and r["phase"]==phase]
            uniform = {(r["seed"],r["step"]):r["true_risk"] for r in group
                       if r["policy"]=="uniform"}
            scaled = {(r["seed"],r["step"]):r["true_risk"] for r in group
                      if r["policy"]=="scaled"}
            for name in POLICIES:
                cells = [r for r in group if r["policy"]==name]
                per_seed: dict[int,list[float]] = {}
                per_scaled: dict[int,list[float]] = {}
                for r in cells:
                    key = (r["seed"],r["step"])
                    per_seed.setdefault(r["seed"],[]).append(uniform[key]-r["true_risk"])
                    per_scaled.setdefault(r["seed"],[]).append(scaled[key]-r["true_risk"])
                sections[f"{scenario}|{phase}|{name}"] = {
                    "gain_vs_uniform":_seed_ci(per_seed),
                    "gain_vs_scaled":_seed_ci(per_scaled),
                    "mean_true_risk":float(np.mean([r["true_risk"] for r in cells])),
                    "mean_observed_mse":float(np.mean([
                        r["observed_squared_gradient_error"] for r in cells])),
                    "fallback_fraction":float(np.mean(["fallback" in r["decision"]
                                                      or "warmup" in r["decision"] for r in cells])),
                    "joint_fraction":float(np.mean([r["decision"]=="joint_accepted"
                                                     for r in cells])),
                    "mean_pair_ess":float(np.mean([r["pair_ess_before"] for r in cells])),
                }
    summary["strata"] = sections
    detector = {}
    for scenario in config.scenarios:
        diagnostics = []
        for seed in config.seeds:
            a = sorted(r["step"] for r in rows if r["policy"]=="drift_gated"
                       and r["seed"]==seed and r["scenario"]==scenario and r["alert"])
            early = sum(t < config.horizon//2 for t in a)
            post = [t-config.horizon//2 for t in a if t>=config.horizon//2]
            diagnostics.append({"seed":seed, "alerts":a, "early_false_alerts":early,
                                "post_change_first_delay":min(post) if post else None})
        detector[scenario] = {
            "all_seed_alerts":diagnostics,
            "false_alert_rate_per_prechange_step":float(sum(x["early_false_alerts"]
                  for x in diagnostics)/(len(config.seeds)*(config.horizon//2))),
            "postchange_detection_fraction":float(np.mean([
                x["post_change_first_delay"] is not None for x in diagnostics])),
            "median_detect_delay_among_detected": (
                float(np.median([x["post_change_first_delay"] for x in diagnostics
                                 if x["post_change_first_delay"] is not None]))
                if any(x["post_change_first_delay"] is not None for x in diagnostics)
                else None),
        }
    summary["drift_detector"] = detector
    return summary


def run_online_study(output: str | Path, *, quick: bool = False,
                     config: OnlineConfig | None = None) -> dict:
    if quick and config is not None:
        raise ValueError("specify quick OR a custom config, not both")
    cfg = (config if config is not None else
           OnlineConfig(horizon=80, warmup=12, window=9, cooldown=12,
                        seeds=(17,29),scenarios=("stationary_signed","signed_to_common"))
           if quick else OnlineConfig())
    start = perf_counter()
    rows = []
    for scenario in cfg.scenarios:
        for seed in cfg.seeds:
            rows.extend(_one_scenario(seed, scenario, cfg))
    summary = summarize_online(rows, cfg)
    summary["runtime_seconds"] = perf_counter()-start
    path = Path(output)
    path.mkdir(parents=True, exist_ok=True)
    with (path/"online_trials.csv").open("w",newline="",encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (path/"online_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    return summary
