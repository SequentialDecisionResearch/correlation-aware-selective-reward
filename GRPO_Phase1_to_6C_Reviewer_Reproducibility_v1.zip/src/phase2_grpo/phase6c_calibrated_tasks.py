"""Frozen Calibration-2 Qwen training and heldout task banks.

Only the prespecified task family is reused. The Phase6B pilot/holdout tasks,
the new training tasks, and the new Phase6C heldout prompts are disjoint even
under addition's commutative symmetry. Rewards are never passed to the model.
"""

import re

from .phase6b_calibration2 import task_bank


CALIBRATION_PILOT_SEEDS = (9217, 9241)
CALIBRATION_EVAL_SEEDS = (9323, 9349, 9371)
_EXPRESSION = re.compile(r"^Compute exactly: (\d+) \+ (\d+)\.")


def _key(task: dict) -> tuple[int, int]:
    match = _EXPRESSION.match(task["prompt"])
    if match is None:
        raise ValueError("unexpected two-digit-addition task grammar")
    return tuple(sorted((int(match.group(1)), int(match.group(2)))))


def calibrated_tasks(cfg):
    """Return locked disjoint (training, heldout) tasks for Phase6C only."""
    if cfg.task_family != "two_digit_add":
        raise ValueError("only the independently selected two_digit_add family is supported")

    # Exclude every Phase6B prompt inspected for task-family selection and
    # every independent Phase6B comparison prompt; do not train on either.
    reserved=set()
    for seed in CALIBRATION_PILOT_SEEDS:
        reserved.update(_key(t) for t in task_bank(6,seed,"two_digit_add",split="pilot"))
    for seed in CALIBRATION_EVAL_SEEDS:
        reserved.update(_key(t) for t in task_bank(60,seed,"two_digit_add",split="eval"))

    # Independent namespaces and large deterministic candidate reserves.
    # A protocol that exhausts distinct exercises fails instead of leaking.
    candidate_count=max(256,8*(cfg.steps+cfg.eval_size))
    train_candidates=task_bank(candidate_count,cfg.seed+4_000_000,
                               "two_digit_add",split="pilot")
    eval_candidates=task_bank(candidate_count,cfg.seed+8_000_000,
                              "two_digit_add",split="eval")

    def take(candidates,size,blocked):
        selected=[]
        for task in candidates:
            key=_key(task)
            if key in blocked:
                continue
            blocked.add(key)
            selected.append({**task,"id":len(selected),"level":"two_digit_add"})
            if len(selected)==size:
                break
        if len(selected)!=size:
            raise RuntimeError("distinct arithmetic exercise bank exhausted")
        return selected

    train=take(train_candidates,cfg.steps,reserved)
    heldout=take(eval_candidates,cfg.eval_size,reserved)
    return train,heldout
