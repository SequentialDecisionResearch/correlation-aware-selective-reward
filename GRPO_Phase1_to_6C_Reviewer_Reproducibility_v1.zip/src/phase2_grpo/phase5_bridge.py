"""Exact finite-support check of the linear-to-normalized-GRPO gap.

This study does NOT implement a real GRPO trainer. The experiment isolates
nonlinearity of group standardization and clipping after naive Horvitz--
Thompson reconstruction. It uses exact enumeration over an unchanged,
pre-reward exact-B uniform sampling design, not Monte Carlo approximation.
"""

import json
from itertools import combinations
from pathlib import Path

import numpy as np

from .design import uniform_design
from .geometry import gradient_map


BRIDGE_SEED = 20261115
BRIDGE_GROUPS = 64
BRIDGE_BUDGETS = (1, 2, 3, 4, 5)
G, D = 6, 3


def group_gradient(scores: np.ndarray, rewards: np.ndarray,
                   ratios: np.ndarray | None = None,
                   clip: float = .2) -> np.ndarray:
    """One-step group-normalized and optionally clipped score gradient.

    For the clipped case, `ratios` are fixed numerical values but scores
    act as the *local derivatives of log ratios*. A clipped flat branch has
    derivative zero, not clipped_ratio*advantage. This omits derivative of
    old-policy advantages, the KL term and token averaging.
    """
    centered = rewards - np.mean(rewards)
    scale = max(float(np.sqrt(np.mean(centered**2))), 1e-8)
    advantage = centered / scale
    if ratios is None:
        return scores @ advantage / rewards.size
    clipped = np.clip(ratios, 1. - clip, 1. + clip)
    unclipped_is_active = ratios * advantage <= clipped * advantage
    contribution = np.where(unclipped_is_active, ratios * advantage, 0.)
    return scores @ contribution / rewards.size


def finite_interaction(scores: np.ndarray, base: np.ndarray,
                       increments: np.ndarray, coordinates: tuple[int, ...],
                       ratios: np.ndarray | None = None) -> np.ndarray:
    """(B+1)-way reward finite difference of the normalized target."""
    result = np.zeros(scores.shape[0])
    for count in range(len(coordinates) + 1):
        for which in combinations(coordinates, count):
            modified = base.copy()
            for i in which:
                modified[i] += increments[i]
            sign = (-1.) ** (len(coordinates) - len(which))
            result += sign * group_gradient(scores, modified, ratios)
    return result


def _bridge_group(scores: np.ndarray, rewards: np.ndarray,
                  ratios: np.ndarray, budget: int) -> dict:
    design = uniform_design(G, budget)
    target_linear = gradient_map(scores) @ rewards
    target_norm = group_gradient(scores, rewards)
    target_clip = group_gradient(scores, rewards, ratios)
    terms = {'linear': [], 'normalized': [], 'clipped': []}
    for subset in design.subsets:
        observed = np.zeros(G)
        observed[subset.astype(bool)] = rewards[subset.astype(bool)] / (budget / G)
        terms['linear'].append(gradient_map(scores) @ observed)
        terms['normalized'].append(group_gradient(scores, observed))
        terms['clipped'].append(group_gradient(scores, observed, ratios))
    truths = {'linear': target_linear,
              'normalized': target_norm, 'clipped': target_clip}
    outcome = {}
    for key in truths:
        arr = np.stack(terms[key], axis=0)
        weights = design.probs
        expectation = weights @ arr
        deviation = arr - truths[key][None, :]
        outcome[key] = {
            'exact_design_bias_norm': float(np.linalg.norm(expectation - truths[key])),
            'exact_design_mean_square_error': float(
                np.sum(weights * np.einsum('ij,ij->i', deviation, deviation))),
        }
    return outcome


def run_bridge(output: str | Path) -> dict:
    rng = np.random.default_rng(BRIDGE_SEED)
    rows = []
    v = np.outer([.8, -.3, 1.0, -.8, .6, -.5],
                 [.8, -.3, 1.0, -.8, .6, -.5]) + .5 * np.eye(G)
    for index in range(BRIDGE_GROUPS):
        scores = rng.normal(size=(D, G))
        rewards = rng.multivariate_normal(np.zeros(G), v)
        ratios = np.exp(rng.normal(0, .24, size=G))
        for b in BRIDGE_BUDGETS:
            metrics = _bridge_group(scores, rewards, ratios, b)
            rows.append({'group': index, 'budget': b, **metrics})
    summary = {'label': 'Phase5_exact_finite_support_nonlinear_bridge',
               'independent_seed': BRIDGE_SEED,
               'groups': BRIDGE_GROUPS, 'G': G,
               'budgets': list(BRIDGE_BUDGETS),
               'scope': 'fixed-scores one-step surrogate, not real GRPO optimization',
               'per_budget': {}}
    for b in BRIDGE_BUDGETS:
        subset = [x for x in rows if x['budget'] == b]
        summary['per_budget'][str(b)] = {
            key: {
                name: float(np.mean([x[key][name] for x in subset]))
                for name in ('exact_design_bias_norm', 'exact_design_mean_square_error')}
            for key in ('linear', 'normalized', 'clipped')}
    test_scores = np.array([
        [.4, -.9, .8, 1.1, -.2, .3],
        [-.8, .25, -.15, .7, .6, -.9],
        [.7, .4, -.6, -.3, .9, .2]])
    base = np.array([-1.2, -.8, .3, .9, -.35, 1.1])
    increments = np.array([.25, -.33, .42, -.27, 0., 0.])
    ratios = np.array([1.42, .84, 1.16, .72, 1.38, 1.05])
    witness = finite_interaction(test_scores, base, increments, (0, 1, 2, 3))
    clip_witness = finite_interaction(
        test_scores, base, increments, (0, 1, 2, 3), ratios)
    summary['four_way_interaction_witness'] = {
        'coordinates': [0, 1, 2, 3], 'base_rewards': base.tolist(),
        'increments': increments.tolist(), 'scores': test_scores.tolist(),
        'ratios': ratios.tolist(),
        'normalized_vector': witness.tolist(),
        'normalized_norm': float(np.linalg.norm(witness)),
        'clipped_vector': clip_witness.tolist(),
        'clipped_norm': float(np.linalg.norm(clip_witness)),
        'interpretation': 'nonzero four-way reward dependence rules out a universally design-unbiased fixed-B=3 estimator based only on three rewards, for this target and fixed pre-query scores'}
    target = Path(output)
    target.mkdir(parents=True, exist_ok=True)
    (target / 'phase5_bridge.json').write_text(
        json.dumps({'summary': summary, 'all_groups': rows}, indent=2),
        encoding='utf-8')
    return summary
