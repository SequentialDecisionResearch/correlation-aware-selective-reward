"""Fixed-marginal auxiliary balancing comparators.

Two distinct designs are provided and named without suggesting either is
the published Deville--Tille cube implementation:

* ``cube_flight_dependent_landing`` is a transparent cube-*style* martingale
  flight phase followed by ordinary dependent-pair landing. We enumerate its
  probability tree, so first- and second-order inclusions are exact.
* ``auxiliary_balance_lp`` is a *stronger*, finite-subset benchmark: it globally
  minimizes the expected squared Horvitz--Thompson auxiliary imbalance among
  designs with exactly the requested marginals.

The latter need not coincide with a particular classical cube algorithm.
For an estimated PSD residual second moment matrix, augmented tensor
auxiliaries make the balance LP mathematically equivalent to the plug-in
joint coupling LP; this is a **novelty caution**, not a new sampling theorem.
"""

from collections import defaultdict

import numpy as np
from scipy.optimize import linprog

from .design import ExactBDesign, all_subsets, check_marginals
from .geometry import gradient_map
from .risk import validate_second_moment


def _validate_auxiliary(zeta: np.ndarray, auxiliary: np.ndarray) -> np.ndarray:
    x = np.asarray(auxiliary, dtype=float)
    if x.ndim != 2 or x.shape[1] != len(zeta) or not np.all(np.isfinite(x)):
        raise ValueError("auxiliary must be a finite p-by-G matrix")
    if np.any(zeta <= 0):
        raise ValueError("positive first-order inclusion probabilities are required")
    return x


def imbalance_squared(subsets: np.ndarray, zeta: np.ndarray,
                      auxiliary: np.ndarray) -> np.ndarray:
    """Squared imbalance of each B-subset, treating features as fixed F0 data."""
    zeta = np.asarray(zeta, dtype=float)
    auxiliary = _validate_auxiliary(zeta, auxiliary)
    z = np.asarray(subsets, dtype=float)
    if z.ndim != 2 or z.shape[1] != len(zeta):
        raise ValueError("subset/auxiliary shape mismatch")
    imbalance = (z / zeta - 1.0) @ auxiliary.T
    return np.sum(imbalance * imbalance, axis=1)


def balance_risk(design: ExactBDesign, auxiliary: np.ndarray) -> float:
    """Exact E_Q[||sum_i (Z_i/pi_i-1) auxiliary_i||^2]."""
    return float(design.probs @ imbalance_squared(design.subsets,
                                                  design.marginals, auxiliary))


def auxiliary_balance_lp(zeta: np.ndarray, budget: int,
                         auxiliary: np.ndarray) -> ExactBDesign:
    """Globally optimize expected auxiliary imbalance for enumerated small G."""
    zeta = check_marginals(zeta, budget)
    aux = _validate_auxiliary(zeta, auxiliary)
    subsets = all_subsets(len(zeta), budget)
    obj = imbalance_squared(subsets, zeta, aux)
    A_eq = np.vstack([np.ones(len(subsets)), subsets[:, :-1].T])
    b_eq = np.r_[1., zeta[:-1]]
    sol = linprog(obj, A_eq=A_eq, b_eq=b_eq, bounds=(0, None), method="highs")
    if not sol.success:
        raise RuntimeError(f"auxiliary balancing LP failed: {sol.message}")
    q = np.maximum(sol.x, 0)
    q /= q.sum()
    design = ExactBDesign(subsets, q, "global_auxiliary_balance_LP")
    if np.max(np.abs(design.marginals - zeta)) > 1e-7:
        raise RuntimeError("balancing LP changed first-order marginals")
    return design


def cube_flight_dependent_landing(zeta: np.ndarray, budget: int,
                                  auxiliary: np.ndarray,
                                  max_nodes: int = 40_000) -> ExactBDesign:
    """Exact distribution from cube-style flight + *simplified* pair landing.

    The flight martingale preserves total sample size and HT auxiliary totals
    as long as a null-space move exists. When it does not, paired martingale
    landing preserves the size and marginal expectations, but **may sacrifice
    auxiliary balance**. No claim is made that this is the optimal published
    cube landing algorithm. The entire finite branch tree is enumerated.
    """
    zeta = check_marginals(zeta, budget)
    aux = _validate_auxiliary(zeta, auxiliary)
    G = len(zeta)
    A = np.vstack([np.ones(G), aux / zeta])
    tol = 2e-11
    leaves: defaultdict[tuple[int, ...], float] = defaultdict(float)
    visited = 0

    def walk(x: np.ndarray, mass: float) -> None:
        nonlocal visited
        visited += 1
        if visited > max_nodes:
            raise RuntimeError("cube-style enumeration exceeded max_nodes")
        x = np.where(x < tol, 0., np.where(x > 1 - tol, 1., x))
        frac = np.flatnonzero((x > tol) & (x < 1 - tol))
        if len(frac) == 0:
            z = np.rint(x).astype(np.int8)
            if int(z.sum()) != budget:
                raise RuntimeError("cube landing violated exact B")
            leaves[tuple(z.tolist())] += mass
            return
        if len(frac) == 1:
            raise ArithmeticError("an exact-size martingale cannot have one fractional entry")

        block = A[:, frac]
        _, singular, vh = np.linalg.svd(block, full_matrices=True)
        rank = int(np.sum(singular > 1e-10 * max(1., singular[0]))) if singular.size else 0
        u = np.zeros(G)
        if len(frac) > rank:
            local_u = vh[-1, :]
            if np.linalg.norm(block @ local_u) > 2e-8:
                raise ArithmeticError("flight direction fails null-space test")
            u[frac] = local_u
        else:
            # Deliberately explicit landing: preserves cardinality and marginal
            # expectations, not necessarily auxiliary balancing constraints.
            u[frac[0]] = 1.
            u[frac[1]] = -1.

        plus = []
        minus = []
        for i in np.flatnonzero(np.abs(u) > 1e-12):
            if u[i] > 0:
                plus.append((1 - x[i]) / u[i])
                minus.append(x[i] / u[i])
            else:
                plus.append(x[i] / (-u[i]))
                minus.append((1 - x[i]) / (-u[i]))
        up = float(min(plus))
        down = float(min(minus))
        if min(up, down) <= 0:
            raise ArithmeticError("numerically degenerate cube branching")
        weight_plus = down / (up + down)  # martingale: E[step]=0
        walk(x + up * u, mass * weight_plus)
        walk(x - down * u, mass * (1 - weight_plus))

    walk(zeta.copy(), 1.)
    keys = list(leaves)
    subsets = np.asarray(keys, dtype=np.int8)
    q = np.asarray([leaves[k] for k in keys], dtype=float)
    if abs(float(q.sum()) - 1) > 1e-8:
        raise RuntimeError("cube branch probabilities did not normalize")
    q /= q.sum()
    result = ExactBDesign(subsets, q, "cube_flight_pair_landing")
    if np.max(np.abs(result.marginals - zeta)) > 1e-7:
        raise RuntimeError("cube flight/landing changed first-order marginals")
    return result


def tensor_auxiliary(scores: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Return p-by-G features making balancing loss EXACTLY equal query risk.

    Let V = L L^T. For each candidate i put
        aux_i = vec(M[:, i] outer L[i, :])
    where M is the LOO score map. Then for any design Q,
        E ||sum_i(Z_i/pi_i - 1) aux_i||^2 = acquisition_risk(Q; V).

    This equivalence is a useful obstacle to static-coupling novelty claims.
    """
    v = validate_second_moment(v)
    m = gradient_map(scores)
    if v.shape != (m.shape[1], m.shape[1]):
        raise ValueError("V and score dimension mismatch")
    lam, eigvec = np.linalg.eigh(v)
    L = eigvec * np.sqrt(np.maximum(lam, 0.))
    features = np.array([np.outer(m[:, i], L[i, :]).ravel()
                         for i in range(m.shape[1])])
    return features.T
