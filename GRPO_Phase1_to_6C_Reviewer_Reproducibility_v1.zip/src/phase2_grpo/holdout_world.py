"""Sealed Phase-4 synthetic challenge worlds (not Phase-3 development cases).

These worlds were specified before running Phase-4 holdout evaluation.
Generator parameters, covariance matrices and seed lists are explicit.
"""

from dataclasses import dataclass

import numpy as np


HOLDOUT_SEEDS = (2017, 2027, 2039, 2053, 2063, 2081, 2089, 2111,
                 2129, 2137, 2153, 2161)
CALIBRATION_SEEDS = tuple(range(3101, 3133))
HOLDOUT_SCENARIOS = (
    "stationary_heteroscedastic",
    "stationary_heavy_tail",
    "abrupt_factor_rotation",
    "gradual_rotation",
    "oscillating_correlations",
    "delayed_variance_shock",
    "heavy_tail_factor_flip",
)


def _factor_cov(loadings: np.ndarray, uniqueness: np.ndarray,
                target_trace: float = 6.) -> np.ndarray:
    vec = np.asarray(loadings, dtype=float)
    uniq = np.asarray(uniqueness, dtype=float)
    v = np.outer(vec, vec) + np.diag(uniq)
    if np.any(uniq <= 0):
        raise ValueError("strictly positive unique component required")
    return v * (target_trace / np.trace(v))


def _matrices(g: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if g != 6:
        raise ValueError("independent holdout profiles intentionally fixed at G=6")
    a = _factor_cov(
        np.array([1.1, -.7, .3, -.9, .65, -.2]),
        np.array([.35, .75, .45, .5, .7, .35]))
    b = _factor_cov(
        np.array([-.2, .9, 1.0, .35, -.8, -.6]),
        np.array([.55, .35, .65, .55, .4, .75]))
    c = _factor_cov(
        np.array([.65, .5, -.9, -.7, .4, .95]),
        np.array([.4, .6, .5, .45, .4, .75]))
    return a, b, c


@dataclass(frozen=True)
class WorldState:
    moment: np.ndarray
    distribution: str
    change_truth: bool
    onset: int | None


def world_state(scenario: str, step: int, horizon: int = 160,
                g: int = 6) -> WorldState:
    if scenario not in HOLDOUT_SCENARIOS:
        raise ValueError(f"unknown holdout world: {scenario}")
    if not 0 <= step < horizon:
        raise ValueError("step outside horizon")
    a, b, c = _matrices(g)
    distribution = "normal"
    change, onset = True, 80
    if scenario == "stationary_heteroscedastic":
        v, change, onset = a, False, None
    elif scenario == "stationary_heavy_tail":
        v, change, onset, distribution = c, False, None, "student_t5"
    elif scenario == "abrupt_factor_rotation":
        v = a if step < 80 else b
    elif scenario == "gradual_rotation":
        onset = 35
        fraction = float(np.clip((step - 35) / 95, 0, 1))
        v = (1 - fraction) * a + fraction * b
    elif scenario == "oscillating_correlations":
        onset = 0
        fraction = .5 * (1 + np.sin(2 * np.pi * step / 46))
        v = (1 - fraction) * b + fraction * c
    elif scenario == "delayed_variance_shock":
        onset = 118
        v = b if step < onset else 2.25 * c
    elif scenario == "heavy_tail_factor_flip":
        onset = 92
        v = c if step < onset else a
        distribution = "student_t5"
    if np.linalg.eigvalsh(v).min() <= 0:
        raise AssertionError("holdout world is not strictly positive definite")
    return WorldState(v, distribution, change, onset)


def draw_residual(rng: np.random.Generator, state: WorldState) -> np.ndarray:
    e = rng.multivariate_normal(np.zeros(len(state.moment)), state.moment)
    if state.distribution == "student_t5":
        # E[(nu-2)/chi2_nu] = 1: the true second moment stays state.moment.
        e *= np.sqrt(3. / rng.chisquare(5))
    return e
