"""Known-design risk identities; all statements condition on pre-query data."""

import numpy as np

from .geometry import gradient_map
from .design import ExactBDesign


def validate_second_moment(v: np.ndarray, tol: float = 1e-8) -> np.ndarray:
    v = np.asarray(v, dtype=float)
    if v.ndim != 2 or v.shape[0] != v.shape[1] or not np.all(np.isfinite(v)):
        raise ValueError("second-moment matrix must be finite and square")
    if not np.allclose(v, v.T, atol=tol, rtol=0):
        raise ValueError("second-moment matrix must be symmetric")
    if np.linalg.eigvalsh(v).min() < -tol:
        raise ValueError("second-moment matrix must be positive semidefinite")
    return v


def augmented_rewards(observed: np.ndarray, prediction: np.ndarray,
                      selected: np.ndarray, pi: np.ndarray) -> np.ndarray:
    """AIPW / model-assisted HT transformation.

    Only observed[selected] is read. Nonqueried entries may be NaN, and
    cannot leak into a returned estimate.
    """
    selected = np.asarray(selected, dtype=bool)
    pi = np.asarray(pi, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    observed = np.asarray(observed, dtype=float)
    if prediction.ndim != 1 or not (selected.shape == pi.shape == observed.shape == prediction.shape):
        raise ValueError("shape mismatch")
    if np.any(pi <= 0) or np.any(pi > 1) or not np.all(np.isfinite(pi)):
        raise ValueError("strict first-order positivity required")
    if not np.all(np.isfinite(prediction)) or not np.all(np.isfinite(observed[selected])):
        raise ValueError("queried rewards and predictions must be finite")
    result = prediction.copy()
    result[selected] += (observed[selected] - prediction[selected]) / pi[selected]
    return result


def acquisition_weight(scores: np.ndarray, design: ExactBDesign) -> np.ndarray:
    m = gradient_map(scores)
    if design.G != m.shape[1]:
        raise ValueError("group size mismatch")
    pi = design.marginals
    if np.any(pi <= 0):
        raise ValueError("first-order positivity required")
    pq = design.pair_inclusions
    cq = pq / np.outer(pi, pi) - 1.0
    return cq * (m.T @ m)


def acquisition_risk(scores: np.ndarray, v: np.ndarray, design: ExactBDesign) -> float:
    v = validate_second_moment(v)
    if design.G != len(v):
        raise ValueError("second-moment dimension does not match group")
    risk = float(np.sum(acquisition_weight(scores, design) * v))
    if risk < -1e-7:
        raise ArithmeticError("negative risk indicates a broken design or formula")
    return max(0.0, risk)


def conditional_query_covariance(scores: np.ndarray, reward_cov: np.ndarray,
                                 v: np.ndarray, design: ExactBDesign) -> np.ndarray:
    """Cov(estimated gradient | F0) = M(Sigma_R + C_Q * V)M^T."""
    m = gradient_map(scores)
    validate_second_moment(v)
    validate_second_moment(reward_cov)
    if reward_cov.shape != v.shape or v.shape[0] != design.G:
        raise ValueError("shape mismatch")
    pi = design.marginals
    if np.any(pi <= 0):
        raise ValueError("first-order positivity required for covariance")
    cq = design.pair_inclusions / np.outer(pi, pi) - 1.0
    return m @ (reward_cov + cq * v) @ m.T


def deterministic_risk_bound(scores: np.ndarray, design: ExactBDesign,
                             frobenius_error_radius: float) -> float:
    """Certified only if ||Vhat - V||_F <= user-supplied radius really holds."""
    if not np.isfinite(frobenius_error_radius) or frobenius_error_radius < 0:
        raise ValueError("invalid error radius")
    return float(frobenius_error_radius * np.linalg.norm(acquisition_weight(scores, design), "fro"))


def confidence_gated_design(scores: np.ndarray, vhat: np.ndarray,
                            candidate: ExactBDesign, baseline: ExactBDesign,
                            error_radius: float, min_improvement: float = 0.0):
    """Safe-choice certificate under *externally justified* Frobenius bound.

    Not a confidence interval estimator. It must not be deployed with a
    guessed radius or a radius obtained from an inaccessible oracle V.
    """
    if candidate.G != baseline.G:
        raise ValueError("different groups")
    if not np.allclose(candidate.marginals, baseline.marginals, atol=1e-8):
        raise ValueError("safety comparison requires identical marginals")
    rc = acquisition_risk(scores, vhat, candidate)
    rb = acquisition_risk(scores, vhat, baseline)
    uc = rc + deterministic_risk_bound(scores, candidate, error_radius)
    lb = rb - deterministic_risk_bound(scores, baseline, error_radius)
    return (candidate if uc + min_improvement < lb else baseline), {
        "accepted": bool(uc + min_improvement < lb),
        "candidate_upper": float(uc), "baseline_lower": float(lb),
    }


def fixed_size_additive_gap(pair_coeff: np.ndarray) -> float:
    """Residual to sufficient no-gain form a_ij = u_i+u_j (i != j)."""
    a = np.asarray(pair_coeff, dtype=float)
    if a.ndim != 2 or len(a) < 3 or a.shape[0] != a.shape[1]:
        raise ValueError("matrix must be square with G>=3")
    rows = []
    targets = []
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            row = np.zeros(len(a))
            row[i], row[j] = 1.0, 1.0
            rows.append(row)
            targets.append(a[i, j])
    u, *_ = np.linalg.lstsq(np.asarray(rows), np.asarray(targets), rcond=None)
    return float(np.max(np.abs(np.asarray(rows) @ u - targets)))

