"""Pure statistical objectives for REAL policy-weight updates in Phase 6C.

No Torch dependence: these estimands are independently unit-testable.
The primary LOO-HT advantage is design-unbiased for the full-feedback LOO
score gradient, conditional on the generated texts and the sampling design.
The normalized plug-in is knowingly nonlinear and generally BIASED.
Clipping and multi-epoch rollout reuse can add further bias.
"""

from dataclasses import asdict, dataclass
import numpy as np


ARMS = ("full", "uniform", "joint_ewma")
OBJECTIVES = ("loo_ht", "normalized_plugin")


@dataclass(frozen=True)
class Phase6CConfig:
    steps: int = 60
    seed: int = 6207
    g: int = 6
    b: int = 3
    warmup: int = 12
    window: int = 9
    exploration: float = .25
    max_new_tokens: int = 64
    objective: str = "loo_ht"
    update_epochs: int = 1
    clip_epsilon: float = .20
    learning_rate: float = 1e-5
    lora_rank: int = 8
    lora_alpha: int = 16
    eval_every: int = 10
    eval_size: int = 24
    train_schedule: str = "easy_to_hard"
    # Keep the historical v1.2 default for reproducible legacy tests/runs.
    # A separate calibrated launcher explicitly requests two_digit_add.
    task_family: str = "legacy"
    calibration_evidence_sha256: str = ""
    model: str = "Qwen/Qwen2.5-0.5B-Instruct"
    model_revision: str = "main"
    device: str = "cuda"
    local_files_only: bool = False

    def __post_init__(self):
        if (self.steps < 2 or self.seed < 0 or self.g != 6 or self.b != 3 or
                not 1 <= self.warmup < self.steps or self.window < 3 or
                not 0 < self.exploration < 1 or
                not 2 <= self.max_new_tokens <= 512 or
                self.objective not in OBJECTIVES or
                not 1 <= self.update_epochs <= 4 or
                not 0 < self.clip_epsilon < 1 or
                not 0 < self.learning_rate <= 1e-3 or
                not 1 <= self.lora_rank <= 64 or self.lora_alpha < 1 or
                self.eval_every < 1 or self.eval_size < 1 or
                self.train_schedule not in ("interleaved","easy_to_hard") or
                self.task_family not in ("legacy", "two_digit_add") or
                (self.task_family == "legacy" and self.calibration_evidence_sha256) or
                (self.task_family != "legacy" and (
                    len(self.calibration_evidence_sha256)!=64 or
                    any(c not in "0123456789abcdef" for c in
                        self.calibration_evidence_sha256))) or
                not self.model or not self.model_revision):
            raise ValueError("invalid Phase 6C configuration")


def reconstructed_rewards(visible: np.ndarray, selection: np.ndarray,
                          pi: np.ndarray) -> np.ndarray:
    selected=np.asarray(selection,dtype=bool)
    v=np.asarray(visible,float)
    inclusion=np.asarray(pi,float)
    if (v.ndim!=1 or selected.shape!=v.shape or inclusion.shape!=v.shape or
            not np.all(np.isfinite(inclusion)) or np.any(inclusion<=0) or
            np.any(inclusion>1) or not np.all(np.isfinite(v[selected])) or
            np.any(np.isfinite(v[~selected]))):
        raise ValueError("invalid masked-reward/propensity array")
    result=np.zeros(len(v),float)
    result[selected]=v[selected]/inclusion[selected]
    return result


def advantage(visible: np.ndarray, selection: np.ndarray, pi: np.ndarray,
              *, objective: str) -> np.ndarray:
    """LOO score coefficients; primary gradient uses sum_i A_i score_i / G.

    If pi=1 and all G labels observed, `loo_ht` reduces to ordinary LOO.
    If B<G, it is unbiased for the linear LOO score gradient, but the
    normalized version is a nonlinear biased plug-in by construction.
    """
    if objective not in OBJECTIVES:
        raise ValueError("unknown policy-gradient objective")
    r=reconstructed_rewards(visible,selection,pi)
    if len(r)<2:
        raise ValueError("group must contain at least two completions")
    if objective=="loo_ht":
        return (len(r)*r-r.sum())/(len(r)-1)
    centered=r-r.mean()
    return centered/(np.sqrt(np.mean(centered**2))+1e-6)


def full_advantage(rewards: np.ndarray, *, objective: str) -> np.ndarray:
    x=np.asarray(rewards,float)
    if not np.all(np.isfinite(x)) or x.ndim!=1:
        raise ValueError("full feedback must be completely observed")
    return advantage(x,np.ones(len(x),bool),np.ones(len(x)),objective=objective)


def policy_score_gradient(scores: np.ndarray, coeff: np.ndarray) -> np.ndarray:
    s=np.asarray(scores,float)
    a=np.asarray(coeff,float)
    if s.ndim!=2 or a.shape!=(s.shape[1],):
        raise ValueError("score features must have shape [d,G]")
    return (s@a)/len(a)


def expected_ht_gradient(scores: np.ndarray, rewards: np.ndarray,
                         design, *, objective="loo_ht") -> np.ndarray:
    """Finite-exact expectation for tests, never used to train on hidden labels."""
    expected=np.zeros(np.asarray(scores).shape[0],float)
    for subset,p in zip(design.subsets,design.probs):
        selected=np.asarray(subset,bool)
        masked=np.full(len(rewards),np.nan)
        masked[selected]=np.asarray(rewards,float)[selected]
        expected+=float(p)*policy_score_gradient(scores,advantage(
            masked,selected,design.marginals,objective=objective))
    return expected
