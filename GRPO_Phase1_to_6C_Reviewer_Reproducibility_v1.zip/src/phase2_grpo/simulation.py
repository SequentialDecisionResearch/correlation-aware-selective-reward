"""Reproducible synthetic experiments. Not evidence of LLM fine-tuning.

Oracle V is used solely for reference/evaluation, never for the deployable
practical design selected using pilot-calibrated Vhat.
"""

import csv
import json
from pathlib import Path

import numpy as np
from scipy.stats import t as student_t

from .calibration import PooledMomentCalibrator
from .design import ExactBDesign, uniform_design
from .geometry import gradient_map
from .optimization import optimize_coupling
from .risk import acquisition_risk, augmented_rewards
from .oracle import CountingOracle


def shared_residual_second_moment(g: int, rho: float,
                                  heterogeneity: float = 0.25) -> np.ndarray:
    if not -1.0 / (g - 1) <= rho <= 1:
        raise ValueError("exchangeable correlation is not PSD")
    corr = (1 - rho) * np.eye(g) + rho * np.ones((g, g))
    scales = 1 + heterogeneity * np.linspace(-1, 1, g)
    return scales[:, None] * corr * scales[None, :]


def pilot_moment_fit(v: np.ndarray, baseline: ExactBDesign, n: int,
                     rng: np.random.Generator):
    g = baseline.G
    residual = rng.multivariate_normal(np.zeros(g), v, size=n)
    masks = np.array([baseline.draw(rng) for _ in range(n)], dtype=bool)
    observed = np.full((n, g), np.nan)
    observed[masks] = residual[masks]
    pi = np.broadcast_to(baseline.marginals, (n, g))
    pi2 = np.broadcast_to(baseline.pair_inclusions, (n, g, g))
    return PooledMomentCalibrator().fit(observed, masks, pi, pi2)


def deterministic_counterexample(repetitions: int = 40_000, seed: int = 20261023) -> dict:
    """Theorem illustration: same pi, identical residuals, risk 0 vs 16."""
    rng = np.random.default_rng(seed)
    score = np.array([[-3., -3., 3., 3.]])
    # M = [-1,-1,1,1] and M 1 = 0.
    subsets = np.array([[1, 0, 1, 0], [0, 1, 0, 1]], dtype=int)
    bad_subsets = np.array([[1, 1, 0, 0], [0, 0, 1, 1]], dtype=int)
    good = ExactBDesign(subsets, np.array([.5, .5]), "balanced_pairs")
    bad = ExactBDesign(bad_subsets, np.array([.5, .5]), "same_sign_pairs")
    v = np.ones((4, 4))
    assert np.allclose(gradient_map(score), [[-1, -1, 1, 1]])
    u = rng.normal(size=repetitions)
    a = rng.integers(0, 2, size=repetitions)
    q_good = subsets[a]
    q_bad = bad_subsets[a]
    m = gradient_map(score)[0]
    err_good = (q_good * (u[:, None] * 2)) @ m
    err_bad = (q_bad * (u[:, None] * 2)) @ m
    return {"G": 4, "B": 2, "marginals": [.5] * 4,
            "analytic_good_risk": acquisition_risk(score, v, good),
            "analytic_bad_risk": acquisition_risk(score, v, bad),
            "mc_good_risk": float(np.mean(err_good ** 2)),
            "mc_bad_risk": float(np.mean(err_bad ** 2)),
            "repetitions": repetitions, "seed": seed}


def design_grid(seed_list=(11, 29, 47, 83), pilot_n: int = 900) -> list[dict]:
    rows = []
    for g in (4, 6, 8):
        for b in sorted(set((1, 2, g // 2, g - 1))):
            if not b < g:
                continue
            base = uniform_design(g, b)
            zeta = base.marginals
            for rho in (0.0, 0.4, 0.8):
                v = shared_residual_second_moment(g, rho)
                for seed in seed_list:
                    rng = np.random.default_rng(1000 * g + 100 * b + int(10 * rho) + seed)
                    scores = rng.normal(size=(3, g))
                    fit = pilot_moment_fit(v, base, pilot_n, rng)
                    oracle, meta = optimize_coupling(scores, v, zeta, b)
                    practical, _ = optimize_coupling(scores, fit.psd, zeta, b)
                    rb = acquisition_risk(scores, v, base)
                    ro = acquisition_risk(scores, v, oracle)
                    rp = acquisition_risk(scores, v, practical)
                    if ro > min(rp, rb) + 1e-6:
                        raise AssertionError("oracle LP must be no worse than its feasible baselines")
                    rows.append({"G": g, "B": b, "rho": rho, "seed": seed,
                                 "pilot_N": pilot_n, "baseline_risk": rb,
                                 "oracle_risk": ro, "practical_risk": rp,
                                 "oracle_gain": rb - ro,
                                 "practical_gain": rb - rp,
                                 "design_regret": rp - ro,
                                 "pair_supported": int(bool(np.all(fit.pair_supported))),
                                 "min_pair_ess": float(fit.pair_effective_n[np.triu_indices(g, 1)].min()),
                                 "vhat_fro_error": float(np.linalg.norm(fit.psd - v, "fro")),
                                 "LP_subsets": meta["subset_count"]})
    return rows


def _softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - np.max(x))
    return e / e.sum()


def _bandit_trial(seed: int, method: str, steps: int, pilot_n: int = 500) -> dict:
    """Tiny four-armed one-step on-policy experiment (not clipped/token GRPO)."""
    rng_pilot = np.random.default_rng(seed + 110_000)
    rng_action = np.random.default_rng(seed + 120_000)
    rng_noise = np.random.default_rng(seed + 130_000)
    rng_query = np.random.default_rng(seed + 140_000)
    g, b, arms = 6, 3, 4
    means = np.array([-0.2, 0.0, 0.35, 0.65])  # world secret for evaluation
    common_sd, idio_sd = .5, .7
    base = uniform_design(g, b)
    pilot_mask = np.array([base.draw(rng_pilot) for _ in range(pilot_n)], dtype=bool)
    pilot_actions = rng_pilot.integers(0, arms, size=(pilot_n, g))
    pilot_rewards = (means[pilot_actions]
                     + rng_pilot.normal(0, common_sd, size=(pilot_n, 1))
                     + rng_pilot.normal(0, idio_sd, size=(pilot_n, g)))
    obs = np.full((pilot_n, g), np.nan)
    obs[pilot_mask] = pilot_rewards[pilot_mask]
    fit = PooledMomentCalibrator().fit(
        obs, pilot_mask,
        np.broadcast_to(base.marginals, (pilot_n, g)),
        np.broadcast_to(base.pair_inclusions, (pilot_n, g, g)))
    vhat = fit.psd
    theta = np.zeros(arms)
    acquired = int(pilot_n * b)
    gradient_sqerr = []
    for _ in range(steps):
        prob = _softmax(theta)
        # Paired exogenous randomness across methods, while policies may diverge.
        actions = np.searchsorted(np.cumsum(prob), rng_action.random(g))
        scores = np.eye(arms)[actions].T - prob[:, None]
        rewards = (means[actions] + rng_noise.normal(0, common_sd)
                   + rng_noise.normal(0, idio_sd, g))
        if method == "joint":
            design, _ = optimize_coupling(scores, vhat, base.marginals, b)
        elif method == "uniform":
            design = base
        else:
            raise ValueError("unknown training method")
        # The optimizer has already selected a design, without oracle access.
        selection = design.draw(rng_query).astype(bool)
        oracle = CountingOracle(rewards)
        oracle.reveal(np.flatnonzero(selection))
        queried = augmented_rewards(oracle.purchased_vector(), np.zeros(g),
                                    selection, design.marginals)
        estimated = gradient_map(scores) @ queried
        reference = gradient_map(scores) @ rewards  # diagnostics only
        gradient_sqerr.append(float(np.sum((estimated - reference) ** 2)))
        theta += 0.12 * estimated
        acquired += oracle.calls
        if oracle.calls != b:
            raise AssertionError("simulator purchased a different number of rewards")
    return {"seed": seed, "method": method, "steps": steps,
            "pilot_calls": int(pilot_n * b), "training_calls": int(steps * b),
            "all_recorded_calls": acquired,
            "final_expected_reward": float(_softmax(theta) @ means),
            "mean_query_gradient_squared_error": float(np.mean(gradient_sqerr)),
            "is_real_llm": False}


def toy_training(seed_list=(11, 29, 47, 83, 101, 127), steps: int = 160) -> list[dict]:
    return [_bandit_trial(seed, method, steps)
            for seed in seed_list for method in ("uniform", "joint")]


def _write_csv(path: Path, rows: list[dict]):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run_all(destination: str | Path, quick: bool = False) -> dict:
    out = Path(destination)
    out.mkdir(parents=True, exist_ok=True)
    counter = deterministic_counterexample(repetitions=10_000 if quick else 40_000)
    rows = design_grid(seed_list=(11, 29) if quick else (11, 29, 47, 83),
                       pilot_n=350 if quick else 900)
    training = toy_training(seed_list=(11, 29) if quick else (11, 29, 47, 83, 101, 127),
                            steps=60 if quick else 160)
    _write_csv(out / "design_grid.csv", rows)
    _write_csv(out / "toy_training.csv", training)
    (out / "counterexample.json").write_text(json.dumps(counter, indent=2), encoding="utf-8")
    paired = {}
    for record in training:
        paired.setdefault(record["seed"], {})[record["method"]] = record["final_expected_reward"]
    differences = np.array([pair["joint"] - pair["uniform"]
                            for _, pair in sorted(paired.items())], dtype=float)
    paired_mean = float(differences.mean())
    paired_halfwidth = float(student_t.ppf(.975, len(differences) - 1)
                             * differences.std(ddof=1) / np.sqrt(len(differences)))
    summary = {
        "mode": "quick_smoke" if quick else "synthetic_research_diagnostic",
        "design_cells": len(rows), "training_runs": len(training),
        "mean_oracle_gain": float(np.mean([r["oracle_gain"] for r in rows])),
        "mean_practical_gain": float(np.mean([r["practical_gain"] for r in rows])),
        "fraction_practical_better_than_uniform": float(np.mean([r["practical_gain"] > 1e-8 for r in rows])),
        "training_uniform_mean": float(np.mean([r["final_expected_reward"] for r in training if r["method"] == "uniform"])),
        "training_joint_mean": float(np.mean([r["final_expected_reward"] for r in training if r["method"] == "joint"])),
        "training_paired_mean_delta": paired_mean,
        "training_paired_descriptive_t95_interval": [paired_mean - paired_halfwidth,
                                                      paired_mean + paired_halfwidth],
        "caveat": "Synthetic toy experiment; t interval is descriptive for six paired seeds, not powered or real LLM training."}
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary

