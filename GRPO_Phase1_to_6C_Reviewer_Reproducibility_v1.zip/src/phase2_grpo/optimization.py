"""Exact small-G fixed-marginal coupling and cost-aware Bernoulli allocation."""

import numpy as np
from scipy.optimize import brentq, linprog

from .design import ExactBDesign, all_subsets, check_marginals
from .geometry import gradient_gram
from .risk import validate_second_moment, acquisition_risk


def optimize_coupling(scores: np.ndarray, v: np.ndarray, zeta: np.ndarray,
                      budget: int) -> tuple[ExactBDesign, dict]:
    """Global optimality *within enumerated exact-B support* for small G."""
    zeta = check_marginals(zeta, budget)
    validate_second_moment(v)
    k = gradient_gram(scores)
    if v.shape != k.shape:
        raise ValueError("V / score shape mismatch")
    if np.any(zeta <= 0):
        raise ValueError("strict positivity needed for HT gradient")
    z = all_subsets(len(zeta), budget)
    w = v * k / np.outer(zeta, zeta)
    objective = np.einsum("ti,ij,tj->t", z, w, z)
    ae = np.vstack([np.ones(len(z)), z[:, :-1].T])
    be = np.r_[1.0, zeta[:-1]]
    sol = linprog(objective, A_eq=ae, b_eq=be, bounds=(0, None), method="highs")
    if not sol.success:
        raise RuntimeError(f"joint coupling LP failed: {sol.message}")
    q = np.maximum(sol.x, 0.0)
    q /= q.sum()
    d = ExactBDesign(z, q, "global_exactB_coupling_LP")
    residual = float(np.max(np.abs(d.marginals - zeta)))
    if residual > 1e-7:
        raise RuntimeError(f"optimized marginals incorrect (err={residual})")
    return d, {"status": "global_optimum_over_enumerated_subsets",
               "subset_count": int(len(z)), "support_count": int(np.sum(q > 1e-9)),
               "marginal_error": residual,
               "risk": acquisition_risk(scores, v, d),
               "linear_program_objective": float(sol.fun)}


def bernoulli_sqrt_marginals(coeffs: np.ndarray, budget: float,
                            costs: np.ndarray | None = None,
                            floor: float = 1e-5) -> np.ndarray:
    """Minimum sum a_i/pi_i, subject sum cost_i*pi_i <= budget.

    This is a classical comparator, not a new theoretical contribution.
    """
    a = np.asarray(coeffs, dtype=float)
    c = np.ones(len(a)) if costs is None else np.asarray(costs, dtype=float)
    if (a.ndim != 1 or c.shape != a.shape or not np.all(np.isfinite(a))
            or not np.all(np.isfinite(c)) or np.any(a < 0) or np.any(c <= 0)):
        raise ValueError("nonnegative coefficients and positive costs required")
    if (not np.isfinite(budget) or not np.isfinite(floor)
            or not 0 < floor <= 1 or budget < floor * c.sum() - 1e-12):
        raise ValueError("budget does not permit the positivity floor")
    if budget >= c.sum():
        return np.ones(len(a))
    if np.all(a == 0):
        # Objective is flat. Uniform cost-normalized feasible allocation.
        return np.full(len(a), min(1.0, budget / c.sum()))
    def p(lam):
        return np.clip(np.sqrt(a / (lam * c)), floor, 1.0)
    def f(lam):
        return float(c @ p(lam) - budget)
    high = 1.0
    while f(high) > 0:
        high *= 2
        if not np.isfinite(high):
            raise ArithmeticError("allocation multiplier overflow")
    low = high
    while f(low) <= 0:
        low /= 2
        if low < 1e-280:
            raise ArithmeticError("unattainable allocation tolerance")
    lam = brentq(f, low, high, xtol=1e-14, rtol=1e-14)
    return p(lam)

