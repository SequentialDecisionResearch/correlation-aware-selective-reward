"""Frozen, deterministic arithmetic prompts and exact local verifier.

Rewards are deliberately cheap: any 'saved budget' is a LOGICAL query
budget in this study, never an actual verifier cost or wall-clock saving.
"""

import re
import numpy as np


BOXED = re.compile(r"\\boxed\s*\{\s*([+-]?\d+)\s*\}")
FINAL = re.compile(r"\b(?:final\s*answer|answer)\s*(?::|=|\bis\b)\s*([+-]?\d+)\b", re.I)
BARE = re.compile(r"^\s*([+-]?\d+)\s*\.?\s*$")
STRICT_BOXED = re.compile(r"\s*\\boxed\s*\{\s*([+-]?\d+)\s*\}\s*")

# The same output contract is used by all three phases and both real-Qwen
# generation backends. These are generation instructions, not answer keys.
ANSWER_INSTRUCTION = (
    "Return exactly one LaTeX box containing the final integer, "
    "in the form \\boxed{N}. No steps, explanations, or code."
)
SYSTEM_PROMPT = (
    "You solve integer arithmetic. Return only the requested final answer "
    "in the form \\boxed{N}. Do not show reasoning, steps, or code."
)


def _identified_answer(completion: str) -> tuple[int | None, str | None]:
    """Choose the *last* explicit answer marker, not intermediate numbers.

    A natural-language ``answer is N`` is a legitimate answer marker even
    when the model fails the requested boxed-only formatting. In contrast,
    an unmarked number in a calculation is never converted into a reward.
    """
    tagged = [(m.start(), int(m.group(1)), kind)
              for pattern, kind in ((BOXED, "boxed"), (FINAL, "labeled"))
              for m in pattern.finditer(completion)]
    if tagged:
        _, value, kind = max(tagged, key=lambda item: item[0])
        return value, kind
    bare=BARE.fullmatch(completion)
    if bare:
        return int(bare.group(1)), "bare"
    lines = [s.strip() for s in completion.splitlines() if s.strip()]
    last=BARE.fullmatch(lines[-1]) if lines else None
    if last:
        return int(last.group(1)), "bare_last_line"
    return None, None


def final_integer(completion: str) -> int | None:
    """Parse an explicitly identified final answer, never intermediate math."""
    return _identified_answer(completion)[0]


def score_answer(task: dict, completion: str) -> dict:
    predicted,kind = _identified_answer(completion)
    correct = bool(predicted is not None and predicted == int(task["answer"]))
    # Strict compliance is separate from arithmetic correctness. A response
    # such as "Therefore, the answer is 320." can receive a correct-answer
    # reward while failing the exact-box-only output contract.
    strict = STRICT_BOXED.fullmatch(completion) is not None
    return {"reward": float(correct), "parsed_answer": predicted,
            "parseable": predicted is not None,
            "format_compliant": strict,
            "strict_format_correct": bool(strict and correct),
            "answer_format": kind}


def make_tasks(*, count: int, seed: int, schedule: str) -> list[dict]:
    if count < 1 or schedule not in ("interleaved", "easy_to_hard"):
        raise ValueError("invalid tasks configuration")
    tasks = []
    for i in range(count):
        rng = np.random.default_rng(np.random.SeedSequence([seed, 6001, i]))
        if schedule == "easy_to_hard":
            level = "easy" if i < count // 2 else "hard"
        else:
            level = "easy" if i % 2 == 0 else "hard"
        a, b, c, d, e = [int(x) for x in rng.integers(3, 24, size=5)]
        if level == "easy":
            if i % 2 == 0:
                expression, ans = f"({a} × {b}) + {c}", a * b + c
            else:
                expression, ans = f"({a} + {b}) × {c} - {d}", (a+b)*c-d
        else:
            modulus = int(rng.integers(23, 101))
            if i % 2 == 0:
                expression = f"(({a} × {b} - {c}) × ({d} + {e})) mod {modulus}"
                ans = ((a*b-c)*(d+e)) % modulus
            else:
                expression = f"({a}² + {b} × {c} - {d}) mod {modulus}"
                ans = (a*a+b*c-d) % modulus
        prompt = f"Compute exactly: {expression}."
        if level == "hard":
            prompt += " Here 'mod' means the nonnegative remainder."
        prompt += " " + ANSWER_INSTRUCTION
        tasks.append({"id": i, "level": level, "expression": expression,
                      "answer": int(ans), "prompt": prompt})
    return tasks
