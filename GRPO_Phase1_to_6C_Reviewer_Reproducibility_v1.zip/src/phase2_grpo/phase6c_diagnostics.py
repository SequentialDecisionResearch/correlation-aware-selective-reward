"""Read-only Phase6C v1.5 diagnostics over sealed, completed v1.4 runs.

All new artifacts are written to a DISTINCT diagnostic root. Existing run
manifests, journals, model states, calibration evidence, and evaluations are
never modified. A post-hoc stress protocol is locked BEFORE its first result.
"""

from __future__ import annotations

import csv
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile

import numpy as np
from scipy.stats import t as student_t

from .phase6a_checkpoint import Checkpoints, atomic_json, digest
from .phase6a_tasks import ANSWER_INSTRUCTION
from .phase6c_objectives import ARMS, Phase6CConfig


PROTOCOL = "phase6c_v1_5_posthoc_locked_stress_20261025"
STRATA = ("two_digit_carry_ood", "three_digit_double_carry", "three_term_add")
THRESHOLDS = (0.75, 0.85, 0.90, 0.95)


def read_json(path: Path) -> dict:
    with Path(path).open(encoding="utf-8") as stream:
        return json.load(stream)


def file_sha(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_once(path: Path, obj: dict) -> None:
    path = Path(path)
    if path.exists():
        if read_json(path) != obj:
            raise RuntimeError(f"refusing to change locked diagnostic artifact: {path}")
    else:
        atomic_json(path, obj)


def csv_once(path: Path, rows: list[dict], fields: list[str]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        with path.open(encoding="utf-8", newline="") as stream:
            current = list(csv.DictReader(stream))
        if current != [{k: "" if r[k] is None else str(r[k]) for k in fields}
                       for r in rows]:
            raise RuntimeError(f"refusing to rewrite diagnostic CSV: {path}")
        return
    temp = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="",
                prefix=f".{path.name}.", suffix=".tmp", dir=path.parent,
                delete=False) as stream:
            temp = Path(stream.name)
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if temp is not None and temp.exists():
            temp.unlink()


def _check_output_not_in_runs(output: Path, runs: list[Path]) -> None:
    target = output.resolve()
    for run in runs:
        if target == run.resolve() or target.is_relative_to(run.resolve()):
            raise ValueError("diagnostic output MUST NOT be inside an original training run")


def open_existing_checkpoint(root: Path, arm: str) -> Checkpoints:
    directory = root / "arms" / arm
    manifest_path = directory / "manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(manifest_path)
    manifest = read_json(manifest_path)
    return Checkpoints(directory, manifest["config"])


def stored_state(cp: Checkpoints, step: int, *, check_hash: bool = True) -> Path:
    state = cp.directory / "optimizer_states" / f"after_step_{step:06d}.pt"
    record = cp.load("initial_state", 0) if step == 0 else cp.load("train_steps", step - 1)
    if record is None or not state.is_file():
        raise RuntimeError(f"missing committed model state: {state}")
    if check_hash and file_sha(state) != record["state_sha256"]:
        raise RuntimeError(f"model state SHA-256 mismatch: {state}")
    return state


def evaluation_steps(cfg: Phase6CConfig) -> list[int]:
    return [0] + [i for i in range(1, cfg.steps + 1)
                  if i % cfg.eval_every == 0 or i == cfg.steps]


def load_run(root: Path) -> dict:
    root = Path(root).resolve()
    summary_path = root / "phase6c_summary.json"
    audit_path = root / "phase6c_audit.json"
    summary, audit = read_json(summary_path), read_json(audit_path)
    if (summary.get("phase") != "6C" or not summary.get("complete") or
            not summary.get("genuine_model_updates") or
            summary.get("config", {}).get("task_family") != "two_digit_add" or
            set(summary.get("progress", {})) != set(ARMS) or
            set(summary.get("final_heldout", {})) != set(ARMS) or
            not audit.get("pass") or
            audit.get("checked_train_steps") != audit.get("expected") or
            audit.get("expected") != 3 * summary["config"]["steps"]):
        raise RuntimeError(f"incomplete, unaudited, or non-calibrated real run: {root}")
    cfg = Phase6CConfig(**summary["config"])
    if any(summary["progress"][a] != cfg.steps or
           not summary["real_backend_by_arm"][a] for a in ARMS):
        raise RuntimeError(f"missing real completed training arm: {root}")
    paths = {}
    shared_tasks = None
    for arm in ARMS:
        cp = open_existing_checkpoint(root, arm)
        saved_cfg = cp.fingerprint
        manifest = read_json(cp.directory / "manifest.json")
        if manifest.get("fingerprint") != saved_cfg or manifest["config"]["config"] != asdict(cfg):
            raise RuntimeError("run manifest and summary disagree")
        tasks_record = cp.load("tasks", 0)
        if tasks_record is None:
            raise RuntimeError("missing heldout task bank")
        if shared_tasks is None:
            shared_tasks = tasks_record
        elif tasks_record != shared_tasks:
            raise RuntimeError(f"heldout/train tasks differ among arms in {root}")
        if len(tasks_record["heldout"]) != cfg.eval_size:
            raise RuntimeError("heldout task count differs from locked configuration")
        for step in evaluation_steps(cfg):
            stored_state(cp, step)
            historical = (cp.load("baseline_eval", 0) if step == 0 else
                          cp.load("train_steps", step - 1)["heldout_evaluation"])
            if historical is None:
                raise RuntimeError(f"missing historical heldout evaluation at {step}")
        paths[arm] = file_sha(cp.directory / "manifest.json")
    return {"seed": cfg.seed, "root": str(root), "config": asdict(cfg),
            "summary_sha256": file_sha(summary_path),
            "audit_sha256": file_sha(audit_path),
            "task_sha256": digest(shared_tasks), "arm_manifest_sha256": paths}


def stress_bank(per_stratum: int = 32) -> dict:
    """Freeze a fresh OOD test panel; never inspect model outcomes to choose items.

    Two-digit training/calibration operands are in 11..79. The first stress
    stratum exclusively uses 80..99, so it cannot overlap those examples.
    Remaining strata have structurally distinct expressions.
    """
    if not 8 <= per_stratum <= 64:
        raise ValueError("stress-per-stratum must be 8..64")
    tasks = []
    for family_index, family in enumerate(STRATA):
        used: set[tuple[int, ...]] = set()
        trial = 0
        while len(used) < per_stratum:
            if trial > 200000:
                raise RuntimeError("cannot construct distinct stress tasks")
            rng = np.random.default_rng(np.random.SeedSequence(
                [20261025, 1505, family_index, trial]))
            trial += 1
            if family == "two_digit_carry_ood":
                a, b = map(int, rng.integers(80, 100, size=2))
                if a % 10 + b % 10 < 10:
                    continue
                values, expr, answer = tuple(sorted((a, b))), f"{a} + {b}", a + b
            elif family == "three_digit_double_carry":
                a, b = map(int, rng.integers(150, 900, size=2))
                if (a % 10 + b % 10 < 10 or
                        (a // 10) % 10 + (b // 10) % 10 + 1 < 10):
                    continue
                values, expr, answer = tuple(sorted((a, b))), f"{a} + {b}", a + b
            else:
                a, b, c = map(int, rng.integers(40, 100, size=3))
                if (a % 10 + b % 10 + c % 10 < 10):
                    continue
                values, expr, answer = tuple(sorted((a, b, c))), f"({a} + {b}) + {c}", a+b+c
            if values in used:
                continue
            used.add(values)
            index = len(used) - 1
            tasks.append({"id": f"{family}_{index:03d}", "level": family,
                          "expression": expr,
                          "prompt": f"Compute exactly: {expr}. {ANSWER_INSTRUCTION}",
                          "answer": int(answer)})
    return {"protocol": PROTOCOL, "per_stratum": per_stratum,
            "strata": list(STRATA), "tasks": tasks,
            "claim_boundary": "post-hoc OOD exploratory stress; no training or tuning on these answers"}


def verify_stress_disjoint(bank: dict, roots: list[Path]) -> dict:
    """Check actual sealed C task banks, not just a theoretical seed claim."""
    stress_prompts={t["prompt"] for t in bank["tasks"]}
    stress_simple=set()
    pattern=re.compile(r"^Compute exactly: (\d+) \+ (\d+)\.")
    for task in bank["tasks"]:
        match=pattern.match(task["prompt"])
        if match:
            stress_simple.add(tuple(sorted(map(int,match.groups()))))
    tested=0
    for root in roots:
        record=open_existing_checkpoint(root,"uniform").load("tasks",0)
        for task in record["train"]+record["heldout"]:
            tested+=1
            if task["prompt"] in stress_prompts:
                raise RuntimeError("stress prompt leaked into original training/heldout")
            match=pattern.match(task["prompt"])
            if match and tuple(sorted(map(int,match.groups()))) in stress_simple:
                raise RuntimeError("commuted stress addition leaked into original tasks")
    return {"original_tasks_checked":tested,"exact_prompt_overlap":0,
            "commuted_two_term_addition_overlap":0,
            "calibration_domain": "two_digit_add original operands 11..79; stress simple sums use operands >=80"}


def prepare(run_paths: list[str | Path], output: Path, *, per_stratum=32) -> dict:
    roots = [Path(p).resolve() for p in run_paths]
    if len(roots) < 1 or len(set(roots)) != len(roots):
        raise ValueError("provide distinct completed runs")
    _check_output_not_in_runs(Path(output), roots)
    runs = [load_run(path) for path in roots]
    seeds = [r["seed"] for r in runs]
    if len(set(seeds)) != len(seeds):
        raise ValueError("seeds must be distinct")
    common = None
    for run in runs:
        cfg = dict(run["config"])
        cfg.pop("seed")
        if common is None:
            common = cfg
        elif cfg != common:
            raise RuntimeError("run configurations differ beyond seed")
    bank = stress_bank(per_stratum)
    disjointness=verify_stress_disjoint(bank,roots)
    manifest = {"schema": 1, "protocol": PROTOCOL,
                "stress_bank_sha256": digest(bank),
                "stress_disjointness":disjointness,
                "runs": sorted(runs, key=lambda r: r["seed"]),
                "common_config_excluding_seed": common,
                "evaluation_steps": evaluation_steps(Phase6CConfig(**runs[0]["config"])),
                "scope": "read-only post-hoc diagnostic, no confirmation claim"}
    output = Path(output)
    write_once(output / "stress_bank.json", bank)
    write_once(output / "diagnostic_manifest.json", manifest)
    return {"status": "locked", "seeds": sorted(seeds),
            "stress_items": len(bank["tasks"]),
            "stress_bank_sha256": digest(bank), "output": str(output)}


def locked_inputs(output: Path) -> tuple[dict, dict]:
    output = Path(output)
    manifest = read_json(output / "diagnostic_manifest.json")
    bank = read_json(output / "stress_bank.json")
    if (manifest.get("protocol") != PROTOCOL or bank.get("protocol") != PROTOCOL or
            manifest["stress_bank_sha256"] != digest(bank)):
        raise RuntimeError("diagnostic protocol or stress bank modified")
    for r in manifest["runs"]:
        root = Path(r["root"])
        for field, name in (("summary_sha256", "phase6c_summary.json"),
                            ("audit_sha256", "phase6c_audit.json")):
            if file_sha(root / name) != r[field]:
                raise RuntimeError("old run mutated after diagnostic lock")
        for arm, old_sha in r["arm_manifest_sha256"].items():
            if file_sha(root / "arms" / arm / "manifest.json") != old_sha:
                raise RuntimeError("old arm manifest mutated after diagnostic lock")
    return manifest, bank


def cluster_interval(values: list[float]) -> dict:
    x = np.asarray(values, dtype=float)
    m = float(x.mean())
    if len(x) < 2:
        bounds = None
    else:
        h = float(student_t.ppf(.975, len(x)-1)*x.std(ddof=1)/math.sqrt(len(x)))
        bounds = [m-h,m+h]
    return {"mean": m, "descriptive_seed_t95": bounds, "seeds": len(x),
            "empirically_zero_variance": bool(len(x)>1 and np.ptp(x)==0),
            "warning": "zero-width sample interval is NOT a population equivalence certificate"}


def learning_curves(manifest: dict) -> tuple[list[dict], dict]:
    """Calculate per-seed trapezoid AULC and first observed threshold hit."""
    curve_rows = []
    seed_rows = []
    for run in manifest["runs"]:
        root = Path(run["root"])
        cfg = Phase6CConfig(**run["config"])
        for arm in ARMS:
            cp = open_existing_checkpoint(root, arm)
            points = [(0, float(cp.load("baseline_eval", 0)["accuracy"]))]
            for step in evaluation_steps(cfg)[1:]:
                points.append((step, float(cp.load("train_steps", step-1)
                                  ["heldout_evaluation"]["accuracy"])))
            aulc = float(sum((points[i][0]-points[i-1][0])*
                             (points[i][1]+points[i-1][1])/2
                             for i in range(1,len(points))) / cfg.steps)
            row = {"seed": cfg.seed, "arm": arm, "auc_accuracy_trapezoid": aulc,
                   "initial_accuracy": points[0][1], "final_accuracy": points[-1][1]}
            for threshold in THRESHOLDS:
                first = next((s for s,a in points if a >= threshold), None)
                row[f"first_step_at_{threshold:.2f}"] = first
                row[f"hit_{threshold:.2f}"] = first is not None
            seed_rows.append(row)
            curve_rows.extend({"seed": cfg.seed, "arm": arm,
                               "step": step, "accuracy": acc}
                              for step,acc in points)
    by = {(r["seed"],r["arm"]):r for r in seed_rows}
    output = {"protocol": PROTOCOL, "n_seeds": len(manifest["runs"]),
              "thresholds": list(THRESHOLDS), "seed_arm": seed_rows,
              "auc_paired_differences": {}, "threshold_summary": {},
              "limit": "first-hit refers to observed evaluation checkpoints, not exact crossing step"}
    for other in ("uniform", "full"):
        gaps = [by[(r["seed"], "joint_ewma")]["auc_accuracy_trapezoid"] -
                by[(r["seed"],other)]["auc_accuracy_trapezoid"]
                for r in manifest["runs"]]
        output["auc_paired_differences"][f"joint_ewma_minus_{other}"] = cluster_interval(gaps)
    for threshold in THRESHOLDS:
        name = f"first_step_at_{threshold:.2f}"
        output["threshold_summary"][f"{threshold:.2f}"] = {}
        for arm in ARMS:
            values = [r[name] for r in seed_rows if r["arm"] == arm]
            hits = [v for v in values if v is not None]
            output["threshold_summary"][f"{threshold:.2f}"][arm] = {
                "hit_seeds": len(hits), "total_seeds": len(values),
                "first_step_by_seed": values,
                "mean_step_among_hits_exploratory":
                    float(np.mean(hits)) if hits else None,
                "censored_seed_count": len(values)-len(hits)}
    return curve_rows, output


def adapter_metrics(initial: dict, uniform: dict, adaptive: dict, full: dict) -> dict:
    """Tensor duck-typed: supports torch Tensor and numpy in unit tests."""
    keys = set(initial)
    if not keys or any(set(x)!=keys for x in (uniform,adaptive,full)):
        raise ValueError("adapter key mismatch")
    vals = []
    for name in sorted(keys):
        arrays = []
        for source in (initial,uniform,adaptive,full):
            t = source[name]
            if hasattr(t,"detach"):
                t = t.detach().cpu().float().numpy()
            v = np.asarray(t,dtype=np.float64)
            if not np.all(np.isfinite(v)):
                raise ValueError("nonfinite adapter weights")
            arrays.append(v)
        if len({a.shape for a in arrays})!=1:
            raise ValueError("adapter parameter shape mismatch")
        vals.append(arrays)
    result={"adapter_parameter_count": sum(x[0].size for x in vals),
            "layer_count": len(vals)}
    def compare(i,j):
        squared = sum(float(np.square(x[i]-x[j]).sum()) for x in vals)
        ni = sum(float(np.square(x[i]).sum()) for x in vals)
        nj = sum(float(np.square(x[j]).sum()) for x in vals)
        dot = sum(float(np.sum(x[i]*x[j])) for x in vals)
        return {"l2": math.sqrt(squared),
                "relative_to_first_l2": math.sqrt(squared/max(ni,1e-30)),
                "cosine": float(dot/math.sqrt(ni*nj)) if ni>0 and nj>0 else None}
    result["uniform_vs_joint_ewma"]=compare(1,2)
    result["uniform_vs_full"]=compare(1,3)
    result["joint_ewma_vs_full"]=compare(2,3)
    result["uniform_vs_initial"]=compare(0,1)
    result["joint_ewma_vs_initial"]=compare(0,2)
    result["full_vs_initial"]=compare(0,3)
    return result


_LORA_A = re.compile(r"^(.*?)\.lora_A(?:\.[^.]+)?\.weight$")
_LORA_B = re.compile(r"^(.*?)\.lora_B(?:\.[^.]+)?\.weight$")


def effective_lora_metrics(initial: dict, uniform: dict, adaptive: dict,
                           full: dict, *, scaling: float) -> dict:
    """Gauge-insensitive Frobenius gaps between effective LoRA updates B@A.

    Avoid expanding dense Q/V matrices: <B1 A1,B2 A2> is computed from
    low-rank A/B cross products. All arms share the same base/scaling.
    """
    if not (math.isfinite(scaling) and scaling>0):
        raise ValueError("invalid LoRA scaling")
    def modules(state):
        groups={}
        for key,value in state.items():
            match_a=_LORA_A.match(key)
            match_b=_LORA_B.match(key)
            if not (match_a or match_b):
                continue
            group=(match_a or match_b).group(1)
            part="A" if match_a else "B"
            t=value
            if hasattr(t,"detach"):
                t=t.detach().cpu().float().numpy()
            a=np.asarray(t,dtype=np.float64)
            if a.ndim!=2 or not np.all(np.isfinite(a)):
                raise ValueError("invalid LoRA A/B tensor")
            groups.setdefault(group,{})[part]=a
        if not groups or any(set(x)!={"A","B"} for x in groups.values()):
            raise ValueError("no paired LoRA A/B weights found")
        if any(x["A"].shape[0]!=x["B"].shape[1] for x in groups.values()):
            raise ValueError("LoRA rank mismatch")
        return groups
    sources=[modules(s) for s in (initial,uniform,adaptive,full)]
    names=set(sources[0])
    if any(set(s)!=names for s in sources):
        raise ValueError("LoRA module names differ across arms")
    def dot(i,j):
        total=0.
        for name in names:
            a1,b1=sources[i][name]["A"],sources[i][name]["B"]
            a2,b2=sources[j][name]["A"],sources[j][name]["B"]
            if a1.shape!=a2.shape or b1.shape!=b2.shape:
                raise ValueError("LoRA module matrix shape changed")
            total+=float(np.sum((b1.T@b2)*(a1@a2.T)))
        return (scaling**2)*total
    norms=[max(0.,dot(i,i)) for i in range(4)]
    def compare(i,j):
        xy=dot(i,j)
        sq=max(0.,norms[i]+norms[j]-2*xy)
        return {"effective_delta_l2":math.sqrt(sq),
                "effective_relative_to_first_l2":math.sqrt(sq/max(norms[i],1e-30)),
                "effective_cosine":xy/math.sqrt(norms[i]*norms[j])
                    if norms[i]>0 and norms[j]>0 else None}
    return {"lora_modules":len(names),"scaling":scaling,
            "uniform_vs_joint_ewma":compare(1,2),
            "uniform_vs_full":compare(1,3),
            "joint_ewma_vs_full":compare(2,3),
            "uniform_vs_initial":compare(0,1),
            "joint_ewma_vs_initial":compare(0,2),
            "full_vs_initial":compare(0,3)}


def inspect(output: Path, *, loader=None) -> dict:
    manifest,_ = locked_inputs(output)
    curves,curve_summary = learning_curves(manifest)
    write_once(Path(output)/"phase6c_learning_curve_stats.json",curve_summary)
    csv_once(Path(output)/"phase6c_checkpoint_learning_curves.csv",curves,
             ["seed","arm","step","accuracy"])
    if loader is None:
        try:
            import torch
        except ImportError as exc:
            raise RuntimeError("checkpoint weight distances require PyTorch") from exc
        loader = lambda p: torch.load(p,map_location="cpu",weights_only=True)
    distances = []
    for run in manifest["runs"]:
        root=Path(run["root"])
        cfg=Phase6CConfig(**run["config"])
        checkpoints={a:open_existing_checkpoint(root,a) for a in ARMS}
        states={a:loader(stored_state(cp,cfg.steps))["adapter"]
                for a,cp in checkpoints.items()}
        initial=loader(stored_state(checkpoints["uniform"],0))["adapter"]
        for a in ("full","joint_ewma"):
            other=loader(stored_state(checkpoints[a],0))["adapter"]
            if adapter_metrics(initial,other,initial,initial)["uniform_vs_joint_ewma"]["l2"] != 0:
                raise RuntimeError("different initial LoRA adapters across arms")
        distances.append({"seed":run["seed"],
                          **adapter_metrics(initial,states["uniform"],
                                            states["joint_ewma"],states["full"]),
                          "effective_update":effective_lora_metrics(
                              initial,states["uniform"],states["joint_ewma"],
                              states["full"],scaling=cfg.lora_alpha/cfg.lora_rank)})
    distance_summary={"protocol":PROTOCOL,"per_seed":distances,
                      "claim_boundary":"parameter distances establish divergence, not superior generalization"}
    write_once(Path(output)/"phase6c_adapter_distances.json",distance_summary)
    return {"status":"inspected","n_seeds":len(distances),
            "auc_adaptive_minus_uniform":curve_summary["auc_paired_differences"]["joint_ewma_minus_uniform"],
            "final_adapter_distances_l2":[d["uniform_vs_joint_ewma"]["l2"] for d in distances],
            "effective_update_distances_l2":[d["effective_update"]["uniform_vs_joint_ewma"]
                ["effective_delta_l2"] for d in distances]}
