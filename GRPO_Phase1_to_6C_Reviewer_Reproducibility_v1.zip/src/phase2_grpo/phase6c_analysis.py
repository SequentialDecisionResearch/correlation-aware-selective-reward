"""Post-hoc multi-seed paired analysis of sealed, independently audited 6C runs.

Runs are comparable only when their locked configurations match except for
the training random seed. All confidence intervals cluster at the SEED level.
With a small number of seeds, intervals are descriptive, not guarantees.
"""

from copy import deepcopy
import csv
import json
from pathlib import Path

import numpy as np
from scipy.stats import t as student_t

from .phase6a_checkpoint import atomic_json
from .phase6c_objectives import ARMS


def _read_json(path):
    with Path(path).open(encoding="utf-8") as stream:
        return json.load(stream)


def _paired_summary(values):
    x=np.asarray(values,float)
    if x.ndim!=1 or len(x)<1 or not np.all(np.isfinite(x)):
        raise ValueError("invalid paired seed-level observations")
    m=float(x.mean())
    half=(float(student_t.ppf(.975,len(x)-1)*x.std(ddof=1)/np.sqrt(len(x)))
          if len(x)>1 else None)
    return {"mean_delta":m,"seed_cluster_t95":None if half is None else
            [m-half,m+half],"n_independent_seeds":len(x),
            "positive_seed_fraction":float(np.mean(x>0))}


def aggregate(paths, output: str|Path, *, allow_fake_qa: bool=False):
    """Refuse absent audits, incomplete arms and non-comparable schedules."""
    run_dirs=[Path(path) for path in paths]
    if not run_dirs:
        raise ValueError("provide at least one completed Phase6C run directory")
    rows=[];template=None;seeds=set()
    for path in run_dirs:
        summary=_read_json(path/"phase6c_summary.json")
        audit=_read_json(path/"phase6c_audit.json")
        if (summary.get("phase")!="6C" or not summary.get("complete") or
                set(summary.get("final_heldout",{}))!=set(ARMS)):
            raise RuntimeError(f"missing full training arms: {path}")
        if (not audit.get("pass") or audit.get("checked_train_steps")!=
                audit.get("expected") or audit.get("expected")!=
                3*summary["config"]["steps"]):
            raise RuntimeError(f"invalid or incomplete 6C journal audit: {path}")
        if not allow_fake_qa and not summary.get("genuine_model_updates"):
            raise RuntimeError(f"not real LoRA training (likely fake QA): {path}")
        config=deepcopy(summary["config"])
        seed=int(config.pop("seed"))
        if seed in seeds:
            raise ValueError(f"repeated seed {seed}: paired replicates not independent")
        seeds.add(seed)
        if template is None:
            template=config
        elif config!=template:
            raise ValueError("locked training parameters differ beyond seed")
        acc={a:float(summary["final_heldout"][a]["accuracy"]) for a in ARMS}
        rows.append({"seed":seed,"path":str(path),
                     "full_accuracy":acc["full"],
                     "uniform_accuracy":acc["uniform"],
                     "joint_ewma_accuracy":acc["joint_ewma"],
                     "adaptive_minus_uniform":acc["joint_ewma"]-acc["uniform"],
                     "adaptive_minus_full":acc["joint_ewma"]-acc["full"],
                     "uniform_minus_full":acc["uniform"]-acc["full"]})
    rows.sort(key=lambda row:row["seed"])
    out=Path(output)
    out.mkdir(parents=True,exist_ok=True)
    with (out/"phase6c_seed_pairs.csv").open("w",encoding="utf-8",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader()
        writer.writerows(rows)
    result={"phase":"6C_multiseed", "n_seeds":len(rows),
            "independent_seed_ids":[row["seed"] for row in rows],
            "common_config_excluding_seed":template,
            "real_LoRA_required":not allow_fake_qa,
            "paired_accuracy":{k:_paired_summary([row[k] for row in rows])
                 for k in ("adaptive_minus_uniform","adaptive_minus_full",
                           "uniform_minus_full")},
            "limitations":"seed-cluster descriptive t intervals; shared heldout prompts; no external evaluation; binary arithmetic reward"}
    atomic_json(out/"phase6c_multiseed_summary.json",result)
    return result
