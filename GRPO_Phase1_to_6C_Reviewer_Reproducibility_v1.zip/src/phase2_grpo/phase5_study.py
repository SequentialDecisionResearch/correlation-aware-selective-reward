"""Phase-5 LOCKED online synthetic study; no LLM and no algorithm tuning.

The protocol is in docs/PHASE5_FROZEN_PROTOCOL.md. All candidate policies
receive only historically purchased residuals. Evaluation-only full rewards
and true second moments stay inside the driver. New random streams and world
profiles are disjoint from Phase 1--4 development and holdout experiments.
"""

import csv
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.stats import t as student_t

from .geometry import gradient_map
from .holdout_world import draw_residual, WorldState
from .online_study import OnlineAcquirer, OnlineConfig
from .optimization import optimize_coupling
from .oracle import CountingOracle
from .risk import acquisition_risk, augmented_rewards


PHASE5_SEEDS = (4001, 4003, 4007, 4013, 4019, 4021, 4027, 4049,
                4051, 4057, 4073, 4079, 4091, 4093, 4099, 4111)
PHASE5_WORLDS = (
    'stationary_independent', 'stationary_positive_factor',
    'stationary_sparse_t5', 'abrupt_sign_switch',
    'two_change_blocks', 'smooth_sigmoid_rotation',
)
PHASE5_POLICIES = ('uniform', 'cube_classic', 'scaled',
                   'joint_ewma', 'joint_frozen')
PRIMARY = ('scaled', 'uniform', 'joint_frozen')


def _factor(v: np.ndarray, diag: np.ndarray) -> np.ndarray:
    matrix = np.outer(v, v) + np.diag(diag)
    return matrix * (6. / np.trace(matrix))


def phase5_world(name: str, step: int, horizon: int = 160) -> WorldState:
    """All covariance functions specified before the confirmatory run."""
    if name not in PHASE5_WORLDS or not 0 <= step < horizon:
        raise ValueError('unrecognized world or out-of-range step')
    independent = np.diag([.42, .73, .98, 1.10, 1.28, 1.49])
    pos = _factor(np.array([.55, .9, .75, 1.2, .4, .65]),
                  np.array([.55, .8, .7, .55, .95, .65]))
    neg = _factor(np.array([-.8, .65, -.5, .95, -.9, .35]),
                  np.array([.65, .45, .8, .7, .55, .95]))
    sparse = np.array([
        [1.,.57,0,0,0,0], [.57,1.15,0,0,0,0],
        [0,0,.8,-.45,0,0], [0,0,-.45,1.25,0,0],
        [0,0,0,0,.7,.22], [0,0,0,0,.22,1.10],
    ])
    sparse *= 6. / np.trace(sparse)
    distribution = 'normal'
    onset = None
    change = False
    if name == 'stationary_independent':
        v = independent
    elif name == 'stationary_positive_factor':
        v = pos
    elif name == 'stationary_sparse_t5':
        v, distribution = sparse, 'student_t5'
    elif name == 'abrupt_sign_switch':
        onset, change = 68, True
        v = pos if step < onset else neg
    elif name == 'two_change_blocks':
        onset, change = 52, True
        v = sparse if step < 52 else pos if step < 112 else neg
    else:
        onset, change = 36, True
        z = (step - 92.) / 19.
        blend = 1. / (1. + np.exp(-z))
        v = (1. - blend) * neg + blend * pos
    if np.linalg.eigvalsh(v).min() <= 0:
        raise AssertionError('covariance must be positive definite')
    return WorldState(v, distribution, change, onset)


def _run_world(seed: int, world: str, cfg: OnlineConfig) -> list[dict]:
    children = np.random.SeedSequence([
        20261113, seed, PHASE5_WORLDS.index(world)
    ]).spawn(2 + len(PHASE5_POLICIES))
    score_rng, reward_rng, *policy_rngs = [np.random.default_rng(c) for c in children]
    agents = {p: OnlineAcquirer(p, cfg) for p in PHASE5_POLICIES}
    draws = dict(zip(PHASE5_POLICIES, policy_rngs))
    rows = []
    for step in range(cfg.horizon):
        state = phase5_world(world, step, cfg.horizon)
        scores = score_rng.normal(size=(3, cfg.g))
        hidden = draw_residual(reward_rng, state)
        m = gradient_map(scores)
        oracle, _ = optimize_coupling(scores, state.moment,
                                      agents['uniform'].pi, cfg.b)
        lower = acquisition_risk(scores, state.moment, oracle)
        for policy in PHASE5_POLICIES:
            agent = agents[policy]
            # Only the evaluator computes the next quantity; it is not
            # provided to .propose() or .observe().
            fit_error_before = float(np.linalg.norm(
                agent.model.fitted - state.moment, ord='fro'))
            tic = perf_counter()
            design, meta = agent.propose(scores)
            runtime = perf_counter() - tic
            true_risk = float(acquisition_risk(scores, state.moment, design))
            if true_risk + 1e-7 < lower:
                raise AssertionError('oracle optimality violation')
            if abs(design.marginals - .5).max() > 1e-7:
                raise AssertionError('first inclusion probabilities changed')
            selected = design.draw(draws[policy]).astype(bool)
            gold = CountingOracle(hidden)
            rewards = gold.reveal(np.flatnonzero(selected))
            if gold.calls != cfg.b:
                raise AssertionError('unequal purchased gold budget')
            masked = np.full(cfg.g, np.nan)
            masked[selected] = rewards
            estimate = augmented_rewards(masked, np.zeros(cfg.g),
                                         selected, design.marginals)
            actual_sq = float(np.linalg.norm(m @ (estimate - hidden)) ** 2)
            diagnostics = agent.observe(masked, selected, design)
            rows.append({
                'seed': seed, 'world': world, 'step': step,
                'period': 'later' if step >= cfg.horizon // 2 else 'early',
                'policy': policy, 'distribution': state.distribution,
                'true_onset': state.onset,
                'true_change': int(state.change_truth),
                'true_risk': true_risk, 'oracle_risk': float(lower),
                'realized_squared_error': actual_sq,
                'covariance_error_before': fit_error_before,
                'pair_ess_before': float(meta['pair_ess_before']),
                'gold_queries': gold.calls,
                'decision': meta['decision'],
                'proposal_seconds': runtime,
                'min_pair_inclusion': float(np.min(
                    design.pair_inclusions[np.triu_indices(cfg.g, 1)])),
                'max_marginal_error': float(np.max(
                    abs(design.marginals - .5))),
                'selected_subset': ''.join(str(int(x)) for x in selected),
                'drift_alert': int(diagnostics['alert']),
            })
    return rows


def _seed_interval(deltas: dict[int, list[float]]) -> dict:
    arr = np.array([np.mean(x) for _, x in sorted(deltas.items())])
    mean = float(arr.mean())
    margin = float(student_t.ppf(.975, len(arr) - 1)
                   * arr.std(ddof=1) / np.sqrt(len(arr)))
    return {'seed_count': len(arr), 'paired_mean_gain': mean,
            'descriptive_t95': [mean - margin, mean + margin],
            'positive_seed_fraction': float(np.mean(arr > 0))}


def summarize_phase5(rows: list[dict], cfg: OnlineConfig,
                     seeds: tuple[int, ...], worlds: tuple[str, ...]) -> dict:
    summary = {'study': 'Phase5_frozen_synthetic_one_step_surrogate',
               'parameters': asdict(cfg), 'new_seeds': list(seeds),
               'new_worlds': list(worlds), 'policies': list(PHASE5_POLICIES),
               'rows': len(rows),
               'metered_synthetic_gold_queries': sum(x['gold_queries'] for x in rows),
               'externally_preregistered': False,
               'no_real_LLM_post_training': True}
    per_world = {}
    primary_by_seed = {baseline: {s: [] for s in seeds} for baseline in PRIMARY}
    all_methods = {}
    for world in worlds:
        late = [x for x in rows if x['world'] == world and x['period'] == 'later']
        risk = {p: {(x['seed'], x['step']): x['true_risk'] for x in late
                    if x['policy'] == p} for p in PHASE5_POLICIES}
        world_row = {'risk_by_policy': {p: float(np.mean(list(risk[p].values())))
                                        for p in PHASE5_POLICIES},
                     'mean_covariance_error_by_policy': {
                         p: float(np.mean([x['covariance_error_before'] for x in late
                                           if x['policy'] == p])) for p in PHASE5_POLICIES}}
        for baseline in PRIMARY:
            deltas = {s: [] for s in seeds}
            for (s, t), val in risk[baseline].items():
                gain = val - risk['joint_ewma'][(s, t)]
                deltas[s].append(gain)
                primary_by_seed[baseline][s].append(gain)
            world_row[f'gain_{baseline}_minus_joint'] = _seed_interval(deltas)
        per_world[world] = world_row
    for p in PHASE5_POLICIES:
        all_methods[p] = {
            'mean_later_risk': float(np.mean([
                x['true_risk'] for x in rows if x['policy'] == p
                and x['period'] == 'later'])),
            'mean_proposal_seconds': float(np.mean([
                x['proposal_seconds'] for x in rows if x['policy'] == p])),
        }
    summary['worlds'] = per_world
    summary['overall_later_risks'] = all_methods
    summary['primary_comparisons'] = {
        f'{base}_minus_joint': _seed_interval(primary_by_seed[base])
        for base in PRIMARY}
    summary['worlds_joint_better_than_scaled'] = sum(
        cell['gain_scaled_minus_joint']['paired_mean_gain'] > 1e-9
        for cell in per_world.values())
    independent = per_world.get('stationary_independent')
    if independent is not None:
        summary['independent_no_coupling_max_risk_gap'] = float(
            max(independent['risk_by_policy'].values())
            - min(independent['risk_by_policy'].values()))
    return summary


def run_phase5(output: str | Path, quick: bool = False) -> dict:
    start = perf_counter()
    cfg = OnlineConfig() if not quick else OnlineConfig(
        horizon=80, warmup=26, window=18)
    seeds = PHASE5_SEEDS if not quick else PHASE5_SEEDS[:2]
    worlds = PHASE5_WORLDS if not quick else PHASE5_WORLDS[:2]
    records = []
    for world in worlds:
        for seed in seeds:
            records.extend(_run_world(seed, world, cfg))
    summary = summarize_phase5(records, cfg, seeds, worlds)
    summary['quick_smoke_only'] = quick
    summary['runtime_seconds'] = perf_counter() - start
    summary['source_hashes_sha256'] = {
        name: hashlib.sha256((Path(__file__).parent / name).read_bytes()).hexdigest()
        for name in ('phase5_study.py', 'online_study.py', 'online_moments.py')}
    target = Path(output)
    target.mkdir(parents=True, exist_ok=True)
    with (target / 'phase5_trials.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    (target / 'phase5_summary.json').write_text(
        json.dumps(summary, indent=2), encoding='utf-8')
    return summary
