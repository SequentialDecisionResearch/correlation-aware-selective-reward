"""Crash-resistant, versioned, individually committed Phase-6A checkpoints.

Each completed group/policy decision is fsynced to a temporary file and
atomically renamed.  An interrupted write never counts as completed work.
The reader validates a SHA-256 envelope before using any persisted record.
"""

from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Iterator


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    """Durable replace; a crash leaves the previous complete file intact."""
    path.parent.mkdir(parents=True, exist_ok=True)
    data = canonical(value) + b"\n"
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent,
                                         prefix=f".{path.name}.", suffix=".tmp",
                                         delete=False) as handle:
            tmp = Path(handle.name)
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        if os.name != "nt":
            directory_fd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
    finally:
        if tmp is not None and tmp.exists():
            tmp.unlink()


@contextmanager
def run_lock(output: Path) -> Iterator[None]:
    """Nonblocking OS-owned lock; released automatically after a hard crash."""
    output.mkdir(parents=True, exist_ok=True)
    with (output / "phase6a.lock").open("a+b") as handle:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            if not handle.read(1):
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise RuntimeError("another Phase-6A process owns this run") from exc
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise RuntimeError("another Phase-6A process owns this run") from exc
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


class Checkpoints:
    def __init__(self, directory: str | Path, config: dict):
        self.directory = Path(directory)
        self.fingerprint = digest(config)
        manifest = self.directory / "manifest.json"
        if manifest.exists():
            stored = self._read_raw(manifest)
            if stored.get("config") != config or stored.get("fingerprint") != self.fingerprint:
                raise RuntimeError("checkpoint/config mismatch; use a NEW --output folder")
        else:
            atomic_json(manifest, {"schema": 1, "config": config,
                                   "fingerprint": self.fingerprint})

    @staticmethod
    def _read_raw(path: Path) -> dict:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, UnicodeError) as exc:
            raise RuntimeError(f"corrupt checkpoint: {path}") from exc
        if not isinstance(value, dict):
            raise RuntimeError(f"checkpoint is not an object: {path}")
        return value

    def save(self, kind: str, index: int, payload: dict) -> None:
        if index < 0 or not kind or "/" in kind or ".." in kind or "\\" in kind:
            raise ValueError("invalid checkpoint key")
        path = self.path(kind, index)
        if path.exists():
            raise RuntimeError(f"refusing to overwrite committed checkpoint: {path}")
        core = {"schema": 1, "fingerprint": self.fingerprint,
                "kind": kind, "index": index, "payload": payload}
        atomic_json(path, {**core, "sha256": digest(core)})

    def path(self, kind: str, index: int) -> Path:
        if not kind or "/" in kind or ".." in kind or "\\" in kind:
            raise ValueError("invalid checkpoint kind")
        return self.directory / kind / f"group_{index:06d}.json"

    def load(self, kind: str, index: int) -> dict | None:
        path = self.path(kind, index)
        if not path.exists():
            return None
        record = self._read_raw(path)
        checksum = record.pop("sha256", None)
        if (checksum != digest(record) or record.get("fingerprint") != self.fingerprint
                or record.get("kind") != kind or record.get("index") != index
                or record.get("schema") != 1 or not isinstance(record.get("payload"), dict)):
            raise RuntimeError(f"checkpoint integrity failure: {path}")
        return record["payload"]

    def contiguous_count(self, kind: str, expected: int) -> int:
        folder = self.directory / kind
        actual = sorted(folder.glob("group_*.json")) if folder.exists() else []
        if len(actual) > expected:
            raise RuntimeError(f"unexpected extra {kind} checkpoints")
        for i, path in enumerate(actual):
            if path.name != f"group_{i:06d}.json":
                raise RuntimeError(f"missing or duplicated checkpoint in {kind}")
            self.load(kind, i)
        return len(actual)
