"""Resumable *real weight-updating* LoRA/GRPO-family training experiment.

Design-aware primary estimator is LOO-HT, with exact conditional score-gradient
unbiasedness only BEFORE clipping, data-dependent normalization or reuse.
The alternate normalized objective is an explicitly BIASED plug-in with
partially acquired rewards. This is not a claim to reproduce every detail
of the HuggingFace TRL GRPOTrainer implementation.
"""

from dataclasses import asdict
import csv
import hashlib
import os
from pathlib import Path
import platform
import tempfile
from typing import Callable

import numpy as np
import scipy

from .design import ExactBDesign
from .online_study import OnlineAcquirer, OnlineConfig
from .phase6a_checkpoint import Checkpoints, atomic_json, digest, run_lock
from .phase6a_model import decision_seed
from .phase6a_study import source_hashes
from .phase6a_tasks import make_tasks, score_answer
from .phase6b_study import b_tasks
from .phase6c_objectives import (ARMS, Phase6CConfig, advantage,
                                 full_advantage, policy_score_gradient)


def _hashes() -> dict:
    base=Path(__file__).resolve()
    root=base.parents[2]
    result=source_hashes()
    for relative in ("src/phase2_grpo/phase6b_study.py",
            "src/phase2_grpo/phase6c_objectives.py",
            "src/phase2_grpo/phase6c_model.py",
            "src/phase2_grpo/phase6c_training.py",
            "scripts/run_phase6c.py"):
        result[relative]=hashlib.sha256((root/relative).read_bytes()).hexdigest()
    return result


def locked(cfg: Phase6CConfig) -> dict:
    hashes=_hashes()
    if cfg.task_family!="legacy":
        root=Path(__file__).resolve().parents[2]
        for relative in ("src/phase2_grpo/phase6c_calibrated_tasks.py",
                         "src/phase2_grpo/phase6b_calibration2.py",
                         "scripts/run_phase6c_calibrated.py"):
            hashes[relative]=hashlib.sha256((root/relative).read_bytes()).hexdigest()
    return {"phase":"6C", "schema":3 if cfg.task_family!="legacy" else 2,
            "config":asdict(cfg),"source_sha256":hashes,
            "runtime":{"python":platform.python_version(),
                       "numpy":np.__version__,"scipy":scipy.__version__},
            "reward_protocol":"v1.2_last_explicit_answer_box_or_label_or_bare",
            "format_protocol":"v1.2_strict_boxed_only_separately_reported",
            "claim_boundary":"actual_LoRA_update; LOO-HT_unbiased_before_clipping; cheap_reward_budget_is_logical"}


def _tasks(cfg):
    if cfg.task_family!="legacy":
        from .phase6c_calibrated_tasks import calibrated_tasks
        return calibrated_tasks(cfg)
    train=make_tasks(count=cfg.steps,seed=cfg.seed,schedule=cfg.train_schedule)
    heldout=b_tasks(cfg.eval_size,seed=cfg.seed+100_000,
                    scenario="interleaved_control")
    return train,heldout


def _cp(cfg,output,arm):
    if arm not in ARMS:
        raise ValueError("invalid training arm")
    config={**locked(cfg),"arm":arm}
    cp=Checkpoints(Path(output)/"arms"/arm,config)
    train,heldout=_tasks(cfg)
    existing=cp.load("tasks",0)
    if existing is None:
        cp.save("tasks",0,{"train":train,"heldout":heldout})
    elif existing!={"train":train,"heldout":heldout}:
        raise RuntimeError("Phase6C task split altered after start")
    return cp,train,heldout


def _online(cfg):
    return OnlineConfig(g=cfg.g,b=cfg.b,
        horizon=max(80,cfg.steps,cfg.window*4,2*cfg.warmup+2),
        warmup=cfg.warmup,window=cfg.window,exploration=cfg.exploration)


def _agent_replay(cp,cfg,arm,count):
    if arm=="full":
        return None
    model=OnlineAcquirer(arm,_online(cfg))
    for i in range(count):
        row=cp.load("train_steps",i)
        design=ExactBDesign(np.asarray(row["design"]["subsets"]),
            np.asarray(row["design"]["probs"]),"replayed")
        selected=np.asarray(row["selected"],bool)
        seen=np.full(cfg.g,np.nan)
        seen[selected]=np.asarray(row["paid_rewards"],float)
        model.observe(seen,selected,design)
    return model


def _file_sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b""):
            h.update(block)
    return h.hexdigest()


def _state_path(cp,step):
    return cp.directory/"optimizer_states"/f"after_step_{step:06d}.pt"


def _save_state(cp,step,state):
    """Save optimizer+LoRA+RNG first; only JSON journal commits a step."""
    import torch
    target=_state_path(cp,step)
    target.parent.mkdir(parents=True,exist_ok=True)
    tmp=None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent,
                prefix=f".{target.name}.",suffix=".tmp",delete=False) as stream:
            tmp=Path(stream.name)
            torch.save(state,stream)
            stream.flush();os.fsync(stream.fileno())
        os.replace(tmp,target)
        if os.name!="nt":
            fd=os.open(target.parent,os.O_RDONLY)
            try:os.fsync(fd)
            finally:os.close(fd)
    finally:
        if tmp is not None and tmp.exists():
            tmp.unlink()
    return _file_sha(target)


def _restore(cp,n,policy):
    if n==0:
        return
    import torch
    last=cp.load("train_steps",n-1)
    f=_state_path(cp,n)
    if not f.is_file() or _file_sha(f)!=last["state_sha256"]:
        raise RuntimeError("latest LoRA/optimizer checkpoint missing or corrupt")
    policy.restore(torch.load(f,map_location="cpu",weights_only=True),n)


def _model_info(cp, info, root, cfg):
    # A moving HF `main` must not silently substitute a different base model
    # across training arms, even when each individual arm can resume.
    global_cp=Checkpoints(Path(root),locked(cfg))
    global_info=global_cp.load("shared_base_fingerprint",0)
    if global_info is None:
        global_cp.save("shared_base_fingerprint",0,info)
    elif global_info!=info:
        raise RuntimeError("inconsistent base model/environment ACROSS 6C training arms")
    existing=cp.load("model_info",0)
    if existing is None:
        cp.save("model_info",0,info)
    elif existing!=info:
        raise RuntimeError("model/weights/PyTorch fingerprint changed since checkpoint")


def _train_one(cfg,output,arm,*,max_new=None,policy_factory=None,progress=None):
    """At most max_new durable optimizer steps. A crash redoes at most one."""
    cp,tasks,heldout=_cp(cfg,output,arm)
    completed=cp.contiguous_count("train_steps",cfg.steps)
    if completed==cfg.steps or max_new==0:
        return 0,completed
    if policy_factory is None:
        from .phase6c_model import RealLoRAPolicy
        policy_factory=RealLoRAPolicy
    policy=policy_factory(cfg)
    _model_info(cp,policy.info,output,cfg)
    is_real_lora = policy.info.get("backend_type") == "hf_lora"
    _restore(cp,completed,policy)
    acquirer=_agent_replay(cp,cfg,arm,completed)
    if cp.load("baseline_eval",0) is None:
        cp.save("baseline_eval",0,policy.evaluate(heldout))
    if cfg.task_family!="legacy" and completed==0:
        initial=cp.load("initial_state",0)
        if initial is None:
            initial_sha=_save_state(cp,0,policy.checkpoint_payload(0))
            cp.save("initial_state",0,{"state_sha256":initial_sha})
        elif (_file_sha(_state_path(cp,0))!=initial["state_sha256"]):
            raise RuntimeError("initial LoRA adapter/optimizer state is corrupt")
    end=cfg.steps if max_new is None else min(cfg.steps,completed+max_new)
    for i in range(completed,end):
        task=tasks[i]
        public_task={"id":i,"prompt":task["prompt"],"level":task["level"]}
        generated=policy.generate(public_task,i)
        scores=np.asarray(generated["score_features"],float)
        if scores.shape!=(3,cfg.g) or not np.all(np.isfinite(scores)):
            raise RuntimeError("real-policy score sketch malformed")
        if arm=="full":
            selected=np.ones(cfg.g,bool)
            design=ExactBDesign(np.ones((1,cfg.g),dtype=np.int8),
                                np.ones(1),"full_feedback")
            decision="full_feedback"
        else:
            design,metadata=acquirer.propose(scores)
            decision=metadata["decision"]
            if (design.B!=cfg.b or
                    np.max(np.abs(design.marginals-cfg.b/cfg.g))>1e-7):
                raise RuntimeError("budget or marginal constraint violated")
            selected=design.draw(np.random.default_rng(
                decision_seed(cfg.seed,arm,i))).astype(bool)
        # Retrospective *cheap* oracle; NEVER pass full rewards to learner.
        scored=[score_answer(task,s["text"]) for s in generated["samples"]]
        oracle=np.asarray([x["reward"] for x in scored],float)
        paid=oracle[selected]
        seen=np.full(cfg.g,np.nan)
        seen[selected]=paid
        coeff=advantage(seen,selected,design.marginals,
                        objective=cfg.objective)
        if not np.all(np.isfinite(coeff)):
            raise RuntimeError("nonfinite acquired advantage")
        observed_info=acquirer.observe(seen,selected,design) if acquirer else None
        # Do not pass gold answers or unpurchased labels to the trainable
        # policy/optimizer, even as extra dictionary fields.
        train_report=policy.update(public_task,generated["samples"],coeff)
        evaluation=(policy.evaluate(heldout) if
                    (i+1)%cfg.eval_every==0 or i+1==cfg.steps else None)
        state_hash=_save_state(cp,i+1,policy.checkpoint_payload(i+1))
        # This atomic JSON is the sole durable step commit marker.
        cp.save("train_steps",i,{
            "index":i,"arm":arm,"task_level":task["level"],
            "generated":generated,"selected":selected.astype(int).tolist(),
            "paid_rewards":paid.tolist(),"shadow_full_rewards":oracle.tolist(),
            "shadow_full_parseable":[x["parseable"] for x in scored],
            "shadow_full_format_compliant":[x["format_compliant"] for x in scored],
            "shadow_full_strict_format_correct":[x["strict_format_correct"] for x in scored],
            "observed_only_advantage":coeff.tolist(),
            "design":{"subsets":design.subsets.tolist(),"probs":design.probs.tolist()},
            "decision":decision,"logical_reward_queries":int(selected.sum()),
            "shadow_reward_evaluations":cfg.g,
            "shadow_positive_rewards":int(oracle.sum()),
            "score_gradient_proxy":policy_score_gradient(scores,coeff).tolist(),
            "training":train_report,"heldout_evaluation":evaluation,
            "online_diagnostic":observed_info,
            "completed_optimizer_steps":(i+1)*cfg.update_epochs,
            "state_sha256":state_hash,"model_updates_are_real":is_real_lora})
        if progress:
            progress(arm,i+1,cfg.steps)
    return end-completed,end


def run(cfg: Phase6CConfig,output:str|Path,*,arms=ARMS,
        stage="all",max_new_steps=None,policy_factory=None,progress=None):
    if stage not in ("all","train","summary","audit"):
        raise ValueError("unknown 6C stage")
    if max_new_steps is not None and max_new_steps<0:
        raise ValueError("negative training limit")
    if not arms or len(set(arms))!=len(arms) or any(a not in ARMS for a in arms):
        raise ValueError("invalid training arm selection")
    root=Path(output)
    with run_lock(root):
        Checkpoints(root,locked(cfg))
        progresses={};remaining=max_new_steps
        if stage in ("all","train"):
            for arm in arms:
                new,n=_train_one(cfg,root,arm,max_new=remaining,
                                policy_factory=policy_factory,progress=progress)
                progresses[arm]={"new_updates":new,"completed":n}
                if remaining is not None:
                    remaining-=new
        if stage in ("all","summary","audit"):
            result=summarize(cfg,root,arms)
            if stage in ("all","audit") and result["complete"]:
                result["audit"]=audit(cfg,root,arms)
            return result
        return {"phase":"6C","progress":progresses}


def summarize(cfg,root,arms=ARMS):
    root=Path(root); progress={};metrics=[];final={};baseline={};positive={}
    parseable={};format_compliant={};strict_format_correct={}
    nonzero_gradient_steps={};nonzero_weight_delta_steps={};optimizer_steps={}
    complete=True; real_status={}
    for arm in arms:
        cp,_,_= _cp(cfg,root,arm)
        info=cp.load("model_info",0)
        real_status[arm]=bool(info and info.get("backend_type")=="hf_lora")
        base_ev=cp.load("baseline_eval",0)
        if base_ev is not None:
            baseline[arm]=base_ev
        n=cp.contiguous_count("train_steps",cfg.steps)
        progress[arm]=n
        positive[arm]=0
        parseable[arm]=0
        format_compliant[arm]=0
        strict_format_correct[arm]=0
        nonzero_gradient_steps[arm]=0
        nonzero_weight_delta_steps[arm]=0
        optimizer_steps[arm]=0
        complete &= n==cfg.steps
        for i in range(n):
            row=cp.load("train_steps",i)
            positive[arm]+=row["shadow_positive_rewards"]
            parseable[arm]+=sum(row["shadow_full_parseable"])
            format_compliant[arm]+=sum(row["shadow_full_format_compliant"])
            strict_format_correct[arm]+=sum(row["shadow_full_strict_format_correct"])
            norms=row["training"]["grad_norm_per_epoch"]
            nonzero_gradient_steps[arm]+=int(any(float(x)>0 for x in norms))
            delta=float(row["training"].get("adapter_delta_l2",0.))
            nonzero_weight_delta_steps[arm]+=int(delta>0)
            optimizer_steps[arm]+=int(row["training"]["genuine_lora_optimizer_steps"])
            ev=row["heldout_evaluation"]
            metrics.append({"arm":arm,"step":i+1,
                            "logical_reward_queries":row["logical_reward_queries"],
                            "shadow_positive_fraction":row["shadow_positive_rewards"]/cfg.g,
                            "shadow_parseable_fraction":sum(row["shadow_full_parseable"])/cfg.g,
                            "shadow_format_compliance_fraction":sum(row["shadow_full_format_compliant"])/cfg.g,
                            "shadow_strict_format_correct_fraction":sum(row["shadow_full_strict_format_correct"])/cfg.g,
                            "loss_final_epoch":row["training"]["loss_per_epoch"][-1],
                            "adapter_delta_l2":delta,
                            "grad_norm_max":max(float(x) for x in norms),
                            "heldout_accuracy":None if ev is None else ev["accuracy"],
                            "heldout_count":None if ev is None else ev["heldout_count"]})
            if ev is not None:
                final[arm]=ev
    result={"phase":"6C","complete":bool(complete),
            "config":asdict(cfg),"progress":progress,
            "evaluation_protocol":"v1.2_last_explicit_answer_box_or_label_or_bare",
            "strict_format_definition":"whole response exactly a boxed integer (whitespace allowed)",
            # An optimizer.step() with all-zero LOO advantages is a real
            # computation, but does not establish a nonzero model update.
            "genuine_model_updates":bool(complete and all(real_status.values())
                and all(nonzero_gradient_steps[a]>0 and
                        nonzero_weight_delta_steps[a]>0 for a in arms)),
            "real_optimizer_steps_committed_by_arm":optimizer_steps,
            "nonzero_gradient_steps_by_arm":nonzero_gradient_steps,
            "nonzero_weight_delta_steps_by_arm":nonzero_weight_delta_steps,
            "real_backend_by_arm":real_status,
            "initial_heldout":baseline,"final_heldout":final,
            "training_shadow_reward_positive_fraction_by_arm":{
                arm:(positive[arm]/(cfg.g*progress[arm]) if progress[arm] else None)
                for arm in arms},
            "training_shadow_parseable_fraction_by_arm":{
                arm:(parseable[arm]/(cfg.g*progress[arm]) if progress[arm] else None)
                for arm in arms},
            "training_shadow_format_compliance_fraction_by_arm":{
                arm:(format_compliant[arm]/(cfg.g*progress[arm]) if progress[arm] else None)
                for arm in arms},
            "training_shadow_strict_format_correct_fraction_by_arm":{
                arm:(strict_format_correct[arm]/(cfg.g*progress[arm]) if progress[arm] else None)
                for arm in arms},
            "total_logical_reward_queries":sum(x["logical_reward_queries"] for x in metrics),
            "limitation":"cheap exact arithmetic verifier; logical budget only; one seed per run; full arm has double label budget"}
    if metrics:
        with (root/"phase6c_learning_curves.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
    atomic_json(root/"phase6c_summary.json",result)
    return result


def audit(cfg,root,arms=ARMS):
    """Model-free replay of reward subsets and journal/state integrity.

    For calibrated real LoRA, also verify saved adjacent adapter-weight deltas
    on CPU. This still cannot independently re-execute GPU autograd/backward.
    """
    root=Path(root);checked=0;violations=[]
    for arm in arms:
        cp,tasks,_=_cp(cfg,root,arm)
        if cp.contiguous_count("train_steps",cfg.steps)!=cfg.steps:
            raise RuntimeError("Phase6C audit requires complete arms")
        if cfg.task_family!="legacy":
            initial=cp.load("initial_state",0)
            if (initial is None or not _state_path(cp,0).is_file() or
                    _file_sha(_state_path(cp,0))!=initial["state_sha256"]):
                raise RuntimeError("calibrated audit requires intact initial LoRA state")
        info=cp.load("model_info",0)
        real_lora=bool(info and info.get("backend_type")=="hf_lora")
        agent=None if arm=="full" else OnlineAcquirer(arm,_online(cfg))
        for i in range(cfg.steps):
            try:
                row=cp.load("train_steps",i)
                if row["index"]!=i or row["arm"]!=arm:
                    raise AssertionError("step identity changed")
                if _file_sha(_state_path(cp,i+1))!=row["state_sha256"]:
                    raise AssertionError("model/optimizer state corrupt")
                scores=np.asarray(row["generated"]["score_features"],float)
                sampled=row["generated"]["samples"]
                if len(sampled)!=cfg.g or scores.shape!=(3,cfg.g):
                    raise AssertionError("generated group malformed")
                rescored=[score_answer(tasks[i],s["text"]) for s in sampled]
                rewards=np.asarray([x["reward"] for x in rescored],float)
                if not np.array_equal(rewards,row["shadow_full_rewards"]):
                    raise AssertionError("oracle mismatch")
                for field,property_name in (("shadow_full_parseable","parseable"),
                        ("shadow_full_format_compliant","format_compliant"),
                        ("shadow_full_strict_format_correct","strict_format_correct")):
                    if row[field]!=[x[property_name] for x in rescored]:
                        raise AssertionError("shadow reward/format diagnostics mismatch")
                if int(rewards.sum())!=row["shadow_positive_rewards"]:
                    raise AssertionError("shadow reward count mismatch")
                delta=float(row["training"].get("adapter_delta_l2",0.))
                if not np.isfinite(delta) or delta<0:
                    raise AssertionError("invalid LoRA parameter delta diagnostic")
                if cfg.task_family!="legacy" and real_lora:
                    # Numerical verification against *actual saved adapter
                    # tensors*; a logged gradient norm alone is insufficient.
                    import torch
                    before=torch.load(_state_path(cp,i),map_location="cpu",weights_only=True)
                    after=torch.load(_state_path(cp,i+1),map_location="cpu",weights_only=True)
                    previous=before["adapter"];updated=after["adapter"]
                    if not previous or set(previous)!=set(updated):
                        raise AssertionError("LoRA adapter keys missing or changed")
                    actual=(sum(float((updated[k].float()-previous[k].float())
                            .square().sum()) for k in previous))**.5
                    if not np.isclose(delta,actual,rtol=1e-4,atol=1e-7):
                        raise AssertionError("reported LoRA update differs from saved weights")
                saved=ExactBDesign(np.asarray(row["design"]["subsets"]),
                                   np.asarray(row["design"]["probs"]),"audit")
                selected=np.asarray(row["selected"],bool)
                if arm=="full":
                    if not np.all(selected) or saved.B!=cfg.g:
                        raise AssertionError("full-feedback budget altered")
                else:
                    current,meta=agent.propose(scores)
                    a={tuple(z):float(p) for z,p in zip(saved.subsets,saved.probs)}
                    b={tuple(z):float(p) for z,p in zip(current.subsets,current.probs)}
                    if set(a)!=set(b) or any(abs(a[z]-b[z])>1e-7 for z in a):
                        raise AssertionError("adaptive proposal not reproducible")
                    draw=current.draw(np.random.default_rng(decision_seed(cfg.seed,arm,i)))
                    if not np.array_equal(selected,draw) or selected.sum()!=cfg.b:
                        raise AssertionError("subset RNG/budget mismatch")
                if not np.array_equal(rewards[selected],row["paid_rewards"]):
                    raise AssertionError("labels revealed incorrectly")
                seen=np.full(cfg.g,np.nan);seen[selected]=rewards[selected]
                coeff=advantage(seen,selected,saved.marginals,
                                objective=cfg.objective)
                if not np.allclose(coeff,row["observed_only_advantage"],atol=1e-9):
                    raise AssertionError("training advantage not observed-only")
                if not np.allclose(policy_score_gradient(scores,coeff),
                    row["score_gradient_proxy"],atol=1e-9):
                    raise AssertionError("score-gradient proxy mismatch")
                if agent:agent.observe(seen,selected,saved)
                checked+=1
            except Exception as exc:
                violations.append(f"{arm}/{i}: {exc}");break
    result={"pass":not violations,"checked_train_steps":checked,
            "expected":len(arms)*cfg.steps,"violations":violations,
            "scope":"journal/reward/design replay plus calibrated saved-adapter deltas; GPU backward not independently reproduced"}
    atomic_json(root/"phase6c_audit.json",result)
    if violations:raise AssertionError("Phase6C audit FAILED: "+violations[0])
    return result
