"""Predictable, masked-reward, propensity-aware online second moments.

Every update consumes only purchased residual entries and **actual** first-
and second-order inclusion probabilities of the randomized acquisition
mixture. This avoids phantom pair identification but does not guarantee
well-calibrated prompt-conditional confidence bounds.
"""

from collections import deque
from dataclasses import dataclass

import numpy as np

from .calibration import nearest_psd
from .design import ExactBDesign


def mix_design(candidate: ExactBDesign, exploration: ExactBDesign,
               epsilon: float) -> ExactBDesign:
    """Mixture gives all pair inclusion probability when 2<=B<G and eps>0.

    When q from the cube algorithm has partial support, union the supports
    rather than assume identical subset ordering. Preserves *exact* target
    first marginals and B; the actual pair probabilities are then recorded.
    """
    if (not np.isfinite(epsilon)) or not 0 <= epsilon <= 1:
        raise ValueError("epsilon must be in [0,1]")
    if candidate.G != exploration.G or candidate.B != exploration.B:
        raise ValueError("acquisition mixture size mismatch")
    if np.max(np.abs(candidate.marginals - exploration.marginals)) > 1e-8:
        raise ValueError("candidate/exploration must have the same marginals")
    weights: dict[tuple[int, ...], float] = {}
    for p, sub in zip(candidate.probs, candidate.subsets):
        key = tuple(map(int, sub))
        weights[key] = weights.get(key, 0.) + (1 - epsilon) * float(p)
    for p, sub in zip(exploration.probs, exploration.subsets):
        key = tuple(map(int, sub))
        weights[key] = weights.get(key, 0.) + epsilon * float(p)
    q = np.array(list(weights.values()), dtype=float)
    q /= q.sum()
    support = np.asarray(list(weights), dtype=np.int8)
    result = ExactBDesign(support, q,
                          f"mixture_eps_{epsilon:g}_{candidate.label}")
    if np.max(np.abs(result.marginals - candidate.marginals)) > 1e-7:
        raise AssertionError("mixture destroyed prescribed marginals")
    return result


@dataclass(frozen=True)
class DriftReport:
    statistic: float
    detected: bool
    sufficient_history: bool
    min_pair_ess: float


class OnlineSecondMoment:
    """Exponentially weighted IPW moments + transparent two-window monitor.

    The two-window Frobenius statistic is *heuristic*, NOT a calibrated test
    at a given type-I level; adaptive sampling violates a naive permutation
    exchangeability argument. All thresholds below are development choices.
    Never call :meth:`update` before acquisition; that would leak rewards.
    """

    def __init__(self, g: int, *, ewma_alpha: float = .075,
                 ridge: float = .02, diagonal_shrinkage: float = .08,
                 window: int = 22, drift_threshold: float = 1.30,
                 ess_history: int = 100):
        if (g < 3 or not 0 < ewma_alpha <= 1 or ridge < 0
                or not 0 <= diagonal_shrinkage <= 1 or window < 3
                or drift_threshold <= 0 or ess_history < 2 * window):
            raise ValueError("invalid online moment parameters")
        self.g = g
        self.alpha = ewma_alpha
        self.ridge = ridge
        self.shrink = diagonal_shrinkage
        self.window = window
        self.threshold = drift_threshold
        self.ewma = np.eye(g)
        self.count = 0
        self.contributions: deque[np.ndarray] = deque(maxlen=2 * window)
        self.weights: deque[np.ndarray] = deque(maxlen=ess_history)
        self.last_report = DriftReport(0., False, False, 0.)
        self.change_events: list[int] = []

    @property
    def fitted(self) -> np.ndarray:
        raw = (self.ewma + self.ewma.T) / 2
        diagonal = np.diag(np.maximum(np.diag(raw), .05))
        shrunk = (1 - self.shrink) * raw + self.shrink * diagonal
        return nearest_psd(shrunk + self.ridge * np.eye(self.g), 1e-8)

    def min_pair_ess(self) -> float:
        if not self.weights:
            return 0.
        weights = np.stack(tuple(self.weights), axis=0)
        sw = weights.sum(axis=0)
        ess = sw * sw / (np.square(weights).sum(axis=0) + 1e-20)
        return float(np.min(ess[np.triu_indices(self.g, 1)]))

    def update(self, observed_residuals: np.ndarray, selected: np.ndarray,
               design: ExactBDesign, *, allow_detection: bool = True) -> DriftReport:
        """Observe only purchased entries and compute their IPW cross-products.

        `design` MUST be the actual mixture used for the draw, not the
        un-mixed candidate. B>=2 and pair positivity are required.
        """
        residual = np.asarray(observed_residuals, dtype=float)
        mask = np.asarray(selected, dtype=bool)
        if (residual.shape != (self.g,) or mask.shape != (self.g,)
                or design.G != self.g or int(mask.sum()) != design.B):
            raise ValueError("observed residual/selection/design shape mismatch")
        if not np.all(np.isfinite(residual[mask])):
            raise ValueError("all purchased residuals must be finite")
        joint_prob = design.pair_inclusions
        if np.any(joint_prob <= 1e-14):
            raise ValueError("strict pair inclusion required; mix with uniform B>=2")
        x = np.zeros(self.g)
        x[mask] = residual[mask]
        # This is IPW for E[e_i e_j], including i==j: pi_ii=pi_i.
        ipw = np.outer(x, x) / joint_prob
        self.ewma = (1 - self.alpha) * self.ewma + self.alpha * ipw
        weights = np.outer(mask, mask).astype(float) / joint_prob
        self.contributions.append(ipw)
        self.weights.append(weights)
        self.count += 1
        if len(self.contributions) != 2 * self.window:
            report = DriftReport(0., False, False, self.min_pair_ess())
            self.last_report = report
            return report
        parts = list(self.contributions)
        old = np.mean(parts[:self.window], axis=0)
        new = np.mean(parts[self.window:], axis=0)
        # Both moments are unbiased under constant V, but observations are
        # heteroskedastic due to adaptive inclusion probabilities.
        distance = float(np.linalg.norm(new - old, "fro"))
        scale = max(1., float(np.linalg.norm(old, "fro")),
                    float(np.linalg.norm(new, "fro")))
        statistic = distance / scale
        detected = bool(allow_detection and statistic > self.threshold)
        if detected:
            self.change_events.append(self.count)
            # Lose stale history while retaining observed first-order scale;
            # do not inspect the true (inaccessible) covariance.
            self.ewma = np.diag(np.maximum(np.diag(self.ewma), .1))
            self.contributions.clear()
            self.weights.clear()
        report = DriftReport(statistic, detected, True,
                             self.min_pair_ess())
        self.last_report = report
        return report
