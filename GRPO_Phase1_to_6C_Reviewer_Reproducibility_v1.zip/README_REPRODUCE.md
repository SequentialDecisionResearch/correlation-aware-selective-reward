# GRPO evidence and reproducibility bundle (Phase 1–6D)

**Scope:** A compact, inspectable repository for the archived numerical evidence,
the Python/R implementations, figure scripts, Phase 6C training journals,
and all 144 Phase 6D frozen-checkpoint records. Phase 6C and Phase 6D each have
a **CPU-only** evidence replay. Smoke archives, redundant ZIPs, caches,
optimizer states, and downloaded base-model weights are not included.

**Start here for an honest reproduction claim:** this ZIP can regenerate the
paper's tables and figures *from archived data*. For Phase 6D it verifies the
original SHA-256 group records and independently recalculates all 144 pairs
of exact true-gradient/sketch acquisition risks from stored six-by-six Gram
matrices and all 20 selection subsets. It **cannot** reproduce the original
GPU backward passes, recompute original adapter-weight distances from weights,
or re-run Qwen inference, because `optimizer_states/*.pt` were deliberately
omitted to reduce the source transfer from approximately 3.17 GB. The numeric
results requiring those omitted operations are included as **archived output**.
If an independent GPU audit of those claims is required, the original complete
checkpoints must be supplied separately, or the training must be rerun. Reruns
need not be bit-for-bit identical across PyTorch/CUDA/model revisions.

## Quick start (Windows CMD or PowerShell)

Extract the ZIP and `cd` to the folder containing this file.

```text
python -m pip install -e ".[figures]"
python -m unittest discover -s tests -q
python scripts/reproduce_archived_results.py --verify-only
python scripts/reproduce_phase6d_archived.py
python scripts/reproduce_archived_results.py --output reproduced_outputs
```

The first two commands require installed dependencies. Phase 6C numerical
verification uses only the Python standard library; Phase 6D exact-risk replay
uses NumPy and SciPy, but no PyTorch or GPU. Plotting needs `matplotlib`,
installed by the `figures` extra. The third and fourth commands validate the
archived evidence; the fifth creates:

- `reproduced_outputs/phase6c_verified_summary.json`
- `reproduced_outputs/figures/phase6c_mean_learning_curves.png`
- `reproduced_outputs/figures/phase6c_stress_by_difficulty.png`
- `reproduced_outputs/figures/phase6c_effective_lora_distances.png`

The curves show per-arm means across **three independent seeds**. Their light
shaded ranges show the observed minimum and maximum, **not confidence bands**.
All three figures are descriptive; the fixed stress task bank was designed
*after* earlier heldout outcomes were observed (but locked before stress
predictions), so it is an exploratory test.

## Reproduce archived earlier-phase figures

All raw inputs and existing PNGs are in `results/`. Run from the repository
root after installing `.[figures]`:

```text
python scripts/make_figures.py
python scripts/make_phase2_figures.py --input results/phase2_full/all_trials.csv --output results/phase2_figures
python scripts/make_online_figures.py
python scripts/make_phase4_holdout_figures.py --input results/phase4_frozen_holdout_full --output results/phase4_figures
python scripts/make_phase5_figures.py --input results/phase5_full --output results/phase5_figures
```

These commands regenerate existing image files in `results/`. Phase 2, 4, and 5
generation was independently exercised during packaging using distinct
temporary output folders; no claims are made that plots necessarily have
byte-for-byte-identical PNG hashes across matplotlib versions.

## Archived Phase 6C evidence (real LoRA runs)

- `results/phase6b_calibration2_v1/`: locked Phase 6B reward-density and
  design-calibration records, selected `two_digit_add` task family.
- `results/phase6c_cal2_seed6207/`, `...6219/`, `...6251/`: original three
  60-step run summaries, audit records, per-arm training journals and curves.
- `results/phase6c_cal2_multiseed/`: original paired three-seed summary.
- `results/phase6c_v15_diagnostics/`: locked stress bank, per-item predictions,
  per-item paired differences, checkpoint AULC statistics, archived effective
  LoRA distance measurements, and stress-stratified summaries.

The `scripts/reproduce_archived_results.py` verifier checks SHA-256 fingerprints
of the **unaltered** run summaries and original audits against the frozen
diagnostic manifest. It cross-checks all reported final accuracies, the
aggregate paired gaps, 63 checkpoint learning-curve cells, nine AULC records,
3,240 item prediction rows, 1,080 paired item rows, and stress means across
all methods and difficulty strata. These are consistency and arithmetic
replays, **not** an independent replication of original GPU execution.

Archived final heldout accuracy, 24 items per seed:

| Seed | Full (6 labels) | Uniform (3) | Joint EWMA (3) |
| --- | ---: | ---: | ---: |
| 6207 | 23/24 | 23/24 | 23/24 |
| 6219 | 24/24 | 24/24 | 24/24 |
| 6251 | 18/24 | 17/24 | 17/24 |

Paired across three seeds, **Joint EWMA − Uniform = 0** percentage points in
final heldout accuracy. Full-feedback has **twice the logical reward-label
budget** and so is not a matched-budget superiority comparator. This experiment
does **not** show a real-world improvement in LLM task accuracy from adaptive
acquisition. An original Phase 6B reduction in a score-based design-risk
surrogate cannot be relabeled as an actual GRPO gradient-variance gain.

The custom Phase 6C objective is a leave-one-out Horvitz–Thompson-weighted
**GRPO-family** surrogate, not canonical TRL GRPOTrainer. The arithmetic
verifier is cheap and deterministic: purchased labels constitute a **logical**
budget, not demonstrated API cost savings.

## Archived Phase 6D evidence (frozen LoRA-gradient mechanism check)

`results/phase6d_gradient_v1/` contains the immutable experiment manifest,
precommitted task bank, group-risk CSV, summary JSON, and 144 per-group JSON
records. These records hold generated responses, binary gold rewards,
pre-query fixed-budget subset designs, actual LoRA-gradient Gram matrices,
three-dimensional score features, and exact design risks. The ZIP entries
with Windows backslashes were normalized to ordinary repository directories
without editing the JSON content.

Run `python scripts/reproduce_phase6d_archived.py` from the archive root.
It verifies original Phase 6C journal/manifest hashes, the Phase 6D task-bank
and group-record hashes, $G=6$, $B=3$, $\pi_i=0.5$, all 20 subset probabilities,
and recomputes both real-gradient and sketch risks. It checks every published
CSV entry and the reported per-seed stratum ratios. It intentionally does
not follow absolute Windows paths stored in the original manifest.

Among 96 checkpoint-30/60 groups, the risk-weighted reduction of the joint
design relative to uniform is **3.27% for true LoRA gradients**, against
**26.91% for the sketch**. Source-model and seed contrasts can have either
sign; the recorded 0-step negative control has zero design difference.
The signs of non-negligible true gains are 27 positive, nine negative, and
60 ties (including groups with zero baseline risk). This is exploratory
conditional risk, **not** a model-accuracy or optimizer-trajectory gain.

The archived true-gradient Gram values are independently checked for internal
consistency and exact HT risk, **not** re-derived by running Qwen autograd.
The original GPU-generated records remain unchanged. To run the original
Phase 6D `--stage report` command, the original `optimizer_states` files
must be restored; the new lightweight replay script needs only these archives.

## Distinguish preserved archives from generated data

- `src/`, `scripts/` (except added CPU replays), `tests/`, `docs/`:
  from the frozen Phase 1–6C source archive, overlaid with the separately
  supplied Phase 6D v1.6 code and tests. Historical draft manuscripts and
  internal project reports were excluded from this public research release.
- Phase 6B and Phase 6C result directories: losslessly copied from the
  user-provided light results ZIP, with Windows ZIP path separators normalized.
- Earlier Phase 1–5 `results/` and reference figure PNGs: supplied from the
  previously delivered project workspace, not from the two newly uploaded ZIPs.
- Phase 6D manifest, task bank, per-group records, summary and CSV: losslessly
  extracted from the completed 144-group user archive (no fabricated GPU data).
- `scripts/reproduce_archived_results.py`, this guide,
  `scripts/reproduce_phase6d_archived.py`, `reproduced_outputs/`, and
  `CHECKSUMS.sha256`: reviewer-facing additions, made from the archived data;
  no further experiments were run.

For audit traceability, **original run JSON and diagnostic manifests have not
been rewritten**. Some archived fields contain absolute paths to the original
Windows experiment workstation; the CPU replay tool intentionally resolves
data from the extracted repository root instead of relying on those paths.

## Additional conditions for full model-level reproduction

The omitted original `results/phase6c_cal2_seed*/arms/<arm>/optimizer_states/`
directories contain step-indexed `.pt` files with LoRA, optimizer and RNG
states. The full Phase 6C audit and GPU diagnostic evaluation expect these
states. To reproduce *all* original stored-weight evidence, bring back the
corresponding checkpoints and use the documented Phase 6C/diagnostics scripts
in a compatible CUDA/PyTorch/Hugging Face environment.

The base model is `Qwen/Qwen2.5-0.5B-Instruct`, recorded at `model_revision=main`.
Because this is a floating revision tag, the source archive does not by itself
guarantee future bit-exact model downloads. The repository has no embedded
credentials and no downloaded base-model weights.

## Archive verification

`CHECKSUMS.sha256` records SHA-256 values of included files (excluding itself).
On a system with `sha256sum`:

```text
sha256sum -c CHECKSUMS.sha256
```

On Windows, the self-contained Python archived-result checks above work without
the `sha256sum` command. Tests and figure scripts may create new files in
working directories; compare checksums before doing so if an immutable archive
baseline is needed.

**Paper-matching scope:** The companion manuscript includes the completed
Phase 6D real-gradient diagnostic and maps its table to the raw records in
Appendix B. It is not a proof of byte-identical Qwen training reproduction.
