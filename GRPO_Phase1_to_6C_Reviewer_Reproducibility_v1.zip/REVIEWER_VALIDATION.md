# Evidence audit for the Correlated GRPO paper (Phase 1--6D)

This archive updates the original Phase 1--6C reviewer release without changing
its name. It adds the complete Phase 6D frozen-checkpoint records and the
corresponding source, tests, and CPU-only exact-risk replay.

## Checked against the accompanying manuscript

* Phase 6C final held-out accuracy: uniform and joint-EWMA acquisition each
  attain 64/72 across the three original seed panels. The unchanged-accuracy
  result remains a negative downstream finding.
* Phase 6D: 144 saved group conditions (3 seeds x 2 source arms x 3
  checkpoints x 2 task families x 4 groups). Each fixed-size acquisition risk
  enumerates all 20 subsets of 3 from 6 candidates. All 144 group SHA-256
  records, original design marginals, and exact true-gradient/sketch risks are
  checked by `python scripts/reproduce_phase6d_archived.py`.
* On the 96 post-initial checkpoints, pooled risk reduction (uniform minus
  joint over uniform) is **26.909565% for the original score sketch** but only
  **3.265514% for saved real-LoRA autograd Gram geometry**. The real-gradient
  effects by checkpoint are -6.829279% (step 30), +21.314125% (step 60).
* The three seed-level real-gradient effects are +16.794955%, -22.464471%,
  and +10.697727%; 27 groups improve, nine worsen, 60 are numerical ties.

## Recommended local checks

```text
python -m pip install -e ".[figures]"
python -m unittest discover -s tests -q
python scripts/reproduce_archived_results.py --verify-only
python scripts/reproduce_phase6d_archived.py
sha256sum -c CHECKSUMS.sha256
```

Checksums cover all included payload files except the checksum index itself.
The real-gradient verification checks arithmetic and integrity **from
previously saved LoRA gradient Gram matrices**. It does not reproduce the
original GPU autograd calculations, model training trajectories, or inference
from the omitted optimizer checkpoints. Thus the package provides exact
archive-based computational verification, not a fresh model-level replication.

The separate `CORR_GRPO_LaTeX.zip` compiles the PDF with `latexmk -pdf
CORR_GRPO.tex`; the code archive need not contain the manuscript source.
