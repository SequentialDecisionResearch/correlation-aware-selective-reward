# CORR_GRPO manuscript source

The scientific manuscript is `CORR_GRPO.tex`. Its two required inputs are
`references.bib` and the three PNGs in `figures/`.

Compile from this directory (TeX Live, MiKTeX or equivalent):

```
latexmk -pdf -interaction=nonstopmode -halt-on-error CORR_GRPO.tex
```

Or manually:

```
pdflatex -interaction=nonstopmode -halt-on-error CORR_GRPO.tex
bibtex CORR_GRPO
pdflatex -interaction=nonstopmode -halt-on-error CORR_GRPO.tex
pdflatex -interaction=nonstopmode -halt-on-error CORR_GRPO.tex
```

The PDF delivered with this source package was built from these files.

Source of values: the separately supplied `GRPO_Phase1_to_6C_Reviewer_Reproducibility_v1.zip`
(retained filename, now including Phase 6D) contains the frozen numerical
JSON/CSV outputs, 144 SHA-256-checked Phase 6D group records, tests, scripts,
and plot inputs. Appendix B maps claims to specific files and scripts. PNG
figures in this LaTeX archive are precomputed so compilation requires neither
Python nor a GPU.

The paper includes Phase 6D frozen-checkpoint real-gradient risks and the
completed negative findings from Phase 6C. The bibliography retains the seven
previously checked scientific references. The repository URL is
`https://github.com/SequentialDecisionResearch/correlation-aware-selective-reward`.

The lightweight results package does not include full GPU optimizer or LoRA
checkpoints. Its CPU-only Phase 6D auditor recomputes exact risks from saved
Gram matrices and validates archived records; it does not rerun autograd.
The paper does not claim byte-identical GPU training reproduction.
